// End-to-end check of the web app in real Chromium with a fake Supabase: Google sign-in, the legal pages, and (v5) the lesson engine, the
// migration of v3/v4 progress and the offline shell (run it in Claude's sandbox: Playwright is global there).
// Usage: node web/e2e/auth.e2e.mjs <dist-dir> [port]
import { createRequire } from 'node:module';
import { createServer } from 'node:http';
import { readFileSync, existsSync } from 'node:fs';
import { extname, join } from 'node:path';
const require = createRequire('/home/claude/.npm-global/lib/node_modules/');
const { chromium } = require('playwright');

const dir = process.argv[2] ?? 'dist-site';
const port = Number(process.argv[3] ?? 8771);
const SB = 'https://yvszergcvjnzpogubqex.supabase.co';
const types = { '.html': 'text/html', '.js': 'text/javascript', '.png': 'image/png', '.webmanifest': 'application/manifest+json' };
const server = createServer((req, res) => {
  const path = decodeURIComponent(new URL(req.url, 'http://x').pathname);
  // like GitHub Pages: /privacy answers 301 -> /privacy/ when privacy/index.html exists
  if (path !== '/' && !path.endsWith('/') && !extname(path) && existsSync(join(dir, path, 'index.html'))) { res.writeHead(301, { location: path + '/' }); return res.end(); }
  const p = join(dir, path.replace(/\/$/, '/index.html'));
  if (!existsSync(p)) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { 'content-type': types[extname(p)] ?? 'application/octet-stream' }); res.end(readFileSync(p));
}).listen(port);
const ORIGIN = `http://localhost:${port}`;

let fails = 0;
const check = (name, ok, extra = '') => { console.log(ok ? 'PASS' : 'FAIL', name, extra); if (!ok) fails++; };
const cors = { 'access-control-allow-origin': '*', 'access-control-allow-headers': '*', 'access-control-allow-methods': '*' };
const calls = [];
async function fakeSupabase(ctx, { user = { id: 'u1', email: 'sara@example.com', user_metadata: { full_name: 'Sara A' } }, authorizeTo = null, refreshStatus = 200 } = {}) {
  await ctx.route(SB + '/**', async (route) => {
    const r = route.request(), u = new URL(r.url());
    calls.push(r.method() + ' ' + u.pathname + u.search);
    if (r.method() === 'OPTIONS') return route.fulfill({ status: 204, headers: cors });
    if (u.pathname === '/auth/v1/authorize') {
      const back = u.searchParams.get('redirect_to');
      return route.fulfill({ status: 302, headers: { location: authorizeTo ?? back + '#access_token=AT1&refresh_token=RT1&expires_in=3600&token_type=bearer' } });
    }
    if (u.pathname === '/auth/v1/user') return route.fulfill({ status: 200, headers: { ...cors, 'content-type': 'application/json' }, body: JSON.stringify(user) });
    if (u.pathname === '/auth/v1/token') return route.fulfill({ status: refreshStatus, headers: { ...cors, 'content-type': 'application/json' }, body: JSON.stringify(refreshStatus === 200 ? { access_token: 'AT2', refresh_token: 'RT2', expires_in: 3600 } : { error: 'invalid_grant' }) });
    if (u.pathname === '/auth/v1/logout') return route.fulfill({ status: 204, headers: cors });
    return route.fulfill({ status: 200, headers: { ...cors, 'content-range': '0-0/1' }, body: '[]' });
  });
}
const browser = await chromium.launch();
const newCtx = () => browser.newContext({ viewport: { width: 390, height: 844 }, locale: 'ar', deviceScaleFactor: 2, isMobile: true, hasTouch: true });
const watch = (page) => { const errs = []; page.on('pageerror', (e) => errs.push('pageerror: ' + e.message)); page.on('console', (m) => { if (m.type() === 'error' && !/fonts\.(googleapis|gstatic)|ERR_|Failed to load resource/.test(m.text())) errs.push('console: ' + m.text()); }); return errs; };
const openProfile = async (page) => { await page.click('nav button[data-t=me]'); await page.waitForTimeout(150); };

// 1) signed out: the profile tab offers Google sign-in
{
  const ctx = await newCtx(); await fakeSupabase(ctx); const page = await ctx.newPage(); const errs = watch(page);
  await page.goto(ORIGIN + '/'); await page.waitForSelector('#app *');
  await openProfile(page);
  check('signed out: login button shown', (await page.locator('button.open', { hasText: 'Google' }).count()) === 1);
  await page.screenshot({ path: '/tmp/e2e-signedout.png' });

  // 2) press login -> fake Google/Supabase -> back with tokens in the hash -> profile tab shows the account
  await page.click('button.open >> text=Google');
  await page.waitForFunction(() => document.body.innerText.includes('Sara A'), null, { timeout: 8000 });
  check('after the redirect: name and email shown', (await page.innerText('#app')).includes('sara@example.com'));
  check('after sign-in the profile tab is open', (await page.locator('nav button.on').getAttribute('data-t')) === 'me');
  check('tokens removed from the URL', !(await page.evaluate(() => location.hash)) && !page.url().includes('access_token'));
  const stored = await page.evaluate(() => JSON.parse(localStorage.getItem('lingotrace-auth-v1')));
  check('session stored (access + refresh)', stored.access_token === 'AT1' && stored.refresh_token === 'RT1');
  await page.screenshot({ path: '/tmp/e2e-signedin.png' });

  // 3) reload: still signed in, no login button
  await page.reload(); await page.waitForSelector('#app *'); await openProfile(page);
  check('reload keeps the session', (await page.innerText('#app')).includes('Sara A'));

  // 4) sign out
  await page.click('button >> text=تسجيل الخروج');
  await page.waitForFunction(() => !!document.querySelector('button.open'));
  check('sign out: back to the login button + storage cleared', (await page.evaluate(() => localStorage.getItem('lingotrace-auth-v1'))) === null);
  check('logout hit the server with scope=local', calls.some((c) => c.startsWith('POST /auth/v1/logout?scope=local')));
  check('no JS errors (flow 1-4)', errs.length === 0, errs.join(' | '));
  await ctx.close();
}
// 5) an expired stored session is refreshed on start
{
  const ctx = await newCtx(); await fakeSupabase(ctx); const page = await ctx.newPage(); const errs = watch(page);
  await page.addInitScript(() => { if (!localStorage.getItem('lingotrace-auth-v1')) localStorage.setItem('lingotrace-auth-v1', JSON.stringify({ access_token: 'OLD', refresh_token: 'RT0', expires_at: 1, user: { id: 'u1', email: 'cached@example.com', name: 'Cached', avatar: null } })); });
  calls.length = 0;
  await page.goto(ORIGIN + '/'); await page.waitForSelector('#app *'); await page.waitForTimeout(500); await openProfile(page);
  check('expired session: refresh then user reload', calls.some((c) => c.includes('/auth/v1/token?grant_type=refresh_token')) && (await page.innerText('#app')).includes('Sara A'));
  check('new tokens saved', (await page.evaluate(() => JSON.parse(localStorage.getItem('lingotrace-auth-v1')).access_token)) === 'AT2');
  check('no JS errors (refresh)', errs.length === 0, errs.join(' | '));
  await ctx.close();
}
// 6) refresh rejected -> signed out with a message
{
  const ctx = await newCtx(); await fakeSupabase(ctx, { refreshStatus: 400 }); const page = await ctx.newPage();
  await page.addInitScript(() => { localStorage.setItem('lingotrace-auth-v1', JSON.stringify({ access_token: 'OLD', refresh_token: 'BAD', expires_at: 1, user: null })); });
  await page.goto(ORIGIN + '/'); await page.waitForSelector('#app *'); await page.waitForTimeout(500); await openProfile(page);
  const txt = await page.innerText('#app');
  check('rejected refresh: login button + message', txt.includes('سجّل الدخول من جديد') && (await page.locator('button.open').count()) === 1);
  await ctx.close();
}
// 7) cancelled Google sign-in: error shown, app fine
{
  const ctx = await newCtx(); await fakeSupabase(ctx, { authorizeTo: ORIGIN + '/#error=access_denied&error_description=Access+denied' }); const page = await ctx.newPage(); const errs = watch(page);
  await page.goto(ORIGIN + '/'); await page.waitForSelector('#app *'); await openProfile(page);
  await page.click('button.open >> text=Google');
  await page.waitForFunction(() => document.body.innerText.includes('Access denied'), null, { timeout: 8000 });
  check('cancelled login: message shown on the profile tab', (await page.locator('nav button.on').getAttribute('data-t')) === 'me');
  check('no JS errors (cancel)', errs.length === 0, errs.join(' | '));
  await ctx.close();
}
// 8) offline with a stored session: profile still shows the cached account, lessons still open
{
  const ctx = await newCtx(); await fakeSupabase(ctx); const page = await ctx.newPage(); const errs = watch(page);
  await page.addInitScript(() => { if (!localStorage.getItem('lingotrace-auth-v1')) localStorage.setItem('lingotrace-auth-v1', JSON.stringify({ access_token: 'AT', refresh_token: 'RT', expires_at: 9999999999, user: { id: 'u1', email: 'cached@example.com', name: 'Cached', avatar: null } })); });
  await page.goto(ORIGIN + '/'); await page.waitForSelector('#app *'); await page.evaluate(() => navigator.serviceWorker.ready); await page.reload(); await page.waitForTimeout(400);
  await ctx.setOffline(true);
  await page.reload({ waitUntil: 'domcontentloaded' }); await page.waitForSelector('#app *'); await page.waitForTimeout(400); await openProfile(page);
  // the account was refreshed from the (fake) server on the earlier online load, so offline shows that last known name
  check('offline: last known account shown, no login button', (await page.innerText('#app')).includes('Sara A') && (await page.locator('button.open').count()) === 0);
  await page.click('nav button[data-t=home]'); await page.click('.open'); await page.waitForTimeout(300);
  check('offline: lesson map opens', (await page.innerText('#app')).includes('ابدأ'));
  check('offline: a lesson starts from the cached engine', await page.evaluate(() => { try { return LT.start(1).es.queue.length === 20; } catch (e) { return false; } }));
  check('no JS errors (offline)', errs.length === 0, errs.join(' | '));
  await ctx.close();
}
// 9) regression: the lesson itself still works (type the first word right, see progress move)
{
  const ctx = await newCtx(); await fakeSupabase(ctx); const page = await ctx.newPage(); const errs = watch(page);
  await page.goto(ORIGIN + '/'); await page.waitForSelector('#app *');
  await page.click('.open'); await page.waitForSelector('.nd.cu'); await page.click('.nd.cu'); await page.waitForSelector('#in');
  const w1 = await page.evaluate(() => LT.cur(S).word.wordText);
  await page.fill('#in', w1); await page.press('#in', 'Enter');
  await page.waitForFunction(() => LT.cur(S).step === 'sentence' || LT.progress(S).done >= 1, null, { timeout: 8000 });
  check('lesson: correct word accepted and the item advances', await page.evaluate(() => LT.cur(S).step === 'sentence' || LT.progress(S).done >= 1));
  check('no JS errors (lesson)', errs.length === 0, errs.join(' | '));
  await ctx.close();
}
// 10) legal pages: linked from the profile tab, reachable at the exact URLs registered in Google Cloud, load nothing external, link back
{
  const ctx = await newCtx(); await fakeSupabase(ctx); const page = await ctx.newPage(); const errs = watch(page);
  const external = [];
  page.on('request', (r) => { if (/^\/(privacy|terms)\//.test(new URL(page.url()).pathname) && !r.url().startsWith(ORIGIN)) external.push(r.url()); });
  await page.goto(ORIGIN + '/'); await page.waitForSelector('#app *'); await openProfile(page);
  check('signed out: terms and privacy links shown', (await page.locator('#app a[href="terms/"]').count()) === 1 && (await page.locator('#app a[href="privacy/"]').count()) === 1);
  await page.goto(ORIGIN + '/privacy'); // exactly what was typed in Google Cloud
  check('/privacy redirects to /privacy/ and shows the policy', new URL(page.url()).pathname === '/privacy/' && (await page.locator('h1').innerText()) === 'سياسة الخصوصية');
  check('privacy page shows the contact email', (await page.innerText('main')).includes('rasd0594474369@gmail.com'));
  await page.screenshot({ path: '/tmp/e2e-privacy.png' });
  await page.click('header a:has-text("العودة إلى التطبيق")'); await page.waitForSelector('#app *');
  check('back link returns to the app', new URL(page.url()).pathname === '/');
  await openProfile(page); await page.click('#app a[href="terms/"]'); await page.waitForSelector('h1');
  check('terms link opens /terms/', new URL(page.url()).pathname === '/terms/' && (await page.locator('h1').innerText()) === 'شروط الاستخدام');
  await page.screenshot({ path: '/tmp/e2e-terms.png' });
  await page.click('footer a:has-text("سياسة الخصوصية")'); await page.waitForSelector('h1');
  check('terms footer links to the privacy page', new URL(page.url()).pathname === '/privacy/');
  await page.goto(ORIGIN + '/terms'); check('/terms redirects to /terms/', new URL(page.url()).pathname === '/terms/');
  check('legal pages requested nothing from other origins', external.length === 0, external.join(' '));
  check('no JS errors (legal)', errs.length === 0, errs.join(' | '));
  await ctx.close();
}
// 11) v5 migration in the real browser: v3/v4 progress ('spelling-v2') shows up unchanged, is copied to the new key once, and a reset cannot bring it back
{
  const tz = 'Asia/Riyadh';
  const today = new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date());
  const LEGACY = { xp: 130, streak: 3, best: 5, day: today, c: { 1: 1, 2: 1 }, rot: { the: { weight: 2, status: 'active', due: 3, last: '2026-11-10T08:00:00.000Z' }, be: { weight: 0, status: 'mastered', due: null, last: '2026-11-09T08:00:00.000Z' }, notaword: { weight: 1, status: 'active', due: 2, last: '2026-11-08T08:00:00.000Z' } }, loc: 'en-GB', unlock: false, tr: false };
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, locale: 'ar', timezoneId: tz, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
  await fakeSupabase(ctx);
  await ctx.addInitScript((legacy) => { try { if (!localStorage.getItem('__seeded')) { localStorage.setItem('spelling-v2', JSON.stringify(legacy)); localStorage.setItem('__seeded', '1'); } } catch (e) { /* ignore */ } }, LEGACY);
  const page = await ctx.newPage(); const errs = watch(page);
  await page.goto(ORIGIN + '/'); await page.waitForSelector('#app *'); await openProfile(page);
  const text = await page.innerText('#app');
  check('migration: XP, completed lessons and the mistake list are carried over', text.includes('130') && text.includes('2 / 140') && text.includes('the · وزن 2 · درس 3') && !text.includes('notaword'), text.replace(/\s+/g, ' ').slice(0, 160));
  const saved = await page.evaluate(() => ({ now: JSON.parse(localStorage.getItem('lingotrace-progress-v1')), old: localStorage.getItem('spelling-v2'), notr: document.body.classList.contains('notr'), streak: LT.streak() }));
  check('migration: new key written, old key untouched, preferences and streak kept', saved.now.v === 1 && saved.now.xp === 130 && Object.keys(saved.now.completed).join() === '1,2' && saved.now.prefs.loc === 'en-GB' && saved.old === JSON.stringify(LEGACY) && saved.notr && saved.streak === 3);
  await page.screenshot({ path: '/tmp/e2e-migrated.png' });
  await page.reload(); await page.waitForSelector('#app *'); await openProfile(page);
  check('migration runs once: after a reload the state is the same', (await page.evaluate(() => P.xp)) === 130 && (await page.evaluate(() => LT.migrated)) === false);
  await page.selectOption('select', 'en-US'); await page.check('input[type=checkbox]');
  const prefs = await page.evaluate(() => ({ p: P.prefs, saved: JSON.parse(localStorage.getItem('lingotrace-progress-v1')).prefs }));
  check('the voice select and the unlock switch update and save the preferences', prefs.p.loc === 'en-US' && prefs.p.unlock === true && prefs.saved.loc === 'en-US' && prefs.saved.unlock === true, JSON.stringify(prefs));
  await page.click('button:has-text("إعادة ضبط التجربة")'); await page.waitForTimeout(150);
  check('reset: XP back to 0 and the old key removed', (await page.evaluate(() => P.xp)) === 0 && (await page.evaluate(() => localStorage.getItem('spelling-v2'))) === null);
  await page.reload(); await page.waitForSelector('#app *');
  check('after a reset and a reload the old progress does not come back', (await page.evaluate(() => P.xp)) === 0 && (await page.evaluate(() => Object.keys(P.completed).length)) === 0);
  check('no JS errors (migration)', errs.length === 0, errs.join(' | '));
  await ctx.close();
}
// 12) a whole lesson on the bundled engine in Chromium: 250 XP, saved, survives a reload, replay pays nothing, a double failure enters the mistake list and is injected later
{
  const ctx = await newCtx(); await fakeSupabase(ctx); const page = await ctx.newPage(); const errs = watch(page);
  await page.goto(ORIGIN + '/'); await page.waitForSelector('#app *');
  const first = await page.evaluate(() => {
    S = LT.start(1); const mode = S.mode, items = S.es.queue.length;
    for (let g = 0; !LT.finished(S) && g < 500; g++) LT.submit(S, LT.cur(S).text);
    LT.finish(S); S = null;
    return { mode, items, xp: P.xp, completed: Object.keys(P.completed), streak: LT.streak(), next: LT.nextLesson() };
  });
  check('lesson 1 on the engine: 20 words, 250 XP, completed, streak 1, next is lesson 2', first.mode === 'first_run' && first.items === 20 && first.xp === 250 && first.completed.join() === '1' && first.streak === 1 && first.next === 2, JSON.stringify(first));
  const saved = await page.evaluate(() => JSON.parse(localStorage.getItem('lingotrace-progress-v1')));
  check('progress is saved under the new key with a session chain id', saved.v === 1 && saved.xp === 250 && saved.completed['1'] === true && saved.streak.streakCount === 1 && /^[0-9a-f-]{36}$/.test(saved.lastSessionId));
  await page.reload(); await page.waitForSelector('#app *'); await openProfile(page);
  check('after a reload the XP and the lesson are still there', (await page.innerText('#app')).includes('1 / 140') && (await page.evaluate(() => P.xp)) === 250);
  const replay = await page.evaluate(() => { S = LT.start(1); const mode = S.mode; while (!LT.finished(S)) LT.submit(S, LT.cur(S).text); LT.finish(S); S = null; return { mode, xp: P.xp }; });
  check('replay: no extra XP', replay.mode === 'replay' && replay.xp === 250);
  const fail = await page.evaluate(() => {
    const failed = []; S = LT.start(2);
    while (!LT.finished(S)) {
      const c = LT.cur(S); let t = c.text;
      if (c.step === 'word' && !c.rev && !failed.length) { failed.push(c.word.wordId); t = 'zzzzzz'; } else if (c.rev && failed.includes(c.word.wordId)) t = 'zzzzzz';
      LT.submit(S, t);
    }
    LT.finish(S); S = null;
    return { rotation: LT.rotation().map((r) => [r.text, r.weight, r.due]) };
  });
  check('a word failed twice enters the mistake list (weight 1, due lesson 4)', fail.rotation.length === 1 && fail.rotation[0][1] === 1 && fail.rotation[0][2] === 4, JSON.stringify(fail));
  await page.evaluate(() => go('home')); await openProfile(page);
  check('the profile lists it', (await page.innerText('#app')).includes(fail.rotation[0][0] + ' · وزن 1 · درس 4'));
  const at4 = await page.evaluate(() => { S = LT.start(4); const pos = S.es.queue.findIndex((q) => q.source === 'injected'); while (LT.cur(S).src !== 'injected') LT.submit(S, LT.cur(S).text); V = 'lesson'; show = false; render(); return { pos, len: S.es.queue.length }; });
  check('lesson 4 injects the word, labels it on screen, and it is neither first nor last', at4.pos >= 1 && (await page.locator('.sm2', { hasText: 'من أخطائك السابقة' }).count()) === 1, JSON.stringify(at4));
  await page.screenshot({ path: '/tmp/e2e-injected.png' });
  check('no JS errors (engine lesson)', errs.length === 0, errs.join(' | '));
  await ctx.close();
}
// 13) answer shown = peek: the lower XP tier, and the answer that stays visible on the next step still counts as a peek
{
  const ctx = await newCtx(); await fakeSupabase(ctx); const page = await ctx.newPage(); const errs = watch(page);
  await page.goto(ORIGIN + '/'); await page.waitForSelector('#app *');
  await page.click('.open'); await page.waitForSelector('.nd.cu'); await page.click('.nd.cu'); await page.waitForSelector('#in');
  const w1 = await page.evaluate(() => LT.cur(S).word.wordText);
  await page.click('button[onclick="toggle()"]');
  check('the eye button shows the answer and records the peek', (await page.locator('.ans').count()) === 1 && (await page.evaluate(() => S.es.peeked)) === true);
  await page.fill('#in', w1); await page.press('#in', 'Enter');
  await page.waitForFunction(() => !busy && LT.cur(S).step === 'sentence', null, { timeout: 8000 });
  check('the answer is still shown on the sentence step, and counts as a peek there too', (await page.locator('.ans').count()) === 1 && (await page.evaluate(() => S.es.peeked)) === true);
  const s1 = await page.evaluate(() => LT.cur(S).text);
  await page.fill('#in', s1); await page.press('#in', 'Enter');
  await page.waitForFunction(() => !busy && LT.progress(S).done >= 1, null, { timeout: 20000 });
  check('a peeked first try pays the lower tier (5 XP, not 10)', await page.evaluate(() => S.es.xp.recovered === 5 && S.es.xp.firstTry === 0));
  check('no JS errors (peek)', errs.length === 0, errs.join(' | '));
  await ctx.close();
}
// 14) closing the app in the middle of a lesson counts nothing and loses nothing
{
  const ctx = await newCtx(); await fakeSupabase(ctx); const page = await ctx.newPage(); const errs = watch(page);
  await page.goto(ORIGIN + '/'); await page.waitForSelector('#app *');
  await page.evaluate(() => { S = LT.start(1); for (let i = 0; i < 6; i++) LT.submit(S, LT.cur(S).text); });
  await page.reload(); await page.waitForSelector('#app *');
  const st = await page.evaluate(() => ({ xp: P.xp, completed: Object.keys(P.completed).length, session: S }));
  check('reload mid-lesson: nothing counted, back on the map', st.xp === 0 && st.completed === 0 && st.session === null);
  const again = await page.evaluate(() => { const s = LT.start(1); return [s.mode, LT.progress(s).total]; });
  check('the lesson can be started again from scratch', again[0] === 'first_run' && again[1] === 20);
  check('no JS errors (restart)', errs.length === 0, errs.join(' | '));
  await ctx.close();
}
// 15) the result screen after a lesson (what a user sees when a lesson ends), a replay's result, and the leaderboard tab still renders
{
  const ctx = await newCtx(); await fakeSupabase(ctx); const page = await ctx.newPage(); const errs = watch(page);
  await page.goto(ORIGIN + '/'); await page.waitForSelector('#app *');
  const info = await page.evaluate(() => {
    S = LT.start(1); let failedWord = null;
    while (!LT.finished(S)) { const c = LT.cur(S); let t = c.text; if (c.step === 'word' && !c.rev && !failedWord) { failedWord = c.word.wordText; t = 'zzzzzz'; } LT.submit(S, t); }
    LT.finish(S); V = 'lesson'; show = false; render();
    const x = S.es.xp; return { failedWord, total: x.firstTry + x.recovered + x.lessonBonus, x };
  });
  const text = await page.innerText('#app');
  check('result screen: lesson title, XP total and breakdown', text.includes('اكتمل الدرس 1') && text.includes(String(info.total)) && text.includes(`من أول محاولة ${info.x.firstTry}`) && text.includes(`مراجعات ${info.x.recovered}`) && text.includes(`مكافأة ${info.x.lessonBonus}`), text.replace(/\s+/g, ' ').slice(0, 220));
  check('result screen lists the word that needed a review', text.includes(info.failedWord), info.failedWord);
  await page.screenshot({ path: '/tmp/e2e-result.png' });
  const rp = await page.evaluate(() => { S = LT.start(1); while (!LT.finished(S)) LT.submit(S, LT.cur(S).text); LT.finish(S); V = 'lesson'; render(); return P.xp; });
  check('replay result says no points and XP is unchanged', (await page.innerText('#app')).includes('إعادة — بلا نقاط') && rp === info.total);
  await page.evaluate(() => go('home')); await page.click('nav button[data-t=board]'); await page.waitForTimeout(150);
  check('leaderboard tab renders and shows the user row', (await page.innerText('#app')).includes('أنت'));
  check('no JS errors (result screens)', errs.length === 0, errs.join(' | '));
  await ctx.close();
}
await browser.close(); server.close();
console.log(fails === 0 ? 'ALL PASS' : fails + ' FAILED');
process.exit(fails ? 1 : 0);
