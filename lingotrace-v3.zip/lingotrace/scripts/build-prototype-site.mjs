// Builds dist-site/ from the single-file prototype so GitHub Pages serves the real app:
//   index.html = prototype/spelling-trainer.html + PWA hooks (manifest, icons, service worker)
//   check.html = the connection check page (site-placeholder/index.html)
// Only Node built-ins are used. Usage: node scripts/build-prototype-site.mjs [output-dir]
import { readFileSync, writeFileSync, mkdirSync, copyFileSync, rmSync } from 'node:fs';

const out = process.argv[2] ?? 'dist-site';
const app = readFileSync('prototype/spelling-trainer.html', 'utf8');
if (!app.includes('</title>') || !app.includes('</body>')) throw new Error('prototype has no </title> or </body>');

const head = [
  '<meta name="theme-color" content="#0d1220">',
  '<link rel="manifest" href="manifest.webmanifest">',
  '<link rel="icon" type="image/png" href="icon-192.png">',
  '<link rel="apple-touch-icon" href="apple-touch-icon.png">',
].join('\n');
const sw = "<script>if('serviceWorker' in navigator){addEventListener('load',function(){navigator.serviceWorker.register('sw.js').catch(function(){})})}</script>";

let html = app.replace('</title>', '</title>\n' + head);
const i = html.lastIndexOf('</body>');
html = html.slice(0, i) + sw + '\n' + html.slice(i);

rmSync(out, { recursive: true, force: true });
mkdirSync(out, { recursive: true });
writeFileSync(`${out}/index.html`, html);
copyFileSync('site-placeholder/index.html', `${out}/check.html`);
for (const f of ['manifest.webmanifest', 'sw.js', 'icon-192.png', 'icon-512.png', 'icon-maskable-512.png', 'apple-touch-icon.png']) {
  copyFileSync(`site-placeholder/${f}`, `${out}/${f}`);
}
console.log(`built ${out}: index.html ${html.length} bytes (prototype + PWA hooks), check.html, manifest, sw.js, icons`);
