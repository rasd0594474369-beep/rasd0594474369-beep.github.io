#!/usr/bin/env bash
# LingoTrace CI entry point. Called from the project root by .github/workflows/build.yml (a copy lives in docs/github/build.yml).
# Produces: ci-out/*.log, a markdown report in $GITHUB_STEP_SUMMARY, and dist-site/ plus "deploy=true" in $GITHUB_OUTPUT when there is a site to publish.
# Exit code: 0 when the tests pass and (once the app exists) the web build works; 1 otherwise.
set -uo pipefail

OUT=ci-out
rm -rf "$OUT" dist-site
mkdir -p "$OUT"
SUMMARY="${GITHUB_STEP_SUMMARY:-$OUT/summary.md}"
RESULT="${GITHUB_OUTPUT:-$OUT/outputs.txt}"
: >"$OUT/rows.md"
: >"$OUT/failures.md"
declare -A OK

# run NAME COMMAND...  : logs to ci-out/NAME.log, records a table row, and keeps going when the command fails
run() {
  local name="$1"; shift
  local t0=$SECONDS rc
  echo "::group::$name"
  "$@" >"$OUT/$name.log" 2>&1
  rc=$?
  tail -n 15 "$OUT/$name.log"
  echo "::endgroup::"
  local secs=$((SECONDS - t0))
  if [ "$rc" -eq 0 ]; then
    OK[$name]=1
    echo "| $name | ✅ | ${secs}s |" >>"$OUT/rows.md"
  else
    echo "| $name | ❌ exit $rc | ${secs}s |" >>"$OUT/rows.md"
    echo "::warning title=Step failed::$name"
    {
      echo
      echo "### ❌ $name (last 40 lines)"
      echo '```'
      tail -n 40 "$OUT/$name.log" | cut -c1-240
      echo '```'
    } >>"$OUT/failures.md"
  fi
  return "$rc"
}

KIT=$(cat VERSION 2>/dev/null || echo "unknown")
echo "kit $KIT | node $(node -v), npm $(npm -v)"

# 1) engine, content, functions and SQL-twin tests (they need no install)
TEST_CMD="${CI_TEST_CMD:-node --test supabase/tests/twin/*.test.ts supabase/tests/functions/*.test.ts packages/content/test/*.test.ts packages/engine/test/*.test.ts}"
run tests bash -c "$TEST_CMD"
TESTS=$(grep -E '^(# |ℹ )(tests|pass|fail) ' "$OUT/tests.log" | sed -E 's/^(# |ℹ )//' | tr '\n' ' ')

# 2) the app, once apps/mobile exists: install, align the Expo versions, typecheck, export the web build
HAS_APP=0
if [ -f apps/mobile/package.json ]; then
  HAS_APP=1
  run install bash -c 'npm install --no-audit --no-fund --legacy-peer-deps'
  if [ "${OK[install]:-0}" = 1 ]; then
    run expo-fix bash -c 'cd apps/mobile && npx --yes expo install --fix'
    run typecheck bash -c 'cd apps/mobile && npx tsc --noEmit'
    run web-build bash -c 'cd apps/mobile && npx expo export --platform web --output-dir ../../dist-site'
  fi
fi

# 3) which site do we publish? (the placeholder page only while the app is not in the zip yet)
SITE_KIND=none
if [ "$HAS_APP" = 1 ]; then
  if [ "${OK[web-build]:-0}" = 1 ] && [ -f dist-site/index.html ]; then SITE_KIND=app; fi
elif [ -f prototype/spelling-trainer.html ]; then
  run site node scripts/build-prototype-site.mjs dist-site
  if [ "${OK[site]:-0}" = 1 ] && [ -f dist-site/index.html ]; then SITE_KIND=prototype; fi
elif [ -d site-placeholder ]; then
  cp -r site-placeholder dist-site && SITE_KIND=placeholder
fi

PASS=0
if [ "${OK[tests]:-0}" = 1 ] && [ "$SITE_KIND" != none ]; then PASS=1; fi
if [ "$PASS" = 1 ]; then echo "deploy=true" >>"$RESULT"; else echo "deploy=false" >>"$RESULT"; fi

{
  echo "## LingoTrace build"
  echo
  echo "Kit: $KIT"
  echo
  if [ -n "$TESTS" ]; then echo "Tests: $TESTS"; echo; fi
  echo "| step | result | time |"
  echo "|---|---|---|"
  cat "$OUT/rows.md"
  echo
  case "$SITE_KIND" in
    app) echo "Site: built from apps/mobile" ;;
    prototype) echo "Site: the LingoTrace app (single-file prototype + PWA); connection check at /check.html" ;;
    placeholder) echo "Site: placeholder page (the app is not in the zip yet)" ;;
    *) echo "Site: none" ;;
  esac
  if [ "$PASS" = 1 ]; then echo "Verdict: ✅ deploying"; else echo "Verdict: ❌ nothing deployed"; fi
  cat "$OUT/failures.md"
  if [ "$HAS_APP" = 1 ] && [ -f apps/mobile/package.json ]; then
    echo
    echo "<details><summary>apps/mobile dependencies after expo install --fix</summary>"
    echo
    echo '```json'
    node -e 'const p=require("./apps/mobile/package.json");console.log(JSON.stringify({dependencies:p.dependencies,devDependencies:p.devDependencies},null,1))' 2>&1
    echo '```'
    echo "</details>"
  fi
} >>"$SUMMARY"

if [ -z "${GITHUB_STEP_SUMMARY:-}" ]; then cat "$SUMMARY"; fi
[ "$PASS" = 1 ]
