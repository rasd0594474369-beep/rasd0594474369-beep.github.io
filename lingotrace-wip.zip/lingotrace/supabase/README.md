# supabase/

The database, auth configuration and Edge Functions of LingoTrace.

```
config.toml                      Supabase CLI config: Google + Apple only, closed Data API surface, JWT-checked functions
migrations/                      applied in order; the grants migration must stay after every migration that creates objects
  ..0100_core_schema             tables (content, users, progress, SRS, misspelled_words, sessions, XP ledger) + the deletion cascade
  ..0200_functions_triggers      updated_at, XP ledger -> total_xp, time zone check, profile created at sign-up
  ..0300_leaderboard             get_leaderboard() and get_my_rank(): all / week / month
  ..0400_rls_policies            row level security on every table
  ..0500_account_deletion        v_account_deletion_gaps: proves nothing personal survives a deletion
  ..0600_grants_lockdown         closed by default, then exactly what the app needs
  ..0700_internal_tables_deny    restrictive deny-all on lesson_sessions, session_attempts, xp_events
  20261022000100_session_chain   lesson_sessions.parent_session_id: each user's sessions form one line (offline FIFO). Applied 2026-10-25
functions/                       Edge Functions commit-session and delete-account + shared code (see functions/README.md)
seed/                            the content (see seed/README.md)
tests/twin/                      Node tests: the schema on a SQLite twin + static security guards + guards for the SQL scripts (run anywhere)
tests/functions/                 Node tests for the Edge Functions (handlers end to end on the twin, Apple, shared modules, static checks)
tests/database/                  SQL scripts for a REAL PostgreSQL, each in a transaction that is rolled back
```

## Security model in one paragraph

Clients (the `anon` and `authenticated` roles) can read the public content and **their own** profile, progress,
SRS state and misspellings, and edit four profile columns (`display_name`, `tts_locale`, `time_zone`,
`show_on_leaderboard`). They cannot write XP, streaks, progress or sessions: those are written only by the
`commit-session` Edge Function, which replays the typed answers with the shared engine and connects directly as the
owner. Each user's sessions form one chain (a unique root per user, one child per session, enforced by two unique partial
indexes), so lessons played offline are recorded in the order they were played. The leaderboard functions are the only SECURITY DEFINER code callable by clients; they return a display name,
a score and a rank, only for people who opted in.

## Run the tests

```bash
node --test supabase/tests/twin/*.test.ts supabase/tests/functions/*.test.ts   # anywhere, no database needed (Node 22.18+)
node scripts/sync-engine.ts --check            # the engine copy inside functions/_shared is current
node scripts/gen-pgrepo-contract.ts --check    # 005 below is current (regenerate without --check after changing PgRepo)
cd supabase && tsc -p tsconfig.json            # strict types for the functions and their tests (needs typescript + @types/node)
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f supabase/tests/database/001_signup_triggers_constraints.sql
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f supabase/tests/database/002_rls_leaderboard_account_deletion.sql
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f supabase/tests/database/004_content_integrity.sql   # after the seed
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f supabase/tests/database/005_pgrepo_contract.sql      # after migration 8: generated, replays PgRepo's real statements
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f supabase/tests/database/006_session_chain.sql          # after migration 8: the chain constraints and account deletion
```
`003_leaderboard_performance.sql` builds 100,000 users inside a transaction it rolls back: never on a database with real users.

Last verified on a Supabase project (PostgreSQL 17.11, free plan): 001 23/23, 002 22/22, the restrictive deny, the
performance script, and the Supabase security advisor. On 2026-10-25, after migration 8 was applied to the project: **006 15 of 15 and 005 79 of 79**
(the project had been paused by the free plan and was restored first; the security advisor showed only the two accepted notes).

## Accepted advisor notes (by design)

- **Security, `authenticated_security_definer_function_executable`** on `get_leaderboard` and `get_my_rank`: they must
  read other people's rows to rank them, and expose nothing but name, score and rank.
- **Performance, unindexed foreign keys** `user_word_stats.word_id` and `misspelled_words.word_id`: they only matter when
  a vocabulary row is deleted. Never delete vocabulary rows; retire a word by unpublishing its lesson.
- **Performance, unused indexes**: a fresh database has no traffic yet; look again after real usage.

## Operations

- Apple's sign-in secret (`APPLE_CLIENT_SECRET`) is a JWT that Apple limits to 6 months: put the renewal in a calendar.
- The week and month boards aggregate `xp_events` in the window; at about 100,000 users and 200,000 events they took
  roughly a quarter of a second. If that grows, add a daily XP roll-up table.
- Rate-limit the leaderboard functions at the edge before launch: any signed-in user can page through the opted-in board.
- The free plan **pauses a project after about a week without activity** (seen on 2026-10-25): every request then fails until it is
  restored from the dashboard or with the connector's `restore_project` (about 3 minutes, data is kept). A paid plan avoids it.
- The functions are called with `x-region: ap-south-1` (the database region) and deployed with `verify_jwt` on; see
  `functions/README.md`. Sign in with Apple needs four secrets (`APPLE_TEAM_ID`, `APPLE_KEY_ID`, `APPLE_CLIENT_ID`,
  `APPLE_PRIVATE_KEY`) before Apple accounts can be deleted properly.
