import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync } from 'node:fs';
import { LEVEL_ORDER, parseContent, parseCsv } from '../src/content-import.ts';
import { buildCsvs, buildLevelSeedSql, csvField } from '../src/export-supabase.ts';
import { lessonId, uuidV5, wordId } from '../src/ids.ts';
import { openTwin, type Db } from '../../../supabase/tests/twin/translate.ts';

const parsed = parseContent(readFileSync(new URL('../data/words.csv', import.meta.url), 'utf8'));
assert.deepEqual(parsed.errors, []);
const content = parsed.content!;
const allWords = content.lessons.flatMap((l) => l.words);
const coreDir = new URL('../../../supabase/migrations/', import.meta.url);
const coreSql = readFileSync(new URL(readdirSync(coreDir).find((f) => f.endsWith('_core_schema.sql'))!, coreDir), 'utf8');
const count = (db: Db, t: string) => Number(db.prepare(`SELECT count(*) AS n FROM ${t}`).all()[0]!.n);

describe('ids', () => {
  it('uuidV5 matches the RFC 4122 test vector, and the ids of existing content never change', () => {
    assert.equal(uuidV5('www.example.com', '6ba7b810-9dad-11d1-80b4-00c04fd430c8'), '2ed6657d-e927-568b-95e1-2665a8aea6a2');
    assert.equal(wordId('bridge'), '9e3b2e84-f287-50c4-a9b0-e2688d32efa6'); // pinned: the same id as in the first seed
    assert.equal(wordId('  Fortunate '), 'e9f5f3bf-aa1f-5a47-81b3-b1fe11d5c0fb');
    assert.equal(lessonId('A1', 1), '32fd4a60-5d2c-56dc-a582-8bf9fc415ad0');
  });
});

describe('the shipped content', () => {
  it('is 2,800 words in 140 lessons of 20 across A1-B2, all with Arabic', () => {
    assert.equal(content.lessons.length, 140);
    assert.equal(allWords.length, 2800);
    assert.ok(content.lessons.every((l) => l.words.length === 20));
    assert.deepEqual(content.levels.filter((l) => l.lessons > 0).map((l) => l.code), ['A1', 'A2', 'B1', 'B2']);
    assert.ok(allWords.every((w) => w.meaning && w.sentenceAr && /[\u0600-\u06FF]/.test(w.meaning + w.sentenceAr)));
    // the importer's informational notes about lesson counts are expected; anything about missing Arabic is not
    assert.deepEqual(parsed.warnings.filter((w) => /translation|meaning|Arabic/i.test(w.message)), []);
  });
});

describe('CSV export (dashboard import)', () => {
  const csv = buildCsvs(content);
  const rows = (s: string) => parseCsv(s).slice(1);

  it('has the right row counts and headers', () => {
    assert.equal(rows(csv.lessons).length, 140);
    assert.equal(rows(csv.vocabularyBank).length, 2800);
    assert.equal(rows(csv.lessonWords).length, 2800);
    assert.deepEqual(parseCsv(csv.lessons)[0], ['id', 'level_code', 'lesson_number', 'global_seq', 'is_published']);
    assert.deepEqual(parseCsv(csv.vocabularyBank)[0], ['id', 'word_text', 'sentence_context', 'meaning_ar', 'sentence_ar', 'level_code', 'freq_rank']);
    assert.deepEqual(parseCsv(csv.lessonWords)[0], ['lesson_id', 'position', 'word_id']);
  });

  it('is consistent: unique ids, dense global_seq, 20 positions per lesson, every link resolves, word level = lesson level', () => {
    const lessons = rows(csv.lessons);
    const words = rows(csv.vocabularyBank);
    const links = rows(csv.lessonWords);
    assert.equal(new Set(lessons.map((r) => r[0])).size, 140);
    assert.equal(new Set(words.map((r) => r[0])).size, 2800);
    assert.deepEqual(lessons.map((r) => Number(r[3])).sort((a, b) => a - b), Array.from({ length: 140 }, (_, i) => i + 1));
    const levelOfLesson = new Map(lessons.map((r) => [r[0]!, r[1]!]));
    const wordsById = new Map(words.map((r) => [r[0]!, r]));
    const perLesson = new Map<string, number[]>();
    for (const [lid, pos, wid] of links) {
      assert.ok(levelOfLesson.has(lid!), `unknown lesson ${lid}`);
      assert.ok(wordsById.has(wid!), `unknown word ${wid}`);
      assert.equal(wordsById.get(wid!)![5], levelOfLesson.get(lid!), 'word level must equal its lesson level');
      perLesson.set(lid!, [...(perLesson.get(lid!) ?? []), Number(pos)]);
    }
    for (const [lid, positions] of perLesson) assert.deepEqual(positions.sort((a, b) => a - b), Array.from({ length: 20 }, (_, i) => i + 1), `lesson ${lid}`);
    assert.equal(new Set(links.map((r) => r[2])).size, 2800, 'every word is in exactly one lesson');
  });

  it('quotes commas, quotes and Arabic correctly (round trip equals the source)', () => {
    assert.equal(csvField('a,b'), '"a,b"');
    assert.equal(csvField('say "hi"'), '"say ""hi"""');
    const back = rows(csv.vocabularyBank);
    const withComma = allWords.find((w) => w.sentence.includes(','))!;
    const r = back.find((x) => x[0] === wordId(withComma.text))!;
    assert.equal(r[2], withComma.sentence);
    assert.equal(r[3], withComma.meaning);
    assert.equal(r[4], withComma.sentenceAr);
  });

  it('has the rank bands for the four levels', () => {
    assert.equal(csv.levelRankBandsSql.split('\n').filter((l) => l.startsWith('update')).length, 4);
    assert.match(csv.levelRankBandsSql, /update public\.levels set rank_from = 1, rank_to = 700 where code = 'A1';/);
  });
});

describe('SQL seed (run on the SQLite twin of the core schema)', () => {
  const files = LEVEL_ORDER.map((l) => buildLevelSeedSql(content, l)).filter((s): s is string => s !== null);
  // strip the schema prefix of the statements only (never inside the data: the sentence of the word 'public' ends with "public."),
  // and do not use translateMigration, which splits on ';' (sentences contain ';')
  const run = (db: Db) => files.forEach((f) => db.exec(f.replace(/\b(insert into|update) public\./g, '$1 ')));

  it('one file per level for A1-B2, none for C1, each in its own transaction', () => {
    assert.equal(files.length, 4);
    assert.equal(buildLevelSeedSql(content, 'C1'), null);
    for (const f of files) assert.match(f, /^-- Generated by[\s\S]*\nbegin;\n[\s\S]*\ncommit;\n$/);
  });

  it('loads cleanly into the real schema constraints, with the right counts, and loading twice changes nothing', async () => {
    const db = await openTwin(coreSql);
    run(db);
    const snapshot = () => ['lessons', 'vocabulary_bank', 'lesson_words'].map((t) => count(db, t));
    assert.deepEqual(snapshot(), [140, 2800, 2800]);
    run(db);
    assert.deepEqual(snapshot(), [140, 2800, 2800]);
    assert.deepEqual(db.prepare("SELECT code, rank_from AS f, rank_to AS t FROM levels WHERE rank_from IS NOT NULL ORDER BY ordinal").all().map((r) => `${r.code}:${r.f}-${r.t}`), ['A1:1-700', 'A2:701-1400', 'B1:1401-2100', 'B2:2101-2800']);
    assert.equal(count(db, "vocabulary_bank WHERE sentence_ar IS NOT NULL AND meaning_ar IS NOT NULL"), 2800);
    assert.equal(count(db, 'lessons WHERE is_published = 1'), 140);
  });

  it('every lesson has 20 words, every sentence contains its word, and Arabic survives', async () => {
    const db = await openTwin(coreSql);
    run(db);
    assert.equal(count(db, '(SELECT lesson_id FROM lesson_words GROUP BY lesson_id HAVING count(*) <> 20)'), 0);
    const bad = db.prepare("SELECT word_text FROM vocabulary_bank WHERE instr(lower(sentence_context), lower(word_text)) = 0").all();
    assert.deepEqual(bad, []);
    const fortunate = db.prepare("SELECT sentence_ar AS s FROM vocabulary_bank WHERE word_text = 'fortunate'").all()[0]!.s;
    assert.equal(fortunate, content.lessons.flatMap((l) => l.words).find((w) => w.text === 'fortunate')!.sentenceAr);
  });
});
