/**
 * Writes the database seed from data/words.csv.
 *   node scripts/export-supabase.ts [wordsCsv=data/words.csv] [seedDir=../../supabase/seed]
 * Output:  <seedDir>/10_content_A1.sql ... 13_content_B2.sql   one SQL seed per level (picked up by `supabase db reset`)
 *          <seedDir>/csv/01_lessons.csv, 02_vocabulary_bank.csv, 03_lesson_words.csv, 00_levels_rank_bands.sql
 */
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { LEVEL_ORDER, parseContent } from '../src/content-import.ts';
import { buildCsvs, buildLevelSeedSql } from '../src/export-supabase.ts';

const [input = 'data/words.csv', seedDir = '../../supabase/seed'] = process.argv.slice(2);
const parsed = parseContent(readFileSync(input, 'utf8'));
if (parsed.errors.length || !parsed.content) {
  for (const e of parsed.errors) console.error(`  row ${e.row ?? '-'}: ${e.message}`);
  throw new Error(`${input} has ${parsed.errors.length} error(s): fix them first`);
}
const content = parsed.content;
mkdirSync(`${seedDir}/csv`, { recursive: true });

let n = 10;
for (const level of LEVEL_ORDER) {
  const sql = buildLevelSeedSql(content, level);
  if (sql === null) continue;
  const file = `${seedDir}/${n++}_content_${level}.sql`;
  writeFileSync(file, sql, 'utf8');
  console.log(`${file}  ${(sql.length / 1024).toFixed(0)} KB`);
}
const csv = buildCsvs(content);
writeFileSync(`${seedDir}/csv/01_lessons.csv`, csv.lessons, 'utf8');
writeFileSync(`${seedDir}/csv/02_vocabulary_bank.csv`, csv.vocabularyBank, 'utf8');
writeFileSync(`${seedDir}/csv/03_lesson_words.csv`, csv.lessonWords, 'utf8');
writeFileSync(`${seedDir}/csv/00_levels_rank_bands.sql`, csv.levelRankBandsSql, 'utf8');
console.log(`CSV: ${content.lessons.length} lessons, ${content.lessons.reduce((s, l) => s + l.words.length, 0)} words`);
