# LingoTrace: ملف التسليم (HANDOFF)

آخر تحديث: 2026-10-22 (اكتملت المرحلة 1). هذا الملف يلخّص كل ما أُنجز، وأين توقفنا، وما تبقى بالترتيب، ليُكمل أي محادثة جديدة من نفس النقطة.
القارئ الأول هو **Claude في محادثة جديدة**: اقرأ القسم 0 ثم 7، ولا تعِد ما أُنجز.

---

## 0. كيف تبدأ في محادثة جديدة (للمستخدم)

1. نزّل هذه الملفات من المحادثة القديمة وارفعها في المحادثة الجديدة: `HANDOFF.md` و`lingotrace-wip.zip` و`spelling-core.zip`.
2. في المحادثة الجديدة اربط موصّل **Supabase** (البطاقة ستظهر، اضغط Connect). حسابك مربوط سابقًا، لكن الموصّل قد يحتاج تفعيلًا في المحادثة الجديدة.
3. الصق هذا النص كما هو:

```
أكمل مشروع LingoTrace من ملف التسليم المرفق (HANDOFF.md). اقرأه كاملًا أولًا، ثم فكّ lingotrace-wip.zip و spelling-core.zip.
قواعد العمل: أتكلم عربي خليجي، أستخدم تطبيق Claude على الجوال وليس عندي كمبيوتر، ولا أريد أي تكلفة مالية،
وأريد الملفات واحدًا واحدًا بنفس الترتيب في القسم 7، مع تجربة كل ملف على قدر ما تستطيع وبيان ما جُرّب وما لم يُجرَّب.
ابدأ من «أين توقفنا بالضبط» في القسم 2 (ما بقي من المرحلة 2 يحتاج موصّل Supabase وموافقتي على كل أمر كتابة) ثم تابع بالترتيب. اربط موصّل Supabase عند الحاجة، ولا تنفّذ على قاعدتي إلا بعد موافقتي.
```

---

## 1. المشروع والقيود

**المنتج:** تطبيق إملاء إنجليزي (dictation) بمستويات CEFR من A1 إلى B2 (C1 لاحقًا)، بأسلوب Duolingo، واجهة عربية RTL بثيم داكن.
المستخدم يسمع الكلمة ويكتبها؛ الأخطاء تُدخل نظام تكرار متباعد (SRS)؛ نقاط XP وسلسلة أيام ومتصدرون.

**المطلوب النهائي (من المستخدم):**
- React Native + Expo + TypeScript، يعمل على Web (PWA) وiOS وAndroid.
- **الشكل مطابق 100% للنموذج الأولي** (`prototype/spelling-trainer.html`): نفس العناصر والألوان والخطوط. التحسينات "تحت الغطاء" فقط: استجابة على كل الشاشات، حركات 60 إطارًا.
- **لا تجمع المشروع في ملف واحد**: بنية معيارية، والملفات تُسلَّم واحدًا واحدًا بدءًا من قاعدة البيانات.
- **Offline-first** بـ AsyncStorage، والمزامنة تلقائية عند عودة الاتصال.
- حقل الكتابة بلا تصحيح تلقائي ولا حروف كبيرة تلقائية ولا اقتراحات، ومتوافق مع أي لوحة مفاتيح.
- متطلبات المتاجر: زر Google Sign-In وزر Sign in with Apple وزر **Delete Account** صريح داخل الإعدادات.
- مفاتيح Supabase عبر Expo Constants / .env بأمان.
- Supabase للـ BaaS والمصادقة (Google وApple) والمزامنة بين الأجهزة.
- جداول: `users` (ملفات) و`vocabulary_bank` و`user_progress` و`misspelled_words`، ومتصدرون بترتيب ديناميكي، ومخطط حذف الحساب بالـcascade.
- `expo-speech` للنطق على الجوال والويب.

**قيود المستخدم (مهمة):**
- لغة التخاطب: عربية خليجية. يستخدم تطبيق Claude على الجوال و**ليس عنده كمبيوتر**.
- **لا يريد أي تكلفة مالية.** (الاستثناء المعروف: متاجر التطبيقات، انظر 8.)
- يريد "حقيقي وكامل وعالي المواصفات وسريع"، فكن صادقًا في ما جُرّب وما لم يُجرَّب.
- **كل أمر كتابة على قاعدته عبر الموصّل يحتاج موافقته** (نافذة Allow). لا تحاول تجاوز رفضه بأداة أخرى.

---

## 2. ما أُنجز (ملخص)

| # | ما أُنجز | أين | الحالة |
|---|---|---|---|
| 1 | **النموذج الأولي** HTML (6 شاشات، RTL، ثيم داكن) | `prototype/spelling-trainer.html`، منشور على https://claude.ai/artifact/9YXiiEsJtY4LRxBdXxTqfv | يعمل، 46 فحص متصفح |
| 2 | **محرك TypeScript** (قواعد الإملاء، SRS، الطابور، الجلسة، السلسلة، إعادة التحقق replay، commit) | `spelling-core.zip` (المجلد `src/`) | **104 اختبارات** (69 للمحرك + 35 لخط المحتوى والنشر القديم) تنجح |
| 3 | **المحتوى**: 2,800 كلمة A1-B2 من NGSL v1.2 (CC BY-SA 4.0)، 140 درسًا × 20 كلمة، جملة لكل كلمة، معنى عربي، **ترجمة عربية للجملة** | `packages/content/data/` و`spelling-core/data/` | مُتحقَّق آليًا (راجع 8: مراجعة عربية بشرية مطلوبة) |
| 4 | **قاعدة بيانات Supabase حقيقية** (8 migrations مُطبَّقة) | مشروع `lingotrace` على Supabase و`supabase/migrations/` | **كلها مُطبَّقة ومُجرَّبة فعليًا** (راجع 3). الثامن (`session_chain`) طُبّق في 2026-10-25 |
| 5 | **اختبارات القاعدة**: 6 سكربتات SQL لـPostgreSQL حقيقي، **كلها جُرِّبت فعليًا** (005: 79 من 79 و006: 15 من 15 في 2026-10-25؛ 004 ينتظر المحتوى) + 51 اختبار Node (توأم SQLite + حرّاس أمان ساكنة + حرّاس السكربتات نفسها) | `supabase/tests/` | تنجح |
| 6 | **حزمة content الجديدة**: مولّد ids ثابتة، تصدير Seed SQL لكل مستوى + 3 ملفات CSV، 9 اختبارات | `packages/content/` | تنجح؛ **المحتوى لم يُحمَّل بعد في القاعدة** |
| 7 | **config.toml** لـSupabase (Google وApple فقط، JWT على الدوال) مُتحقَّق من مفاتيحه مقابل مرجع CLI (أكتوبر 2026) | `supabase/config.toml` | جاهز، **لم يُدفع للمشروع المستضاف** |
| 8 | بنية المشروع المقترحة والمتفق عليها (القسم 4) | هذا الملف | معتمدة |
| 9 | **حزمة engine في المستودع الجديد**: مدخل للعميل `@lingotrace/engine` ومدخل للخادم `@lingotrace/engine/server`؛ `planCommit` يحسب الدقة ويجمّع الأخطاء الحرفية؛ **سلسلة الجلسات** (`parentSessionId` + `out_of_order`)؛ **محلّل حمولة الطلب** `parseSessionCommit`؛ إدراج المحاولات في عبارة واحدة | `packages/engine/` | **104 اختبارات** تنجح + `tsc` صارم نظيف. **على PostgreSQL الحقيقي: مُجرَّبة** (005: كل عبارات `PgRepo` والحالة النهائية تطابق التوأم) |
| 10 | **دوال Edge** `commit-session` و`delete-account` + `_shared/` (auth، body، cors، errors، rate-limit، apple، log، db) + نسخة المحرك المولَّدة `_shared/engine/` + `scripts/sync-engine.ts` | `supabase/functions/` و`scripts/` و`supabase/tests/functions/` | **68 اختبارًا** تنجح، و`tsc` صارم نظيف. **الدالتان منشورتان** (2026-10-25، النسخة 1، ACTIVE، `verify_jwt` مفعّل). `delete-account` قُرئت بعد النشر وطابقت المستودع؛ `commit-session` نُشرت من نسخة يدوية لـ22 ملفًا **ولم تُقرأ للمطابقة بعد**. **لا دالة استُدعيت بعد تحت Deno** |

اختبارات المستودع الجديد: **232** (51 في `supabase/tests/twin` + 68 في `supabase/tests/functions` + 9 في `packages/content/test` + 104 في `packages/engine/test`). الأمر: `node --test supabase/tests/twin/*.test.ts supabase/tests/functions/*.test.ts packages/content/test/*.test.ts packages/engine/test/*.test.ts` (Node 22.18+). فحص الأنواع: `cd packages/engine && tsc -p tsconfig.json` و`cd supabase && tsc -p tsconfig.json` (يحتاجان `typescript` و`@types/node`؛ جُرّبا مع TS 6.0.3 و@types/node 25.6.0). ملفان مولَّدان لهما فحص `--check` واختبار يفشل إن تقادما: `node scripts/sync-engine.ts` و`node scripts/gen-pgrepo-contract.ts`.

### أين توقفنا بالضبط
اكتملت **المرحلة 1** و**المرحلة 2** عدا الأسرار وأول استدعاء حقيقي. **حالة القاعدة الحقيقية بتاريخ 2026-10-25:** كانت **متوقفة تلقائيًا (INACTIVE)**: الخطة المجانية توقف المشروع بعد نحو أسبوع بلا نشاط. استُعيدت بـ`restore_project` (بموافقتك) وهي الآن `ACTIVE_HEALTHY`، وبياناتها سليمة: 8 migrations، 11 جدولًا كلها بـRLS و12 سياسة، 6 دوال، المستويات الخمسة، `v_account_deletion_gaps` فارغ، DateStyle ISO. المدقق الأمني بالتنبيهين المقصودين فقط (دالتا المتصدرين)، والأدائي INFO فقط.

**تم في 2026-10-25 على القاعدة الحقيقية** (كل كتابة بموافقة المستخدم):
1. ✅ ربط موصّل Supabase، فحص للقراءة فقط، واستعادة المشروع.
2. ✅ طُبّق migration 8 (`session_chain`).
3. ✅ `006_session_chain.sql` (15 من 15) ثم `005_pgrepo_contract.sql` (79 من 79). كلاهما داخل معاملة تُلغى، وتأكدنا بعدهما أن الجداول فارغة (لا أثر). **أهم نتيجة:** كل عبارات `PgRepo` تعمل على PostgreSQL 17.11 بمعاملات نصية كما يرسلها السائق، والحالة النهائية للجداول السبعة تطابق التوأم بصمةً بصمة، وحذف الحساب يمسح سلسلة الجلسات دفعة واحدة.
4. ✅ المدقق بعد الـmigration: لا تنبيهات جديدة.
5. ✅ نُشرت `delete-account` (النسخة 1، ACTIVE، `verify_jwt: true`). قبلت المنصة أسماء الملفات `../_shared/...` وحزمة `npm:@supabase/supabase-js@2.106.1`، وقُرئ ما نُشر فطابق المستودع.
6. ✅ نُشرت `commit-session` (النسخة 1، ACTIVE، `verify_jwt: true`): 22 ملفًا بالأسماء النسبية نفسها، وقبلت المنصة الاستيراد من `https://deno.land/x/postgres@v0.17.0/mod.ts` عند البناء. **نُقلت الملفات يدويًا (92KB) ولم تُقرأ للمطابقة بعد**.

**الباقي، بهذا الترتيب:**
A. **مطابقة `commit-session`:** `get_edge_function` ثم مقارنة كل ملف بالمستودع قبل الاعتماد عليها (إن وُجدت أتمتة نشر لاحقًا فهي أفضل من النقل اليدوي). بعد أي تعديل على `packages/engine/src` أعد: `node scripts/sync-engine.ts` ثم أعد نشر `commit-session` (أسماء الملفات نفسها، `verify_jwt: true`). **الملفات الاثنان والعشرون:** `index.ts` و`handler.ts` من `commit-session/`، ومن `../_shared/`: `auth` و`body` و`cors` و`db` و`errors` و`log` و`rate-limit`، ومن `../_shared/engine/`: `commit-request` و`queue-builder` و`replay` و`rng` و`session` و`spelling` و`stats` و`streak` و`types`، ومن `../_shared/engine/server/`: `commit` و`index` و`parse-commit` و`pg-repo`.
B. **الأسرار** يدويًا من لوحة Supabase (الموصّل لا يضبط الأسرار): `ALLOWED_ORIGINS` (للويب فقط) وأسرار Apple الأربعة **كلها أو لا شيء** (`APPLE_TEAM_ID` و`APPLE_KEY_ID` و`APPLE_CLIENT_ID` و`APPLE_PRIVATE_KEY`؛ تحتاج عضوية Apple Developer المدفوعة، وبدونها تعمل الدوال وتُحذف حسابات Apple دون إلغاء توكناتها).
C. **أول استدعاء HTTP حقيقي بتوكن حقيقي**: يحتاج تسجيل دخول فعليًا (المرحلة 4). **لا دالة استُدعيت بعد تحت Deno**، فكل ما في `supabase/functions/README.md` تحت «Not verified» لا يزال افتراضًا مبنيًا على الوثائق.
D. **تنبيه تشغيل:** المشروع سيتوقف مجددًا بعد نحو أسبوع بلا نشاط ما دام على الخطة المجانية. الاستعادة: `restore_project` عبر الموصّل أو من لوحة Supabase، وتأخذ نحو 3 دقائق. حين يستعمله مستخدمون يوميًا لا يتوقف (انظر القسم 8).

**ما صار في المستودع** (كله مُجرَّب بـNode، 232 اختبارًا، وجزؤه القاعدي على PostgreSQL الحقيقي):
- **سلسلة الجلسات** (migration 8 + المحرك): كل جلسة تسمّي الجلسة التي لُعبت قبلها (`parentSessionId`، null للأولى). الخادم يقبل الجلسة فقط إن كان أبوها آخر جلسة سجّلها لهذا المستخدم، وإلا `409 out_of_order` ومعه `details.lastSessionId`. الفحص يأتي بعد فحص التكرار وقبل أي فحص يعتمد على الحالة، فدرس وصل قبل سابقه يُبلَّغ كـ`out_of_order` القابل لإعادة المحاولة لا كـ`lesson_locked` النهائي. القاعدة تضمن وحدها أن جلسات المستخدم خط واحد (جذر واحد لكل مستخدم، طفل واحد لكل جلسة، لا جلسة أبوها نفسها) **وهذا جُرِّب على PostgreSQL الحقيقي في 006**.
- **`parseSessionCommit`** (محرك/خادم): يحوّل JSON غير الموثوق إلى `SessionCommit` أو يقول أي حقل خاطئ دون ترديد قيمته، ويبني كائنًا نظيفًا. بدونه كان `{"attempts":[null]}` يُسقط خدمة الالتزام بـ`TypeError: Cannot read properties of null` (جُرّب فعليًا).
- **إدراج المحاولات في عبارة واحدة**: التزام درس سليم **18 عبارة بدل 56** (20 بدل 58 مع كلمة فاشلة)، ويحرس الميزانية (≤ 24) اختبار. جُرّب على PostgreSQL الحقيقي (العبارة متعددة الصفوف بمعاملات غير محدّدة النوع).
- **دوال Edge** وملفاتها المشتركة وسكربت مزامنة المحرك (قرارات التصميم في المرحلة 2 أدناه).
- **`005_pgrepo_contract.sql` مولَّد من عبارات `PgRepo` الفعلية** (سيناريو ثابت: أول مرة، حقن مراجعة، إعادة لعب أسوأ، مستخدم ثانٍ، جلسة مكررة، جلسة بأب قديم)، يصدّرها `PREPARE/EXECUTE` بقيم نصية كما يرسلها السائق، ويقارن الحالة النهائية لسبعة جداول بالتوأم عبر `md5`. يستعمل رموزًا قصيرة (`@u1@`) بدل الـUUIDs ويستبدلها داخل القاعدة (28KB). **قيد معروف:** ترتيب البصمات نصّي، فمفتاح رقمي مثل `n` لا يُرتَّب كرقم إلا ما دام أقل من 10 (أكبر قيمة في السيناريو 8). **حرّاس:** كل سكربت قاعدة معاملة واحدة تنتهي بـ`rollback` (لا `commit` شاردة)، ASCII، والمولَّد محدَّث.
- **ثغرات اختبار وُجدت وأُغلقت أثناء العمل** (أخطاء أدواتي لا الشيفرة): مترجم التوأم كان يقسّم عند أي `;` حتى داخل النصوص فصار يحترم الاقتباس (وله اختبارات)، وأنواع `Db.run` صارت دقيقة.

---

## 3. الحالة الحقيقية لقاعدة البيانات (Supabase)

- **المشروع:** الاسم `lingotrace`، المرجع (ref) `yvszergcvjnzpogubqex`، الرابط `https://yvszergcvjnzpogubqex.supabase.co`، المنطقة `ap-south-1` (مومباي)، المنظمة `gepdhkepreptscaweeqj` («راشد الطارقي»)، الخطة **Free** (تكلفة 0$)، PostgreSQL **17.11**، ترميز UTF8، DateStyle ISO.
- **المنفّذ عليه:** 8 ملفات (أسماء الإصدارات على الخادم تلقائية، وتختلف عن أسماء الملفات في `supabase/migrations/`):
  1. `core_schema`: 11 جدولًا: `levels, lessons, vocabulary_bank, lesson_words, users, user_progress, user_word_stats, misspelled_words, lesson_sessions, session_attempts, xp_events` + سلسلة cascade.
  2. `functions_triggers`: `set_updated_at` و`trg_xp_events_apply` (XP يغذي `users.total_xp`) و`validate_user_time_zone` و`handle_new_user` (يُنشئ الملف الشخصي عند التسجيل، ولا يستخدم الإيميل اسمًا أبدًا).
  3. `leaderboard`: `get_leaderboard(period, limit, offset)` و`get_my_rank(period)`؛ الفترات `all|week|month`.
  4. `rls_policies`: RLS على الجداول الـ11 (محتوى عام للقراءة، بيانات المستخدم لصاحبها).
  5. `account_deletion`: العرض `v_account_deletion_gaps` (يجب أن يبقى فارغًا).
  6. `grants_lockdown`: مغلق افتراضيًا ثم صلاحيات دقيقة. `service_role` بلا أي صلاحية جداول.
  7. `internal_tables_deny_policies`: سياسة RESTRICTIVE تمنع العملاء من `lesson_sessions` و`session_attempts` و`xp_events`.
  8. `session_chain` (طُبّق 2026-10-25): `lesson_sessions.parent_session_id` وفهرسان فريدان جزئيان (جذر واحد لكل مستخدم، طفل واحد لكل جلسة) وقيد `parent_session_id <> id`.
- **نموذج الأمان:** العميل يقرأ المحتوى العام وصفوفه فقط، ويعدّل 4 أعمدة من ملفه (`display_name, tts_locale, time_zone, show_on_leaderboard`). لا يكتب XP ولا سلسلة ولا تقدمًا ولا جلسات. هذه تُكتب فقط من دالة Edge `commit-session` باتصال مباشر بدور المالك (يتجاوز RLS).
- **ما اختُبر فعليًا على القاعدة الحقيقية:** `001` (23/23: التسجيل والـtriggers والقيود والعربي) و`002` (22/22: RLS بصلاحيات anon وauthenticated، المتصدرون بالتعادل والتصفح والفترات، حذف الحساب عبر `auth.users`)، وسياسة المنع، و`003` (أداء 100 ألف مستخدم و200 ألف حدث: الصفحة الأولى أقل من 1 مللي ثانية، ترتيبي ≈ 19، الأسبوعي ≈ 75، الشهري ≈ 240 مللي ثانية)، و`004` (سكربت سلامة المحتوى: جُرّب على قاعدة فارغة وعلى بيانات سليمة وعلى بيانات معيبة عمدًا). **وفي 2026-10-25:** `006` (15 من 15: قيود السلسلة وحذف الحساب مع المفتاح الأجنبي الذاتي) و`005` (79 من 79: كل عبارات `PgRepo` وتطابق الحالة النهائية مع التوأم).
- **مدقق Supabase:** أمان: تنبيه واحد مقبول (دالتا المتصدرين SECURITY DEFINER مقصودتان). أداء: INFO فقط (فهارس FK غير موجودة على `word_id` في جدولين، وفهارس غير مستخدمة لأن القاعدة جديدة). كلها موثّقة في `supabase/README.md`.
- **القاعدة فارغة حاليًا** (لا مستخدمين ولا محتوى؛ جداول المستويات الخمسة فقط). كل الاختبارات تعمل داخل معاملات تُلغى (rollback).
- **توقف تلقائي (اكتشفناه في 2026-10-25):** المشروع كان `INACTIVE`. الخطة المجانية تُوقف المشروع بعد نحو أسبوع بلا نشاط؛ البيانات تبقى محفوظة وتُستعاد بـ`restore_project` (نحو 3 دقائق، مجانًا). أثناء التطوير ستتكرر هذه الفجوات، وقد تتكرر في الإنتاج إن مرّ أسبوع بلا مستخدم. الحل الدائم خطة Pro (تكلفة شهرية، وقرارك أنت لأن القيد الأصلي «لا تكلفة»).
- **دوال Edge المنشورة:** `delete-account` و`commit-session` (النسخة 1 لكل منهما، `verify_jwt` مفعّل).
- **إعدادات Auth على المشروع المستضاف ما زالت افتراضية:** Google وApple غير مضبوطين، وتسجيل الإيميل قد يكون مفعّلًا (راجع المرحلة 4). `config.toml` لا يؤثر عليه إلا عبر `supabase config push`.

### حدود الأدوات التي تعلمناها
- بيئة Claude **بلا إنترنت**: لا `npm install` ولا Expo ولا Deno. يمكن اختبار الشيفرة النقية (المحرك، المحتوى، SQL على SQLite، وSQL الحقيقي عبر الموصّل) لكن لا يمكن بناء تطبيق RN ولا تشغيل Edge Functions محليًا.
- أدوات Supabase: حمّلها بـ`tool_search` (مثلًا `supabase execute_sql apply_migration deploy_edge_function get_advisors list_tables`). `execute_sql` يقبل `begin; ... rollback;` ويُرجع نتيجة آخر SELECT، فهكذا نختبر بلا أثر. الكتابة (`apply_migration`, `create_project`...) تطلب موافقة المستخدم.
- **حشو المحتوى (651 ك.ب) عبر الموصّل غير عملي** (مئات آلاف الرموز). لذلك يُحمَّل بواسطة المستخدم (المرحلة 3).

---

## 4. القرارات المعمارية المتفق عليها

**المستودع:** npm workspaces (`apps/*`, `packages/*`)

```
lingotrace/
  apps/mobile/            Expo Router: iOS + Android + Web/PWA
  packages/engine/        TS نقي بلا اعتماديات: دخل العميل (index) + دخل الخادم (server)
  packages/content/       بيانات المفردات + التصدير إلى Seed Supabase
  supabase/               config.toml, migrations, seed, functions, tests
  prototype/              المرجع البصري المجمّد
  e2e/                    Playwright (مطابقة البكسل مع النموذج الأولي) + Maestro
  scripts/  docs/  .github/workflows/
```

1. **محرك مشترك:** نفس الشيفرة تعمل في التطبيق (جلسات بلا إنترنت) وفي `commit-session` (التحقق وإعادة الحساب). XP لا يُصدَّق من العميل أبدًا. الدخل `@lingotrace/engine/server` لا يُستورد في التطبيق (قاعدة ESLint).
2. **Expo Router** (مسارات ملفية، روابط ويب، إعادة التوجيه لـOAuth).
3. **تسمية الجداول:** `users`=ملفات (id = `auth.users.id`) · `vocabulary_bank`=الكلمات (+`level_code`) · `user_progress`=تقدم الدروس (+دقة) · `misspelled_words`=الأخطاء الحرفية وتكرارها (جدول جديد) · وبقية الجداول (`user_word_stats` حالة SRS التي يحتاجها المحرك، `lesson_sessions`، `session_attempts`، `xp_events`).
4. **التخزين:** AsyncStorage للكاش والـoutbox خلف واجهة `KeyValueStore`؛ توكنات الدخول عبر `largeSecureStore` (مفتاح AES في SecureStore، والبيانات المشفّرة في AsyncStorage).
5. **المحتوى داخل التطبيق** (`content.v1.json` مضمَّن، يعمل بلا إنترنت من أول تشغيل) + تحديثات delta عند الاتصال.
6. **شاشتان غير موجودتين في النموذج الأولي** (تسجيل الدخول والإعدادات/حذف الحساب): تُصمَّمان بنفس اللغة البصرية وتُعرضان على المستخدم قبل البناء.
7. **الأداء:** Reanimated لحركات UI-thread، FlashList للقوائم الطويلة، حالة الدرس في الذاكرة مع كتابة التخزين عند حدود الخطوات فقط (لا عند كل ضغطة مفتاح)، Hermes، تقسيم المسارات على الويب.

**مفاتيح وأسرار:** في التطبيق فقط `EXPO_PUBLIC_SUPABASE_URL` والمفتاح العام (anon/publishable). أي سر (service role، مفتاح Apple، سر Google) يبقى في أسرار Supabase/EAS فقط.

---

## 5. حقائق النموذج الأولي (للمطابقة البصرية)

- الشاشات: الرئيسية (بطاقة المستوى النشط قرمزية داكنة، مستويات مكتملة ومقفلة، زر «افتح الدروس»)، المسار (خريطة عقد عمودية متعرّجة: أخضر مكتمل، أحمر حالي، رمادي مقفل)، الدرس، النتيجة («اكتمل الدرس» وقائمة الأخطاء)، الترتيب (المتصدرون وصفّ «أنت»)، الملف الشخصي. شريط تبويب سفلي: الرئيسية / الترتيب / الملف الشخصي.
- **الخط:** IBM Plex Sans Arabic بالأوزان 400/500/600/700 (يُحمَّل في النموذج من Google Fonts، وفي التطبيق **يُضمَّن** عبر `expo-font`).
- **ألوان (CSS):** `--bg:#0d1220` · `--card:#141b2d` · `--line:#222c47` · `--tx:#f4f6fb` · `--mut:#8b93a7` · `--pk:#ff5a78` · `--mint:#34d399`، مع تدرّج قرمزي لبطاقة المستوى النشط (استخرج القيم الدقيقة من `prototype/` عند كتابة `tokens.ts`).
- أحجام بوحدات `cqw` (حاوية) بلا media queries → تُستبدل بدالة مقياس في `responsive.ts`. حواف آمنة `safe-area-inset`. حركة واحدة (وميض المؤشر) + أنيميشن الأزرار.
- شاشة الدرس: رأس مع × وشريط تقدم؛ زر استماع + عين + ترجمة + سهم رجوع؛ صف المعنى العربي (يُخفى كاملًا عند الإيقاف لا تمويهًا)؛ صف ترجمة الجملة (نفس القاعدة)؛ حقل كتابة كبير أبيض أثناء الكتابة ثم أخضر/أحمر بعد الإرسال ومؤشر وامض؛ الجملة الخاطئة **لا تُكرَّر**: يظهر التصحيح في مكانه ثم يتقدم؛ زر الرجوع يتصفّح الخطوات السابقة للعرض فقط؛ زر «التالي» أحمر فاتح `#e57373` فوق لوحة المفاتيح بنحو 18px؛ حارس لوحة المفاتيح العربية يحذّر دون احتساب محاولة فاشلة.
- **قواعد المنتج:** المسافة 0 صحيح، 1 زلّة صغيرة (إعادة كتابة بلا عقوبة)، >1 أو الفشل مرتين خطأ كبير (يدخل SRS)؛ الطابور: 20 كلمة + حتى كلمتين مراجعة مُحقنة (مبعثرة، لا متجاورتان، منفردتان)؛ XP: +10 من أول مرة نظيفة، +5 للمستردّة/المحقونة/المساعدة، +50 مكافأة درس؛ الإعادة (replay) = 0 XP ولا تلمس التدوير؛ السلسلة = يوم تقويمي في منطقة المستخدم الزمنية.

---

## 6. المراجع والملفات

| ملف | ما فيه |
|---|---|
| `lingotrace-wip.zip` | المستودع الجديد (supabase مع دوال Edge، packages/content، packages/engine، scripts، prototype، docs) |
| `spelling-core.zip` | المشروع الأول الكامل: المحرك والاختبارات (104) وخط المحتوى والـdemo وسكربتات النشر على PostgreSQL عام |
| `words.csv` | 2,800 كلمة مع الجمل والمعاني والترجمة (عمود `sentence_ar`) |
| `spelling-trainer.html` | النموذج الأولي المستقل (نفسه في `prototype/`) |

أوامر مفيدة: `node --test supabase/tests/twin/*.test.ts supabase/tests/functions/*.test.ts packages/content/test/*.test.ts packages/engine/test/*.test.ts` · `cd packages/content && node scripts/export-supabase.ts data/words.csv ../../supabase/seed` (يعيد توليد الـseed). · `node scripts/sync-engine.ts [--check]` · `node scripts/gen-pgrepo-contract.ts [--check|--explain]`

---

## 7. المتبقي بالتفصيل وبالترتيب

لكل مرحلة **معيار إنجاز**. لا تنتقل قبل تحققه. بعد كل دفعة: حدّث هذا الملف في القسم 2.

### المرحلة 1: إكمال `packages/engine` ✅ (اكتملت 2026-10-22)
الهدف: نقل المحرك المُختبَر إلى المستودع الجديد مع التعديلات للمخطط الجديد.
1. **أنشئ `src/commit-request.ts`** (آمن للعميل): انقل إليه من `spelling-core/src/commit.ts` الواجهة `SessionCommit` والدالة `toSessionCommit` (بما تحتاجه من ثوابت مثل `ENGINE_VERSION` من `types.ts`).
2. **`src/server/commit.ts`** = الباقي من `commit.ts` القديم بعد إصلاح المسارات (`../types.ts`، `../spelling.ts`، `../replay.ts`، `../session.ts`، `../stats.ts`، `../streak.ts`، `../queue-builder.ts`، `../commit-request.ts`) مع **إضافتين** في `planCommit`:
   - `lessonProgress.accuracy` = `wordsTotal===0 ? 0 : Math.round(100*wordsClean/wordsTotal)`.
   - `misspelled: {userId, wordId, typed, occurrences, firstSeenAt, lastSeenAt}[]` تُجمَّع من `summary.attempts`: فقط `step==='word' && verdict!=='exact'`، و`typed = normalizeWord(a.input)` (يُستورد من `../spelling.ts`)، تُتجاهل القيم الفارغة أو الأطول من 100 حرف، والتوقيت من `a.at`. (الدرس: سجل المحاولة `AttemptLog` فيه `at` و`input` و`verdict` و`step`.)
3. **`src/server/pg-repo.ts`** من القديم مع: `words`→`vocabulary_bank` (في `loadLessonWords` و`loadDueMistakes`)؛ `lesson_progress`→`user_progress` (في `isLessonCompleted` و`isLessonUnlocked` والـupsert)؛ upsert التقدم الجديد:
   `INSERT INTO user_progress (user_id, lesson_id, first_completed_at, completions, best_accuracy, last_accuracy, last_played_at) VALUES ($1,$2,$3,1,$4,$4,$5) ON CONFLICT (user_id, lesson_id) DO UPDATE SET first_completed_at = COALESCE(user_progress.first_completed_at, excluded.first_completed_at), completions = user_progress.completions + 1, best_accuracy = GREATEST(COALESCE(user_progress.best_accuracy,0), excluded.best_accuracy), last_accuracy = excluded.last_accuracy, last_played_at = excluded.last_played_at`؛ وupsert الأخطاء الحرفية لكل عنصر من `plan.misspelled`:
   `INSERT INTO misspelled_words (user_id, word_id, typed, occurrences, first_seen_at, last_seen_at) VALUES ($1..$6) ON CONFLICT (user_id, word_id, typed) DO UPDATE SET occurrences = misspelled_words.occurrences + excluded.occurrences, first_seen_at = LEAST(misspelled_words.first_seen_at, excluded.first_seen_at), last_seen_at = GREATEST(misspelled_words.last_seen_at, excluded.last_seen_at)`.
4. **`src/index.ts`** (يصدّر الوحدات الثماني + `commit-request`) و**`src/server/index.ts`** (commit + pg-repo) و**`package.json`**: `name:@lingotrace/engine`، `type:module`، `exports: {".": "./src/index.ts", "./server": "./src/server/index.ts"}`.
5. **الاختبارات:** انسخ `engine.test.ts` و`replay.test.ts` و`streak.test.ts` من `spelling-core/test/` دون تغيير (تستورد من `../src/index.ts`). انقل `commit.test.ts` مع: استيراد الخادم من `../src/server/index.ts`، وأسماء الجداول الجديدة، ومساعد `test/helpers/db.ts` جديد مبني على `supabase/tests/twin/translate.ts` (`openTwin`) بدل ترجمة `schema.sql` القديم؛ ومحوّل الـpool يترجم `LEAST/GREATEST` إلى `MIN/MAX` وبقية ما كان في `helpers/sqlite.ts` القديم (`$n`→`?n`، إزالة `FOR UPDATE`، `CAST(date AS text)`، الأعداد المنطقية). `seedWorld` يُدخل في `vocabulary_bank`. أضف اختبارات: تجميع الأخطاء الحرفية، `best_accuracy` مقابل `last_accuracy`، وأن إعادة إرسال نفس الجلسة لا تضاعف العدّ.
6. قاعدة ESLint لاحقًا: يُمنع استيراد `@lingotrace/engine/server` من `apps/mobile`.
**معيار الإنجاز:** كل الاختبارات المنقولة تنجح (تقريبًا 104 + الجديدة) وتحافظ على سلوك المحرك كما هو.

**النتيجة (2026-10-22): تحقق المعيار.** 87 اختبارًا تنجح في الحزمة: engine 32 + replay 7 + streak 10 + commit 30 + pg-repo 5 + boundaries 3؛ و`tsc` (strict + noUncheckedIndexedAccess) بلا أخطاء. جُرّب أيضًا أن الاختبارات الجديدة **تفشل فعلًا** عند إفساد المنطق (11 تعديلًا متعمَّدًا كلها كُشفت ثم أُعيدت الملفات: 8 على منطق الالتزام والمحوّل — اتجاه GREATEST/LEAST في الدقة والنافذة، جمع العدّ، فلتر خطوة الجملة، التقريب، حساب الطول بوحدات UTF-16، عدم إزالة NUL — واثنان على ORDER BY لترتيب الأولوية، وواحد لتسرّب استيراد من العميل إلى الخادم).

**عن الرقم 104:** يضم 69 اختبارًا للمحرك (commit 15 + engine 32 + replay 7 + streak 10 + repo-words 5): نُقلت كلها عدا اختباري `repo-words` عن تطابق `schema.sql` مع الـmigration القديمة (لا معنى لهما في المستودع الجديد)؛ ثم 35 لخط المحتوى والنشر القديم لم تُنقل: `content-import` 14 و`data` 6 و`ngsl` 8 (تعتمد على سكربتَي `seed-sql.ts` و`ngsl.ts` القديمين) و`deploy-sql` 7 (سكربتات نشر PostgreSQL القديمة). راجع القسم 8.

**ما اختلف عن النص أعلاه (وسببه):**
1. `typed` في الأخطاء الحرفية يمرّ بإزالة NUL قبل `normalizeWord` (لم يذكرها النص): PostgreSQL يرفض NUL في أعمدة `text` فكان الالتزام كله سيفشل. والطول يُحسب بنقاط الترميز (`Array.from`) لا بوحدات UTF-16 ليطابق `char_length`: 100 إيموجي تُحفظ و101 تُتجاهل (مُختبَر).
2. `firstSeenAt/lastSeenAt` تؤخذ من `at` في سجل الإعادة (ISO UTC مُطبَّع أصلًا) دون إعادة تحليل.
3. صُدِّرت `collectMisspellings` و`MISSPELLED_MAX_LENGTH` لاختبار الدالة النقية مباشرة.
4. اختبار الذرّية صار 6 اختبارات: يُحقَن الفشل عند كل عبارة كتابة على حدة (`session_attempts`، `user_word_stats`، `misspelled_words`، `xp_events`، `user_progress`، تحديث `users`) لإثبات أن كل الكتابات داخل المعاملة.
5. الاختبار القديم المسمّى «يقبل UUID حقيقية» لم يكن يختبر القبول: أُضيف التزام كامل بمعرّفات UUID ومدقق المعرّفات الافتراضي (الذي سيعمل في الإنتاج)، وكانت بقية اختبارات الالتزام كلها تتجاوزه بمعرّفات مقروءة.
6. أُضيف `test/pg-repo.test.ts`: يضمن أن ترتيب `loadDueMistakes` في SQL يطابق ترتيب المحرك (`byPriority`) على 25 مجموعة بيانات عشوائية فيها تعادلات وقيم NULL، وأن `isLessonUnlocked` يتجاهل الدروس غير المنشورة. (هذا بديل فعلي للتعليق القديم «MUST stay in sync with fn_due_mistakes()» الذي يشير إلى دالة غير موجودة.)
7. `tsconfig.json` للحزمة يستخدم `module: ESNext` و`moduleResolution: Bundler` (لا NodeNext) لأن مساعد الاختبار يستورد ملفًا خارج الحزمة (`supabase/tests/twin/translate.ts`) وليس في الجذر `package.json` بعد. عند إنشائه في المرحلة 5 يمكن وراثة `tsconfig.base.json`.

### المرحلة 2: دوال Edge + اختبار SQL الحقيقي (اكتمل 2026-10-25 عدا الأسرار وأول استدعاء حقيقي؛ راجع «أين توقفنا بالضبط»)
> **قياس فعلي:** كان التزام درس سليم 56 عبارة (40 منها `INSERT` منفردة)؛ بعد تجميع المحاولات صار **18** (20 مع كلمة فاشلة). إعادة تشغيل درس من 40 محاولة تأخذ نحو 0.36 ملّي ثانية في Node، وحمولة الطلب نحو 4.9KB.

1. **migration 8** ✅ `20261022000100_session_chain.sql`: `lesson_sessions.parent_session_id uuid` مع مفتاح أجنبي (NO ACTION عمدًا: جلسة لها ابن لا تُحذف، وحذف المستخدم كله يمر لأن كل الصفوف تُحذف في عبارة واحدة، **وجُرِّب هذا فعلًا على PostgreSQL**) و`check (parent_session_id <> id)` وفهرسين فريدين جزئيين (`user_id where parent is null` و`parent_session_id where not null`). حارس `DO` يفشل برسالة واضحة إن لم يكن الجدول فارغًا. **طُبّق على القاعدة الحقيقية في 2026-10-25.** أُسقط تصميم بديل مدروس (عمود `users.last_session_id` للوصول O(1) وقراءة العميل له) لأنه مصدر حقيقة ثانٍ؛ يمكن إضافته لاحقًا إن احتاجه التطبيق.
2. **`supabase/functions/_shared/`** ✅ `auth.ts` و`body.ts` و`cors.ts` و`errors.ts` و`rate-limit.ts` و`apple.ts` و`log.ts` و`db.ts` و`engine/` (نسخة مولَّدة بايتًا ببايت بـ`scripts/sync-engine.ts`، ويفشل اختبار إن تقادمت). **قرارات:** (أ) **التوقيع تتحقق منه المنصة** (`verify_jwt = true`، حسب وثائق Supabase) ودالتنا تقرأ المطالبات فقط (`sub` UUID، `role = authenticated`، `aud`، `exp`، `nbf`) وتأخذ المستخدم من التوكن لا من الجسم؛ **لا تنشر الدوال بـ`verify_jwt` معطّلًا أبدًا** (اختبار يحرس `config.toml` فقط؛ وعند النشر عبر الموصّل مرّر `verify_jwt: true` صراحةً). فُضّل هذا على تحقق إضافي بـ`SUPABASE_JWKS` لأنه لا يمكن اختباره بتوكنات حقيقية هنا وخطؤه قد يمنع كل المستخدمين. (ب) **تثبيت المنطقة من جهة الطلب لا النشر:** رأس `x-region: ap-south-1` (أو `region` في `functions.invoke`، أو `forceFunctionRegion` في الرابط)؛ ولا يعاد التوجيه تلقائيًا إن تعطلت المنطقة فعلى عامل المزامنة إعادة المحاولة مرة بلا الرأس؛ و`x-region` ضمن رؤوس CORS المسموحة. (ج) محدّد المعدّل في ذاكرة العملية (فرامل لا حصة، لأن Supabase تشغّل عمليات كثيرة). (د) `db.ts`: اتصال واحد لكل عملية عبر `SUPABASE_DB_URL`، والسر الاختياري `DB_URL` يبدّله (مثلًا بمجمّع الاتصالات).
3. **`commit-session`** ✅ (`handler.ts` مُختبَر + `index.ts` رقيق): POST فقط، JSON فقط، حد الجسم 128KiB يُعدّ على التيار لا على `content-length`، حد المعدّل 30 في الدقيقة للمستخدم، ثم `parseSessionCommit` ثم `commitSession`. **شكل موحّد للإجابات:** نجاح `200 {ok:true, receipt}`، وفشل `{ok:false, error:{code, message, retryable, details?}}` مع جدول الأكواد والحالات في `supabase/functions/README.md` (400 بيانات سيئة، 401، 404، 409 تعارض مع حالة الخادم أو ترتيب، 413، 415، 426 تحديث التطبيق، 429 مع `Retry-After`، 500). الأخطاء الداخلية لا تُسرَّب للعميل وتُسجَّل في الخادم. السجلات معرّفات وأكواد وأزمنة فقط، **واختبار يثبت أن ما كتبه المستخدم لا يدخل السجل**. واختبار يضمن أن كل `RejectCode` جديد في المحرك له حالة HTTP.
4. **`delete-account`** ✅: يتحقق من التوكن، ويحذف المستخدم عبر `auth.admin.deleteUser` (supabase-js مثبّت على `2.106.1` وهو إصدار مؤكَّد التاريخ 2026-05-20) فتتولى سلاسل cascade الباقي. **انحرافان عن الخطة الأصلية:** (أ) يرجع `200` بجسم `{ok, appleRevocation, alreadyDeleted}` بدل `204` ليرى التطبيق ما حدث. (ب) **تدفق Apple** (مما تحققنا منه في وثائق Apple): إلغاء التوكن يحتاج توكنًا للمستخدم، فيطلب التطبيق من Apple **رمز تفويض جديدًا** قبل الحذف (نافذة Sign in with Apple عادية) ويرسله في `appleAuthorizationCode`؛ الدالة تبدّله بتوكنات (`/auth/token`) ثم تلغيها (`/auth/revoke`) بـ`client_secret` تولّده بتوقيع ES256 عبر Web Crypto (مختبَر بمفاتيح مولَّدة وبـApple مزيف)؛ بدون الرمز `400 apple_reauth_required`، ولو رفضته Apple `502 apple_revoke_failed` **دون حذف** والمحاولة قابلة للتكرار؛ ولو لم تُضبط أسرار Apple يمضي الحذف مع `skipped_not_configured` وتحذير في السجل. حذف حساب اختفى أصلًا نجاح (`alreadyDeleted`). الأسرار الأربعة كلها أو لا شيء (ضبط ناقص يفشل بصوت عالٍ عند الإقلاع). لا تحقق من أن الرمز يخص نفس حساب Apple المرتبط (من يبدّل حسابًا آخر يلغي توكنات نفسه فقط).
5. **تجميع محاولات الكتابة** ✅ (فوق).
6. **سكربتا العقد** ✅ جُرِّبا على القاعدة الحقيقية في 2026-10-25 (005: 79 من 79، 006: 15 من 15).
7. **النشر والتشغيل**: الدالتان ✅ منشورتان. الأسرار ⏳. المدقق ✅ بلا جديد. مطابقة `commit-session` ⏳.
**معيار الإنجاز:** الدالتان منشورتان بـ`verify_jwt` مفعّلًا ✅، و005 و006 تنجحان على القاعدة الحقيقية ✅، ومدقق Supabase بلا تنبيهات جديدة ✅.

### المرحلة 3: تحميل المحتوى في القاعدة (يحتاج المستخدم)
الملفات جاهزة: `supabase/seed/10_content_A1.sql … 13_content_B2.sql` (≈152 ك.ب لكل مستوى) و`supabase/seed/csv/*`. بدون كمبيوتر:
- **الأسهل من الجوال:** افتح كل ملف SQL كنص، انسخه كاملًا، الصقه في Supabase > SQL Editor (من متصفح الجوال) ثم Run، بالترتيب A1 ثم A2 ثم B1 ثم B2. إن رفض المحرر الحجم الكبير، قسّم الملف إلى أجزاء (اطلب من Claude توليد ملفات أصغر).
- **مع كمبيوتر أو GitHub Codespaces (متصفح):** `psql` كما في `supabase/seed/README.md`.
ثم يشغّل Claude `004_content_integrity.sql` عبر الموصّل: يجب أن تكون كل الصفوف `ok=true` (يتوقع 140 درسًا و2,800 كلمة و2,800 رابطًا).

### المرحلة 4: المصادقة (Auth)
1. أطفئ تسجيل الإيميل على المشروع المستضاف (Dashboard > Authentication)، وبدّل Site URL وRedirect URLs إلى القيم الصحيحة.
2. **Google (مجاني):** أنشئ في Google Cloud Console عميل OAuth Web (ومعه عملاء iOS وAndroid لاحقًا). أدخل Client IDs (الويب أولًا) والسر في Supabase > Providers > Google.
3. **Apple (مدفوع، لاحقًا):** يتطلب عضوية Apple Developer (99$ سنويًا). السر JWT يُجدَّد كل ≤6 أشهر. حتى ذلك الحين يُبنى الزر ولا يعمل.
4. بعد الإعداد: اختبر تسجيل الدخول فعليًا (ويب أولًا) وتأكد أن `handle_new_user` أنشأ الملف الشخصي.

### المرحلة 5: تطبيق Expo (≈80 ملفًا، بهذا الترتيب)
0. ابحث أولًا عن **إصدار Expo SDK الحالي** وأحدث توافق للحزم، ثم ثبّت الإصدارات.
1. **جذر المستودع:** `package.json` (workspaces) · `tsconfig.base.json` (strict + noUncheckedIndexedAccess) · `eslint.config.js` · `.prettierrc` · `.nvmrc` · `.gitignore` · `.env.example` (قيم عامة فقط).
2. **`apps/mobile` الإعدادات:** `app.config.ts` (يقرأ `EXPO_PUBLIC_*` إلى `extra`، `scheme: lingotrace`، `ios.usesAppleSignIn`، الـplugins) · `eas.json` (development/preview/production) · `metro.config.js` · `babel.config.js` (reanimated) · `tsconfig.json` · `jest.config.ts` + `jest.setup.ts`.
3. **`src/design/`:** `tokens.ts` (القيم الدقيقة من النموذج الأولي) · `typography.ts` (IBM Plex Sans Arabic عبر `@expo-google-fonts/ibm-plex-sans-arabic`) · `responsive.ts` (بديل `cqw`) · `rtl.ts` · `motion.ts`.
4. **`src/ui/`:** Text · Button · Card · ProgressBar · Screen · TabBar · Toast · `icons/` (مسارات SVG نفسها من النموذج عبر `react-native-svg`).
5. **`src/data/`:** `supabase/{client,env}.ts` (+ `database.types.ts` مولَّد بأداة generate_typescript_types) · `storage/{kv,asyncStorageKv,largeSecureStore,versioning}.ts` · `content/{bundled,remote,selectors}.ts` · `outbox/{queue,syncWorker,backoff,connectivity}.ts` (FIFO، `parent_session_id`، إعادة محاولة بتأخير متصاعد، NetInfo) · `repositories/*`. ولّد `assets/content/content.v1.json` من `packages/content`.
6. **`src/features/`** بالترتيب: `lesson` (الأهم: **`SpellingInput`** بـ`autoCorrect={false} autoCapitalize="none" spellCheck={false} autoComplete="off" importantForAutofill="no" textContentType="none"` ومعالجة الاقتراحات على أندرويد، `KeyboardLanguageGuard`، `speech.ts` بـ`expo-speech`) ثم `home` ثم `path` ثم `result` ثم `board` ثم `profile` ثم `auth` (`oauth.native.ts` بـ`@react-native-google-signin` و`expo-apple-authentication` مع `signInWithIdToken`، و`oauth.web.ts` بتحويل OAuth) ثم `settings` (شاشة تُعرض على المستخدم قبل البناء: تتضمن **Delete Account** بتأكيد كتابي، وسطر الاعتماد لـNGSL).
7. **المسارات `app/`:** `_layout.tsx` (خطوط، RTL، safe-area، query، بوابة الدخول، مزامنة) · `+html.tsx` (lang=ar dir=rtl، تسجيل SW) · `(auth)/sign-in.tsx` · `(tabs)/{index,board,me}.tsx` · `path/[levelCode].tsx` · `lesson/[lessonId]/{index,result}.tsx` · `settings.tsx` · `(legal)/{privacy,terms,delete-account}.tsx` (روابط عامة يطلبها المتجران).
8. **الويب/PWA:** `public/manifest.webmanifest` و`sw.js` و`_headers` (CSP وHSTS وnosniff) والأيقونات.
**معيار الإنجاز:** يبني `expo export -p web` بلا أخطاء، وتمر اختبارات jest، ويعمل درس كامل بلا إنترنت ثم يُزامَن.

### المرحلة 6: التحقق (يحتاج بيئة تشغيل)
- Claude لا يستطيع تشغيل Expo. المستخدم بلا كمبيوتر، فالخيارات: **GitHub Codespaces** (من متصفح الجوال)، أو جهاز مستعار لمرة واحدة، أو **EAS Build** السحابي مع تثبيت التطبيق على الجوال. اشرح الخطوات الدقيقة وقتها، وأعطِ المستخدم أوامر قصيرة ينسخها ويرسل لك مخرجاتها.
- `e2e/web/visual-parity.spec.ts` (Playwright): لقطات من `prototype/spelling-trainer.html` مقابل بناء الويب عند 360×800 و390×844 و768×1024 و1280×800، بحدّ تسامح. هذا هو إثبات "مطابق 100%" على الويب؛ على iOS/Android المطابقة بالقيم (ألوان/أحجام/خطوط) والفروق الصغيرة في تلوين النص طبيعية.
- `e2e/mobile/*.yaml` (Maestro): درس بلا إنترنت ثم مزامنة، تسجيل الدخول، حذف الحساب.
- `.github/workflows`: `ci.yml` (typecheck، lint، اختبارات، فحص SQL) · `visual-parity.yml` · `supabase-deploy.yml` · `web-deploy.yml` · `eas-build.yml`.

### المرحلة 7: الإطلاق والمتاجر
- صفحات الخصوصية والشروط ورابط حذف الحساب على الويب؛ نموذج Data Safety (Google) وملاحظات المراجعة (Apple).
- **مراجعة عربية بشرية** لكل المعاني والترجمات (كتبها Claude).
- اعتماد NGSL (CC BY-SA 4.0) داخل التطبيق (الإعدادات > حول). تأكد من الترخيص الحالي في newgeneralservicelist.org.
- الاستضافة: الويب كملفات ثابتة (Cloudflare Pages أو Netlify أو Vercel، مجانية).

### المرحلة 8: تصليب وتشغيل
- تحديد معدل الطلبات للمتصدرين (أي مستخدم مسجّل يستطيع تصفّح اللوحة كاملة) والدوال، وCORS، ورؤوس الأمان.
- جدول تجميع يومي للـXP إذا كبرت المتصدرون الأسبوعية/الشهرية.
- تجديد سر Apple كل 6 أشهر، ونسخ احتياطي دوري (`pg_dump` من اتصال مباشر)، ومتابعة مدقق Supabase بعد وجود مستخدمين حقيقيين.
- C1: قائمة الكلمات يقدّمها المستخدم لاحقًا (يُضاف مستوى بنفس خط المحتوى).

---

## 8. مخاطر وأسئلة مفتوحة

- **تكاليف المتاجر (غير مجانية):** عضوية Apple Developer **99$ سنويًا**، ولا يعمل Sign in with Apple بحساب Apple مجاني؛ وGoogle Play **25$ مرة واحدة**. المسار المجاني: الويب/PWA + تسجيل Google، وأندرويد عبر APK مباشر بلا Play. أبقِ زر Apple مبنيًا لكنه غير مفعّل حتى قرار الدفع.
- **الخطة المجانية لـSupabase:** تُوقَف المشاريع الخاملة بعد أسبوع عادةً ويلزم تفعيلها يدويًا، وقاعدة 500MB. مناسبة للتطوير، ولا تُعتمد للإنتاج دون ترقية بقرار المستخدم (راجع الأسعار الحالية وقتها).
- **المنطقة:** لا يوجد خليج في Supabase؛ اخترنا مومباي. قِس الزمن الفعلي من الخليج وقارن مع فرانكفورت قبل الإطلاق.
- **ترتيب الجلسات بلا إنترنت:** حُلّ بسلسلة `parent_session_id` (مكتوبة، لم تُطبَّق بعد). **حدود معروفة للتصميم:** (1) جلسة رُفضت نهائيًا في وسط الصف (مثلًا `replay_failed`) لا تدخل السلسلة، فما بعدها من جلسات عمل العميل على حالة محلية ملوّثة بها وسيُرفض غالبًا: على عامل المزامنة في المرحلة 5 أن يعيد مزامنة الحالة من الخادم ويتخلى عن الجلسات الأحدث غير المرسلة. (2) جهازان يلعبان بلا إنترنت في وقت واحد: الثاني يصله `out_of_order` ومعه رأس السلسلة، لكن حالته المحلية قديمة فيُرجَّح رفض جلسته. (3) جهاز جديد أو إعادة تثبيت: يتعلم الرأس من إجابة `out_of_order` (لا يستطيع العميل قراءة `lesson_sessions`). الفحص الحاسم يبقى إعادة التشغيل نفسها، فالسلسلة لتحسين الرسائل والترتيب لا للأمان.
- **مفتاح العرض:** تأكد قبل البناء من تسمية مفاتيح Supabase الحالية (publishable/anon) في لوحة المشروع، واستخدم الاسم الصحيح في `.env.example`.
- **معرّف الحزمة (bundle id / package name):** قرار مطلوب من المستخدم (مثل `com.اسمك.lingotrace`) لأنه يدخل في إعدادات Google وApple.
- **الاسم العام ونطاق الويب:** غير محسومين.
- **مراجعة المحتوى العربي** مطلوبة قبل الإطلاق.
- لم يُشغَّل شيء على أجهزة iOS/Android ولا على Expo أبدًا: كل كود التطبيق القادم **غير مُجرَّب** حتى يُشغَّل خارج بيئة Claude.
- **تعليقات قديمة في وحدات مُنسوخة** (تُركت عمدًا لتبقى الملفات مطابقة بايتًا للأصل المُختبَر): `queue-builder.ts` السطران 48 و131 يذكران دالة SQL `fn_due_mistakes()` وهي **غير موجودة** في مخطط Supabase الجديد (المرجع الحقيقي هو `PgRepo.loadDueMistakes`، ويحرس تطابقه `pg-repo.test.ts`)، و`types.ts` السطران 23 و66 يذكران جدول `words` بدل `vocabulary_bank`. تعليقات فقط بلا أثر على السلوك؛ صحّحها عند أول تعديل مقصود على هذه الملفات.
- **اختبارات خط المحتوى لم تُنقل:** `packages/content/src/content-import.ts` منقول (يختلف سطر استيراد واحد) لكن اختباراته الأصلية (`content-import` 14 و`data` 6 و`ngsl` 8 في `spelling-core/test/`) تعتمد على سكربتات قديمة لم تُنقل (`seed-sql.ts` و`ngsl.ts`)، فالتغطية الحالية هي `export.test.ts` (9) وسكربت `004_content_integrity.sql` فقط. قرّر لاحقًا ما يلزم نقله.
- **ESLint للحدّ بين العميل والخادم** (القسم 4) ما زال مؤجلًا للمرحلة 5؛ لكن الجانب الأول من الحدّ (مدخل العميل نقي) يحرسه الآن `boundaries.test.ts`. الجانب الآخر (التطبيق لا يستورد `/server`) يحتاج القاعدة.
- **المنطقة:** تُثبَّت بكل طلب (`x-region: ap-south-1`) وليست إعدادًا ثابتًا للدالة. بدونها تعمل الدالة قرب المتصل فتتحول عشرون جولة إلى القاعدة في مومباي إلى جولات عابرة للمناطق. قِس الزمن الفعلي من الخليج.
- **حدود محدّد المعدّل:** في ذاكرة كل عملية فلا يحدّ إلا العميل الذي يكرر. الحماية الحقيقية: التوكن الإلزامي والإعادة الآمنة (idempotency) وإعادة التشغيل التي ترفض ما لا يتبع القواعد والجداول المغلقة. إن لزمت حصة صارمة فجدول عدّادات في القاعدة (قرار لاحق).
- **افتراضات غير مُتحقَّقة** (لا شيء هنا شغّل Deno بطلب فعلي): واجهة `deno-postgres` v0.17.0 (`Pool(url, 1, true)` و`queryObject({text, args})`)؛ شكل أخطاء `auth.admin.deleteUser` في supabase-js 2.106.1 (`status` 404 أو `code: 'user_not_found'`)؛ سلوك `verify_jwt` على المنصة؛ نقاط Apple الحقيقية؛ CORS في متصفح؛ وصحة التصريحات البديلة في `tests/functions/shims.d.ts`. **تحقّق منه النشر:** المنصة قبلت أسماء `../_shared/...` وحزمة `npm:` المثبّتة واستيراد `deno.land/x/postgres` وبنت الحزمتين. **ونُقل نص `commit-session` يدويًا فلم تُقارَن النسخة المنشورة بالمستودع بعد.** الباقي يظهر عند أول استدعاء حقيقي.
- **اتصالات القاعدة:** اتصال واحد لكل عملية Edge عبر `SUPABASE_DB_URL` (مباشر). إن كثر المستخدمون وضاقت الاتصالات المباشرة فاضبط السر `DB_URL` على عنوان مجمّع المعاملات (لا تغيير في الشيفرة).
- **التوقف التلقائي للمشروع (الخطة المجانية):** ظهر فعلًا (القسم 3). **يتوقف بعد أسبوع كامل بلا أي نشاط، وليس «كل أسبوع»:** طلبات التطبيق واتصالات القاعدة تُحسب نشاطًا، فمشروع عليه مستخدمون بانتظام لا يتوقف عادةً (مصادر خارجية 2026؛ الصفحة الرسمية تقول إن المشاريع المجانية تتوقف بعد أسبوع من عدم النشاط، ولم نتحقق من تعريفها الدقيق للنشاط). **المخاطر الحقيقية:** (1) **مراجعة المتجر:** لو صادف أسبوع بلا طلبات فترة مراجعة التطبيق فسيبدو معطّلًا وقد يُرفض؛ (2) الأسابيع الأولى بعد الإطلاق إن قلّ المستخدمون؛ (3) **لا نسخ احتياطية في الخطة المجانية** (0 أيام). **الموصى به قبل التقديم للمتاجر:** خطة Pro (نحو 25$ شهريًا في مصادر 2026؛ تحقق من السعر الحالي): لا توقف بسبب الخمول ومعها نسخ احتياطية لـ7 أيام. بديل أضعف: طلب دوري يُبقي المشروع نشطًا (يحتاج جدولة خارجية ولا تضمنه Supabase). القرار قرارك لأن القيد الأصلي «لا تكلفة».
