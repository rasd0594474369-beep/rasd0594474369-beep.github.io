// Builds dist-site/ for GitHub Pages: the web app (web/) + PWA files (manifest, service worker, icons) + the connection check page + the privacy and terms pages.
// Only Node built-ins are used. Usage: node scripts/build-site.mjs [output-dir]
import { copyFileSync, mkdirSync, rmSync, readdirSync, statSync, existsSync } from 'node:fs';

const out = process.argv[2] ?? 'dist-site';
rmSync(out, { recursive: true, force: true });
mkdirSync(out, { recursive: true });

const files = [];
for (const f of readdirSync('web')) {
  if (statSync(`web/${f}`).isFile()) { copyFileSync(`web/${f}`, `${out}/${f}`); files.push(f); } // index.html, auth.js, ...
}
if (!files.includes('index.html')) throw new Error('web/index.html is missing');
copyFileSync('site-placeholder/index.html', `${out}/check.html`);
// Legal pages live in web/legal/<name>.html and are published as directory indexes: /privacy/ and /terms/ (GitHub Pages redirects /privacy to /privacy/).
const legal = ['privacy', 'terms'];
for (const name of legal) {
  if (!existsSync(`web/legal/${name}.html`)) throw new Error(`web/legal/${name}.html is missing`);
  mkdirSync(`${out}/${name}`, { recursive: true });
  copyFileSync(`web/legal/${name}.html`, `${out}/${name}/index.html`);
}
for (const f of ['manifest.webmanifest', 'sw.js', 'icon-192.png', 'icon-512.png', 'icon-maskable-512.png', 'apple-touch-icon.png']) {
  copyFileSync(`site-placeholder/${f}`, `${out}/${f}`);
}
console.log(`built ${out}: ${files.join(', ')}, check.html, ${legal.map((n) => n + '/').join(', ')}, manifest, sw.js, icons`);
