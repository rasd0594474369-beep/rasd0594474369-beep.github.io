// End-to-end check of the web app in real Chromium with a fake Supabase (run it in Claude's sandbox: Playwright is global there).
// Usage: node web/e2e/auth.e2e.mjs <dist-dir> [port]
import { createRequire } from 'node:module';
import { createServer } from 'node:http';
import { readFileSync, existsSync } from 'node:fs';
import { extname, join } from 'node:path';
const require = createRequire('/home/claude/.npm-global/lib/node_modules/');
const { chromium } = require('playwright');

const dir = process.argv[2] ?? 'dist-site';
const port = Number(process.argv[3] ?? 8771);
const SB = 'https://yvszergcvjnzpogubqex.supabase.co';
const types = { '.html': 'text/html', '.js': 'text/javascript', '.png': 'image/png', '.webmanifest': 'application/manifest+json' };
const server = createServer((req, res) => {
  const path = decodeURIComponent(new URL(req.url, 'http://x').pathname);
  // like GitHub Pages: /privacy answers 301 -> /privacy/ when privacy/index.html exists
  if (path !== '/' && !path.endsWith('/') && !extname(path) && existsSync(join(dir, path, 'index.html'))) { res.writeHead(301, { location: path + '/' }); return res.end(); }
  const p = join(dir, path.replace(/\/$/, '/index.html'));
  if (!existsSync(p)) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { 'content-type': types[extname(p)] ?? 'application/octet-stream' }); res.end(readFileSync(p));
}).listen(port);
const ORIGIN = `http://localhost:${port}`;

let fails = 0;
const check = (name, ok, extra = '') => { console.log(ok ? 'PASS' : 'FAIL', name, extra); if (!ok) fails++; };
const cors = { 'access-control-allow-origin': '*', 'access-control-allow-headers': '*', 'access-control-allow-methods': '*' };
const calls = [];
async function fakeSupabase(ctx, { user = { id: 'u1', email: 'sara@example.com', user_metadata: { full_name: 'Sara A' } }, authorizeTo = null, refreshStatus = 200 } = {}) {
  await ctx.route(SB + '/**', async (route) => {
    const r = route.request(), u = new URL(r.url());
    calls.push(r.method() + ' ' + u.pathname + u.search);
    if (r.method() === 'OPTIONS') return route.fulfill({ status: 204, headers: cors });
    if (u.pathname === '/auth/v1/authorize') {
      const back = u.searchParams.get('redirect_to');
      return route.fulfill({ status: 302, headers: { location: authorizeTo ?? back + '#access_token=AT1&refresh_token=RT1&expires_in=3600&token_type=bearer' } });
    }
    if (u.pathname === '/auth/v1/user') return route.fulfill({ status: 200, headers: { ...cors, 'content-type': 'application/json' }, body: JSON.stringify(user) });
    if (u.pathname === '/auth/v1/token') return route.fulfill({ status: refreshStatus, headers: { ...cors, 'content-type': 'application/json' }, body: JSON.stringify(refreshStatus === 200 ? { access_token: 'AT2', refresh_token: 'RT2', expires_in: 3600 } : { error: 'invalid_grant' }) });
    if (u.pathname === '/auth/v1/logout') return route.fulfill({ status: 204, headers: cors });
    return route.fulfill({ status: 200, headers: { ...cors, 'content-range': '0-0/1' }, body: '[]' });
  });
}
const browser = await chromium.launch();
const newCtx = () => browser.newContext({ viewport: { width: 390, height: 844 }, locale: 'ar', deviceScaleFactor: 2, isMobile: true, hasTouch: true });
const watch = (page) => { const errs = []; page.on('pageerror', (e) => errs.push('pageerror: ' + e.message)); page.on('console', (m) => { if (m.type() === 'error' && !/fonts\.(googleapis|gstatic)|ERR_|Failed to load resource/.test(m.text())) errs.push('console: ' + m.text()); }); return errs; };
const openProfile = async (page) => { await page.click('nav button[data-t=me]'); await page.waitForTimeout(150); };

// 1) signed out: the profile tab offers Google sign-in
{
  const ctx = await newCtx(); await fakeSupabase(ctx); const page = await ctx.newPage(); const errs = watch(page);
  await page.goto(ORIGIN + '/'); await page.waitForSelector('#app *');
  await openProfile(page);
  check('signed out: login button shown', (await page.locator('button.open', { hasText: 'Google' }).count()) === 1);
  await page.screenshot({ path: '/tmp/e2e-signedout.png' });

  // 2) press login -> fake Google/Supabase -> back with tokens in the hash -> profile tab shows the account
  await page.click('button.open >> text=Google');
  await page.waitForFunction(() => document.body.innerText.includes('Sara A'), null, { timeout: 8000 });
  check('after the redirect: name and email shown', (await page.innerText('#app')).includes('sara@example.com'));
  check('after sign-in the profile tab is open', (await page.locator('nav button.on').getAttribute('data-t')) === 'me');
  check('tokens removed from the URL', !(await page.evaluate(() => location.hash)) && !page.url().includes('access_token'));
  const stored = await page.evaluate(() => JSON.parse(localStorage.getItem('lingotrace-auth-v1')));
  check('session stored (access + refresh)', stored.access_token === 'AT1' && stored.refresh_token === 'RT1');
  await page.screenshot({ path: '/tmp/e2e-signedin.png' });

  // 3) reload: still signed in, no login button
  await page.reload(); await page.waitForSelector('#app *'); await openProfile(page);
  check('reload keeps the session', (await page.innerText('#app')).includes('Sara A'));

  // 4) sign out
  await page.click('button >> text=تسجيل الخروج');
  await page.waitForFunction(() => !!document.querySelector('button.open'));
  check('sign out: back to the login button + storage cleared', (await page.evaluate(() => localStorage.getItem('lingotrace-auth-v1'))) === null);
  check('logout hit the server with scope=local', calls.some((c) => c.startsWith('POST /auth/v1/logout?scope=local')));
  check('no JS errors (flow 1-4)', errs.length === 0, errs.join(' | '));
  await ctx.close();
}
// 5) an expired stored session is refreshed on start
{
  const ctx = await newCtx(); await fakeSupabase(ctx); const page = await ctx.newPage(); const errs = watch(page);
  await page.addInitScript(() => { if (!localStorage.getItem('lingotrace-auth-v1')) localStorage.setItem('lingotrace-auth-v1', JSON.stringify({ access_token: 'OLD', refresh_token: 'RT0', expires_at: 1, user: { id: 'u1', email: 'cached@example.com', name: 'Cached', avatar: null } })); });
  calls.length = 0;
  await page.goto(ORIGIN + '/'); await page.waitForSelector('#app *'); await page.waitForTimeout(500); await openProfile(page);
  check('expired session: refresh then user reload', calls.some((c) => c.includes('/auth/v1/token?grant_type=refresh_token')) && (await page.innerText('#app')).includes('Sara A'));
  check('new tokens saved', (await page.evaluate(() => JSON.parse(localStorage.getItem('lingotrace-auth-v1')).access_token)) === 'AT2');
  check('no JS errors (refresh)', errs.length === 0, errs.join(' | '));
  await ctx.close();
}
// 6) refresh rejected -> signed out with a message
{
  const ctx = await newCtx(); await fakeSupabase(ctx, { refreshStatus: 400 }); const page = await ctx.newPage();
  await page.addInitScript(() => { localStorage.setItem('lingotrace-auth-v1', JSON.stringify({ access_token: 'OLD', refresh_token: 'BAD', expires_at: 1, user: null })); });
  await page.goto(ORIGIN + '/'); await page.waitForSelector('#app *'); await page.waitForTimeout(500); await openProfile(page);
  const txt = await page.innerText('#app');
  check('rejected refresh: login button + message', txt.includes('سجّل الدخول من جديد') && (await page.locator('button.open').count()) === 1);
  await ctx.close();
}
// 7) cancelled Google sign-in: error shown, app fine
{
  const ctx = await newCtx(); await fakeSupabase(ctx, { authorizeTo: ORIGIN + '/#error=access_denied&error_description=Access+denied' }); const page = await ctx.newPage(); const errs = watch(page);
  await page.goto(ORIGIN + '/'); await page.waitForSelector('#app *'); await openProfile(page);
  await page.click('button.open >> text=Google');
  await page.waitForFunction(() => document.body.innerText.includes('Access denied'), null, { timeout: 8000 });
  check('cancelled login: message shown on the profile tab', (await page.locator('nav button.on').getAttribute('data-t')) === 'me');
  check('no JS errors (cancel)', errs.length === 0, errs.join(' | '));
  await ctx.close();
}
// 8) offline with a stored session: profile still shows the cached account, lessons still open
{
  const ctx = await newCtx(); await fakeSupabase(ctx); const page = await ctx.newPage(); const errs = watch(page);
  await page.addInitScript(() => { if (!localStorage.getItem('lingotrace-auth-v1')) localStorage.setItem('lingotrace-auth-v1', JSON.stringify({ access_token: 'AT', refresh_token: 'RT', expires_at: 9999999999, user: { id: 'u1', email: 'cached@example.com', name: 'Cached', avatar: null } })); });
  await page.goto(ORIGIN + '/'); await page.waitForSelector('#app *'); await page.evaluate(() => navigator.serviceWorker.ready); await page.reload(); await page.waitForTimeout(400);
  await ctx.setOffline(true);
  await page.reload({ waitUntil: 'domcontentloaded' }); await page.waitForSelector('#app *'); await page.waitForTimeout(400); await openProfile(page);
  // the account was refreshed from the (fake) server on the earlier online load, so offline shows that last known name
  check('offline: last known account shown, no login button', (await page.innerText('#app')).includes('Sara A') && (await page.locator('button.open').count()) === 0);
  await page.click('nav button[data-t=home]'); await page.click('.open'); await page.waitForTimeout(300);
  check('offline: lesson map opens', (await page.innerText('#app')).includes('ابدأ'));
  check('no JS errors (offline)', errs.length === 0, errs.join(' | '));
  await ctx.close();
}
// 9) regression: the lesson itself still works (type the first word right, see progress move)
{
  const ctx = await newCtx(); await fakeSupabase(ctx); const page = await ctx.newPage(); const errs = watch(page);
  await page.goto(ORIGIN + '/'); await page.waitForSelector('#app *');
  await page.click('.open'); await page.waitForSelector('.nd.cu'); await page.click('.nd.cu'); await page.waitForSelector('#in');
  const w1 = await page.evaluate(() => S.q[0].w.text);
  await page.fill('#in', w1); await page.press('#in', 'Enter');
  await page.waitForFunction((w) => S && S.q[0] && S.step === 1 || S.done >= 1, w1, { timeout: 8000 });
  check('lesson: correct word accepted and the item advances', await page.evaluate(() => S.step === 1 || S.done >= 1));
  check('no JS errors (lesson)', errs.length === 0, errs.join(' | '));
  await ctx.close();
}
// 10) legal pages: linked from the profile tab, reachable at the exact URLs registered in Google Cloud, load nothing external, link back
{
  const ctx = await newCtx(); await fakeSupabase(ctx); const page = await ctx.newPage(); const errs = watch(page);
  const external = [];
  page.on('request', (r) => { if (/^\/(privacy|terms)\//.test(new URL(page.url()).pathname) && !r.url().startsWith(ORIGIN)) external.push(r.url()); });
  await page.goto(ORIGIN + '/'); await page.waitForSelector('#app *'); await openProfile(page);
  check('signed out: terms and privacy links shown', (await page.locator('#app a[href="terms/"]').count()) === 1 && (await page.locator('#app a[href="privacy/"]').count()) === 1);
  await page.goto(ORIGIN + '/privacy'); // exactly what was typed in Google Cloud
  check('/privacy redirects to /privacy/ and shows the policy', new URL(page.url()).pathname === '/privacy/' && (await page.locator('h1').innerText()) === 'سياسة الخصوصية');
  check('privacy page shows the contact email', (await page.innerText('main')).includes('rasd0594474369@gmail.com'));
  await page.screenshot({ path: '/tmp/e2e-privacy.png' });
  await page.click('header a:has-text("العودة إلى التطبيق")'); await page.waitForSelector('#app *');
  check('back link returns to the app', new URL(page.url()).pathname === '/');
  await openProfile(page); await page.click('#app a[href="terms/"]'); await page.waitForSelector('h1');
  check('terms link opens /terms/', new URL(page.url()).pathname === '/terms/' && (await page.locator('h1').innerText()) === 'شروط الاستخدام');
  await page.screenshot({ path: '/tmp/e2e-terms.png' });
  await page.click('footer a:has-text("سياسة الخصوصية")'); await page.waitForSelector('h1');
  check('terms footer links to the privacy page', new URL(page.url()).pathname === '/privacy/');
  await page.goto(ORIGIN + '/terms'); check('/terms redirects to /terms/', new URL(page.url()).pathname === '/terms/');
  check('legal pages requested nothing from other origins', external.length === 0, external.join(' '));
  check('no JS errors (legal)', errs.length === 0, errs.join(' | '));
  await ctx.close();
}
await browser.close(); server.close();
console.log(fails === 0 ? 'ALL PASS' : fails + ' FAILED');
process.exit(fails ? 1 : 0);
