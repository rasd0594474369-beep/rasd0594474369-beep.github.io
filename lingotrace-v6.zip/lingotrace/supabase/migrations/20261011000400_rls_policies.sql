-- =============================================================================
-- 20261011000400_rls_policies.sql
-- Row level security on EVERY table. The model:
--   content (levels, lessons, vocabulary_bank, lesson_words): anyone may read what is published.
--   own data (users, user_progress, user_word_stats, misspelled_words): read your own rows only.
--     users may also update their own row (the columns allowed are limited by the grants migration).
--   internal (lesson_sessions, session_attempts, xp_events): RLS on and no policy = no client access.
--   Progress is written ONLY by the commit-session Edge Function (a direct owner connection that
--   bypasses RLS), so XP, streaks and rankings can never be forged from a client.
-- (select auth.uid()) is evaluated once per statement instead of once per row.
-- Keep this file plain ASCII.
-- =============================================================================

alter table public.levels            enable row level security;
alter table public.lessons           enable row level security;
alter table public.vocabulary_bank   enable row level security;
alter table public.lesson_words      enable row level security;
alter table public.users             enable row level security;
alter table public.user_progress     enable row level security;
alter table public.user_word_stats   enable row level security;
alter table public.misspelled_words  enable row level security;
alter table public.lesson_sessions   enable row level security;
alter table public.session_attempts  enable row level security;
alter table public.xp_events         enable row level security;

-- --- content: public read ------------------------------------------------------

create policy levels_read on public.levels
  for select to anon, authenticated using (true);

create policy vocabulary_bank_read on public.vocabulary_bank
  for select to anon, authenticated using (true);

create policy lessons_read_published on public.lessons
  for select to anon, authenticated using (is_published);

create policy lesson_words_read_published on public.lesson_words
  for select to anon, authenticated
  using (exists (select 1 from public.lessons l where l.id = lesson_words.lesson_id and l.is_published));

-- --- own data -------------------------------------------------------------------

create policy users_select_own on public.users
  for select to authenticated using (id = (select auth.uid()));

create policy users_update_own on public.users
  for update to authenticated
  using (id = (select auth.uid()))
  with check (id = (select auth.uid()));

create policy user_progress_select_own on public.user_progress
  for select to authenticated using (user_id = (select auth.uid()));

create policy user_word_stats_select_own on public.user_word_stats
  for select to authenticated using (user_id = (select auth.uid()));

create policy misspelled_words_select_own on public.misspelled_words
  for select to authenticated using (user_id = (select auth.uid()));
