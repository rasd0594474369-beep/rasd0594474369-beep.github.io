-- =============================================================================
-- 20261011000200_functions_triggers.sql
-- Trigger functions: updated_at, the XP ledger, time zone validation, and the profile row that
-- is created when a person signs up. Every function pins search_path (no search-path hijacking).
-- Keep this file plain ASCII.
-- =============================================================================

-- --- updated_at ---------------------------------------------------------------

create function public.set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at := now();
  return new;
end $$;

create trigger users_set_updated_at
  before update on public.users
  for each row execute function public.set_updated_at();

create trigger user_word_stats_set_updated_at
  before update on public.user_word_stats
  for each row execute function public.set_updated_at();


-- --- XP ledger -> users.total_xp ----------------------------------------------
-- The only way total_xp ever changes. Runs with the rights of whoever inserts the event
-- (commit-session, connected as the owner); a client has no INSERT right on xp_events at all.

create function public.trg_xp_events_apply()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  update public.users set total_xp = total_xp + new.amount where id = new.user_id;
  return null;
end $$;

create trigger xp_events_apply
  after insert on public.xp_events
  for each row execute function public.trg_xp_events_apply();


-- --- time zone must be a real IANA name ----------------------------------------
-- The streak is "one lesson per calendar day in the user's own time zone": an invalid zone
-- would crash the engine at commit time, so refuse it where it is written.

create function public.validate_user_time_zone()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  if not exists (select 1 from pg_catalog.pg_timezone_names n where n.name = new.time_zone) then
    raise exception 'unknown IANA time zone: %', new.time_zone using errcode = '22023';
  end if;
  return new;
end $$;

create trigger users_validate_time_zone
  before insert or update of time_zone on public.users
  for each row execute function public.validate_user_time_zone();


-- --- profile row for every new auth user ---------------------------------------
-- SECURITY DEFINER because it is fired by the auth service. The display name is public on the
-- leaderboard, so it is NEVER the e-mail address (Apple "hide my e-mail" gives a relay address).

create function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_name text;
begin
  v_name := left(btrim(coalesce(
    nullif(btrim(new.raw_user_meta_data ->> 'full_name'), ''),
    nullif(btrim(new.raw_user_meta_data ->> 'name'), ''),
    'Learner')), 40);
  insert into public.users (id, display_name) values (new.id, v_name) on conflict (id) do nothing;
  return new;
end $$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();
