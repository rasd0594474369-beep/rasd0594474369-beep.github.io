-- =============================================================================
-- 20261011000700_internal_tables_deny_policies.sql
-- Internal tables (lesson_sessions, session_attempts, xp_events) are written by the commit-session
-- Edge Function only (a direct owner connection bypasses RLS). A RESTRICTIVE policy is ANDed with every
-- permissive policy, so even if a permissive policy (or a grant) is added by mistake later, clients
-- still cannot touch these tables. It also documents the intent and keeps the Supabase advisor quiet.
-- Keep this file plain ASCII.
-- =============================================================================

create policy deny_clients on public.lesson_sessions
  as restrictive for all to anon, authenticated using (false) with check (false);

create policy deny_clients on public.session_attempts
  as restrictive for all to anon, authenticated using (false) with check (false);

create policy deny_clients on public.xp_events
  as restrictive for all to anon, authenticated using (false) with check (false);
