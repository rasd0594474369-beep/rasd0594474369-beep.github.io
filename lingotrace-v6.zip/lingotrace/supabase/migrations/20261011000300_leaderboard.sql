-- =============================================================================
-- 20261011000300_leaderboard.sql
-- Dynamic ranking, computed on demand (nothing is stored, so it can never go stale).
--   get_leaderboard(period, limit, offset)  one page of the board
--   get_my_rank(period)                     my rank, my place in the page order, and the players count
-- period: 'all' (total XP) | 'week' (last 7 days) | 'month' (last 30 days).
-- SECURITY DEFINER because clients cannot read other people's rows; the functions expose ONLY a
-- display name, a score and a rank (never an id or e-mail), and only for people who opted in.
-- Ties share a rank; paging order is score, then sign-up date, then id, so pages never overlap.
-- Keep this file plain ASCII.
-- =============================================================================

create function public.get_leaderboard(p_period text default 'all', p_limit int default 50, p_offset int default 0)
returns table (rank_no bigint, display_name text, score bigint, is_me boolean)
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  v_me     uuid := (select auth.uid());
  v_limit  int  := least(greatest(coalesce(p_limit, 50), 1), 100);
  v_offset int  := greatest(coalesce(p_offset, 0), 0);
  v_since  timestamptz;
begin
  if p_period = 'all' then
    return query
      select rank() over (order by u.total_xp desc), u.display_name, u.total_xp, coalesce(u.id = v_me, false)
      from public.users u
      where u.show_on_leaderboard and u.total_xp > 0
      order by u.total_xp desc, u.created_at, u.id
      limit v_limit offset v_offset;
  elsif p_period in ('week', 'month') then
    v_since := now() - (case p_period when 'week' then interval '7 days' else interval '30 days' end);
    return query
      with windowed as (
        select e.user_id, sum(e.amount)::bigint as s
        from public.xp_events e
        where e.created_at >= v_since
        group by e.user_id
        having sum(e.amount) > 0
      )
      select rank() over (order by w.s desc), u.display_name, w.s, coalesce(u.id = v_me, false)
      from windowed w
      join public.users u on u.id = w.user_id and u.show_on_leaderboard
      order by w.s desc, u.created_at, u.id
      limit v_limit offset v_offset;
  else
    raise exception 'unknown period "%": use all, week or month', p_period using errcode = '22023';
  end if;
end $$;

-- No row at all when the caller has no score in the period or has hidden themselves.
-- position_no is the caller's 1-based place in the get_leaderboard order: ask for
-- offset = position_no - 1 - radius to show the rows around "you".
create function public.get_my_rank(p_period text default 'all')
returns table (rank_no bigint, score bigint, position_no bigint, players bigint)
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  v_me      uuid := (select auth.uid());
  v_since   timestamptz;
  v_score   bigint;
  v_created timestamptz;
begin
  if v_me is null then
    return;
  end if;

  if p_period = 'all' then
    select u.total_xp, u.created_at into v_score, v_created
    from public.users u
    where u.id = v_me and u.show_on_leaderboard;
    if not found or v_score <= 0 then
      return;
    end if;
    return query
      select 1 + count(*) filter (where o.total_xp > v_score),
             v_score,
             1 + count(*) filter (where o.total_xp > v_score
                                  or (o.total_xp = v_score and (o.created_at, o.id) < (v_created, v_me))),
             count(*)
      from public.users o
      where o.show_on_leaderboard and o.total_xp > 0;
  elsif p_period in ('week', 'month') then
    v_since := now() - (case p_period when 'week' then interval '7 days' else interval '30 days' end);
    return query
      with windowed as (
        select e.user_id, sum(e.amount)::bigint as s
        from public.xp_events e
        where e.created_at >= v_since
        group by e.user_id
        having sum(e.amount) > 0
      ),
      visible as (
        select w.user_id, w.s, u.created_at
        from windowed w
        join public.users u on u.id = w.user_id and u.show_on_leaderboard
      ),
      me as (
        select v.s, v.created_at from visible v where v.user_id = v_me
      )
      select 1 + count(*) filter (where v.s > me.s),
             me.s,
             1 + count(*) filter (where v.s > me.s
                                  or (v.s = me.s and (v.created_at, v.user_id) < (me.created_at, v_me))),
             count(*)
      from visible v
      cross join me
      group by me.s, me.created_at;
  else
    raise exception 'unknown period "%": use all, week or month', p_period using errcode = '22023';
  end if;
end $$;
