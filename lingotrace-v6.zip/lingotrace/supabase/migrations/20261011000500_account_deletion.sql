-- =============================================================================
-- 20261011000500_account_deletion.sql
-- Account deletion (App Store 5.1.1(v) and Google Play require in-app deletion that really
-- erases the person's data).
--
-- The cascade chain is defined inline in 20261011000100_core_schema.sql:
--
--   auth.users --cascade--> public.users --cascade--> user_progress
--                                         --cascade--> user_word_stats
--                                         --cascade--> misspelled_words
--                                         --cascade--> xp_events
--                                         --cascade--> lesson_sessions --cascade--> session_attempts
--
-- Shared content (levels, lessons, vocabulary_bank, lesson_words) is never touched.
-- Clients cannot delete anything: the delete-account Edge Function revokes the Apple token and
-- deletes the auth user with the service role, and the chain above does the rest.
--
-- v_account_deletion_gaps is the safety net. It lists every table that would KEEP personal rows
-- after a deletion, so adding a table and forgetting its cascade shows up here. It must be empty
-- (supabase/tests/database checks it; the SQLite twin tests check the chain itself).
-- Keep this file plain ASCII.
-- =============================================================================

create view public.v_account_deletion_gaps
with (security_invoker = true)
as
  -- every table with a user_id column must cascade from public.users
  select c.relname::text as table_name,
         'user_id has no ON DELETE CASCADE foreign key to public.users'::text as problem
  from pg_catalog.pg_class c
  join pg_catalog.pg_namespace n on n.oid = c.relnamespace and n.nspname = 'public'
  join pg_catalog.pg_attribute a on a.attrelid = c.oid and a.attname = 'user_id' and not a.attisdropped
  where c.relkind in ('r', 'p')
    and not exists (
      select 1 from pg_catalog.pg_constraint k
      where k.conrelid = c.oid and k.contype = 'f' and k.confdeltype = 'c'
        and k.confrelid = 'public.users'::regclass and k.conkey = array[a.attnum]
    )
  union all
  -- the profile must cascade from the auth user
  select 'users', 'id has no ON DELETE CASCADE foreign key to auth.users'
  where not exists (
    select 1 from pg_catalog.pg_constraint k
    where k.conrelid = 'public.users'::regclass and k.contype = 'f' and k.confdeltype = 'c'
      and k.confrelid = 'auth.users'::regclass
  )
  union all
  -- rows hanging off a session must follow it (cascade) or be detached from it (set null)
  select c.relname::text, 'session_id has no ON DELETE CASCADE / SET NULL foreign key to lesson_sessions'
  from pg_catalog.pg_class c
  join pg_catalog.pg_namespace n on n.oid = c.relnamespace and n.nspname = 'public'
  join pg_catalog.pg_attribute a on a.attrelid = c.oid and a.attname = 'session_id' and not a.attisdropped
  where c.relkind in ('r', 'p')
    and not exists (
      select 1 from pg_catalog.pg_constraint k
      where k.conrelid = c.oid and k.contype = 'f' and k.confdeltype in ('c', 'n')
        and k.confrelid = 'public.lesson_sessions'::regclass and k.conkey = array[a.attnum]
    );
