-- =============================================================================
-- 20261011000600_grants_lockdown.sql
-- Closed by default, then open exactly what the app needs. RLS (previous migration) decides WHICH
-- rows; these grants decide WHICH tables, columns and functions the API roles may touch at all.
-- Roles: anon = not signed in, authenticated = signed in. service_role gets nothing: the Edge
-- Functions connect directly as the owner, and the auth admin API needs no table rights.
-- Keep this file plain ASCII.
-- =============================================================================

-- --- 1. start closed -----------------------------------------------------------

revoke all on all tables    in schema public from anon, authenticated, service_role;
revoke all on all sequences in schema public from anon, authenticated, service_role;
revoke all on all functions in schema public from public, anon, authenticated, service_role;

-- objects created by later migrations start closed too
alter default privileges in schema public revoke all on tables    from anon, authenticated, service_role;
alter default privileges in schema public revoke all on sequences from anon, authenticated, service_role;
alter default privileges in schema public revoke all on functions from public, anon, authenticated, service_role;

-- --- 2. content: public read -----------------------------------------------------

grant select on public.levels, public.lessons, public.vocabulary_bank, public.lesson_words to anon, authenticated;

-- --- 3. own data: read only ------------------------------------------------------
-- (the offline queue is built on the device from user_word_stats, hence the read access)

grant select on public.users, public.user_progress, public.user_word_stats, public.misspelled_words to authenticated;

-- the ONLY columns a client may change; total_xp, streak_count and the rest stay server-only
grant update (display_name, tts_locale, time_zone, show_on_leaderboard) on public.users to authenticated;

-- --- 4. leaderboard ---------------------------------------------------------------

grant execute on function public.get_leaderboard(text, int, int) to authenticated;
grant execute on function public.get_my_rank(text) to authenticated;

-- Not granted on purpose: lesson_sessions, session_attempts, xp_events (internal), the trigger
-- functions, and v_account_deletion_gaps (operators only).
