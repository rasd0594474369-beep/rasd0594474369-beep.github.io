-- =============================================================================
-- 20261011000100_core_schema.sql
-- LingoTrace core schema for Supabase (PostgreSQL 15+).
--
--   1  content    levels, lessons, vocabulary_bank, lesson_words      read-only for clients
--   2  profiles   users                                              1:1 with auth.users
--   3  progress   user_progress, user_word_stats, misspelled_words   written only by commit-session
--   4  sessions   lesson_sessions, session_attempts, xp_events       audit log + XP ledger
--
-- Account deletion: every user-owned table cascades from public.users, and public.users cascades
-- from auth.users, so deleting the auth user removes everything that belongs to that person.
-- Triggers and functions, the leaderboard, RLS policies, the deletion safety net and the grants
-- live in the next migrations. Keep this file plain ASCII.
-- =============================================================================


-- --- 1. CONTENT ---------------------------------------------------------------

create table public.levels (
  code      text     primary key check (code in ('A1', 'A2', 'B1', 'B2', 'C1')),
  ordinal   smallint not null unique check (ordinal between 1 and 5),
  title     text     not null,
  -- Global frequency band shown on the home card; filled by the content seed.
  rank_from int,
  rank_to   int,
  check ((rank_from is null) = (rank_to is null)),
  check (rank_from is null or (rank_from >= 1 and rank_to >= rank_from))
);

insert into public.levels (code, ordinal, title) values
  ('A1', 1, 'Beginner'),
  ('A2', 2, 'Elementary'),
  ('B1', 3, 'Intermediate'),
  ('B2', 4, 'Upper-Intermediate'),
  ('C1', 5, 'Advanced');

create table public.lessons (
  id            uuid     primary key default gen_random_uuid(),
  level_code    text     not null references public.levels (code),
  lesson_number smallint not null check (lesson_number >= 1),
  -- Dense 1..N order across ALL levels. It is the clock of the spaced-repetition system:
  -- user_word_stats.due_seq is compared with it. Assign once and never renumber played lessons.
  global_seq    int      not null check (global_seq >= 1),
  is_published  boolean  not null default false,
  unique (level_code, lesson_number),
  constraint lessons_global_seq_key unique (global_seq)
);

-- One row per spelling item (the "vocabulary bank"). error_weight is deliberately NOT here:
-- this table is shared by every user, the weight is per user and lives in user_word_stats.
create table public.vocabulary_bank (
  id               uuid        primary key default gen_random_uuid(),
  word_text        text        not null check (btrim(word_text) <> '' and char_length(word_text) <= 64),
  sentence_context text        not null check (btrim(sentence_context) <> '' and char_length(sentence_context) <= 300),
  meaning_ar       text        check (meaning_ar is null or char_length(meaning_ar) <= 60),
  sentence_ar      text        check (sentence_ar is null or char_length(sentence_ar) between 1 and 300),
  level_code       text        references public.levels (code),
  freq_rank        int         check (freq_rank >= 1),
  created_at       timestamptz not null default now()
);
-- One row per spelling, case-insensitive. Drop this index if you ever need homographs.
create unique index vocabulary_bank_word_text_uq on public.vocabulary_bank (lower(word_text));
create index vocabulary_bank_level_idx on public.vocabulary_bank (level_code, freq_rank);

create table public.lesson_words (
  lesson_id uuid     not null references public.lessons (id) on delete cascade,
  position  smallint not null check (position between 1 and 20),
  word_id   uuid     not null references public.vocabulary_bank (id),
  primary key (lesson_id, position),
  unique (lesson_id, word_id)
);
create index lesson_words_word_idx on public.lesson_words (word_id);


-- --- 2. PROFILES --------------------------------------------------------------

-- The profile row of an auth user (same id). Created by a trigger on auth.users, never by the client.
create table public.users (
  id                  uuid        primary key references auth.users (id) on delete cascade,
  display_name        text        not null check (char_length(btrim(display_name)) between 1 and 40),
  tts_locale          text        not null default 'en-US' check (tts_locale in ('en-US', 'en-GB')),
  -- Maintained by the xp_events trigger. Clients can never write it.
  total_xp            bigint      not null default 0 check (total_xp >= 0),
  -- Streak = calendar day in the user's own time zone (IANA name from the device).
  streak_count        int         not null default 0 check (streak_count >= 0),
  longest_streak      int         not null default 0 check (longest_streak >= 0),
  last_active_date    date,
  time_zone           text        not null default 'UTC' check (char_length(time_zone) between 1 and 64),
  -- The public leaderboard shows display names, so appearing there is the user's choice.
  show_on_leaderboard boolean     not null default true,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now()
);
create index users_leaderboard_idx on public.users (total_xp desc, created_at, id) where show_on_leaderboard;


-- --- 3. PROGRESS --------------------------------------------------------------

-- One row per user and lesson: completion, attempts and accuracy (scores / analytics).
create table public.user_progress (
  user_id            uuid        not null references public.users (id) on delete cascade,
  lesson_id          uuid        not null references public.lessons (id) on delete cascade,
  first_completed_at timestamptz,                       -- null = started, never finished
  completions        int         not null default 0 check (completions >= 0),
  best_accuracy      smallint    check (best_accuracy between 0 and 100),   -- clean words / total words, percent
  last_accuracy      smallint    check (last_accuracy between 0 and 100),
  last_played_at     timestamptz not null default now(),
  primary key (user_id, lesson_id)
);
create index user_progress_lesson_idx on public.user_progress (lesson_id);

-- Spaced-repetition state: one row per user and word that was failed twice. This IS the
-- "error_weight" of the product brief. The engine reads and writes it (packages/engine).
create table public.user_word_stats (
  user_id           uuid        not null references public.users (id) on delete cascade,
  word_id           uuid        not null references public.vocabulary_bank (id) on delete cascade,
  error_weight      int         not null default 0 check (error_weight >= 0),
  status            text        not null default 'active' check (status in ('active', 'mastered')),
  -- Eligible for injection into any lesson whose global_seq >= due_seq (failed in lesson 2 -> due 4).
  due_seq           int,
  lifetime_failures int         not null default 0 check (lifetime_failures >= 0),
  last_failed_at    timestamptz,
  last_reviewed_at  timestamptz,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  primary key (user_id, word_id),
  constraint rotation_state_valid check (
    (status = 'active'   and error_weight >= 1 and due_seq is not null) or
    (status = 'mastered' and error_weight = 0  and due_seq is null)
  )
);
create index user_word_stats_due_idx on public.user_word_stats (user_id, due_seq) where status = 'active';

-- The exact wrong spellings a user typed, and how often: "recieve" x 4, "recive" x 1 ...
-- typed is stored the way the engine normalizes it (trimmed, lower-case). Every wrong attempt of the
-- word step counts, in first runs and in replays. Rows are upserted by commit-session only.
create table public.misspelled_words (
  user_id       uuid        not null references public.users (id) on delete cascade,
  word_id       uuid        not null references public.vocabulary_bank (id) on delete cascade,
  typed         text        not null check (char_length(typed) between 1 and 100),
  occurrences   int         not null default 1 check (occurrences >= 1),
  first_seen_at timestamptz not null default now(),
  last_seen_at  timestamptz not null default now(),
  primary key (user_id, word_id, typed),
  check (last_seen_at >= first_seen_at)
);
create index misspelled_words_user_freq_idx on public.misspelled_words (user_id, occurrences desc, last_seen_at desc);


-- --- 4. SESSIONS AND XP LEDGER ------------------------------------------------

create table public.lesson_sessions (
  id                 uuid        primary key,           -- generated by the client: committing twice is harmless
  user_id            uuid        not null references public.users (id) on delete cascade,
  lesson_id          uuid        not null references public.lessons (id),
  mode               text        not null check (mode in ('first_run', 'replay')),
  started_at         timestamptz not null,              -- client clock
  completed_at       timestamptz not null,              -- client clock
  committed_at       timestamptz not null default now(), -- server clock: when the session reached us
  words_total        smallint    not null check (words_total >= 0),
  words_clean        smallint    not null check (words_clean >= 0),
  words_failed_twice smallint    not null check (words_failed_twice >= 0),
  xp_earned          int         not null default 0 check (xp_earned >= 0),
  check (completed_at >= started_at)
);
create index lesson_sessions_user_idx on public.lesson_sessions (user_id, completed_at desc);
create index lesson_sessions_lesson_idx on public.lesson_sessions (lesson_id);

-- Append-only log of every typed attempt, 1:1 with AttemptLog in packages/engine. Prune or
-- partition by time if it grows: misspelled_words keeps the lasting aggregate.
create table public.session_attempts (
  session_id uuid     not null references public.lesson_sessions (id) on delete cascade,
  n          smallint not null,                          -- order inside the session
  word_id    uuid     not null references public.vocabulary_bank (id),
  origin     text     not null check (origin in ('lesson', 'injected', 'immediate_review')),
  step       text     not null check (step in ('word', 'sentence')),
  attempt_no smallint not null check (attempt_no >= 1),
  typed      text     not null check (char_length(typed) <= 500),
  distance   smallint not null check (distance >= 0),
  verdict    text     not null check (verdict in ('exact', 'minor', 'major')),
  used_peek  boolean  not null default false,
  primary key (session_id, n)
);
create index session_attempts_word_idx on public.session_attempts (word_id);

-- users.total_xp is the sum of this ledger, kept in sync by a trigger (next migration).
create table public.xp_events (
  id         bigint      generated always as identity primary key,
  user_id    uuid        not null references public.users (id) on delete cascade,
  session_id uuid        references public.lesson_sessions (id) on delete set null,
  reason     text        not null check (reason in ('words_first_try', 'words_recovered', 'lesson_bonus', 'adjustment')),
  amount     int         not null check (amount <> 0),
  created_at timestamptz not null default now()
);
create index xp_events_user_idx on public.xp_events (user_id, created_at desc);
create index xp_events_created_idx on public.xp_events (created_at);                 -- weekly / monthly leaderboards
create index xp_events_session_idx on public.xp_events (session_id) where session_id is not null;

comment on table public.vocabulary_bank is 'Shared word list. sentence_ar and meaning_ar are the Arabic texts shown in the lesson.';
comment on table public.user_word_stats is 'Spaced-repetition state per user and word (error_weight, due_seq). Written by commit-session only.';
comment on table public.misspelled_words is 'Exact wrong spellings per user and word with their frequency. Written by commit-session only.';
comment on column public.misspelled_words.typed is 'Wrong spelling as normalized by the engine (trimmed, lower-case).';
