-- =============================================================================
-- 20261022000100_session_chain.sql
-- Puts the sessions of each user in one chain, so that lessons played offline reach the server
-- in the order they were played (FIFO).
--
-- Why: the server replays every lesson against the user's rotation state (user_word_stats) as it is at
-- commit time. A lesson played after another one used that lesson's outcome (which words were due),
-- so if it arrived first the server would rebuild a different queue than the app played and would
-- reject a valid session. parent_session_id names the session the app played just before this one
-- (NULL for the user's first). The commit-session function accepts a session only when its parent is
-- the head of the chain (the last session committed for that user); otherwise it answers 409
-- "out_of_order" together with the head, and the app sends its outbox in order.
--
-- What the database guarantees on its own: a user has at most ONE root (parent NULL), a session has at
-- most ONE child, and no session is its own parent. So the sessions of a user always form a single line.
-- The foreign key keeps the default NO ACTION on purpose: a session that has a child cannot be deleted,
-- while deleting the whole user (cascade) still works because every row goes in the same statement.
--
-- Assumes no session has been committed yet (true today: the database holds no users). The guard below
-- fails with a clear message otherwise, instead of failing later on the unique index.
-- Keep this file plain ASCII.
-- =============================================================================

do $$
begin
  if exists (select 1 from public.lesson_sessions) then
    raise exception 'lesson_sessions is not empty: backfill parent_session_id in committed_at order before adding the chain indexes';
  end if;
end
$$;

alter table public.lesson_sessions
  add column parent_session_id uuid references public.lesson_sessions (id) check (parent_session_id <> id);

comment on column public.lesson_sessions.parent_session_id is
  'The session this user played just before this one (NULL for the first). Sessions of a user form one chain; the head is the session nobody names as parent.';

create unique index lesson_sessions_root_uidx on public.lesson_sessions (user_id) where parent_session_id is null;
create unique index lesson_sessions_parent_uidx on public.lesson_sessions (parent_session_id) where parent_session_id is not null;
