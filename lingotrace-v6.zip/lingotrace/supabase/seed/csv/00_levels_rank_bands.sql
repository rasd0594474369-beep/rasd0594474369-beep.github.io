-- Run once after importing the CSV files (the dashboard import cannot update the levels table).
update public.levels set rank_from = 1, rank_to = 700 where code = 'A1';
update public.levels set rank_from = 701, rank_to = 1400 where code = 'A2';
update public.levels set rank_from = 1401, rank_to = 2100 where code = 'B1';
update public.levels set rank_from = 2101, rank_to = 2800 where code = 'B2';
