# Loading the content (2,800 words, 140 lessons)

Generated from `packages/content/data` by `npm run export:supabase` in `packages/content`. Never edit these files by hand.

| File | What it is |
|---|---|
| `10_content_A1.sql` ... `13_content_B2.sql` | one SQL seed per level: rank band, lessons, vocabulary_bank, lesson_words. Upserts with fixed ids, so running them again changes nothing. `supabase db reset` runs them locally through `config.toml`. |
| `csv/01_lessons.csv`, `02_vocabulary_bank.csv`, `03_lesson_words.csv` | the same data for the dashboard's CSV import |
| `csv/00_levels_rank_bands.sql` | four `update` lines (the CSV import cannot update the levels table) |

## Option A - SQL with psql (recommended)

Needs `psql` and the **direct** connection string of the project (Dashboard > Connect). A UTF-8 client is required:
the Arabic texts are stored as they are.

```bash
export PGCLIENTENCODING=UTF8          # PowerShell: $env:PGCLIENTENCODING = "UTF8"
for f in supabase/seed/1?_content_*.sql; do psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -q -f "$f"; done
```

## Option B - dashboard CSV import (no tools to install)

1. Table Editor > `lessons` > Insert > import data from CSV > `csv/01_lessons.csv`
2. the same for `vocabulary_bank` with `csv/02_vocabulary_bank.csv`
3. the same for `lesson_words` with `csv/03_lesson_words.csv`  (this order matters: it points at the other two)
4. SQL Editor: paste and run `csv/00_levels_rank_bands.sql`

The CSV import only inserts. Importing a file twice fails on duplicate ids: clear the tables in the reverse order
(`lesson_words`, `vocabulary_bank`, `lessons`) and start again.

## Then check it

Run `supabase/tests/database/004_content_integrity.sql` (psql or SQL Editor). Every row must say `ok = true`.
It catches the classic import failures: a lesson with fewer than 20 words, a sentence without its word, and
Arabic turned into question marks by a non-UTF-8 client.

## The easiest route from a phone: `content.json` through Storage

`content.json` (about 875 KB) holds everything in one file: the four level rank bands, 140 lessons, 2,800 words (with the Arabic
meaning and sentence translation) and the 2,800 lesson-word links. It is generated from the same source as the SQL and CSV files
(`node packages/content/scripts/export-supabase.ts`), and a test fails if it ever differs from them or from the committed copy.

1. In the Supabase dashboard: Storage, New bucket, name `seed`, turn **Public bucket** on, upload `content.json`.
2. Run `20_import_content_from_storage.sql` once (SQL editor, or `execute_sql`). The database downloads the file itself, in ONE
   transaction: it loads the rank bands, lessons, words and links with the same upserts as the `1x_content_*.sql` files, checks
   how many rows each step touched, and removes the temporary `http` extension it needed. All or nothing, safe to run again.
3. Expect 140 lessons, 2,800 words, 2,800 links. Then run `tests/database/004_content_integrity.sql` and delete the bucket `seed`.

Tried on the real database: the logic with a small sample (rolled back) and the download path (the extension installs and reaches
the project's own Storage; before the upload it answers "Bucket not found"). Not tried yet: the full file, which needs the upload.

