-- =============================================================================
-- 20_import_content_from_storage.sql
-- Loads content.json (140 lessons, 2,800 words and their links, plus the level rank bands) into levels, lessons,
-- vocabulary_bank and lesson_words in ONE transaction. This is the easy route from a phone: upload content.json to a
-- PUBLIC Storage bucket named "seed" (Storage > New bucket > name "seed" > Public bucket on > upload the file), run
-- this whole file once (SQL editor, or execute_sql), then delete the bucket "seed".
--
-- It is all-or-nothing: if the file is not there, a count does not match or a constraint fails, nothing is written and
-- nothing stays installed. It is safe to run again (upserts with fixed ids, the same ones as the 1x_content_*.sql files).
-- The download is done by the "http" extension (schema extensions): created here when it is not installed, dropped
-- before the commit when this script created it. The address below is THIS project's; change it for another project.
-- For a dry run on a small sample set the session setting seed.content_json to the JSON text first (it replaces the download).
-- Needs the owner role. Keep this file plain ASCII.
-- =============================================================================
begin;

do $$
declare
  url constant text := 'https://yvszergcvjnzpogubqex.supabase.co/storage/v1/object/public/seed/content.json';
  had_http boolean := exists (select 1 from pg_extension where extname = 'http');
  raw text;
  resp record;
  doc jsonb;
  expected int;
  affected int;
begin
  raw := nullif(current_setting('seed.content_json', true), '');
  if raw is null then
    if not had_http then
      execute 'create extension http with schema extensions';
    end if;
    perform extensions.http_set_curlopt('CURLOPT_TIMEOUT', '60');
    resp := extensions.http_get(url);
    if resp.status <> 200 then
      raise exception 'could not download content.json (HTTP %): is the bucket "seed" public and content.json uploaded?', resp.status;
    end if;
    raw := resp.content;
  end if;

  doc := raw::jsonb;
  if doc->>'version' is distinct from '1' then
    raise exception 'unexpected content.json version: %', doc->>'version';
  end if;

  -- the frequency-rank band of each level
  update public.levels l
     set rank_from = b.rank_from, rank_to = b.rank_to
    from jsonb_to_recordset(doc->'rank_bands') as b(code text, rank_from int, rank_to int)
   where l.code = b.code;
  get diagnostics affected = row_count;
  expected := jsonb_array_length(doc->'rank_bands');
  if affected <> expected then raise exception 'rank bands: updated % of % levels', affected, expected; end if;

  insert into public.lessons (id, level_code, lesson_number, global_seq, is_published)
  select l.id, l.level_code, l.lesson_number, l.global_seq, l.is_published
    from jsonb_to_recordset(doc->'lessons') as l(id uuid, level_code text, lesson_number int, global_seq int, is_published boolean)
  on conflict (id) do update set
    level_code = excluded.level_code, lesson_number = excluded.lesson_number,
    global_seq = excluded.global_seq, is_published = excluded.is_published;
  get diagnostics affected = row_count;
  expected := jsonb_array_length(doc->'lessons');
  if affected <> expected then raise exception 'lessons: wrote % of % rows', affected, expected; end if;

  insert into public.vocabulary_bank (id, word_text, sentence_context, meaning_ar, sentence_ar, level_code, freq_rank)
  select w.id, w.word_text, w.sentence_context, w.meaning_ar, w.sentence_ar, w.level_code, w.freq_rank
    from jsonb_to_recordset(doc->'words') as w(id uuid, word_text text, sentence_context text, meaning_ar text, sentence_ar text, level_code text, freq_rank int)
  on conflict (id) do update set
    word_text = excluded.word_text, sentence_context = excluded.sentence_context, meaning_ar = excluded.meaning_ar,
    sentence_ar = excluded.sentence_ar, level_code = excluded.level_code, freq_rank = excluded.freq_rank;
  get diagnostics affected = row_count;
  expected := jsonb_array_length(doc->'words');
  if affected <> expected then raise exception 'words: wrote % of % rows', affected, expected; end if;

  insert into public.lesson_words (lesson_id, position, word_id)
  select (e->>0)::uuid, (e->>1)::int, (e->>2)::uuid
    from jsonb_array_elements(doc->'lesson_words') as e
  on conflict (lesson_id, position) do update set word_id = excluded.word_id;
  get diagnostics affected = row_count;
  expected := jsonb_array_length(doc->'lesson_words');
  if affected <> expected then raise exception 'lesson_words: wrote % of % rows', affected, expected; end if;

  if not had_http and raw is not null and exists (select 1 from pg_extension where extname = 'http') then
    execute 'drop extension http';
  end if;
end $$;

-- what the database holds now (a full import gives 140, 2800, 2800)
select (select count(*) from public.lessons) as lessons,
       (select count(*) from public.vocabulary_bank) as words,
       (select count(*) from public.lesson_words) as links,
       exists (select 1 from pg_extension where extname = 'http') as http_still_installed;
commit;
