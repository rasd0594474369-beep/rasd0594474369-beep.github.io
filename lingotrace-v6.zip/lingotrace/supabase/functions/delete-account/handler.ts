/**
 * POST /functions/v1/delete-account : permanently deletes the signed-in user's account and everything attached to it.
 *
 * Order of work:
 *   1. If the user signed in with Apple, revoke their Apple tokens first (an Apple requirement). That needs a fresh
 *      authorization code from the app (`appleAuthorizationCode`): without one we ask for it (400 apple_reauth_required);
 *      if Apple refuses, nothing is deleted and the app can simply try again (502 apple_revoke_failed).
 *   2. Delete the user in Supabase Auth. The foreign keys cascade to every table that holds their data
 *      (a test and a database view keep that list honest).
 *
 * Deleting an account that is already gone counts as success, so a retry after a lost response is harmless.
 * The user id comes from the token only.
 */

import type { AppleConfig } from '../_shared/apple.ts';
import type { Authenticate } from '../_shared/auth.ts';
import { isJsonContentType, parseJson, readBodyLimited } from '../_shared/body.ts';
import { corsHeaders, preflightResponse } from '../_shared/cors.ts';
import type { CorsPolicy } from '../_shared/cors.ts';
import { errorResponse, jsonResponse } from '../_shared/errors.ts';
import type { ErrorCode } from '../_shared/errors.ts';
import { describeError } from '../_shared/log.ts';
import type { LogFn } from '../_shared/log.ts';
import type { RateLimiter } from '../_shared/rate-limit.ts';

export const MAX_DELETE_BODY_BYTES = 4 * 1024;
const MAX_APPLE_CODE_LENGTH = 2048;

export type AppleRevocation = 'not_linked' | 'revoked' | 'skipped_not_configured';

export interface DeleteHandlerDeps {
  authenticate: Authenticate;
  limiter: RateLimiter;
  cors: CorsPolicy;
  now: () => Date;
  log: LogFn;
  /** null = Sign in with Apple is not set up on the server. */
  apple: AppleConfig | null;
  /** Exchanges the code for tokens and revokes them; throws when Apple does not accept. */
  revokeApple: (config: AppleConfig, authorizationCode: string) => Promise<void>;
  deleteUser: (userId: string) => Promise<'deleted' | 'not_found'>;
}

export function createDeleteAccountHandler(deps: DeleteHandlerDeps): (req: Request) => Promise<Response> {
  return async (req) => {
    const cors = corsHeaders(deps.cors, req.headers.get('origin'));
    const fail = (code: ErrorCode, message: string, extra: { headers?: Record<string, string>; retryAfterSeconds?: number } = {}) =>
      errorResponse(code, message, { ...extra, headers: { ...cors, ...extra.headers } });

    try {
      if (req.method === 'OPTIONS') return preflightResponse(deps.cors, req);
      if (req.method !== 'POST') return fail('method_not_allowed', 'use POST', { headers: { allow: 'POST, OPTIONS' } });

      const auth = deps.authenticate(req);
      if (!auth.ok) {
        deps.log('warn', 'auth_rejected', { reason: auth.reason });
        return fail('unauthenticated', 'missing or invalid sign-in token');
      }
      const user = auth.user;

      const rate = deps.limiter.check(user.id);
      if (!rate.allowed) {
        deps.log('warn', 'rate_limited', { userId: user.id });
        return fail('rate_limited', 'too many requests, wait a moment', { retryAfterSeconds: rate.retryAfterSeconds });
      }

      // The body is optional: only Apple users need to send something.
      const body = await readBodyLimited(req, MAX_DELETE_BODY_BYTES);
      if (!body.ok) {
        return body.reason === 'too_large'
          ? fail('payload_too_large', `the request body may be at most ${MAX_DELETE_BODY_BYTES} bytes`)
          : fail('invalid_json', 'the request body is not valid UTF-8 JSON');
      }
      let authorizationCode: string | null = null;
      if (body.text.trim() !== '') {
        if (!isJsonContentType(req.headers.get('content-type'))) return fail('unsupported_media_type', 'send application/json');
        const json = parseJson(body.text);
        if (!json.ok || typeof json.value !== 'object' || json.value === null || Array.isArray(json.value)) return fail('invalid_json', 'the request body must be a JSON object');
        const code = (json.value as Record<string, unknown>).appleAuthorizationCode;
        if (code !== undefined) {
          if (typeof code !== 'string' || code.length < 1 || code.length > MAX_APPLE_CODE_LENGTH) return fail('bad_request', 'appleAuthorizationCode must be a short text');
          authorizationCode = code;
        }
      }

      let appleRevocation: AppleRevocation = 'not_linked';
      if (user.providers.includes('apple')) {
        if (deps.apple === null) {
          appleRevocation = 'skipped_not_configured';
          deps.log('warn', 'apple_not_configured', { userId: user.id });
        } else {
          if (authorizationCode === null) return fail('apple_reauth_required', 'ask Apple for a fresh authorization code and send it as appleAuthorizationCode');
          try {
            await deps.revokeApple(deps.apple, authorizationCode);
            appleRevocation = 'revoked';
          } catch (e) {
            const stage = (e as { stage?: unknown }).stage;
            const status = (e as { status?: unknown }).status;
            deps.log('error', 'apple_revoke_failed', { userId: user.id, stage: typeof stage === 'string' ? stage : null, status: typeof status === 'number' ? status : null });
            return fail('apple_revoke_failed', 'Apple did not accept the revocation; nothing was deleted, try again');
          }
        }
      }

      const result = await deps.deleteUser(user.id);
      deps.log('info', 'account_deleted', { userId: user.id, appleRevocation, alreadyDeleted: result === 'not_found' });
      return jsonResponse(200, { ok: true, appleRevocation, alreadyDeleted: result === 'not_found' }, cors);
    } catch (e) {
      deps.log('error', 'delete_failed', { error: describeError(e) });
      return fail('internal', 'something went wrong on our side, try again later');
    }
  };
}
