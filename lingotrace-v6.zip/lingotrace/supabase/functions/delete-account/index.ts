// Deno entry point for delete-account. All behaviour is in handler.ts (tested in Node); this file only wires the real
// dependencies. Deploy with verify_jwt = true (config.toml).
//
// supabase-js is pinned to an exact release (2.106.1, published 2026-05-20) so a deploy never picks up a new version
// by surprise; raise it deliberately.
import { createClient } from 'npm:@supabase/supabase-js@2.106.1';
import { appleConfigFromEnv, revokeAppleAccess } from '../_shared/apple.ts';
import { createAuthenticator } from '../_shared/auth.ts';
import { corsPolicyFromEnv } from '../_shared/cors.ts';
import { logJson } from '../_shared/log.ts';
import { createRateLimiter } from '../_shared/rate-limit.ts';
import { createDeleteAccountHandler } from './handler.ts';

const supabaseUrl = Deno.env.get('SUPABASE_URL');
const secretKey = (JSON.parse(Deno.env.get('SUPABASE_SECRET_KEYS') ?? '{}') as Record<string, string>)['default'] ?? Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
if (!supabaseUrl || !secretKey) throw new Error('SUPABASE_URL and a secret key (SUPABASE_SECRET_KEYS or SUPABASE_SERVICE_ROLE_KEY) are required');
const admin = createClient(supabaseUrl, secretKey, { auth: { persistSession: false, autoRefreshToken: false } });

Deno.serve(
  createDeleteAccountHandler({
    authenticate: createAuthenticator(),
    // Deleting an account is rare and final: 5 attempts per hour and user is plenty.
    limiter: createRateLimiter({ limit: 5, windowMs: 3_600_000 }),
    cors: corsPolicyFromEnv(Deno.env.get('ALLOWED_ORIGINS')),
    now: () => new Date(),
    log: logJson,
    apple: appleConfigFromEnv((name) => Deno.env.get(name)),
    revokeApple: (config, code) => revokeAppleAccess(config, code, { fetch, nowSeconds: () => Math.floor(Date.now() / 1000) }),
    deleteUser: async (userId) => {
      const { error } = await admin.auth.admin.deleteUser(userId);
      if (!error) return 'deleted';
      if (error.status === 404 || error.code === 'user_not_found') return 'not_found';
      throw error;
    },
  }),
);
