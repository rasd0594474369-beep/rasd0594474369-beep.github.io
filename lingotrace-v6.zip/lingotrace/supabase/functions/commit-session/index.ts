// Deno entry point for commit-session. All behaviour is in handler.ts (tested in Node); this file only wires the real
// dependencies. Deploy with verify_jwt = true (config.toml): the platform checks the token signature before this runs.
import { PgRepo } from '../_shared/engine/server/index.ts';
import { createAuthenticator } from '../_shared/auth.ts';
import { corsPolicyFromEnv } from '../_shared/cors.ts';
import { sqlPool } from '../_shared/db.ts';
import { logJson } from '../_shared/log.ts';
import { createRateLimiter } from '../_shared/rate-limit.ts';
import { createCommitHandler } from './handler.ts';

Deno.serve(
  createCommitHandler({
    authenticate: createAuthenticator(),
    repo: new PgRepo(sqlPool),
    // 30 per minute and user: an app coming back online sends its queued lessons one after another.
    limiter: createRateLimiter({ limit: 30, windowMs: 60_000 }),
    cors: corsPolicyFromEnv(Deno.env.get('ALLOWED_ORIGINS')),
    now: () => new Date(),
    log: logJson,
  }),
);
