/**
 * POST /functions/v1/commit-session : the app reports a finished lesson, the server replays it and records the result.
 *
 * This file is the HTTP layer only. Everything that decides whether a session is valid and what it earns lives in the
 * engine (`planCommit` / `commitSession`); this layer authenticates, bounds, parses, maps the outcome to a status code
 * and keeps secrets out of the answer. Dependencies are passed in, so the whole flow runs in Node's tests.
 *
 * The user id comes from the token and nowhere else: the body is parsed into a clean object that has no user field.
 */

import { commitSession, parseSessionCommit } from '../_shared/engine/server/index.ts';
import type { CommitRepo } from '../_shared/engine/server/index.ts';
import type { Authenticate } from '../_shared/auth.ts';
import { isJsonContentType, parseJson, readBodyLimited } from '../_shared/body.ts';
import { corsHeaders, preflightResponse } from '../_shared/cors.ts';
import type { CorsPolicy } from '../_shared/cors.ts';
import { errorResponse, jsonResponse } from '../_shared/errors.ts';
import type { ErrorCode } from '../_shared/errors.ts';
import { describeError } from '../_shared/log.ts';
import type { LogFn } from '../_shared/log.ts';
import type { RateLimiter } from '../_shared/rate-limit.ts';

/** A busy lesson is a few tens of KB; this leaves room and still stops a body built to waste memory. */
export const MAX_COMMIT_BODY_BYTES = 128 * 1024;

export interface CommitHandlerDeps {
  authenticate: Authenticate;
  repo: CommitRepo;
  limiter: RateLimiter;
  cors: CorsPolicy;
  now: () => Date;
  log: LogFn;
  maxBodyBytes?: number;
}

export function createCommitHandler(deps: CommitHandlerDeps): (req: Request) => Promise<Response> {
  const maxBytes = deps.maxBodyBytes ?? MAX_COMMIT_BODY_BYTES;

  return async (req) => {
    const started = deps.now().getTime();
    const cors = corsHeaders(deps.cors, req.headers.get('origin'));
    const fail = (code: ErrorCode, message: string, extra: { headers?: Record<string, string>; details?: Record<string, unknown>; retryAfterSeconds?: number } = {}) =>
      errorResponse(code, message, { ...extra, headers: { ...cors, ...extra.headers } });

    try {
      if (req.method === 'OPTIONS') return preflightResponse(deps.cors, req);
      if (req.method !== 'POST') return fail('method_not_allowed', 'use POST', { headers: { allow: 'POST, OPTIONS' } });

      const auth = deps.authenticate(req);
      if (!auth.ok) {
        deps.log('warn', 'auth_rejected', { reason: auth.reason });
        return fail('unauthenticated', 'missing or invalid sign-in token');
      }
      const userId = auth.user.id;

      const rate = deps.limiter.check(userId);
      if (!rate.allowed) {
        deps.log('warn', 'rate_limited', { userId });
        return fail('rate_limited', 'too many requests, wait a moment', { retryAfterSeconds: rate.retryAfterSeconds });
      }

      if (!isJsonContentType(req.headers.get('content-type'))) return fail('unsupported_media_type', 'send application/json');

      const body = await readBodyLimited(req, maxBytes);
      if (!body.ok) {
        return body.reason === 'too_large'
          ? fail('payload_too_large', `the request body may be at most ${maxBytes} bytes`)
          : fail('invalid_json', 'the request body is not valid UTF-8 JSON');
      }
      const json = parseJson(body.text);
      if (!json.ok) return fail('invalid_json', 'the request body is not valid JSON');

      const parsed = parseSessionCommit(json.value);
      if (!parsed.ok) return fail('bad_request', parsed.message);
      const commit = parsed.value;

      const outcome = await commitSession(deps.repo, userId, commit, deps.now());
      const ms = deps.now().getTime() - started;
      if (outcome.ok) {
        deps.log('info', 'commit', { userId, sessionId: commit.sessionId, status: outcome.receipt.status, xp: outcome.receipt.xpEarned, ms });
        return jsonResponse(200, { ok: true, receipt: outcome.receipt }, cors);
      }
      deps.log('info', 'commit_rejected', { userId, sessionId: commit.sessionId, code: outcome.code, ms });
      return fail(outcome.code, outcome.message, outcome.details ? { details: outcome.details } : {});
    } catch (e) {
      deps.log('error', 'commit_failed', { error: describeError(e), ms: deps.now().getTime() - started });
      return fail('internal', 'something went wrong on our side, try again later');
    }
  };
}
