# supabase/functions

Two Edge Functions and what they share. Everything here except the two `index.ts` entry points and `_shared/db.ts`
(the only files that touch Deno) is plain TypeScript with web-standard APIs, so it is tested in Node.

```
commit-session/   handler.ts (HTTP layer, tested)   index.ts (Deno wiring)
delete-account/   handler.ts (HTTP layer, tested)   index.ts (Deno wiring)
_shared/
  auth.ts         reads the user token (id, sign-in methods); the platform has already checked the signature
  body.ts         reads a request body with a hard size limit, however the client announces its size
  cors.ts         exact-origin CORS for the browser build, from the ALLOWED_ORIGINS secret
  errors.ts       the one JSON shape for every answer, the code -> HTTP status table, the retryable flag
  rate-limit.ts   in-memory sliding window per user (a brake, not a quota: see "Limits")
  apple.ts        Sign in with Apple: sign the client secret (ES256), exchange the code, revoke the tokens
  log.ts          one JSON line per event; ids, codes and timings only, never what the user typed
  db.ts           the PostgreSQL pool (Deno only)
  engine/         GENERATED copy of packages/engine/src: run `node scripts/sync-engine.ts` after every engine change
```

## commit-session

`POST /functions/v1/commit-session` reports a finished lesson. The server replays it with the shared engine and records the
result: attempts, XP, rotation, misspellings, accuracy, streak and the session chain, in one transaction. It is idempotent.

Headers: `Authorization: Bearer <user JWT>`, `apikey: <publishable key>`, `Content-Type: application/json`, and
`x-region: ap-south-1` (see "Region"). Body: the `SessionCommit` the engine builds with `toSessionCommit` (at most 128 KiB; a
perfect lesson is about 5 KB):

```json
{ "engineVersion": 1, "sessionId": "<uuid>", "parentSessionId": "<uuid>|null", "lessonId": "<uuid>", "mode": "first_run|replay",
  "seed": 123456789, "timeZone": "Asia/Riyadh", "startedAt": "<iso>", "completedAt": "<iso>", "injectedWordIds": ["<uuid>"],
  "attempts": [ { "itemId": "L:<uuid>", "step": "word|sentence", "input": "candle", "usedPeek": false, "at": "<iso>" } ] }
```

The user comes from the token only; a user id in the body is ignored. Success is `200`:

```json
{ "ok": true, "receipt": { "status": "committed|duplicate", "sessionId": "...", "mode": "first_run", "xpEarned": 250,
                           "totalXp": 250, "streak": 1, "longestStreak": 1, "newMistakes": 0 } }
```

Every failure has the same shape, and `code` is the contract the app's sync worker switches on:

```json
{ "ok": false, "error": { "code": "out_of_order", "message": "...", "retryable": true, "details": { "lastSessionId": "<uuid>|null" } } }
```

| code | HTTP | retryable | meaning and what the app does |
|---|---|---|---|
| `unauthenticated` | 401 | no | missing, expired or non-user token: refresh the session or sign in again |
| `method_not_allowed` / `unsupported_media_type` | 405 / 415 | no | a bug in the app |
| `payload_too_large` | 413 | no | a bug in the app (the limit is 128 KiB) |
| `invalid_json` / `bad_request` | 400 | no | a bug in the app; `message` names the field |
| `timing_implausible` | 400 | no | the device clock is wrong, or the session was impossibly fast |
| `out_of_order` | 409 | **yes** | an earlier session of this user has not arrived: send the outbox in play order. `details.lastSessionId` is the chain head the server knows (null before the first session) |
| `lesson_locked`, `mode_mismatch`, `injection_invalid`, `replay_failed`, `lesson_unpublished` | 409 | no | the app's state and the server's disagree: re-sync the learner's state; this session cannot be recorded as played |
| `lesson_not_found` | 404 | no | unknown lesson id |
| `engine_outdated` | 426 | no | the lesson rules of this app version differ from the server's: ask the user to update |
| `rate_limited` | 429 | **yes** | wait `Retry-After` seconds |
| `internal` | 500 | **yes** | the server failed; nothing was recorded (one transaction) |

Retry only network errors and the retryable codes. Everything else is final for that session.

**The session chain.** Each session names the session played just before it (`parentSessionId`, null for the very first). The
server accepts a session only when its parent is the last session it recorded for the user. The check runs before every state
check, so a lesson that arrives ahead of its predecessor is reported as the retryable `out_of_order`, never as a permanent
`lesson_locked`. A session sent again after it was recorded is answered `duplicate` (HTTP 200), whatever the chain looks like now.
A new device or a reinstalled app learns the head from the `out_of_order` answer.

## delete-account

`POST /functions/v1/delete-account` permanently deletes the signed-in user and everything attached to them (the foreign keys
cascade; `v_account_deletion_gaps` proves the list is complete). The body is optional:

```json
{ "appleAuthorizationCode": "<fresh code from a new Sign in with Apple prompt>" }
```

For a user whose account is linked to Apple, and when the Apple secrets are set, the app must ask Apple for a fresh code right
before deleting and send it: the function exchanges it for tokens and revokes them (an Apple requirement), and only then
deletes. Without the code it answers `400 apple_reauth_required`; if Apple refuses it answers `502 apple_revoke_failed`
(retryable) and deletes nothing. If the Apple secrets are not set, deletion goes ahead and the answer says
`"appleRevocation": "skipped_not_configured"`. Success is `200`:

```json
{ "ok": true, "appleRevocation": "not_linked|revoked|skipped_not_configured", "alreadyDeleted": false }
```

Deleting an account that is already gone is a success (`alreadyDeleted: true`), so a retry after a lost answer is harmless.
Five attempts per hour and user.

## Region

The database is in `ap-south-1` (Mumbai). A function runs in the region nearest to the caller unless the request names one, and
a commit makes about 20 database round trips, so the app should always send `x-region: ap-south-1` (supabase-js: the `region`
option of `functions.invoke`; for cross-origin calls where a custom header is awkward, the `forceFunctionRegion` query parameter).
Supabase does not re-route a request that names a region when that region is down: the sync worker should retry once without the
header. `x-region` is already in the CORS allow list.

## Deploying

1. `node scripts/sync-engine.ts` (the test `sync-engine.test.ts` fails if the copy is stale), then the whole test run.
2. Apply migration `20261022000100_session_chain.sql`: `commit-session` writes `parent_session_id`.
3. Deploy each function **with `verify_jwt: true`** (with the Supabase connector's `deploy_edge_function`, name each file relative to the
   function folder and write the shared ones as `../_shared/x.ts`; the platform resolves them) (`config.toml` has it; a test guards the file). The platform checks the token
   signature before our code runs and `auth.ts` does not check it again, so a function deployed with it off would accept forged
   tokens. Each function needs its own folder, all of `_shared/` and all of `_shared/engine/`.
4. Secrets (names cannot start with `SUPABASE_`): `ALLOWED_ORIGINS` (exact origins of the web build, comma separated; unset for
   native only), and for Sign in with Apple **all four or none**: `APPLE_TEAM_ID`, `APPLE_KEY_ID`, `APPLE_CLIENT_ID` (the app's
   bundle id), `APPLE_PRIVATE_KEY` (the .p8 text; `\n` for newlines is fine). Optional `DB_URL` replaces `SUPABASE_DB_URL` (for
   example with the transaction pooler string if direct connections ever run short). Supabase provides `SUPABASE_URL`,
   `SUPABASE_DB_URL` and the secret key (`SUPABASE_SECRET_KEYS`, or the legacy `SUPABASE_SERVICE_ROLE_KEY`) itself.
   Only `delete-account` reads a key that can administer users; `commit-session` talks to the database directly.

## Limits

- Bodies: 128 KiB for a commit, 4 KiB for a deletion; counted on the stream, not trusted from `content-length`.
- Rate: 30 commits per minute and user, 5 deletions per hour and user. The counters live in the memory of one isolate, and
  Supabase runs many, so this stops a client that loops; it is not a quota. The real protection is the required token, the
  idempotency, the replay (it rejects anything that does not follow the rules) and the closed tables.
- Cost: replaying a 40-attempt lesson takes about 0.4 ms (measured in Node); Supabase allows 2 s of CPU per request.
- One database connection per isolate; a commit holds one transaction and locks the user's row, so a user's commits queue up.

## What is verified, and what is not

Verified in Node (68 tests): both handlers end to end with the real engine and the real commit service on the SQLite twin of the
schema (preflight, methods, tokens, size limits, JSON and shape errors, a commit, a repeat, out-of-order delivery, every error
status, rate limiting, 500s that leak nothing, logs without user text, account wipe including the session chain); Apple signing
with generated keys and a fake Apple; the shared modules; the engine copy; and static checks of the Deno files. `tsc` strict
also checks the Deno files against stand-in declarations (`tests/functions/shims.d.ts`).

Verified on the real project (2026-10-25): the SQL half, by `tests/database/005_pgrepo_contract.sql` (79 of 79) and `006_session_chain.sql`
(15 of 15); and the deployment of both functions (version 1, ACTIVE, `verify_jwt` on): the platform accepted the file names `../_shared/...`,
`npm:@supabase/supabase-js@2.106.1` and the `https://deno.land/x/postgres@v0.17.0/mod.ts` import, and built both. `delete-account` was read
back after the deploy and matches this repository.

**Not verified**: `commit-session` was deployed from a hand-copied set of 22 files (92 KB) and has not been read back and compared yet; no function has
been called under the Edge runtime; `db.ts` with the Deno Postgres driver; supabase-js `auth.admin.deleteUser` (exact 2.106.1); Apple's real
endpoints; the platform's JWT check; CORS in a browser; and the shims themselves, which are written from the documentation. The rest is one
real sign-in away. After any change under `packages/engine/src`, run `node scripts/sync-engine.ts` and redeploy `commit-session`.
