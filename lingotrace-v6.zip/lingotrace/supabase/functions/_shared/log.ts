/** One JSON object per line: easy to filter in the Supabase function logs. Callers pass ids and codes, never user content. */
export type LogLevel = 'info' | 'warn' | 'error';
/** Receives ids, codes and timings only. Never request bodies, answers the user typed, or tokens. */
export type LogFn = (level: LogLevel, event: string, data?: Record<string, unknown>) => void;

export const logJson: LogFn = (level, event, data = {}) => {
  const line = JSON.stringify({ level, event, ...data });
  if (level === 'error') console.error(line);
  else if (level === 'warn') console.warn(line);
  else console.log(line);
};

/** Enough of an exception to find the problem in the logs, never enough to leak far if a driver puts values in its messages. */
export const describeError = (e: unknown): { name: string; message: string } =>
  e instanceof Error ? { name: e.name, message: e.message.slice(0, 300) } : { name: 'NonError', message: String(e).slice(0, 300) };
