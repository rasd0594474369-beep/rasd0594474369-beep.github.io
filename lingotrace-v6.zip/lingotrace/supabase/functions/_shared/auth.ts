/**
 * Who is calling?
 *
 * The platform checks the SIGNATURE: both functions are deployed with `verify_jwt = true` (config.toml, guarded by a
 * test), so a request with a missing, forged or expired token never reaches our code (Supabase, "Securing Edge
 * Functions"). What is left for us is to read the token carefully: it must be a signed-in USER's token (not the anon
 * key, not a service key), and the user id must come from it, never from anything the client put in the body.
 *
 * Because the signature is not re-checked here, never deploy these functions with `verify_jwt` off.
 *
 * Web-standard APIs only, so the same code runs in Deno and in Node's tests.
 */

export interface AuthUser {
  /** `sub` of the token: the id in auth.users. */
  id: string;
  /** Sign-in methods linked to the account, e.g. ["google"] or ["apple", "google"]. */
  providers: readonly string[];
  isAnonymous: boolean;
}

export type AuthResult = { ok: true; user: AuthUser } | { ok: false; reason: string };
export type Authenticate = (req: Request) => AuthResult;

const MAX_TOKEN_LENGTH = 8192;
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const BASE64URL = /^[A-Za-z0-9_-]+$/;

type Obj = Record<string, unknown>;
const isObject = (v: unknown): v is Obj => typeof v === 'object' && v !== null && !Array.isArray(v);

function decodeSegment(segment: string): Obj | null {
  if (!BASE64URL.test(segment)) return null;
  try {
    const binary = atob(segment.replace(/-/g, '+').replace(/_/g, '/') + '='.repeat((4 - (segment.length % 4)) % 4));
    const json = new TextDecoder('utf-8', { fatal: true }).decode(Uint8Array.from(binary, (c) => c.charCodeAt(0)));
    const value: unknown = JSON.parse(json);
    return isObject(value) ? value : null;
  } catch {
    return null;
  }
}

/** The token of an `Authorization: Bearer <token>` header, or null. */
export function bearerToken(req: Request): string | null {
  const match = /^Bearer ([^\s]+)$/i.exec(req.headers.get('authorization')?.trim() ?? '');
  return match ? match[1]! : null;
}

export function readUserToken(token: string, nowMs: number): AuthResult {
  if (token.length > MAX_TOKEN_LENGTH) return { ok: false, reason: 'token too long' };
  const parts = token.split('.');
  if (parts.length !== 3 || parts.some((p) => p.length === 0)) return { ok: false, reason: 'not a JWT' };

  const header = decodeSegment(parts[0]!);
  const claims = decodeSegment(parts[1]!);
  if (!header || !claims) return { ok: false, reason: 'unreadable token' };
  if (header.alg === 'none') return { ok: false, reason: 'unsigned token' };

  const { sub, role, aud, exp, nbf } = claims;
  if (typeof sub !== 'string' || !UUID.test(sub)) return { ok: false, reason: 'no user id' };
  if (role !== 'authenticated') return { ok: false, reason: 'not a signed-in user token' };
  if (aud !== 'authenticated' && !(Array.isArray(aud) && aud.includes('authenticated'))) return { ok: false, reason: 'wrong audience' };
  if (typeof exp !== 'number' || !Number.isFinite(exp) || exp * 1000 <= nowMs) return { ok: false, reason: 'token expired' };
  if (nbf !== undefined && (typeof nbf !== 'number' || nbf * 1000 > nowMs)) return { ok: false, reason: 'token not valid yet' };

  const meta = isObject(claims.app_metadata) ? claims.app_metadata : {};
  const listed = Array.isArray(meta.providers) ? meta.providers.filter((p): p is string => typeof p === 'string') : [];
  const providers = listed.length > 0 ? listed : typeof meta.provider === 'string' ? [meta.provider] : [];
  return { ok: true, user: { id: sub.toLowerCase(), providers, isAnonymous: claims.is_anonymous === true } };
}

export function createAuthenticator(options: { now?: () => number } = {}): Authenticate {
  const now = options.now ?? Date.now;
  return (req) => {
    const token = bearerToken(req);
    return token === null ? { ok: false, reason: 'no bearer token' } : readUserToken(token, now());
  };
}
