# GENERATED, do not edit

This folder is a byte-for-byte copy of `packages/engine/src`, made by `scripts/sync-engine.ts`.
Change the engine there, then run `node scripts/sync-engine.ts`. `--check` fails when this copy is out of date.
