/**
 * PostgreSQL connection for the Edge Functions (Deno only: this file is NOT covered by the Node tests; the contract
 * script against the real database is what proves it).
 *
 * Uses the Deno Postgres driver the Supabase docs show for Edge Functions. `SUPABASE_DB_URL` is a direct connection
 * with SSL already set up. One connection per isolate is enough (a commit holds a single transaction at a time) and keeps
 * the number of connections low when many isolates run. If the project ever outgrows direct connections, point the DB_URL
 * secret at the transaction pooler string; nothing else changes.
 */

import * as postgres from 'https://deno.land/x/postgres@v0.17.0/mod.ts';
import type { SqlPool } from './engine/server/index.ts';

let pool: postgres.Pool | undefined;

function getPool(): postgres.Pool {
  if (pool === undefined) {
    const url = Deno.env.get('DB_URL') ?? Deno.env.get('SUPABASE_DB_URL');
    if (!url) throw new Error('neither DB_URL nor SUPABASE_DB_URL is set');
    pool = new postgres.Pool(url, 1, true); // lazy: connects on first use
  }
  return pool;
}

export const sqlPool: SqlPool = {
  async connect() {
    const client = await getPool().connect();
    return {
      async query(text, values = []) {
        const result = await client.queryObject({ text, args: values as unknown[] });
        return { rows: result.rows as Record<string, unknown>[] };
      },
      release: () => client.release(),
    };
  },
};
