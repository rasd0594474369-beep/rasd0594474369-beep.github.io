/**
 * A sliding-window limiter kept in memory. Honest about its reach: an Edge Function runs in many short-lived
 * isolates, each with its own counters, so this is a cheap brake against a client that loops, NOT a hard quota.
 * What actually protects the data is elsewhere: a valid JWT is required, every commit is idempotent, the replay
 * rejects anything that does not match the rules, and Row Level Security keeps clients away from the tables.
 */

export type RateDecision = { allowed: true } | { allowed: false; retryAfterSeconds: number };

export interface RateLimiter {
  check(key: string): RateDecision;
}

export interface RateLimiterOptions {
  /** Requests allowed per window and key. */
  limit: number;
  windowMs: number;
  /** Clock, injectable for tests. */
  now?: () => number;
  /** Upper bound on remembered keys, so a flood of different users cannot grow memory without limit. */
  maxKeys?: number;
}

export function createRateLimiter(options: RateLimiterOptions): RateLimiter {
  const { limit, windowMs } = options;
  const now = options.now ?? Date.now;
  const maxKeys = options.maxKeys ?? 10_000;
  if (!Number.isInteger(limit) || limit < 1 || windowMs < 1) throw new Error('rate limiter needs limit >= 1 and windowMs >= 1');
  const hits = new Map<string, number[]>();

  const prune = (t: number): void => {
    for (const [key, times] of hits) {
      if (times.length === 0 || times[times.length - 1]! <= t - windowMs) hits.delete(key);
    }
    // still too many distinct keys: forget the oldest ones (Map keeps insertion order)
    for (const key of hits.keys()) {
      if (hits.size <= maxKeys) break;
      hits.delete(key);
    }
  };

  return {
    check(key) {
      const t = now();
      const times = (hits.get(key) ?? []).filter((x) => x > t - windowMs);
      if (times.length >= limit) {
        hits.set(key, times);
        return { allowed: false, retryAfterSeconds: Math.max(1, Math.ceil((times[0]! + windowMs - t) / 1000)) };
      }
      times.push(t);
      hits.delete(key); // re-insert so the most recently active keys sit last
      hits.set(key, times);
      if (hits.size > maxKeys) prune(t);
      return { allowed: true };
    },
  };
}
