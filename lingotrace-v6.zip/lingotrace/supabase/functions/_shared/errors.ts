/**
 * One shape for every answer the Edge Functions give.
 *
 *   success: { "ok": true, ... }
 *   failure: { "ok": false, "error": { "code": "...", "message": "...", "retryable": bool, "details"?: {...} } }
 *
 * `code` is the stable contract the app's sync worker switches on; `message` is for logs and developers
 * (the app shows its own translated text). `retryable` says whether sending the SAME request again later can
 * succeed: true for rate limits, server trouble and out-of-order (after the earlier sessions went through),
 * false for everything where the request itself is wrong or no longer valid.
 *
 * Web-standard APIs only (Request/Response/Headers), so the same code runs in Deno and in Node's tests.
 */

export type ErrorCode =
  // decided by the engine's commit service
  | 'bad_request' | 'lesson_not_found' | 'lesson_unpublished' | 'lesson_locked' | 'mode_mismatch'
  | 'injection_invalid' | 'timing_implausible' | 'replay_failed' | 'engine_outdated' | 'out_of_order'
  // decided by the HTTP layer
  | 'unauthenticated' | 'method_not_allowed' | 'unsupported_media_type' | 'payload_too_large'
  | 'invalid_json' | 'rate_limited' | 'internal'
  // account deletion
  | 'apple_reauth_required' | 'apple_revoke_failed';

const STATUS: Record<ErrorCode, number> = {
  bad_request: 400,
  invalid_json: 400,
  timing_implausible: 400,
  apple_reauth_required: 400,
  unauthenticated: 401,
  lesson_not_found: 404,
  method_not_allowed: 405,
  // the app's state and the server's state disagree: re-sync, or send the earlier sessions first
  lesson_unpublished: 409,
  lesson_locked: 409,
  mode_mismatch: 409,
  injection_invalid: 409,
  replay_failed: 409,
  out_of_order: 409,
  payload_too_large: 413,
  unsupported_media_type: 415,
  engine_outdated: 426,
  rate_limited: 429,
  internal: 500,
  apple_revoke_failed: 502,
};

const RETRYABLE: ReadonlySet<ErrorCode> = new Set<ErrorCode>(['out_of_order', 'rate_limited', 'internal', 'apple_revoke_failed']);

export const statusFor = (code: ErrorCode): number => STATUS[code];
export const isRetryable = (code: ErrorCode): boolean => RETRYABLE.has(code);

const BASE_HEADERS: Record<string, string> = {
  'content-type': 'application/json; charset=utf-8',
  'cache-control': 'no-store',
  'x-content-type-options': 'nosniff',
};

export function jsonResponse(status: number, body: unknown, extraHeaders: Record<string, string> = {}): Response {
  return new Response(JSON.stringify(body), { status, headers: { ...BASE_HEADERS, ...extraHeaders } });
}

export interface ErrorOptions {
  headers?: Record<string, string>;
  details?: Record<string, unknown>;
  retryAfterSeconds?: number;
}

export function errorResponse(code: ErrorCode, message: string, options: ErrorOptions = {}): Response {
  const headers = { ...(options.headers ?? {}) };
  if (options.retryAfterSeconds !== undefined) headers['retry-after'] = String(Math.max(1, Math.ceil(options.retryAfterSeconds)));
  const error: Record<string, unknown> = { code, message, retryable: isRetryable(code) };
  if (options.details) error.details = options.details;
  return jsonResponse(statusFor(code), { ok: false, error }, headers);
}
