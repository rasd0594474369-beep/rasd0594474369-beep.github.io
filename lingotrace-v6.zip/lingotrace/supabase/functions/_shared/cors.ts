/**
 * CORS for the browser build of the app (the PWA). Native apps are not browsers and need none of this.
 *
 * Only origins listed exactly in the ALLOWED_ORIGINS secret (comma separated, e.g. "https://app.example.com")
 * are echoed back; there is no wildcard. With the secret unset, no browser origin is allowed.
 * `x-region` is allowed because the app pins the function region with that header (supabase-js `region` option),
 * and a custom header makes the browser send a preflight request first.
 */

export interface CorsPolicy {
  readonly allowedOrigins: ReadonlySet<string>;
}

export function corsPolicyFromEnv(value: string | undefined): CorsPolicy {
  const origins = (value ?? '').split(',').map((o) => o.trim()).filter(Boolean);
  for (const o of origins) {
    if (o === '*' || o.includes('*')) throw new Error('ALLOWED_ORIGINS must list exact origins; wildcards are not allowed');
    if (!/^https?:\/\/[^/\s]+$/.test(o)) throw new Error(`ALLOWED_ORIGINS entry "${o}" is not an origin (scheme://host[:port], no path)`);
  }
  return { allowedOrigins: new Set(origins) };
}

const ALLOW_HEADERS = 'authorization, apikey, content-type, x-client-info, x-region';

/** Headers for an actual response: the origin is echoed only when it is on the list; `vary` always, so caches stay correct. */
export function corsHeaders(policy: CorsPolicy, origin: string | null): Record<string, string> {
  const headers: Record<string, string> = { vary: 'Origin' };
  if (origin !== null && policy.allowedOrigins.has(origin)) headers['access-control-allow-origin'] = origin;
  return headers;
}

/** Answer to the browser's OPTIONS check. Allowed origins get the permissions; others get a bare 204 and the browser blocks the call. */
export function preflightResponse(policy: CorsPolicy, req: Request): Response {
  const headers = corsHeaders(policy, req.headers.get('origin'));
  if (headers['access-control-allow-origin']) {
    headers['access-control-allow-methods'] = 'POST, OPTIONS';
    headers['access-control-allow-headers'] = ALLOW_HEADERS;
    headers['access-control-max-age'] = '86400';
  }
  return new Response(null, { status: 204, headers });
}
