/**
 * Reads a request body without trusting its size. `content-length` is a hint a client can lie about (or omit), so the
 * stream itself is counted and abandoned as soon as it passes the limit.
 */

export type BodyResult = { ok: true; text: string } | { ok: false; reason: 'too_large' | 'invalid_text' };

export async function readBodyLimited(req: Request, maxBytes: number): Promise<BodyResult> {
  const declared = req.headers.get('content-length');
  if (declared !== null && /^\d+$/.test(declared) && Number(declared) > maxBytes) return { ok: false, reason: 'too_large' };
  if (req.body === null) return { ok: true, text: '' };

  const reader = req.body.getReader();
  const chunks: Uint8Array[] = [];
  let total = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    total += value.byteLength;
    if (total > maxBytes) {
      await reader.cancel().catch(() => {});
      return { ok: false, reason: 'too_large' };
    }
    chunks.push(value);
  }
  const bytes = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.byteLength;
  }
  try {
    return { ok: true, text: new TextDecoder('utf-8', { fatal: true }).decode(bytes) };
  } catch {
    return { ok: false, reason: 'invalid_text' };
  }
}

export type JsonResult = { ok: true; value: unknown } | { ok: false };

export function parseJson(text: string): JsonResult {
  try {
    return { ok: true, value: JSON.parse(text) as unknown };
  } catch {
    return { ok: false };
  }
}

/** `application/json` with any parameters (charset=...), case-insensitive. */
export const isJsonContentType = (value: string | null): boolean => value !== null && /^application\/json\s*(;|$)/i.test(value.trim());
