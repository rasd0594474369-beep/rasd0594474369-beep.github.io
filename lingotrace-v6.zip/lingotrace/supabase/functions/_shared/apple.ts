/**
 * Sign in with Apple: what Apple requires when an account is deleted. The app must revoke the user's Apple tokens
 * through Apple's REST API, which needs a token for that user. The app gets one by asking Apple again for a fresh
 * authorization code right before deleting (a normal "Sign in with Apple" prompt) and sending it to delete-account,
 * which exchanges it for tokens and revokes them.
 *
 *   POST https://appleid.apple.com/auth/token    grant_type=authorization_code & code & client_id & client_secret
 *   POST https://appleid.apple.com/auth/revoke   token & token_type_hint & client_id & client_secret
 *
 * `client_secret` is a short JWT we sign ourselves (ES256) with the key downloaded from the Apple developer account:
 * iss = team id, sub = client id (the app's bundle id), aud = https://appleid.apple.com, header kid = key id.
 *
 * Web Crypto and fetch only: no dependencies, runs in Deno and in Node's tests. Never put codes, tokens or the key in a log.
 */

export interface AppleConfig {
  teamId: string;
  keyId: string;
  /** The app's bundle id (native) or Services id (web) that Apple knows as the client. */
  clientId: string;
  /** The .p8 key, PEM text. Newlines may be stored as the two characters \n. */
  privateKeyPem: string;
}

const APPLE_VARS = ['APPLE_TEAM_ID', 'APPLE_KEY_ID', 'APPLE_CLIENT_ID', 'APPLE_PRIVATE_KEY'] as const;

/**
 * All four settings or none. None means "Apple sign-in is not set up" (null); some but not all is a mistake that would
 * silently skip token revocation, so it fails loudly instead.
 */
export function appleConfigFromEnv(get: (name: string) => string | undefined): AppleConfig | null {
  const values = APPLE_VARS.map((name) => get(name)?.trim() ?? '');
  const missing = APPLE_VARS.filter((_, i) => values[i] === '');
  if (missing.length === APPLE_VARS.length) return null;
  if (missing.length > 0) throw new Error(`Apple settings are incomplete, missing: ${missing.join(', ')}`);
  const [teamId, keyId, clientId, privateKeyPem] = values as [string, string, string, string];
  return { teamId, keyId, clientId, privateKeyPem };
}

export class AppleError extends Error {
  readonly stage: 'client_secret' | 'exchange' | 'revoke';
  /** HTTP status Apple answered with, or null when there was no answer. */
  readonly status: number | null;
  constructor(stage: AppleError['stage'], status: number | null, message: string) {
    super(message);
    this.name = 'AppleError';
    this.stage = stage;
    this.status = status;
  }
}

export interface AppleDeps {
  fetch: typeof fetch;
  nowSeconds: () => number;
}

const TOKEN_URL = 'https://appleid.apple.com/auth/token';
const REVOKE_URL = 'https://appleid.apple.com/auth/revoke';
const AUDIENCE = 'https://appleid.apple.com';
const REQUEST_TIMEOUT_MS = 8000;

const toBase64Url = (bytes: Uint8Array): string => {
  let binary = '';
  for (const b of bytes) binary += String.fromCharCode(b);
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
};
const textToBase64Url = (text: string): string => toBase64Url(new TextEncoder().encode(text));

function pemToDer(pem: string): Uint8Array<ArrayBuffer> {
  const body = pem
    .replace(/\\n/g, '\n')
    .replace(/-----BEGIN [A-Z ]+-----/, '')
    .replace(/-----END [A-Z ]+-----/, '')
    .replace(/\s+/g, '');
  return Uint8Array.from(atob(body), (c) => c.charCodeAt(0));
}

/** The JWT Apple wants as `client_secret`. Short-lived on purpose: made per request, valid for minutes (Apple allows up to 6 months). */
export async function createClientSecret(cfg: AppleConfig, nowSeconds: number, ttlSeconds = 300): Promise<string> {
  try {
    const key = await crypto.subtle.importKey('pkcs8', pemToDer(cfg.privateKeyPem), { name: 'ECDSA', namedCurve: 'P-256' }, false, ['sign']);
    const header = textToBase64Url(JSON.stringify({ alg: 'ES256', kid: cfg.keyId, typ: 'JWT' }));
    const payload = textToBase64Url(JSON.stringify({ iss: cfg.teamId, iat: nowSeconds, exp: nowSeconds + ttlSeconds, aud: AUDIENCE, sub: cfg.clientId }));
    const signature = await crypto.subtle.sign({ name: 'ECDSA', hash: 'SHA-256' }, key, new TextEncoder().encode(`${header}.${payload}`));
    return `${header}.${payload}.${toBase64Url(new Uint8Array(signature))}`; // ECDSA output is r||s, the form JWS wants
  } catch {
    throw new AppleError('client_secret', null, 'could not sign the Apple client secret (check APPLE_PRIVATE_KEY)');
  }
}

async function postForm(stage: 'exchange' | 'revoke', url: string, fields: Record<string, string>, deps: AppleDeps): Promise<unknown> {
  let response: Response;
  try {
    response = await deps.fetch(url, {
      method: 'POST',
      headers: { 'content-type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams(fields).toString(),
      signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
    });
  } catch {
    throw new AppleError(stage, null, `${stage}: no answer from Apple`);
  }
  const text = await response.text().catch(() => '');
  let body: unknown = null;
  try {
    body = text === '' ? null : JSON.parse(text);
  } catch {
    body = null;
  }
  if (!response.ok) {
    const reason = typeof (body as { error?: unknown } | null)?.error === 'string' ? (body as { error: string }).error : 'rejected';
    throw new AppleError(stage, response.status, `${stage}: Apple answered ${response.status} (${reason})`);
  }
  return body;
}

/** Turns the fresh authorization code into tokens and revokes them, which removes the app from the user's Apple ID. */
export async function revokeAppleAccess(cfg: AppleConfig, authorizationCode: string, deps: AppleDeps): Promise<void> {
  const clientSecret = await createClientSecret(cfg, deps.nowSeconds());
  const tokens = (await postForm('exchange', TOKEN_URL, {
    client_id: cfg.clientId, client_secret: clientSecret, code: authorizationCode, grant_type: 'authorization_code',
  }, deps)) as { refresh_token?: unknown; access_token?: unknown } | null;

  const refresh = typeof tokens?.refresh_token === 'string' && tokens.refresh_token !== '' ? tokens.refresh_token : null;
  const access = typeof tokens?.access_token === 'string' && tokens.access_token !== '' ? tokens.access_token : null;
  const token = refresh ?? access;
  if (token === null) throw new AppleError('exchange', null, 'exchange: Apple returned no token');

  await postForm('revoke', REVOKE_URL, {
    client_id: cfg.clientId, client_secret: clientSecret, token, token_type_hint: refresh !== null ? 'refresh_token' : 'access_token',
  }, deps);
}
