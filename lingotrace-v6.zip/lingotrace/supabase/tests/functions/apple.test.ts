import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { AppleError, appleConfigFromEnv, createClientSecret, revokeAppleAccess } from '../../functions/_shared/apple.ts';
import type { AppleConfig } from '../../functions/_shared/apple.ts';

const NOW = 1_790_000_000;
const CODE = 'c-authorization-code-0123456789';

const pemOf = (pkcs8: ArrayBuffer): string => {
  const base64 = Buffer.from(pkcs8).toString('base64').replace(/(.{64})/g, '$1\n');
  return `-----BEGIN PRIVATE KEY-----\n${base64}\n-----END PRIVATE KEY-----\n`;
};
async function keyPair() {
  const pair = await crypto.subtle.generateKey({ name: 'ECDSA', namedCurve: 'P-256' }, true, ['sign', 'verify']);
  return { publicKey: pair.publicKey, pem: pemOf(await crypto.subtle.exportKey('pkcs8', pair.privateKey)) };
}
const config = (pem: string): AppleConfig => ({ teamId: 'TEAM123456', keyId: 'KEY1234567', clientId: 'com.example.lingotrace', privateKeyPem: pem });

const decode = (segment: string) => JSON.parse(Buffer.from(segment, 'base64url').toString('utf8'));
async function verifyJwt(jwt: string, publicKey: CryptoKey): Promise<boolean> {
  const [h, p, s] = jwt.split('.') as [string, string, string];
  return crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, publicKey, Buffer.from(s, 'base64url'), new TextEncoder().encode(`${h}.${p}`));
}

interface Call { url: string; method: string; headers: Record<string, string>; fields: Record<string, string>; hasSignal: boolean }
/** A fake Apple: records every request and answers from a script (one answer per call, in order). */
function fakeApple(answers: Array<Response | Error>) {
  const calls: Call[] = [];
  const fetchFn = (async (url: string, init: RequestInit) => {
    calls.push({
      url: String(url), method: String(init.method), headers: init.headers as Record<string, string>,
      fields: Object.fromEntries(new URLSearchParams(String(init.body))), hasSignal: init.signal instanceof AbortSignal,
    });
    const next = answers.shift();
    if (next === undefined) throw new Error('unexpected extra request');
    if (next instanceof Error) throw next;
    return next;
  }) as unknown as typeof fetch;
  return { calls, deps: { fetch: fetchFn, nowSeconds: () => NOW } };
}
const json = (status: number, body: unknown) => new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } });

describe('appleConfigFromEnv', () => {
  const env = (o: Record<string, string>) => (name: string) => o[name];
  it('is off with no settings, complete with all four, and a loud error with only some', () => {
    assert.equal(appleConfigFromEnv(env({})), null);
    assert.equal(appleConfigFromEnv(env({ APPLE_TEAM_ID: '  ' })), null); // blank counts as unset
    assert.deepEqual(
      appleConfigFromEnv(env({ APPLE_TEAM_ID: ' T ', APPLE_KEY_ID: 'K', APPLE_CLIENT_ID: 'c.id', APPLE_PRIVATE_KEY: 'pem' })),
      { teamId: 'T', keyId: 'K', clientId: 'c.id', privateKeyPem: 'pem' },
    );
    assert.throws(() => appleConfigFromEnv(env({ APPLE_TEAM_ID: 'T', APPLE_KEY_ID: 'K' })), /missing: APPLE_CLIENT_ID, APPLE_PRIVATE_KEY/);
  });
});

describe('createClientSecret', () => {
  it('signs a JWT Apple can verify: ES256, the right claims, a short life', async () => {
    const { publicKey, pem } = await keyPair();
    const jwt = await createClientSecret(config(pem), NOW);
    const [h, p] = jwt.split('.') as [string, string];
    assert.deepEqual(decode(h), { alg: 'ES256', kid: 'KEY1234567', typ: 'JWT' });
    assert.deepEqual(decode(p), { iss: 'TEAM123456', iat: NOW, exp: NOW + 300, aud: 'https://appleid.apple.com', sub: 'com.example.lingotrace' });
    assert.equal(Buffer.from(jwt.split('.')[2]!, 'base64url').length, 64); // r || s, the form JWS requires (not DER)
    assert.ok(await verifyJwt(jwt, publicKey));
    assert.equal(decode(jwt.split('.')[1]!).exp - NOW, 300);
    assert.equal(decode((await createClientSecret(config(pem), NOW, 60)).split('.')[1]!).exp, NOW + 60);
  });

  it('rejects a tampered token, and accepts the key with its newlines stored as \\n', async () => {
    const { publicKey, pem } = await keyPair();
    const jwt = await createClientSecret(config(pem), NOW);
    const [h, , s] = jwt.split('.') as [string, string, string];
    const forged = `${h}.${Buffer.from(JSON.stringify({ ...decode(jwt.split('.')[1]!), sub: 'com.attacker.app' })).toString('base64url')}.${s}`;
    assert.equal(await verifyJwt(forged, publicKey), false);
    const escaped = await createClientSecret(config(pem.trim().replace(/\n/g, '\\n')), NOW); // how a one-line secret often looks
    assert.ok(await verifyJwt(escaped, publicKey));
  });

  it('fails with an AppleError that does not repeat the key when the key is not usable', async () => {
    await assert.rejects(createClientSecret(config('-----BEGIN PRIVATE KEY-----\nQUJDREVGRw==\n-----END PRIVATE KEY-----'), NOW), (e: unknown) => {
      assert.ok(e instanceof AppleError && e.stage === 'client_secret' && e.status === null);
      assert.ok(!e.message.includes('QUJDREVGRw'));
      return true;
    });
  });
});

describe('revokeAppleAccess', () => {
  it('exchanges the code, then revokes the refresh token, with one client secret for both calls', async () => {
    const { publicKey, pem } = await keyPair();
    const apple = fakeApple([json(200, { access_token: 'A-token', refresh_token: 'R-token', id_token: 'x' }), json(200, {})]);
    await revokeAppleAccess(config(pem), CODE, apple.deps);
    assert.equal(apple.calls.length, 2);
    const [exchange, revoke] = apple.calls as [Call, Call];
    assert.deepEqual([exchange.url, exchange.method, exchange.headers['content-type']], ['https://appleid.apple.com/auth/token', 'POST', 'application/x-www-form-urlencoded']);
    assert.deepEqual([exchange.fields.grant_type, exchange.fields.code, exchange.fields.client_id], ['authorization_code', CODE, 'com.example.lingotrace']);
    assert.deepEqual([revoke.url, revoke.method], ['https://appleid.apple.com/auth/revoke', 'POST']);
    assert.deepEqual([revoke.fields.token, revoke.fields.token_type_hint, revoke.fields.client_id], ['R-token', 'refresh_token', 'com.example.lingotrace']);
    assert.equal(exchange.fields.client_secret, revoke.fields.client_secret);
    assert.ok(await verifyJwt(revoke.fields.client_secret!, publicKey));
    assert.ok(exchange.hasSignal && revoke.hasSignal, 'every call to Apple has a timeout');
  });

  it('falls back to the access token when Apple sends no refresh token', async () => {
    const { pem } = await keyPair();
    const apple = fakeApple([json(200, { access_token: 'A-token' }), json(200, {})]);
    await revokeAppleAccess(config(pem), CODE, apple.deps);
    assert.deepEqual([apple.calls[1]!.fields.token, apple.calls[1]!.fields.token_type_hint], ['A-token', 'access_token']);
  });

  it('stops at the first failure and says which step and which status, never revoking after a failed exchange', async () => {
    const { pem } = await keyPair();
    const cases: Array<[string, Array<Response | Error>, AppleError['stage'], number | null, number]> = [
      ['exchange refused', [json(400, { error: 'invalid_grant' })], 'exchange', 400, 1],
      ['Apple unreachable at exchange', [new TypeError('fetch failed')], 'exchange', null, 1],
      ['exchange answers without a token', [json(200, { id_token: 'only' })], 'exchange', null, 1],
      ['revoke refused', [json(200, { refresh_token: 'R' }), json(500, { error: 'server_error' })], 'revoke', 500, 2],
      ['Apple unreachable at revoke', [json(200, { refresh_token: 'R' }), new TypeError('fetch failed')], 'revoke', null, 2],
      ['an HTML error page instead of JSON', [new Response('<html>Bad gateway</html>', { status: 502 })], 'exchange', 502, 1],
    ];
    for (const [label, answers, stage, status, calls] of cases) {
      const apple = fakeApple(answers);
      await assert.rejects(revokeAppleAccess(config(pem), CODE, apple.deps), (e: unknown) => {
        assert.ok(e instanceof AppleError, label);
        assert.deepEqual([e.stage, e.status], [stage, status], label);
        return true;
      }, label);
      assert.equal(apple.calls.length, calls, label);
    }
  });

  it('never puts the code, a token, the client secret or the key into an error message', async () => {
    const { pem } = await keyPair();
    const apple = fakeApple([json(200, { refresh_token: 'R-secret-token' }), json(400, { error: 'invalid_request', error_description: 'token R-secret-token is bad' })]);
    await assert.rejects(revokeAppleAccess(config(pem), CODE, apple.deps), (e: unknown) => {
      const text = String((e as Error).message);
      for (const secret of [CODE, 'R-secret-token', apple.calls[0]!.fields.client_secret!, pem.slice(40, 80)]) assert.ok(!text.includes(secret), `message leaked ${secret.slice(0, 12)}...`);
      return true;
    });
  });
});
