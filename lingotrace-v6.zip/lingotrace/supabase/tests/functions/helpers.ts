// Shared fixtures for the Edge Function tests: a real engine, the real commit service and PgRepo on the Supabase schema
// twin, tokens shaped like Supabase user tokens, and a client that plays lessons the way the app does.
import { beginSession, currentPrompt, newSeed, submit, toSessionCommit } from '../../functions/_shared/engine/index.ts';
import type { Prompt, SessionCommit } from '../../functions/_shared/engine/index.ts';
import { PgRepo } from '../../functions/_shared/engine/server/index.ts';
import type { CommitRepo } from '../../functions/_shared/engine/server/index.ts';
import { UUID_IDS, WORDS, openDb, seedWorld, sentenceOf, sqlitePool } from '../../../packages/engine/test/helpers/db.ts';
import type { Db } from '../../../packages/engine/test/helpers/db.ts';
import { createAuthenticator } from '../../functions/_shared/auth.ts';
import { corsPolicyFromEnv } from '../../functions/_shared/cors.ts';
import { createRateLimiter } from '../../functions/_shared/rate-limit.ts';
import { createCommitHandler } from '../../functions/commit-session/handler.ts';
import type { CommitHandlerDeps } from '../../functions/commit-session/handler.ts';

export { UUID_IDS, uuidOf } from '../../../packages/engine/test/helpers/db.ts';

export const NOW_MS = Date.parse('2026-10-05T12:00:00.000Z');
/** Lessons are played the day before NOW, so every completedAt is in the past. */
export const PLAYED_AT = Date.parse('2026-10-04T10:00:00.000Z');
export const HOUR = 3_600_000;
export const ORIGIN = 'https://app.lingotrace.example';

const b64url = (value: unknown): string => Buffer.from(JSON.stringify(value)).toString('base64url');

export interface TokenOptions {
  sub?: string;
  role?: string;
  aud?: string;
  exp?: number;
  providers?: string[];
  isAnonymous?: boolean;
}
/** A token shaped like Supabase's. The signature is a placeholder: the platform checks signatures, the function reads claims. */
export function tokenFor(userId: string, o: TokenOptions = {}): string {
  const claims = {
    sub: o.sub ?? userId,
    role: o.role ?? 'authenticated',
    aud: o.aud ?? 'authenticated',
    exp: o.exp ?? Math.floor(NOW_MS / 1000) + 3600,
    app_metadata: { provider: (o.providers ?? ['google'])[0], providers: o.providers ?? ['google'] },
    ...(o.isAnonymous ? { is_anonymous: true } : {}),
  };
  return `${b64url({ alg: 'ES256', typ: 'JWT', kid: 'test' })}.${b64url(claims)}.c2lnbmF0dXJl`;
}

export async function world(): Promise<{ db: Db; repo: PgRepo; ids: typeof UUID_IDS }> {
  const db = await openDb();
  seedWorld(db, UUID_IDS);
  return { db, repo: new PgRepo(sqlitePool(db)), ids: UUID_IDS };
}

export interface PlayOptions {
  n: number;
  sessionId: string;
  parent?: string | null;
  /** What to type for a prompt; defaults to the right answer. */
  answer?: (prompt: Prompt) => string;
  at?: number;
}
/** A finished lesson as the app would send it (first run, no rotation words). */
export function play(ids: typeof UUID_IDS, o: PlayOptions): SessionCommit {
  const lessonWords = WORDS.slice((o.n - 1) * 20, o.n * 20).map((t) => ({ wordId: ids.word(t), wordText: t, sentenceContext: sentenceOf(t), errorWeight: 0 }));
  const seed = newSeed();
  let { state, rng } = beginSession({ sessionId: o.sessionId, lessonSeq: o.n, mode: 'first_run', seed, lessonWords, history: [] });
  let clock = o.at ?? PLAYED_AT;
  const startedAt = new Date(clock).toISOString();
  while (state.phase !== 'completed') {
    const p = currentPrompt(state)!;
    clock += 2000;
    state = submit(state, (o.answer ?? ((x) => x.text))(p), { now: new Date(clock), rng }).state;
  }
  return toSessionCommit(state, { lessonId: ids.lesson(o.n), parentSessionId: o.parent ?? null, seed, timeZone: 'UTC', startedAt, completedAt: new Date(clock + 500).toISOString() });
}

export interface LogEvent { level: string; event: string; data: Record<string, unknown> }

export function commitHandler(repo: CommitRepo, overrides: Partial<CommitHandlerDeps> = {}) {
  const events: LogEvent[] = [];
  const handler = createCommitHandler({
    authenticate: createAuthenticator({ now: () => NOW_MS }),
    repo,
    limiter: createRateLimiter({ limit: 1000, windowMs: 60_000, now: () => NOW_MS }),
    cors: corsPolicyFromEnv(ORIGIN),
    now: () => new Date(NOW_MS),
    log: (level, event, data = {}) => events.push({ level, event, data }),
    ...overrides,
  });
  return { handler, events };
}

export interface PostOptions {
  token?: string | null;
  body?: unknown;
  rawBody?: string;
  method?: string;
  headers?: Record<string, string>;
}
export function request(path: string, o: PostOptions = {}): Request {
  const headers: Record<string, string> = { 'content-type': 'application/json', ...(o.headers ?? {}) };
  if (o.token !== null && o.token !== undefined) headers.authorization = `Bearer ${o.token}`;
  const method = o.method ?? 'POST';
  const body = method === 'GET' || method === 'OPTIONS' ? undefined : (o.rawBody ?? JSON.stringify(o.body ?? {}));
  return new Request(`https://project.supabase.co/functions/v1/${path}`, { method, headers, body });
}

export const readJson = async (r: Response): Promise<any> => JSON.parse(await r.text());
