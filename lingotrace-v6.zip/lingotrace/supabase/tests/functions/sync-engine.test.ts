import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { MARKER_FILE, inSync, syncEngine } from '../../../scripts/sync-engine.ts';

const root = fileURLToPath(new URL('../../../', import.meta.url));

function scratch() {
  const dir = mkdtempSync(join(tmpdir(), 'sync-engine-'));
  const source = join(dir, 'src');
  const target = join(dir, 'copy');
  const put = (base: string, rel: string, text: string) => {
    mkdirSync(dirname(join(base, rel)), { recursive: true });
    writeFileSync(join(base, rel), text);
  };
  return { dir, source, target, put, cleanup: () => rmSync(dir, { recursive: true, force: true }) };
}

describe('sync-engine', () => {
  it('copies every .ts file (nested folders included) plus a marker, and ignores everything else', () => {
    const s = scratch();
    try {
      s.put(s.source, 'index.ts', 'export {};\n');
      s.put(s.source, 'server/commit.ts', 'export const a = 1;\n');
      s.put(s.source, 'notes.md', 'not code');
      const report = syncEngine({ source: s.source, target: s.target, write: true });
      assert.deepEqual(report, { changed: [], missing: ['index.ts', 'server/commit.ts', MARKER_FILE], extra: [] });
      assert.equal(readFileSync(join(s.target, 'server/commit.ts'), 'utf8'), 'export const a = 1;\n');
      assert.ok(!existsSync(join(s.target, 'notes.md')));
      assert.match(readFileSync(join(s.target, MARKER_FILE), 'utf8'), /GENERATED, do not edit/);
      assert.ok(inSync(syncEngine({ source: s.source, target: s.target, write: false })), 'a second run finds nothing to do');
    } finally { s.cleanup(); }
  });

  it('notices a changed, a missing and a stray file, and writing repairs all three', () => {
    const s = scratch();
    try {
      s.put(s.source, 'a.ts', 'A1');
      s.put(s.source, 'b.ts', 'B1');
      syncEngine({ source: s.source, target: s.target, write: true });
      s.put(s.source, 'a.ts', 'A2'); // the engine changed
      rmSync(join(s.target, 'b.ts')); // a copy went missing
      s.put(s.target, 'old.ts', 'left over'); // a file that no longer exists in the engine
      s.put(s.target, 'hand-made.md', 'someone edited here');
      const report = syncEngine({ source: s.source, target: s.target, write: false });
      assert.deepEqual(report, { changed: ['a.ts'], missing: ['b.ts'], extra: ['hand-made.md', 'old.ts'] });
      assert.ok(!inSync(report));
      syncEngine({ source: s.source, target: s.target, write: true });
      assert.ok(inSync(syncEngine({ source: s.source, target: s.target, write: false })));
      assert.deepEqual([readFileSync(join(s.target, 'a.ts'), 'utf8'), existsSync(join(s.target, 'old.ts'))], ['A2', false]);
    } finally { s.cleanup(); }
  });

  it('in check mode changes nothing at all', () => {
    const s = scratch();
    try {
      s.put(s.source, 'a.ts', 'A');
      syncEngine({ source: s.source, target: s.target, write: false });
      assert.ok(!existsSync(s.target), 'the target was not even created');
      syncEngine({ source: s.source, target: s.target, write: true });
      s.put(s.source, 'a.ts', 'A-new');
      syncEngine({ source: s.source, target: s.target, write: false });
      assert.equal(readFileSync(join(s.target, 'a.ts'), 'utf8'), 'A');
    } finally { s.cleanup(); }
  });

  it('refuses to "sync" from a folder with no TypeScript (a wrong path would otherwise wipe the copy)', () => {
    const s = scratch();
    try {
      s.put(s.source, 'readme.md', 'x');
      s.put(s.target, 'a.ts', 'precious');
      assert.throws(() => syncEngine({ source: s.source, target: s.target, write: true }), /no \.ts files/);
      assert.equal(readFileSync(join(s.target, 'a.ts'), 'utf8'), 'precious');
    } finally { s.cleanup(); }
  });

  it('THE COPY INSIDE THE REPOSITORY IS CURRENT (after changing packages/engine/src run: node scripts/sync-engine.ts)', () => {
    const report = syncEngine({ source: join(root, 'packages/engine/src'), target: join(root, 'supabase/functions/_shared/engine'), write: false });
    assert.deepEqual(report, { changed: [], missing: [], extra: [] }, 'supabase/functions/_shared/engine is out of date: run `node scripts/sync-engine.ts`');
  });
});
