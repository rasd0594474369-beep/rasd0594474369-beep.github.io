// Static checks over the Edge Function sources. The Deno-only wiring (index.ts, db.ts) cannot run in Node, so these tests
// pin down the mistakes that would only show up at deploy time: a path that does not exist, a floating dependency version,
// a function that reaches into another function's folder, a secret read where it has no business being.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { existsSync, readFileSync, readdirSync } from 'node:fs';
import { dirname, join, relative, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

const FUNCTIONS = fileURLToPath(new URL('../../functions/', import.meta.url));
const TESTS = fileURLToPath(new URL('./', import.meta.url));

const tsFiles = (dir: string): string[] =>
  readdirSync(dir, { recursive: true }).map(String).filter((f) => f.endsWith('.ts')).map((f) => join(dir, f)).sort();
const stripComments = (code: string) => code.replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '');
const specifiers = (file: string): string[] =>
  [...stripComments(readFileSync(file, 'utf8')).matchAll(/(?:\bfrom|\bimport)\s*\(?\s*['"]([^'"]+)['"]/g)].map((m) => m[1]!);
const rel = (file: string) => relative(FUNCTIONS, file).split(sep).join('/');

const all = tsFiles(FUNCTIONS);
const mine = all.filter((f) => !rel(f).startsWith('_shared/engine/')); // the engine copy is checked by sync-engine and the engine's own tests
const isWiring = (f: string) => rel(f).endsWith('/index.ts') && !rel(f).startsWith('_shared/') || rel(f) === '_shared/db.ts';

describe('edge function sources', () => {
  it('has the files we expect and nothing unannounced', () => {
    assert.deepEqual(mine.map(rel), [
      '_shared/apple.ts', '_shared/auth.ts', '_shared/body.ts', '_shared/cors.ts', '_shared/db.ts', '_shared/errors.ts', '_shared/log.ts', '_shared/rate-limit.ts',
      'commit-session/handler.ts', 'commit-session/index.ts', 'delete-account/handler.ts', 'delete-account/index.ts',
    ]);
  });

  it('every relative import points at a file that exists', () => {
    const broken: string[] = [];
    for (const file of all) for (const spec of specifiers(file)) {
      if (spec.startsWith('.') && !existsSync(resolve(dirname(file), spec))) broken.push(`${rel(file)} -> ${spec}`);
    }
    assert.deepEqual(broken, []);
  });

  it('each function bundles on its own: it imports only from _shared and from its own folder', () => {
    const stray: string[] = [];
    for (const file of mine) {
      const folder = rel(file).split('/')[0]!;
      if (folder === '_shared') continue;
      for (const spec of specifiers(file)) {
        if (!spec.startsWith('.')) continue;
        const target = rel(resolve(dirname(file), spec)).split('/')[0]!;
        if (target !== '_shared' && target !== folder) stray.push(`${rel(file)} -> ${spec}`);
      }
    }
    assert.deepEqual(stray, []);
  });

  it('_shared never depends on a function folder', () => {
    const stray = mine.filter((f) => rel(f).startsWith('_shared/')).flatMap((f) => specifiers(f).filter((s) => s.startsWith('.')).map((s) => ({ f, s })))
      .filter(({ f, s }) => !rel(resolve(dirname(f), s)).startsWith('_shared/'));
    assert.deepEqual(stray.map(({ f, s }) => `${rel(f)} -> ${s}`), []);
  });

  it('every remote dependency is pinned to an exact version (no @2, no @latest, no bare name)', () => {
    const remote: string[] = [];
    for (const file of all) for (const spec of specifiers(file)) if (/^(npm:|jsr:|https?:)/.test(spec)) remote.push(spec);
    assert.ok(remote.length >= 2, 'the wiring files do import remote modules');
    const pinned = (s: string) =>
      /^(npm|jsr):(@[\w.-]+\/)?[\w.-]+@\d+\.\d+\.\d+(-[\w.]+)?(\/.*)?$/.test(s) || /^https:\/\/deno\.land\/x\/[\w.-]+@v?\d+\.\d+\.\d+\//.test(s);
    assert.deepEqual(remote.filter((s) => !pinned(s)), []);
  });

  it('Deno-only APIs appear only in the entry points and db.ts, so everything else stays testable in Node', () => {
    const offenders = mine.filter((f) => !isWiring(f) && /\bDeno\./.test(stripComments(readFileSync(f, 'utf8')))).map(rel);
    assert.deepEqual(offenders, []);
    for (const f of mine.filter((x) => rel(x).endsWith('/index.ts') && !rel(x).startsWith('_shared/'))) {
      assert.match(readFileSync(f, 'utf8'), /Deno\.serve\(/, `${rel(f)} must start the server`);
    }
  });

  it('secrets are read only where they are needed: the service key only in delete-account, Apple settings only there and in apple.ts', () => {
    const uses = (pattern: RegExp) => mine.filter((f) => pattern.test(stripComments(readFileSync(f, 'utf8')))).map(rel).sort();
    assert.deepEqual(uses(/SUPABASE_SECRET_KEYS|SUPABASE_SERVICE_ROLE_KEY|service_role/), ['delete-account/index.ts']);
    assert.deepEqual(uses(/APPLE_PRIVATE_KEY/), ['_shared/apple.ts']);
    assert.deepEqual(uses(/\bcreateClient\b/), ['delete-account/index.ts']); // commit-session talks to the database directly, never through the admin client
  });

  it('prints through the logger only, so nothing can be logged by accident', () => {
    const offenders = mine.filter((f) => rel(f) !== '_shared/log.ts' && /\bconsole\./.test(stripComments(readFileSync(f, 'utf8')))).map(rel);
    assert.deepEqual(offenders, []);
  });

  it('every shared module and handler has a test that imports it', () => {
    const testSource = tsFiles(TESTS).filter((f) => !f.endsWith('wiring.test.ts')).map((f) => readFileSync(f, 'utf8')).join('\n');
    const untested = mine.filter((f) => !isWiring(f)).filter((f) => !testSource.includes(`/${rel(f)}'`)).map(rel);
    assert.deepEqual(untested, []);
  });
});
