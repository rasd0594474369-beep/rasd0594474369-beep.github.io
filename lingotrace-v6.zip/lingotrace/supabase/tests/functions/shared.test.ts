import { describe, it, mock } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { bearerToken, createAuthenticator, readUserToken } from '../../functions/_shared/auth.ts';
import { isJsonContentType, parseJson, readBodyLimited } from '../../functions/_shared/body.ts';
import { corsHeaders, corsPolicyFromEnv, preflightResponse } from '../../functions/_shared/cors.ts';
import { errorResponse, isRetryable, jsonResponse, statusFor } from '../../functions/_shared/errors.ts';
import type { ErrorCode } from '../../functions/_shared/errors.ts';
import { describeError, logJson } from '../../functions/_shared/log.ts';
import { createRateLimiter } from '../../functions/_shared/rate-limit.ts';
import { NOW_MS, tokenFor } from './helpers.ts';

const U = '3f2504e0-4f89-41d3-9a0c-0305e82c3301';
const bodyOf = (chunks: Uint8Array[], headers: Record<string, string> = {}) =>
  new Request('https://x.test/', {
    method: 'POST', headers,
    body: new ReadableStream<Uint8Array>({ start(c) { for (const k of chunks) c.enqueue(k); c.close(); } }),
    duplex: 'half',
  } as RequestInit);
const bytes = (s: string) => new TextEncoder().encode(s);

describe('errors', () => {
  it('maps every code to its status, and only the retryable ones say so', () => {
    const expected: Record<ErrorCode, number> = {
      bad_request: 400, invalid_json: 400, timing_implausible: 400, apple_reauth_required: 400,
      unauthenticated: 401, lesson_not_found: 404, method_not_allowed: 405,
      lesson_unpublished: 409, lesson_locked: 409, mode_mismatch: 409, injection_invalid: 409, replay_failed: 409, out_of_order: 409,
      payload_too_large: 413, unsupported_media_type: 415, engine_outdated: 426, rate_limited: 429, internal: 500, apple_revoke_failed: 502,
    };
    for (const [code, status] of Object.entries(expected)) assert.equal(statusFor(code as ErrorCode), status, code);
    const retryable = (Object.keys(expected) as ErrorCode[]).filter(isRetryable).sort();
    assert.deepEqual(retryable, ['apple_revoke_failed', 'internal', 'out_of_order', 'rate_limited']);
  });

  it('has a status for every rejection the engine can produce (a new engine code cannot go unmapped)', () => {
    const source = readFileSync(new URL('../../../packages/engine/src/server/commit.ts', import.meta.url), 'utf8');
    const union = /export type RejectCode =([^;]+);/.exec(source)?.[1];
    assert.ok(union, 'RejectCode not found');
    const codes = [...union!.matchAll(/'([a-z_]+)'/g)].map((m) => m[1]!);
    assert.ok(codes.length >= 10);
    for (const code of codes) assert.notEqual(statusFor(code as ErrorCode), undefined, `no HTTP status for engine code "${code}"`);
  });

  it('builds one shape for failures, with Retry-After rounded up to whole seconds, at least 1', async () => {
    const r = errorResponse('rate_limited', 'slow down', { retryAfterSeconds: 59.1, details: { a: 1 }, headers: { vary: 'Origin' } });
    assert.deepEqual([r.status, r.headers.get('retry-after'), r.headers.get('vary'), r.headers.get('cache-control')], [429, '60', 'Origin', 'no-store']);
    assert.deepEqual(JSON.parse(await r.text()), { ok: false, error: { code: 'rate_limited', message: 'slow down', retryable: true, details: { a: 1 } } });
    assert.equal(errorResponse('rate_limited', 'x', { retryAfterSeconds: 0.2 }).headers.get('retry-after'), '1');
    assert.equal(errorResponse('bad_request', 'x').headers.get('retry-after'), null);
    assert.equal(jsonResponse(200, { ok: true }).headers.get('x-content-type-options'), 'nosniff');
  });
});

describe('cors', () => {
  it('reads exact origins from the secret and refuses wildcards or anything that is not an origin', () => {
    assert.deepEqual([...corsPolicyFromEnv(undefined).allowedOrigins], []);
    assert.deepEqual([...corsPolicyFromEnv(' https://a.example , http://localhost:8081 ,').allowedOrigins], ['https://a.example', 'http://localhost:8081']);
    for (const bad of ['*', 'https://*.example.com', 'https://a.example/app', 'a.example', 'ftp://a.example']) assert.throws(() => corsPolicyFromEnv(bad), /ALLOWED_ORIGINS/, bad);
  });

  it('echoes only an allowed origin, always varies on Origin, and gives permissions only in the preflight', () => {
    const policy = corsPolicyFromEnv('https://a.example');
    assert.deepEqual(corsHeaders(policy, 'https://a.example'), { vary: 'Origin', 'access-control-allow-origin': 'https://a.example' });
    assert.deepEqual(corsHeaders(policy, 'https://b.example'), { vary: 'Origin' });
    assert.deepEqual(corsHeaders(policy, null), { vary: 'Origin' });
    const ok = preflightResponse(policy, new Request('https://x.test/', { method: 'OPTIONS', headers: { origin: 'https://a.example' } }));
    assert.deepEqual([ok.status, ok.headers.get('access-control-allow-methods'), ok.headers.get('access-control-max-age')], [204, 'POST, OPTIONS', '86400']);
    const no = preflightResponse(policy, new Request('https://x.test/', { method: 'OPTIONS', headers: { origin: 'https://b.example' } }));
    assert.deepEqual([no.status, no.headers.get('access-control-allow-origin'), no.headers.get('access-control-allow-methods')], [204, null, null]);
  });
});

describe('body', () => {
  it('reads an empty body as an empty text', async () => {
    assert.deepEqual(await readBodyLimited(new Request('https://x.test/', { method: 'POST' }), 10), { ok: true, text: '' });
  });

  it('accepts exactly the limit and refuses one byte more, counting the stream itself', async () => {
    assert.deepEqual(await readBodyLimited(bodyOf([bytes('a'.repeat(10))]), 10), { ok: true, text: 'a'.repeat(10) });
    assert.deepEqual(await readBodyLimited(bodyOf([bytes('a'.repeat(5)), bytes('b'.repeat(6))]), 10), { ok: false, reason: 'too_large' });
  });

  it('believes an announced size over the limit without reading anything', async () => {
    let pulled = false;
    const req = new Request('https://x.test/', {
      method: 'POST', headers: { 'content-length': '999' },
      // highWaterMark 0: the stream is asked for data only when somebody reads it (by default it pre-fetches at creation)
      body: new ReadableStream<Uint8Array>({ pull(c) { pulled = true; c.enqueue(bytes('x')); c.close(); } }, { highWaterMark: 0 }), duplex: 'half',
    } as RequestInit);
    assert.deepEqual(await readBodyLimited(req, 100), { ok: false, reason: 'too_large' });
    assert.equal(pulled, false);
    // control: without the announcement the same stream IS read
    pulled = false;
    const unannounced = new Request('https://x.test/', { method: 'POST', body: new ReadableStream<Uint8Array>({ pull(c) { pulled = true; c.enqueue(bytes('x')); c.close(); } }, { highWaterMark: 0 }), duplex: 'half' } as RequestInit);
    assert.deepEqual(await readBodyLimited(unannounced, 100), { ok: true, text: 'x' });
    assert.equal(pulled, true);
  });

  it('joins chunks before decoding, so a character split between chunks survives; invalid UTF-8 is refused', async () => {
    const e = bytes('é'); // two bytes
    assert.deepEqual(await readBodyLimited(bodyOf([e.slice(0, 1), e.slice(1)]), 10), { ok: true, text: 'é' });
    assert.deepEqual(await readBodyLimited(bodyOf([new Uint8Array([0xff, 0xfe, 0x41])]), 10), { ok: false, reason: 'invalid_text' });
  });

  it('recognises JSON content types and parses JSON without throwing', () => {
    for (const ok of ['application/json', 'application/json; charset=utf-8', ' Application/JSON ;charset=UTF-8']) assert.ok(isJsonContentType(ok), ok);
    for (const no of [null, '', 'text/plain', 'application/jsonp', 'application/json-patch+json', 'multipart/form-data; x=application/json']) assert.ok(!isJsonContentType(no), String(no));
    assert.deepEqual(parseJson('{"a":1}'), { ok: true, value: { a: 1 } });
    assert.deepEqual(parseJson('{nope'), { ok: false });
  });
});

describe('rate limiter', () => {
  it('lets `limit` requests through per window, then says how long to wait', () => {
    let t = 1_000_000;
    const limiter = createRateLimiter({ limit: 3, windowMs: 60_000, now: () => t });
    for (let i = 0; i < 3; i++) { assert.deepEqual(limiter.check('a'), { allowed: true }); t += 1000; }
    assert.deepEqual(limiter.check('a'), { allowed: false, retryAfterSeconds: 57 }); // the first hit leaves the window 57 s from now
    assert.deepEqual(limiter.check('b'), { allowed: true }); // keys are independent
  });

  it('slides: each old hit frees one place as it leaves the window', () => {
    let t = 0;
    const limiter = createRateLimiter({ limit: 2, windowMs: 10_000, now: () => t });
    limiter.check('a'); t = 4000; limiter.check('a');
    t = 9000; assert.equal(limiter.check('a').allowed, false);
    t = 10_001; assert.equal(limiter.check('a').allowed, true); // the hit at 0 is gone, the one at 4000 still counts
    assert.equal(limiter.check('a').allowed, false);
    t = 14_001; assert.equal(limiter.check('a').allowed, true);
  });

  it('counts a refused request as nothing: waiting the advertised time is enough', () => {
    let t = 0;
    const limiter = createRateLimiter({ limit: 1, windowMs: 5000, now: () => t });
    limiter.check('a');
    for (let i = 0; i < 20; i++) { t += 100; assert.equal(limiter.check('a').allowed, false); } // hammering does not extend the ban
    t = 5001;
    assert.equal(limiter.check('a').allowed, true);
  });

  it('keeps memory bounded by forgetting the longest-idle keys, and rejects nonsense settings', () => {
    let t = 0;
    const limiter = createRateLimiter({ limit: 1, windowMs: 60_000, maxKeys: 2, now: () => t });
    for (const k of ['a', 'b', 'c']) { t += 10; limiter.check(k); }
    assert.equal(limiter.check('c').allowed, false);
    assert.equal(limiter.check('b').allowed, false);
    assert.equal(limiter.check('a').allowed, true); // 'a' was forgotten to make room
    for (const bad of [{ limit: 0, windowMs: 1 }, { limit: 1.5, windowMs: 1 }, { limit: 1, windowMs: 0 }]) assert.throws(() => createRateLimiter(bad), /limit/);
  });
});

describe('auth (reading the user token)', () => {
  const req = (authorization?: string) => new Request('https://x.test/', { headers: authorization === undefined ? {} : { authorization } });
  const claims = (o: Record<string, unknown>) => {
    const part = (v: unknown) => Buffer.from(JSON.stringify(v)).toString('base64url');
    return `${part({ alg: 'ES256' })}.${part({ sub: U, role: 'authenticated', aud: 'authenticated', exp: Math.floor(NOW_MS / 1000) + 60, ...o })}.c2ln`;
  };

  it('takes the token from a Bearer header only', () => {
    assert.equal(bearerToken(req('Bearer abc.def.ghi')), 'abc.def.ghi');
    assert.equal(bearerToken(req('bearer   abc')), null); // exactly one space: keeps parsing strict
    assert.equal(bearerToken(req('  Bearer abc  ')), 'abc');
    for (const bad of [undefined, '', 'Bearer', 'Basic abc', 'Bearer a b', 'abc']) assert.equal(bearerToken(req(bad)), null, String(bad));
  });

  it('reads the user id and linked sign-in methods of a valid token', () => {
    const r = readUserToken(tokenFor(U.toUpperCase(), { providers: ['apple', 'google'] }), NOW_MS);
    assert.deepEqual(r, { ok: true, user: { id: U, providers: ['apple', 'google'], isAnonymous: false } });
    const anon = readUserToken(claims({ is_anonymous: true, app_metadata: { provider: 'anonymous' } }), NOW_MS);
    assert.deepEqual(anon, { ok: true, user: { id: U, providers: ['anonymous'], isAnonymous: true } });
    const none = readUserToken(claims({ app_metadata: undefined }), NOW_MS);
    assert.ok(none.ok && none.user.providers.length === 0);
    assert.ok(readUserToken(claims({ aud: ['x', 'authenticated'] }), NOW_MS).ok);
  });

  it('refuses tokens that are not a signed-in user\'s, with a reason for the log', () => {
    const exp = Math.floor(NOW_MS / 1000);
    const cases: Array<[string, string, RegExp]> = [
      ['not three parts', 'a.b', /not a JWT/],
      ['empty part', `a..c`, /not a JWT/],
      ['unreadable header', 'a!.b.c', /unreadable/],
      ['payload is an array', `${Buffer.from('{}').toString('base64url')}.${Buffer.from('[]').toString('base64url')}.c`, /unreadable/],
      ['unsigned (alg none)', `${Buffer.from('{"alg":"none"}').toString('base64url')}.${claims({}).split('.')[1]}.c`, /unsigned/],
      ['no subject', claims({ sub: undefined }), /user id/],
      ['subject is not a uuid', claims({ sub: 'abc' }), /user id/],
      ['anon key', claims({ role: 'anon' }), /signed-in user/],
      ['service role', claims({ role: 'service_role' }), /signed-in user/],
      ['wrong audience', claims({ aud: 'other' }), /audience/],
      ['expired', claims({ exp: exp - 1 }), /expired/],
      ['expires exactly now', claims({ exp }), /expired/],
      ['exp is not a number', claims({ exp: '9999999999' }), /expired/],
      ['not valid yet', claims({ nbf: exp + 10 }), /not valid yet/],
      ['nbf of the wrong type', claims({ nbf: 'soon' }), /not valid yet/],
      ['absurdly long', `${'a'.repeat(9000)}.b.c`, /too long/],
    ];
    for (const [label, token, reason] of cases) {
      const r = readUserToken(token, NOW_MS);
      assert.ok(!r.ok, label);
      if (!r.ok) assert.match(r.reason, reason, label);
    }
  });

  it('uses its own clock for expiry', () => {
    const token = tokenFor(U, { exp: Math.floor(NOW_MS / 1000) + 10 });
    assert.ok(createAuthenticator({ now: () => NOW_MS })(req(`Bearer ${token}`)).ok);
    assert.ok(!createAuthenticator({ now: () => NOW_MS + 11_000 })(req(`Bearer ${token}`)).ok);
    assert.deepEqual(createAuthenticator()(req()), { ok: false, reason: 'no bearer token' });
  });
});

describe('log', () => {
  it('describes any thrown value briefly', () => {
    assert.deepEqual(describeError(new TypeError('x'.repeat(400))), { name: 'TypeError', message: 'x'.repeat(300) });
    assert.deepEqual(describeError('plain text'), { name: 'NonError', message: 'plain text' });
  });

  it('writes one JSON line per event to the matching console stream', () => {
    const out = mock.method(console, 'log', () => {});
    const warn = mock.method(console, 'warn', () => {});
    const err = mock.method(console, 'error', () => {});
    try {
      logJson('info', 'a', { n: 1 });
      logJson('warn', 'b');
      logJson('error', 'c', { userId: U });
      assert.deepEqual(out.mock.calls.map((c) => JSON.parse(String(c.arguments[0]))), [{ level: 'info', event: 'a', n: 1 }]);
      assert.deepEqual(warn.mock.calls.map((c) => JSON.parse(String(c.arguments[0]))), [{ level: 'warn', event: 'b' }]);
      assert.deepEqual(err.mock.calls.map((c) => JSON.parse(String(c.arguments[0]))), [{ level: 'error', event: 'c', userId: U }]);
    } finally {
      mock.restoreAll();
    }
  });
});
