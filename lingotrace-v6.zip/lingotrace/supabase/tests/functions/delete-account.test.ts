import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { AppleError } from '../../functions/_shared/apple.ts';
import type { AppleConfig } from '../../functions/_shared/apple.ts';
import { createAuthenticator } from '../../functions/_shared/auth.ts';
import { corsPolicyFromEnv } from '../../functions/_shared/cors.ts';
import { createRateLimiter } from '../../functions/_shared/rate-limit.ts';
import { createDeleteAccountHandler } from '../../functions/delete-account/handler.ts';
import type { DeleteHandlerDeps } from '../../functions/delete-account/handler.ts';
import { NOW_MS, ORIGIN, PLAYED_AT, HOUR, UUID_IDS, commitHandler, play, readJson, request, tokenFor, uuidOf, world } from './helpers.ts';
import type { LogEvent } from './helpers.ts';

const U1 = UUID_IDS.user(1);
const U2 = UUID_IDS.user(2);
const APPLE: AppleConfig = { teamId: 'TEAM', keyId: 'KEY', clientId: 'com.example.lingotrace', privateKeyPem: 'not used: revocation is faked here' };
const CODE = 'c-1234567890-apple-authorization-code';

function deleteHandler(overrides: Partial<DeleteHandlerDeps> = {}) {
  const events: LogEvent[] = [];
  const calls: string[] = [];
  const handler = createDeleteAccountHandler({
    authenticate: createAuthenticator({ now: () => NOW_MS }),
    limiter: createRateLimiter({ limit: 1000, windowMs: 3_600_000, now: () => NOW_MS }),
    cors: corsPolicyFromEnv(ORIGIN),
    now: () => new Date(NOW_MS),
    log: (level, event, data = {}) => events.push({ level, event, data }),
    apple: APPLE,
    revokeApple: async (_config, code) => { calls.push(`revoke:${code}`); },
    deleteUser: async (id) => { calls.push(`delete:${id}`); return 'deleted'; },
    ...overrides,
  });
  return { handler, events, calls };
}
const del = (o: Parameters<typeof request>[1] = {}) => request('delete-account', { token: tokenFor(U1), ...o });

describe('delete-account handler', () => {
  it('handles preflight, refuses other methods and missing or wrong tokens, and deletes nothing in those cases', async () => {
    const { handler, calls } = deleteHandler();
    const pre = await handler(request('delete-account', { method: 'OPTIONS', headers: { origin: ORIGIN } }));
    assert.deepEqual([pre.status, pre.headers.get('access-control-allow-origin')], [204, ORIGIN]);
    assert.equal((await handler(request('delete-account', { method: 'GET', token: tokenFor(U1) }))).status, 405);
    for (const token of [null, 'garbage', tokenFor(U1, { role: 'anon' }), tokenFor(U1, { exp: Math.floor(NOW_MS / 1000) - 5 })]) {
      const r = await handler(request('delete-account', { token, rawBody: '' }));
      assert.deepEqual([r.status, (await readJson(r)).error.code], [401, 'unauthenticated']);
    }
    assert.deepEqual(calls, []);
  });

  it('deletes a Google user with no body at all, and never touches Apple', async () => {
    const { handler, calls } = deleteHandler();
    const r = await handler(request('delete-account', { token: tokenFor(U1), rawBody: '', headers: { 'content-type': '' } }));
    assert.equal(r.status, 200);
    assert.deepEqual(await readJson(r), { ok: true, appleRevocation: 'not_linked', alreadyDeleted: false });
    assert.deepEqual(calls, [`delete:${U1}`]);
  });

  it('asks an Apple user for a fresh authorization code and deletes nothing until it arrives', async () => {
    const { handler, calls } = deleteHandler();
    const r = await handler(del({ token: tokenFor(U1, { providers: ['apple'] }), rawBody: '' }));
    assert.equal(r.status, 400);
    const body = await readJson(r);
    assert.deepEqual([body.error.code, body.error.retryable], ['apple_reauth_required', false]);
    assert.deepEqual(calls, []);
  });

  it('revokes the Apple tokens first and deletes the account after, in that order', async () => {
    const { handler, calls } = deleteHandler();
    const r = await handler(del({ token: tokenFor(U1, { providers: ['google', 'apple'] }), body: { appleAuthorizationCode: CODE } }));
    assert.equal(r.status, 200);
    assert.deepEqual(await readJson(r), { ok: true, appleRevocation: 'revoked', alreadyDeleted: false });
    assert.deepEqual(calls, [`revoke:${CODE}`, `delete:${U1}`]);
  });

  it('stops when Apple refuses: nothing is deleted, the user can retry, and the code never reaches the log', async () => {
    const { handler, calls, events } = deleteHandler({
      revokeApple: async () => { throw new AppleError('exchange', 400, 'exchange: Apple answered 400 (invalid_grant)'); },
    });
    const r = await handler(del({ token: tokenFor(U1, { providers: ['apple'] }), body: { appleAuthorizationCode: CODE } }));
    assert.equal(r.status, 502);
    const body = await readJson(r);
    assert.deepEqual([body.error.code, body.error.retryable], ['apple_revoke_failed', true]);
    assert.deepEqual(calls, []);
    const logged = events.find((e) => e.event === 'apple_revoke_failed');
    assert.deepEqual(logged?.data, { userId: U1, stage: 'exchange', status: 400 });
    assert.ok(!JSON.stringify(events).includes(CODE));
  });

  it('still deletes an Apple user when Sign in with Apple is not set up on the server, and says so', async () => {
    const { handler, calls, events } = deleteHandler({ apple: null });
    const r = await handler(del({ token: tokenFor(U1, { providers: ['apple'] }), rawBody: '' }));
    assert.equal(r.status, 200);
    assert.equal((await readJson(r)).appleRevocation, 'skipped_not_configured');
    assert.deepEqual(calls, [`delete:${U1}`]);
    assert.ok(events.some((e) => e.level === 'warn' && e.event === 'apple_not_configured'));
  });

  it('treats an account that is already gone as deleted, so a retry after a lost answer is harmless', async () => {
    const { handler } = deleteHandler({ deleteUser: async () => 'not_found' });
    const r = await handler(del({ rawBody: '' }));
    assert.deepEqual([r.status, await readJson(r)], [200, { ok: true, appleRevocation: 'not_linked', alreadyDeleted: true }]);
  });

  it('turns a failure while deleting into a generic 500 that repeats nothing internal', async () => {
    const { handler, events } = deleteHandler({ deleteUser: async () => { throw new Error('auth admin 500: secret=sb_secret_abc'); } });
    const r = await handler(del({ rawBody: '' }));
    assert.equal(r.status, 500);
    const text = await r.text();
    assert.ok(!text.includes('sb_secret_abc'));
    assert.equal(JSON.parse(text).error.code, 'internal');
    assert.ok(events.some((e) => e.event === 'delete_failed' && e.level === 'error'));
  });

  it('checks the body it accepts: size, JSON, type of the code, content type', async () => {
    const { handler, calls } = deleteHandler();
    const apple = tokenFor(U1, { providers: ['apple'] });
    const cases: Array<[string, Parameters<typeof request>[1], number, string]> = [
      ['invalid JSON', { token: apple, rawBody: '{nope' }, 400, 'invalid_json'],
      ['a JSON array', { token: apple, rawBody: '[]' }, 400, 'invalid_json'],
      ['code that is not text', { token: apple, body: { appleAuthorizationCode: 12345 } }, 400, 'bad_request'],
      ['empty code', { token: apple, body: { appleAuthorizationCode: '' } }, 400, 'bad_request'],
      ['code that is far too long', { token: apple, body: { appleAuthorizationCode: 'x'.repeat(2049) } }, 400, 'bad_request'],
      ['a body over 4 KB', { token: apple, rawBody: JSON.stringify({ appleAuthorizationCode: 'x'.repeat(5000) }) }, 413, 'payload_too_large'],
      ['not declared as JSON', { token: apple, rawBody: '{"appleAuthorizationCode":"abc"}', headers: { 'content-type': 'text/plain' } }, 415, 'unsupported_media_type'],
    ];
    for (const [label, o, status, code] of cases) {
      const r = await handler(request('delete-account', o));
      assert.deepEqual([r.status, (await readJson(r)).error.code], [status, code], label);
    }
    assert.deepEqual(calls, []);
  });

  it('deletes the user named in the token, whatever the body says', async () => {
    const { handler, calls } = deleteHandler();
    const r = await handler(del({ body: { userId: U2, user_id: U2, id: U2 } })); // signed in as U1
    assert.equal(r.status, 200);
    assert.deepEqual(calls, [`delete:${U1}`]);
  });

  it('allows five attempts an hour per user', async () => {
    let clock = NOW_MS;
    const { handler, calls } = deleteHandler({ limiter: createRateLimiter({ limit: 5, windowMs: 3_600_000, now: () => clock }) });
    for (let i = 0; i < 5; i++) assert.equal((await handler(del({ rawBody: '' }))).status, 200);
    const sixth = await handler(del({ rawBody: '' }));
    assert.equal(sixth.status, 429);
    assert.ok(Number(sixth.headers.get('retry-after')) >= 1);
    assert.equal(calls.length, 5);
    clock += 3_600_001;
    assert.equal((await handler(del({ rawBody: '' }))).status, 200);
  });

  it('wipes a user\'s whole history (a session chain with attempts, XP, rotation) and leaves everyone else alone', async () => {
    const w = await world();
    const commit = commitHandler(w.repo).handler;
    const send = async (user: string, body: unknown) => assert.equal((await commit(request('commit-session', { token: tokenFor(user), body }))).status, 200);
    // U1: two chained sessions, one with a mistake so the rotation and misspelling tables hold rows; U2: one session
    const s1 = uuidOf('u1-s1');
    await send(U1, play(UUID_IDS, { n: 1, sessionId: s1, answer: (p) => (p.text === 'candle' ? 'zzndle' : p.text) }));
    await send(U1, play(UUID_IDS, { n: 2, sessionId: uuidOf('u1-s2'), parent: s1, at: PLAYED_AT + HOUR }));
    await send(U2, play(UUID_IDS, { n: 1, sessionId: uuidOf('u2-s1') }));

    const tables = ['lesson_sessions', 'user_word_stats', 'misspelled_words', 'xp_events', 'user_progress'];
    const rows = (table: string, user: string) => Number(w.db.prepare(`SELECT count(*) AS n FROM ${table} WHERE user_id = ?1`).all(user)[0]!.n);
    const attemptsOf = (user: string) => Number(w.db.prepare('SELECT count(*) AS n FROM session_attempts WHERE session_id IN (SELECT id FROM lesson_sessions WHERE user_id = ?1)').all(user)[0]!.n);
    for (const t of tables) assert.ok(rows(t, U1) > 0, `precondition: U1 has rows in ${t}`);
    const u2Before = [...tables.map((t) => rows(t, U2)), attemptsOf(U2)];

    const { handler } = deleteHandler({
      deleteUser: async (id) => (Number(w.db.prepare('DELETE FROM users WHERE id = ?1').run(id).changes) > 0 ? 'deleted' : 'not_found'), // stands in for auth.users -> users cascade
    });
    const r = await handler(del({ rawBody: '' }));
    assert.equal(r.status, 200);

    assert.deepEqual([...tables.map((t) => rows(t, U1)), attemptsOf(U1)], [0, 0, 0, 0, 0, 0]);
    assert.deepEqual([...tables.map((t) => rows(t, U2)), attemptsOf(U2)], u2Before);
    assert.equal(Number(w.db.prepare('SELECT count(*) AS n FROM users WHERE id = ?1').all(U1)[0]!.n), 0);
  });
});
