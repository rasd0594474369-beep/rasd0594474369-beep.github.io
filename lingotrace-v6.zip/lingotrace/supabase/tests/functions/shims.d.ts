// Stand-ins for what only exists inside the Deno runtime, so `tsc` can check the wiring files (index.ts, db.ts) that Node cannot run.
// They are written from the Supabase / deno-postgres / supabase-js documentation and are ASSUMPTIONS: they prove that our files agree
// with each other and with these signatures, not that the signatures match the real libraries. The deploy-time contract script does that.

declare const Deno: {
  env: { get(name: string): string | undefined };
  serve(handler: (req: Request) => Response | Promise<Response>): unknown;
};

declare module 'npm:@supabase/supabase-js@2.106.1' {
  export interface AuthAdminError {
    status?: number;
    code?: string;
  }
  export function createClient(
    url: string,
    key: string,
    options?: { auth?: { persistSession?: boolean; autoRefreshToken?: boolean } },
  ): { auth: { admin: { deleteUser(id: string): Promise<{ error: AuthAdminError | null }> } } };
}

declare module 'https://deno.land/x/postgres@v0.17.0/mod.ts' {
  export interface PoolClient {
    queryObject(query: { text: string; args?: unknown[] }): Promise<{ rows: unknown[] }>;
    release(): void;
  }
  export class Pool {
    constructor(connection: string, size: number, lazy?: boolean);
    connect(): Promise<PoolClient>;
  }
}
