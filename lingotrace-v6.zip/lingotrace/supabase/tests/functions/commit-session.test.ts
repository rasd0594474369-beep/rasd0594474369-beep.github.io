import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { PgRepo } from '../../functions/_shared/engine/server/index.ts';
import type { CommitRepo } from '../../functions/_shared/engine/server/index.ts';
import { createRateLimiter } from '../../functions/_shared/rate-limit.ts';
import { HOUR, NOW_MS, ORIGIN, PLAYED_AT, UUID_IDS, commitHandler, play, readJson, request, tokenFor, uuidOf, world } from './helpers.ts';

const U1 = UUID_IDS.user(1);
const U2 = UUID_IDS.user(2);
const post = (path = 'commit-session', o = {}) => request(path, { token: tokenFor(U1), ...o });
const count = (w: Awaited<ReturnType<typeof world>>, sql: string) => Number(w.db.prepare(`SELECT count(*) AS n FROM ${sql}`).all()[0]!.n);

/** Wraps a repo and counts how often the database was used. */
function spy(repo: CommitRepo): { repo: CommitRepo; calls: () => number } {
  let n = 0;
  return { repo: { transaction: (fn) => (n++, repo.transaction(fn)) }, calls: () => n };
}

describe('commit-session handler', () => {
  it('answers the browser preflight for an allowed origin only, without authentication', async () => {
    const w = await world();
    const { handler } = commitHandler(w.repo);
    const ok = await handler(request('commit-session', { method: 'OPTIONS', headers: { origin: ORIGIN } }));
    assert.equal(ok.status, 204);
    assert.equal(ok.headers.get('access-control-allow-origin'), ORIGIN);
    assert.match(ok.headers.get('access-control-allow-headers') ?? '', /authorization/);
    assert.match(ok.headers.get('access-control-allow-headers') ?? '', /x-region/);
    const other = await handler(request('commit-session', { method: 'OPTIONS', headers: { origin: 'https://evil.example' } }));
    assert.equal(other.status, 204);
    assert.equal(other.headers.get('access-control-allow-origin'), null);
  });

  it('accepts only POST', async () => {
    const w = await world();
    const { handler } = commitHandler(w.repo);
    const r = await handler(request('commit-session', { method: 'GET', token: tokenFor(U1) }));
    assert.equal(r.status, 405);
    assert.equal(r.headers.get('allow'), 'POST, OPTIONS');
    assert.equal((await readJson(r)).error.code, 'method_not_allowed');
  });

  it('refuses missing, malformed and non-user tokens before the database is touched', async () => {
    const w = await world();
    const db = spy(w.repo);
    const { handler } = commitHandler(db.repo);
    const exp = Math.floor(NOW_MS / 1000);
    const bad: Array<[string, string | null]> = [
      ['no header', null],
      ['not a JWT', 'garbage'],
      ['anon key (role anon)', tokenFor(U1, { role: 'anon' })],
      ['service role', tokenFor(U1, { role: 'service_role' })],
      ['expired', tokenFor(U1, { exp: exp - 1 })],
      ['sub is not a uuid', tokenFor(U1, { sub: 'someone' })],
      ['wrong audience', tokenFor(U1, { aud: 'other' })],
    ];
    for (const [label, token] of bad) {
      const r = await handler(request('commit-session', { token, body: play(UUID_IDS, { n: 1, sessionId: uuidOf(label) }) }));
      assert.equal(r.status, 401, label);
      const body = await readJson(r);
      assert.deepEqual([body.ok, body.error.code, body.error.retryable], [false, 'unauthenticated', false], label);
    }
    assert.equal(db.calls(), 0);
  });

  it('requires a JSON content type', async () => {
    const w = await world();
    const { handler } = commitHandler(w.repo);
    const r = await handler(post('commit-session', { headers: { 'content-type': 'text/plain' }, rawBody: '{}' }));
    assert.equal(r.status, 415);
  });

  it('refuses a body over the limit, whether it announces its size or not', async () => {
    const w = await world();
    const db = spy(w.repo);
    const { handler } = commitHandler(db.repo, { maxBodyBytes: 500 });
    const big = 'x'.repeat(2000);
    // announced size
    const announced = await handler(post('commit-session', { rawBody: big, headers: { 'content-length': String(big.length) } }));
    assert.equal(announced.status, 413);
    // no usable size: a stream that just keeps going
    const chunk = new TextEncoder().encode('y'.repeat(200));
    let sent = 0;
    const stream = new ReadableStream<Uint8Array>({ pull(c) { if (sent++ < 50) c.enqueue(chunk); else c.close(); } });
    const streamed = await handler(new Request('https://project.supabase.co/functions/v1/commit-session', {
      method: 'POST', headers: { 'content-type': 'application/json', authorization: `Bearer ${tokenFor(U1)}` }, body: stream, duplex: 'half',
    } as RequestInit));
    assert.equal(streamed.status, 413);
    assert.equal((await readJson(streamed)).error.code, 'payload_too_large');
    assert.equal(db.calls(), 0);
  });

  it('refuses invalid JSON and wrong shapes with a clear 400', async () => {
    const w = await world();
    const db = spy(w.repo);
    const { handler } = commitHandler(db.repo);
    const cases: Array<[string, string, string]> = [
      ['not JSON', '{nope', 'invalid_json'],
      ['array', '[]', 'bad_request'],
      ['empty object', '{}', 'bad_request'],
    ];
    for (const [label, rawBody, code] of cases) {
      const r = await handler(post('commit-session', { rawBody }));
      assert.equal(r.status, 400, label);
      assert.equal((await readJson(r)).error.code, code, label);
    }
    const noAttempts = { ...play(UUID_IDS, { n: 1, sessionId: uuidOf('s') }), attempts: [null] };
    const r = await handler(post('commit-session', { body: noAttempts }));
    assert.equal(r.status, 400);
    assert.match((await readJson(r)).error.message, /attempts\[0\]/);
    assert.equal(db.calls(), 0); // a malformed body never gets as far as the database
  });

  it('commits a lesson: 200 with the receipt, rows written for the user in the token', async () => {
    const w = await world();
    const { handler } = commitHandler(w.repo);
    const commit = play(UUID_IDS, { n: 1, sessionId: uuidOf('s1') });
    const r = await handler(post('commit-session', { body: commit, headers: { origin: ORIGIN } }));
    assert.equal(r.status, 200);
    assert.match(r.headers.get('content-type') ?? '', /application\/json/);
    assert.equal(r.headers.get('cache-control'), 'no-store');
    assert.equal(r.headers.get('access-control-allow-origin'), ORIGIN);
    const body = await readJson(r);
    assert.equal(body.ok, true);
    assert.deepEqual([body.receipt.status, body.receipt.xpEarned, body.receipt.totalXp, body.receipt.streak], ['committed', 250, 250, 1]);
    assert.deepEqual(w.db.prepare('SELECT user_id, parent_session_id AS parent, words_clean FROM lesson_sessions').all().map((x) => ({ ...x })), [{ user_id: U1, parent: null, words_clean: 20 }]);
    assert.equal(count(w, 'session_attempts'), 40);
  });

  it('takes the user from the token only: a user id in the body changes nothing', async () => {
    const w = await world();
    const { handler } = commitHandler(w.repo);
    const commit = { ...play(UUID_IDS, { n: 1, sessionId: uuidOf('s1') }), userId: U2, user_id: U2 };
    const r = await handler(post('commit-session', { body: commit })); // signed in as U1
    assert.equal(r.status, 200);
    assert.deepEqual(w.db.prepare('SELECT user_id FROM lesson_sessions').all().map((x) => x.user_id), [U1]);
    assert.equal(Number(w.db.prepare('SELECT total_xp AS n FROM users WHERE id = ?1').all(U2)[0]!.n), 0);
  });

  it('answers a repeated session with the same receipt instead of an error', async () => {
    const w = await world();
    const { handler } = commitHandler(w.repo);
    const commit = play(UUID_IDS, { n: 1, sessionId: uuidOf('s1') });
    await handler(post('commit-session', { body: commit }));
    const again = await handler(post('commit-session', { body: commit }));
    assert.equal(again.status, 200);
    assert.equal((await readJson(again)).receipt.status, 'duplicate');
    assert.equal(count(w, 'lesson_sessions'), 1);
  });

  it('answers 409 out_of_order with the chain head, and an outbox sent in order goes through', async () => {
    const w = await world();
    const { handler } = commitHandler(w.repo);
    const [a, b, c] = [uuidOf('A'), uuidOf('B'), uuidOf('C')];
    const sessions = [
      play(UUID_IDS, { n: 1, sessionId: a, parent: null, at: PLAYED_AT }),
      play(UUID_IDS, { n: 2, sessionId: b, parent: a, at: PLAYED_AT + HOUR }),
      play(UUID_IDS, { n: 3, sessionId: c, parent: b, at: PLAYED_AT + 2 * HOUR }),
    ];
    const send = (s: (typeof sessions)[number]) => handler(post('commit-session', { body: s }));

    const early = await send(sessions[2]!);
    assert.equal(early.status, 409);
    const body = await readJson(early);
    assert.deepEqual([body.error.code, body.error.retryable, body.error.details], ['out_of_order', true, { lastSessionId: null }]);
    for (const s of sessions) assert.equal((await send(s)).status, 200, s.sessionId);
    assert.deepEqual(w.db.prepare('SELECT id FROM lesson_sessions ORDER BY completed_at').all().map((x) => x.id), [a, b, c]);
  });

  it('keeps the engine\'s reasons as stable codes with fitting statuses, none of them retryable', async () => {
    const w = await world();
    const { handler } = commitHandler(w.repo);
    const a = uuidOf('A');
    const lesson2 = play(UUID_IDS, { n: 2, sessionId: uuidOf('locked'), parent: null });
    const unknown = { ...play(UUID_IDS, { n: 1, sessionId: uuidOf('ghost') }), lessonId: uuidOf('no such lesson') };
    const outdated = { ...play(UUID_IDS, { n: 1, sessionId: uuidOf('old') }), engineVersion: 0 };
    const cases: Array<[string, unknown, number, string]> = [
      ['lesson is locked', lesson2, 409, 'lesson_locked'],
      ['lesson does not exist', unknown, 404, 'lesson_not_found'],
      ['app is out of date', outdated, 426, 'engine_outdated'],
    ];
    for (const [label, body, status, code] of cases) {
      const r = await handler(post('commit-session', { body }));
      const json = await readJson(r);
      assert.deepEqual([r.status, json.error.code, json.error.retryable], [status, code, false], label);
    }
    // a lesson already completed must be sent as a replay
    await handler(post('commit-session', { body: play(UUID_IDS, { n: 1, sessionId: a }) }));
    const again = await handler(post('commit-session', { body: play(UUID_IDS, { n: 1, sessionId: uuidOf('again'), parent: a }) }));
    assert.deepEqual([again.status, (await readJson(again)).error.code], [409, 'mode_mismatch']);
    assert.equal(count(w, 'lesson_sessions'), 1); // rejections leave no trace
  });

  it('limits each user separately, tells them when to retry, and recovers after the window', async () => {
    const w = await world();
    let clock = NOW_MS;
    const { handler } = commitHandler(w.repo, { limiter: createRateLimiter({ limit: 3, windowMs: 60_000, now: () => clock }) });
    const hit = (token: string) => handler(request('commit-session', { token, rawBody: '{}' })); // fails validation: the limiter counts requests, not successes
    for (let i = 0; i < 3; i++) assert.equal((await hit(tokenFor(U1))).status, 400);
    const limited = await hit(tokenFor(U1));
    assert.equal(limited.status, 429);
    assert.ok(Number(limited.headers.get('retry-after')) >= 1);
    const limitedBody = await readJson(limited);
    assert.deepEqual([limitedBody.error.code, limitedBody.error.retryable], ['rate_limited', true]);
    assert.equal((await hit(tokenFor(U2))).status, 400); // another user is not affected
    clock += 61_000;
    assert.equal((await hit(tokenFor(U1))).status, 400);
  });

  it('turns an unexpected failure into a generic 500: nothing internal in the answer, details only in the log', async () => {
    const boom: CommitRepo = { transaction: async () => { throw new Error('connection to db.internal.example failed: password=hunter2'); } };
    const { handler, events } = commitHandler(boom);
    const r = await handler(post('commit-session', { body: play(UUID_IDS, { n: 1, sessionId: uuidOf('s1') }) }));
    assert.equal(r.status, 500);
    const text = await r.text();
    assert.ok(!/hunter2|internal\.example/.test(text), 'the answer must not repeat the error text');
    const body = JSON.parse(text);
    assert.deepEqual([body.error.code, body.error.retryable], ['internal', true]);
    const logged = events.find((e) => e.event === 'commit_failed');
    assert.ok(logged && logged.level === 'error');
    assert.match(String((logged!.data.error as { message: string }).message), /hunter2/); // support can still see it
  });

  it('logs ids, codes and timings, never what the user typed', async () => {
    const w = await world();
    const { handler, events } = commitHandler(w.repo);
    const sessionId = uuidOf('s1');
    const secret = 'zzdistinctivezz';
    const commit = play(UUID_IDS, { n: 1, sessionId, answer: (p) => (p.text === 'candle' ? secret : p.text) });
    assert.ok(commit.attempts.some((a) => a.input === secret), 'precondition: the wrong answer is in the payload');
    const r = await handler(post('commit-session', { body: commit }));
    assert.equal(r.status, 200);
    const everything = JSON.stringify(events);
    assert.ok(!everything.includes(secret));
    assert.ok(!everything.includes('Bearer') && !everything.includes(tokenFor(U1)));
    const line = events.find((e) => e.event === 'commit');
    assert.deepEqual([line?.data.userId, line?.data.sessionId], [U1, sessionId]);
    assert.equal(typeof line?.data.ms, 'number');
  });
});
