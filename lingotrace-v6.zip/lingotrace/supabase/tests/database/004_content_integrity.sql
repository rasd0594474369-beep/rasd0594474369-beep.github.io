-- =============================================================================
-- 004_content_integrity.sql   READ-ONLY. Run it after the content was imported (supabase/seed). Status: written, to be run after the import (phase 3).
--   psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f supabase/tests/database/004_content_integrity.sql
-- Every row of the result must have ok = true. On an empty database it only reports "no content yet".
-- It checks the data the app depends on: 20 words per lesson, every word in exactly one lesson, every sentence
-- holding its word, dense lesson order, level/rank consistency, and intact Arabic (a wrong client encoding at
-- import time turns Arabic into question marks, which this catches). Keep this file plain ASCII.
-- =============================================================================
begin;

create temp table results (n serial primary key, ok boolean not null, label text not null, detail text);
create function pg_temp.rec(p_label text, p_ok boolean, p_detail text default null) returns void language plpgsql as $$
begin
  insert into results (ok, label, detail) values (coalesce(p_ok, false), p_label, p_detail);
end $$;

do $$
declare
  ar_re text := '[' || chr(1536) || '-' || chr(1791) || ']';   -- the Arabic block U+0600..U+06FF
  n_lessons bigint; n_words bigint; n_links bigint; bad bigint; lv record;
begin
  select count(*) into n_lessons from public.lessons;
  select count(*) into n_words from public.vocabulary_bank;
  select count(*) into n_links from public.lesson_words;
  if n_words = 0 then
    perform pg_temp.rec('no content yet: import supabase/seed first, then run this file again', true, 'lessons ' || n_lessons || ', words ' || n_words);
    return;
  end if;
  perform pg_temp.rec('content size (the shipped list is 140 lessons, 2800 words, 2800 links)', n_links = n_lessons * 20 and n_words = n_links, n_lessons || ' lessons, ' || n_words || ' words, ' || n_links || ' links');

  select count(*) into bad from (select lesson_id from public.lesson_words group by lesson_id having count(*) <> 20 or min(position) <> 1 or max(position) <> 20) x;
  perform pg_temp.rec('every lesson has exactly 20 words at positions 1..20', bad = 0, bad || ' lesson(s) differ');
  select count(*) into bad from public.lessons l where not exists (select 1 from public.lesson_words lw where lw.lesson_id = l.id);
  perform pg_temp.rec('no empty lesson', bad = 0, bad::text);
  select count(*) into bad from public.vocabulary_bank w where (select count(*) from public.lesson_words lw where lw.word_id = w.id) <> 1;
  perform pg_temp.rec('every word is in exactly one lesson', bad = 0, bad || ' word(s) in none or several');

  select count(*) into bad from public.vocabulary_bank where sentence_context !~* ('\m' || word_text || '\M');
  perform pg_temp.rec('every sentence contains its word as a whole word', bad = 0, bad || ' sentence(s) lack the word');
  select count(*) into bad from public.vocabulary_bank where word_text !~ '^[A-Za-z]+$';
  perform pg_temp.rec('words are plain letters (no spaces, digits or punctuation)', bad = 0, bad::text);

  perform pg_temp.rec('lesson order is dense: global_seq is 1..N', (select min(global_seq) = 1 and max(global_seq) = count(*) and count(distinct global_seq) = count(*) from public.lessons), null);
  select count(*) into bad from (select level_code from public.lessons group by level_code having min(lesson_number) <> 1 or max(lesson_number) <> count(*)) x;
  perform pg_temp.rec('lesson numbers are dense inside every level', bad = 0, bad::text);
  select count(*) into bad from public.lessons where not is_published;
  perform pg_temp.rec('every lesson is published', bad = 0, bad || ' unpublished');

  select count(*) into bad from public.vocabulary_bank w join public.lesson_words lw on lw.word_id = w.id join public.lessons l on l.id = lw.lesson_id where w.level_code is distinct from l.level_code;
  perform pg_temp.rec('a word''s level equals the level of its lesson', bad = 0, bad::text);
  for lv in select l.code, l.rank_from, l.rank_to from public.levels l where exists (select 1 from public.lessons x where x.level_code = l.code) loop
    select count(*) into bad from public.vocabulary_bank w where w.level_code = lv.code and (w.freq_rank is null or w.freq_rank < lv.rank_from or w.freq_rank > lv.rank_to);
    perform pg_temp.rec('level ' || lv.code || ': rank band ' || coalesce(lv.rank_from::text, '?') || '-' || coalesce(lv.rank_to::text, '?') || ' is set and holds every word rank', lv.rank_from is not null and bad = 0, bad || ' word(s) outside');
  end loop;
  perform pg_temp.rec('frequency ranks are unique', (select count(distinct freq_rank) = count(*) from public.vocabulary_bank), null);

  select count(*) into bad from public.vocabulary_bank where meaning_ar is null or sentence_ar is null;
  perform pg_temp.rec('every word has an Arabic meaning and an Arabic sentence translation', bad = 0, bad || ' missing');
  select count(*) into bad from public.vocabulary_bank where meaning_ar !~ ar_re or sentence_ar !~ ar_re;
  perform pg_temp.rec('Arabic is intact (every meaning and translation holds Arabic letters)', bad = 0, bad || ' row(s) look garbled: re-import with PGCLIENTENCODING=UTF8');
end $$;

select ok, label, detail from results order by n;
rollback;
