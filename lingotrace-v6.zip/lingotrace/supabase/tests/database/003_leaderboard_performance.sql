-- =============================================================================
-- 003_leaderboard_performance.sql   (verified on Supabase PostgreSQL 17.11, free plan)
-- Builds 100000 users and 200000 XP events INSIDE a transaction that always ends with ROLLBACK, then times the
-- leaderboard functions (best of 3). Needs the owner role. The per-row triggers and the auth FK are switched
-- off only inside the transaction (DDL is transactional), and come back with the ROLLBACK.
--   psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f supabase/tests/database/003_leaderboard_performance.sql
-- Do not run it on a database with real users: it takes an ACCESS EXCLUSIVE lock on public.users for a few seconds.
-- Keep this file plain ASCII.
-- =============================================================================
begin;

create temp table results (n serial primary key, ok boolean not null, label text not null, detail text);
create function pg_temp.rec(p_label text, p_ok boolean, p_detail text default null) returns void language plpgsql as $$
begin
  insert into results (ok, label, detail) values (coalesce(p_ok, false), p_label, p_detail);
end $$;

create function pg_temp.time_it(p_label text, p_sql text, p_limit_ms numeric) returns void language plpgsql as $$
declare t0 timestamptz; ms numeric; best numeric := 1e12; total numeric := 0; i int; cnt bigint;
begin
  for i in 1..3 loop
    t0 := clock_timestamp();
    execute p_sql into cnt;
    ms := extract(epoch from clock_timestamp() - t0) * 1000;
    best := least(best, ms); total := total + ms;
  end loop;
  perform pg_temp.rec(p_label || ': best ' || round(best, 1) || ' ms, avg ' || round(total / 3, 1) || ' ms, ' || cnt || ' rows', best <= p_limit_ms, 'target <= ' || p_limit_ms || ' ms');
end $$;

do $$
declare cn text;
begin
  select conname into cn from pg_constraint where conrelid = 'public.users'::regclass and contype = 'f';
  execute format('alter table public.users drop constraint %I', cn);
end $$;
alter table public.users disable trigger users_validate_time_zone;
alter table public.users disable trigger users_set_updated_at;
alter table public.xp_events disable trigger xp_events_apply;

insert into public.users (id, display_name, total_xp, time_zone, created_at, show_on_leaderboard)
select gen_random_uuid(), 'user ' || g, (random() * 5000)::bigint, 'UTC', now() - (g || ' seconds')::interval, random() > 0.05
from generate_series(1, 100000) g;

insert into public.xp_events (user_id, reason, amount, created_at)
select u.id, 'lesson_bonus', 10 + (random() * 90)::int, now() - (random() * 45 || ' days')::interval
from public.users u, generate_series(1, 2);

analyze public.users;
analyze public.xp_events;

do $$
declare me uuid; plan text := ''; r record;
begin
  perform pg_temp.rec('dataset: 100000 users and 200000 XP events', (select count(*) from public.users) = 100000 and (select count(*) from public.xp_events) = 200000, null);

  select e.user_id into me from public.xp_events e join public.users u on u.id = e.user_id
  where e.created_at > now() - interval '5 days' and u.show_on_leaderboard and u.total_xp between 2000 and 3000 order by e.user_id limit 1;
  perform set_config('request.jwt.claims', json_build_object('sub', me, 'role', 'authenticated')::text, true);

  perform pg_temp.time_it('get_leaderboard(all) first page of 50', 'select count(*) from public.get_leaderboard(''all'', 50, 0)', 50);
  perform pg_temp.time_it('get_leaderboard(all) deep page, offset 5000', 'select count(*) from public.get_leaderboard(''all'', 50, 5000)', 100);
  perform pg_temp.time_it('get_my_rank(all) of a mid-ranked user', 'select count(*) from public.get_my_rank(''all'')', 100);
  perform pg_temp.time_it('get_leaderboard(week) first page of 50', 'select count(*) from public.get_leaderboard(''week'', 50, 0)', 400);
  perform pg_temp.time_it('get_my_rank(week)', 'select count(*) from public.get_my_rank(''week'')', 400);
  perform pg_temp.time_it('get_leaderboard(month) first page of 50', 'select count(*) from public.get_leaderboard(''month'', 50, 0)', 600);

  for r in execute 'explain (analyze, buffers, costs off) select rank() over (order by u.total_xp desc), u.display_name, u.total_xp from public.users u where u.show_on_leaderboard and u.total_xp > 0 order by u.total_xp desc, u.created_at, u.id limit 50' loop
    plan := plan || ' / ' || trim(r."QUERY PLAN");
  end loop;
  perform pg_temp.rec('plan of the all-time board query', true, left(plan, 900));
end $$;

select ok, label, detail from results order by n;
rollback;
