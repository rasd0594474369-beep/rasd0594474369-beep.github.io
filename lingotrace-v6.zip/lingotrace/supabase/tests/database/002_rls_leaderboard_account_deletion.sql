-- =============================================================================
-- 002_rls_leaderboard_account_deletion.sql   (verified on Supabase PostgreSQL 17.11: 22 of 22 checks passed)
-- One transaction that always ends with ROLLBACK. Needs the owner role (postgres).
--   psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f supabase/tests/database/002_rls_leaderboard_account_deletion.sql
-- Covers: the leaderboard (all / week / month, ties, paging, hidden users, my rank), RLS and grants as the
-- authenticated and anon roles (role switching + JWT claims), and account deletion through the real
-- auth.users -> public.users -> everything cascade. The last SELECT lists every check. Keep this file plain ASCII.
-- =============================================================================
begin;

create temp table results (n serial primary key, ok boolean not null, label text not null, detail text);
create function pg_temp.rec(p_label text, p_ok boolean, p_detail text default null) returns void language plpgsql as $$
begin
  insert into results (ok, label, detail) values (coalesce(p_ok, false), p_label, p_detail);
end $$;

do $$
declare
  a uuid := '10000000-0000-4000-8000-00000000000a';  b uuid := '10000000-0000-4000-8000-00000000000b';
  c uuid := '10000000-0000-4000-8000-00000000000c';  d uuid := '10000000-0000-4000-8000-00000000000d';
  e uuid := '10000000-0000-4000-8000-00000000000e';
  l1 uuid := '20000000-0000-4000-8000-000000000001'; l2 uuid := '20000000-0000-4000-8000-000000000002';
  w1 uuid := '30000000-0000-4000-8000-000000000001'; w2 uuid := '30000000-0000-4000-8000-000000000002';
  sa uuid := '40000000-0000-4000-8000-00000000000a'; sb uuid := '40000000-0000-4000-8000-00000000000b';
  n1 bigint; n2 bigint; n3 bigint; n4 bigint; n5 bigint; n6 bigint; n7 bigint; n8 bigint;
  e1 text; e2 text; e3 text; e4 text; e5 text; e6 text; e7 text; e8 text; e9 text;
  t1 text; t2 text; t3 text; t4 text; t5 text; t6 text; t7 text; t8 text;
  r1 bigint; r2 bigint;
begin
  -- fixtures, as the owner
  insert into auth.users (id, aud, role, email, raw_user_meta_data) values
    (a, 'authenticated', 'authenticated', 'a@example.com', '{"full_name": "Alice"}'),
    (b, 'authenticated', 'authenticated', 'b@example.com', '{"full_name": "Bob"}'),
    (c, 'authenticated', 'authenticated', 'c@example.com', '{"full_name": "Carol"}'),
    (d, 'authenticated', 'authenticated', 'd@example.com', '{"full_name": "Dave"}'),
    (e, 'authenticated', 'authenticated', 'e@example.com', '{"full_name": "Eve"}');
  update public.users set show_on_leaderboard = false where id = d;
  insert into public.lessons (id, level_code, lesson_number, global_seq, is_published) values (l1, 'A1', 1, 1, true), (l2, 'A1', 2, 2, false);
  insert into public.vocabulary_bank (id, word_text, sentence_context, level_code) values (w1, 'apple', 'I eat an apple.', 'A1'), (w2, 'bridge', 'We cross the bridge.', 'A1');
  insert into public.lesson_words (lesson_id, position, word_id) values (l1, 1, w1), (l2, 1, w2);
  insert into public.user_progress (user_id, lesson_id, first_completed_at, completions) values (a, l1, now(), 1), (b, l1, now(), 1);
  insert into public.user_word_stats (user_id, word_id, error_weight, status, due_seq) values (a, w1, 1, 'active', 3), (b, w1, 2, 'active', 3);
  insert into public.misspelled_words (user_id, word_id, typed) values (a, w1, 'aple'), (b, w1, 'appel');
  insert into public.lesson_sessions (id, user_id, lesson_id, mode, started_at, completed_at, words_total, words_clean, words_failed_twice)
    values (sa, a, l1, 'first_run', now(), now(), 1, 1, 0), (sb, b, l1, 'first_run', now(), now(), 1, 1, 0);
  insert into public.session_attempts (session_id, n, word_id, origin, step, attempt_no, typed, distance, verdict)
    values (sa, 1, w1, 'lesson', 'word', 1, 'aple', 1, 'minor'), (sb, 1, w1, 'lesson', 'word', 1, 'appel', 2, 'major');
  insert into public.xp_events (user_id, session_id, reason, amount, created_at) values
    (a, sa, 'lesson_bonus', 100, now()), (a, null, 'words_first_try', 50, now() - interval '10 days'),
    (b, sb, 'lesson_bonus', 70, now()), (c, null, 'lesson_bonus', 70, now() - interval '40 days'),
    (d, null, 'lesson_bonus', 500, now());

  -- LEADERBOARD as Alice (authenticated)
  set local role authenticated;
  perform set_config('request.jwt.claims', json_build_object('sub', a, 'role', 'authenticated')::text, true);
  select string_agg(rank_no || ':' || display_name || ':' || score || ':' || is_me, ' | ') into t1 from public.get_leaderboard('all', 50, 0);
  select string_agg(rank_no || ':' || display_name || ':' || score || ':' || is_me, ' | ') into t2 from public.get_leaderboard('all', 1, 1);
  select string_agg(rank_no || ':' || display_name || ':' || score || ':' || is_me, ' | ') into t3 from public.get_leaderboard('all', 1, 2);
  select count(*) into n1 from public.get_leaderboard('all', 1000, 0);
  select count(*) into n2 from public.get_leaderboard('all', 0, 0);
  select count(*) into n3 from public.get_leaderboard('all', 50, 3);
  begin perform * from public.get_leaderboard('year'); e1 := 'allowed'; exception when others then e1 := sqlstate; end;
  select rank_no || '/' || position_no || '/' || players || '/' || score into t4 from public.get_my_rank('all');
  select string_agg(rank_no || ':' || display_name || ':' || score || ':' || is_me, ' | ') into t5 from public.get_leaderboard('week', 50, 0);
  select string_agg(rank_no || ':' || display_name || ':' || score || ':' || is_me, ' | ') into t6 from public.get_leaderboard('month', 50, 0);
  select rank_no || '/' || position_no || '/' || players || '/' || score into t7 from public.get_my_rank('week');
  reset role;
  perform pg_temp.rec('board(all): hidden Dave (500 XP) and Eve (0 XP) are absent, ties share rank 2, is_me flags Alice', t1 = '1:Alice:150:true | 2:Bob:70:false | 2:Carol:70:false', t1);
  perform pg_temp.rec('board(all): page 2 of size 1 is Bob, page 3 is Carol (ties never overlap across pages)', t2 = '2:Bob:70:false' and t3 = '2:Carol:70:false', t2 || ' / ' || t3);
  perform pg_temp.rec('board: limit 1000 is capped (3 rows here), limit 0 is raised to 1, offset past the end is empty', n1 = 3 and n2 = 1 and n3 = 0, n1 || ',' || n2 || ',' || n3);
  perform pg_temp.rec('board: an unknown period is refused with 22023', e1 = '22023', e1);
  perform pg_temp.rec('get_my_rank(all) for Alice = rank 1, place 1, 3 players, score 150', t4 = '1/1/3/150', t4);
  perform pg_temp.rec('board(week): only XP of the last 7 days (Alice 100, Bob 70, Carol out)', t5 = '1:Alice:100:true | 2:Bob:70:false', t5);
  perform pg_temp.rec('board(month): Alice 150 (both events), Bob 70, Carol out (40 days old)', t6 = '1:Alice:150:true | 2:Bob:70:false', t6);
  perform pg_temp.rec('get_my_rank(week) for Alice = rank 1, place 1, 2 players, score 100', t7 = '1/1/2/100', t7);

  -- my rank for Bob, Carol, hidden Dave, Eve with no score
  set local role authenticated;
  perform set_config('request.jwt.claims', json_build_object('sub', b, 'role', 'authenticated')::text, true);
  select rank_no || '/' || position_no || '/' || players into t1 from public.get_my_rank('all');
  perform set_config('request.jwt.claims', json_build_object('sub', c, 'role', 'authenticated')::text, true);
  select rank_no || '/' || position_no || '/' || players into t2 from public.get_my_rank('all');
  select count(*) into n1 from public.get_my_rank('week');
  perform set_config('request.jwt.claims', json_build_object('sub', d, 'role', 'authenticated')::text, true);
  select count(*) into n2 from public.get_my_rank('all');
  perform set_config('request.jwt.claims', json_build_object('sub', e, 'role', 'authenticated')::text, true);
  select count(*) into n3 from public.get_my_rank('all');
  reset role;
  perform pg_temp.rec('get_my_rank: Bob = rank 2 place 2, Carol (tie) = rank 2 place 3', t1 = '2/2/3' and t2 = '2/3/3', t1 || ' / ' || t2);
  perform pg_temp.rec('get_my_rank: no row for a user with no score in the period, a hidden user, or zero XP', n1 = 0 and n2 = 0 and n3 = 0, n1 || ',' || n2 || ',' || n3);

  -- RLS as Alice (authenticated)
  set local role authenticated;
  perform set_config('request.jwt.claims', json_build_object('sub', a, 'role', 'authenticated')::text, true);
  select count(*) into n1 from public.users;
  select count(*) into n2 from public.user_progress;
  select count(*) into n3 from public.user_word_stats;
  select count(*) into n4 from public.misspelled_words;
  select count(*) into n5 from public.lessons;
  select count(*) into n6 from public.lesson_words;
  select count(*) into n7 from public.levels;
  select count(*) into n8 from public.vocabulary_bank;
  begin perform 1 from public.lesson_sessions; e1 := 'allowed'; exception when others then e1 := sqlstate; end;
  begin perform 1 from public.session_attempts; e2 := 'allowed'; exception when others then e2 := sqlstate; end;
  begin perform 1 from public.xp_events; e3 := 'allowed'; exception when others then e3 := sqlstate; end;
  begin update public.users set total_xp = 999999 where id = a; e4 := 'allowed'; exception when others then e4 := sqlstate; end;
  begin update public.users set streak_count = 99 where id = a; e5 := 'allowed'; exception when others then e5 := sqlstate; end;
  begin update public.users set id = b where id = a; e6 := 'allowed'; exception when others then e6 := sqlstate; end;
  begin insert into public.user_progress (user_id, lesson_id) values (a, l2); e7 := 'allowed'; exception when others then e7 := sqlstate; end;
  begin delete from public.users where id = a; e8 := 'allowed'; exception when others then e8 := sqlstate; end;
  begin insert into public.xp_events (user_id, reason, amount) values (a, 'lesson_bonus', 1000000); e9 := 'allowed'; exception when others then e9 := sqlstate; end;
  update public.users set display_name = 'Alice 2', show_on_leaderboard = true, time_zone = 'Asia/Riyadh' where id = a;
  get diagnostics r1 = row_count;
  update public.users set display_name = 'Hacked' where id = b;
  get diagnostics r2 = row_count;
  begin perform 1 from public.v_account_deletion_gaps; t1 := 'allowed'; exception when others then t1 := sqlstate; end;
  begin perform public.handle_new_user(); t2 := 'allowed'; exception when others then t2 := sqlstate; end;
  begin perform public.trg_xp_events_apply(); t3 := 'allowed'; exception when others then t3 := sqlstate; end;
  reset role;
  perform pg_temp.rec('RLS: Alice sees only her own profile and her own progress, stats and misspellings', n1 = 1 and n2 = 1 and n3 = 1 and n4 = 1, n1 || ',' || n2 || ',' || n3 || ',' || n4);
  perform pg_temp.rec('RLS: only the published lesson and its words are visible; all 5 levels and 2 words are public', n5 = 1 and n6 = 1 and n7 = 5 and n8 = 2, n5 || ',' || n6 || ',' || n7 || ',' || n8);
  perform pg_temp.rec('grants: lesson_sessions, session_attempts and xp_events are closed to clients (42501)', e1 = '42501' and e2 = '42501' and e3 = '42501', e1 || ',' || e2 || ',' || e3);
  perform pg_temp.rec('grants: a client cannot write total_xp, streak_count or id (42501)', e4 = '42501' and e5 = '42501' and e6 = '42501', e4 || ',' || e5 || ',' || e6);
  perform pg_temp.rec('grants: a client cannot insert progress, delete a profile or add XP (42501)', e7 = '42501' and e8 = '42501' and e9 = '42501', e7 || ',' || e8 || ',' || e9);
  perform pg_temp.rec('RLS: Alice can edit her own profile (1 row) but not Bob''s (0 rows)', r1 = 1 and r2 = 0, r1 || ',' || r2);
  perform pg_temp.rec('grants: the deletion-gaps view and the trigger functions are not callable by clients (42501)', t1 = '42501' and t2 = '42501' and t3 = '42501', t1 || ',' || t2 || ',' || t3);

  -- anon
  set local role anon;
  perform set_config('request.jwt.claims', '{"role": "anon"}', true);
  select count(*) into n1 from public.levels;
  select count(*) into n2 from public.lessons;
  select count(*) into n3 from public.vocabulary_bank;
  begin perform 1 from public.users; e1 := 'allowed'; exception when others then e1 := sqlstate; end;
  begin perform 1 from public.get_leaderboard('all'); e2 := 'allowed'; exception when others then e2 := sqlstate; end;
  begin insert into public.levels (code, ordinal, title) values ('C2', 6, 'x'); e3 := 'allowed'; exception when others then e3 := sqlstate; end;
  begin perform 1 from public.user_progress; e4 := 'allowed'; exception when others then e4 := sqlstate; end;
  reset role;
  perform pg_temp.rec('anon: reads the public content only (5 levels, 1 published lesson, 2 words)', n1 = 5 and n2 = 1 and n3 = 2, n1 || ',' || n2 || ',' || n3);
  perform pg_temp.rec('anon: cannot read users or progress, call the leaderboard, or write content (42501)', e1 = '42501' and e2 = '42501' and e3 = '42501' and e4 = '42501', e1 || ',' || e2 || ',' || e3 || ',' || e4);

  -- ACCOUNT DELETION through the real chain
  delete from auth.users where id = a;
  select count(*) into n1 from public.users where id = a;
  select (select count(*) from public.user_progress where user_id = a) + (select count(*) from public.user_word_stats where user_id = a)
       + (select count(*) from public.misspelled_words where user_id = a) + (select count(*) from public.lesson_sessions where user_id = a)
       + (select count(*) from public.session_attempts where session_id = sa) + (select count(*) from public.xp_events where user_id = a) into n2;
  select (select count(*) from public.user_progress where user_id = b) + (select count(*) from public.user_word_stats where user_id = b)
       + (select count(*) from public.misspelled_words where user_id = b) + (select count(*) from public.lesson_sessions where user_id = b)
       + (select count(*) from public.session_attempts where session_id = sb) + (select count(*) from public.xp_events where user_id = b) into n3;
  select (select count(*) from public.lessons) + (select count(*) from public.vocabulary_bank) + (select count(*) from public.lesson_words) + (select count(*) from public.levels) into n4;
  select count(*) into n5 from public.v_account_deletion_gaps;
  perform pg_temp.rec('DELETE ACCOUNT: deleting the auth user removes the profile and all 6 kinds of rows of that user', n1 = 0 and n2 = 0, n1 || ',' || n2);
  perform pg_temp.rec('DELETE ACCOUNT: another user keeps all 6 rows, shared content is untouched (2 + 2 + 2 + 5)', n3 = 6 and n4 = 11, n3 || ',' || n4);
  perform pg_temp.rec('DELETE ACCOUNT: v_account_deletion_gaps is empty', n5 = 0, n5::text);
  perform pg_temp.rec('DELETE ACCOUNT: other users'' XP is not affected (Bob still 70)', (select total_xp from public.users where id = b) = 70, null);
end $$;

select ok, label, detail from results order by n;
rollback;
