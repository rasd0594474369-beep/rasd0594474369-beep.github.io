-- =============================================================================
-- 001_signup_triggers_constraints.sql   (verified on Supabase PostgreSQL 17.11: 23 of 23 checks passed)
-- Runs inside ONE transaction that always ends with ROLLBACK, so it leaves no trace.
--   psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f supabase/tests/database/001_signup_triggers_constraints.sql
-- or paste it into the Supabase SQL editor. The last SELECT lists every check: ok = true must hold for all.
-- Covers: sign-up trigger (real auth.users rows), time zone validation, updated_at, the XP ledger trigger,
-- the Arabic round trip, and the constraints. Needs the owner role (postgres). Keep this file plain ASCII.
-- =============================================================================
begin;

create temp table results (n serial primary key, ok boolean not null, label text not null, detail text);

create function pg_temp.rec(p_label text, p_ok boolean, p_detail text default null) returns void language plpgsql as $$
begin
  insert into results (ok, label, detail) values (coalesce(p_ok, false), p_label, p_detail);
end $$;

create function pg_temp.must_fail(p_label text, p_stmt text, p_expected text) returns void language plpgsql as $$
begin
  begin
    execute p_stmt;
  exception when others then
    perform pg_temp.rec(p_label || ' (rejected ' || sqlstate || ')', sqlstate = p_expected,
      case when sqlstate = p_expected then null else 'expected ' || p_expected || ' but got ' || sqlstate || ': ' || sqlerrm end);
    return;
  end;
  perform pg_temp.rec(p_label, false, 'the statement was accepted but must be rejected');
end $$;

do $$
declare
  a  uuid := '10000000-0000-4000-8000-00000000000a';
  b  uuid := '10000000-0000-4000-8000-00000000000b';
  c  uuid := '10000000-0000-4000-8000-00000000000c';
  d  uuid := '10000000-0000-4000-8000-00000000000d';
  l1 uuid := '20000000-0000-4000-8000-000000000001';
  w1 uuid := '30000000-0000-4000-8000-000000000001';
  v text; s text; n bigint; ts timestamptz;
begin
  -- sign-up trigger (real auth.users inserts)
  insert into auth.users (id, aud, role, email, raw_user_meta_data) values
    (a, 'authenticated', 'authenticated', 'sara@example.com', '{"full_name": "  Sara Test  "}'),
    (b, 'authenticated', 'authenticated', 'omar.secret@example.com', '{}'),
    (c, 'authenticated', 'authenticated', 'c@example.com', jsonb_build_object('name', repeat('x', 80))),
    (d, 'authenticated', 'authenticated', 'd@example.com', null);
  select display_name into v from public.users where id = a;
  perform pg_temp.rec('sign-up creates the profile with the name from metadata, trimmed', v = 'Sara Test', v);
  select display_name into v from public.users where id = b;
  perform pg_temp.rec('sign-up without a name gives Learner, never the e-mail', v = 'Learner', v);
  select display_name into v from public.users where id = c;
  perform pg_temp.rec('sign-up cuts a long name to 40 characters', char_length(v) = 40, char_length(v)::text);
  select display_name into v from public.users where id = d;
  perform pg_temp.rec('sign-up copes with null metadata', v = 'Learner', v);
  select count(*) into n from public.users where display_name like '%@%' or display_name ilike '%example%';
  perform pg_temp.rec('no display name contains an e-mail address', n = 0, n::text);

  -- time zone trigger
  perform pg_temp.must_fail('time zone: an unknown name', format('update public.users set time_zone = %L where id = %L', 'Mars/Phobos', a), '22023');
  update public.users set time_zone = 'Asia/Riyadh' where id = a;
  select time_zone into v from public.users where id = a;
  perform pg_temp.rec('time zone: Asia/Riyadh is accepted', v = 'Asia/Riyadh', v);

  -- updated_at trigger (now() is frozen inside a transaction, so plant an old value)
  update public.users set display_name = 'Sara T', updated_at = '2000-01-01' where id = a;
  select updated_at into ts from public.users where id = a;
  perform pg_temp.rec('updated_at trigger refreshes the timestamp', ts > '2001-01-01', ts::text);

  -- XP ledger trigger
  insert into public.xp_events (user_id, reason, amount) values (a, 'words_first_try', 10), (a, 'words_recovered', 5), (a, 'lesson_bonus', 50);
  select total_xp into n from public.users where id = a;
  perform pg_temp.rec('xp trigger: total_xp = 10 + 5 + 50', n = 65, n::text);
  perform pg_temp.must_fail('xp trigger: total_xp cannot go negative', format('insert into public.xp_events (user_id, reason, amount) values (%L, %L, -1000)', a, 'adjustment'), '23514');
  select total_xp into n from public.users where id = a;
  perform pg_temp.rec('xp trigger: a rejected event leaves total_xp unchanged', n = 65, n::text);

  -- content + Arabic round trip (the Arabic literals need a UTF-8 client: set PGCLIENTENCODING=UTF8 on Windows)
  insert into public.lessons (id, level_code, lesson_number, global_seq, is_published) values (l1, 'A1', 1, 1, true);
  insert into public.vocabulary_bank (id, word_text, sentence_context, meaning_ar, sentence_ar, level_code)
  values (w1, 'apple', 'I eat an apple.', U&'\062A\0641\0627\062D\0629', U&'\0622\0643\0644 \062A\0641\0627\062D\0629 \0643\0644 \0635\0628\0627\062D.', 'A1');
  select meaning_ar, sentence_ar into v, s from public.vocabulary_bank where id = w1;
  perform pg_temp.rec('Arabic text round-trips intact (meaning + sentence translation)', v = U&'\062A\0641\0627\062D\0629' and s = U&'\0622\0643\0644 \062A\0641\0627\062D\0629 \0643\0644 \0635\0628\0627\062D.', null);
  perform pg_temp.rec('Arabic is stored as UTF-8 (char_length counts characters, not bytes)', (select char_length(meaning_ar) from public.vocabulary_bank where id = w1) = 5, null);

  -- constraints
  perform pg_temp.must_fail('rotation_state_valid: active with error_weight 0', format('insert into public.user_word_stats (user_id, word_id, error_weight, status, due_seq) values (%L, %L, 0, %L, 3)', a, w1, 'active'), '23514');
  perform pg_temp.must_fail('rotation_state_valid: mastered with error_weight 2', format('insert into public.user_word_stats (user_id, word_id, error_weight, status, due_seq) values (%L, %L, 2, %L, null)', a, w1, 'mastered'), '23514');
  perform pg_temp.must_fail('sentence_ar: empty string', format('update public.vocabulary_bank set sentence_ar = %L where id = %L', '', w1), '23514');
  perform pg_temp.must_fail('sentence_ar: 301 characters', format('update public.vocabulary_bank set sentence_ar = repeat(chr(1575), 301) where id = %L', w1), '23514');
  update public.vocabulary_bank set sentence_ar = repeat(chr(1575), 300) where id = w1;
  perform pg_temp.rec('sentence_ar: exactly 300 characters is accepted', (select char_length(sentence_ar) from public.vocabulary_bank where id = w1) = 300, null);
  perform pg_temp.must_fail('vocabulary_bank: words are unique ignoring case', format('insert into public.vocabulary_bank (word_text, sentence_context) values (%L, %L)', 'APPLE', 'APPLE again'), '23505');
  perform pg_temp.must_fail('lesson_words: position 21', format('insert into public.lesson_words (lesson_id, position, word_id) values (%L, 21, %L)', l1, w1), '23514');
  perform pg_temp.must_fail('lessons: global_seq is unique', format('insert into public.lessons (level_code, lesson_number, global_seq) values (%L, 2, 1)', 'A1'), '23505');
  perform pg_temp.must_fail('misspelled_words: typed longer than 100', format('insert into public.misspelled_words (user_id, word_id, typed) values (%L, %L, repeat(%L, 101))', a, w1, 'x'), '23514');
  perform pg_temp.must_fail('users: unknown tts_locale', format('update public.users set tts_locale = %L where id = %L', 'fr-FR', a), '23514');
  perform pg_temp.must_fail('lesson_sessions: completed_at before started_at', format('insert into public.lesson_sessions (id, user_id, lesson_id, mode, started_at, completed_at, words_total, words_clean, words_failed_twice) values (gen_random_uuid(), %L, %L, %L, %L, %L, 1, 1, 0)', a, l1, 'first_run', '2026-10-11T10:05:00Z', '2026-10-11T10:00:00Z'), '23514');
end $$;

select ok, label, detail from results order by n;
rollback;
