-- =============================================================================
-- 006_session_chain.sql   (Status: verified on the real database, PostgreSQL 17.11, on 2026-10-25: 15 of 15 checks ok)
-- Runs inside ONE transaction that always ends with ROLLBACK, so it leaves no trace.
--   psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f supabase/tests/database/006_session_chain.sql
-- or paste it into the Supabase SQL editor. The last SELECT lists every check: ok = true must hold for all.
-- Covers migration 20261022000100_session_chain.sql on a REAL PostgreSQL: the column and its two unique partial
-- indexes exist; the sessions of a user form one line; a second root, a fork, a session that is its own parent and a
-- parent that does not exist are refused with the right error codes; a session that has a child cannot be deleted;
-- the chain-head lookup used by the commit service finds the end of the line; deleting the account removes the whole
-- chain at once (a self-referencing foreign key must not get in the way) and v_account_deletion_gaps stays empty.
-- Needs the owner role (postgres). Keep this file plain ASCII.
-- =============================================================================
begin;

create temp table results (n serial primary key, ok boolean not null, label text not null, detail text);

create function pg_temp.rec(p_label text, p_ok boolean, p_detail text default null) returns void language plpgsql as $$
begin
  insert into results (ok, label, detail) values (coalesce(p_ok, false), p_label, p_detail);
end $$;

create function pg_temp.must_fail(p_label text, p_stmt text, p_expected text) returns void language plpgsql as $$
begin
  begin
    execute p_stmt;
  exception when others then
    perform pg_temp.rec(p_label || ' (rejected ' || sqlstate || ')', sqlstate = p_expected,
      case when sqlstate = p_expected then null else 'expected ' || p_expected || ' but got ' || sqlstate || ': ' || sqlerrm end);
    return;
  end;
  perform pg_temp.rec(p_label, false, 'the statement was accepted but must be rejected');
end $$;

do $$
declare
  a  uuid := '60000000-0000-4000-8000-00000000000a';
  b  uuid := '60000000-0000-4000-8000-00000000000b';
  l1 uuid := '60000000-0000-4000-8000-0000000000a1';
  w1 uuid := '60000000-0000-4000-8000-0000000000b1';
  s1 uuid := '60000000-0000-4000-8000-000000000051';
  s2 uuid := '60000000-0000-4000-8000-000000000052';
  s3 uuid := '60000000-0000-4000-8000-000000000053';
  t1 uuid := '60000000-0000-4000-8000-000000000061';
  x  uuid := '60000000-0000-4000-8000-0000000000ff';
  head_a text; head_b text; head_after text; rows_deleted bigint;
  n1 bigint; n2 bigint; n3 bigint; n4 bigint; n5 bigint;
  col_ok boolean; root_def text; parent_def text;
begin
  insert into auth.users (id, aud, role, email, raw_user_meta_data) values
    (a, 'authenticated', 'authenticated', 'chain-a@example.com', '{}'),
    (b, 'authenticated', 'authenticated', 'chain-b@example.com', '{}');
  insert into public.vocabulary_bank (id, word_text, sentence_context) values (w1, 'zxchain', 'I can see the zxchain today.');
  insert into public.lessons (id, level_code, lesson_number, global_seq, is_published) values (l1, 'A1', 30011, 900011, true);
  insert into public.lesson_words (lesson_id, position, word_id) values (l1, 1, w1);

  -- what the migration created
  select exists (select 1 from information_schema.columns
                 where table_schema = 'public' and table_name = 'lesson_sessions' and column_name = 'parent_session_id'
                   and data_type = 'uuid' and is_nullable = 'YES') into col_ok;
  select indexdef into root_def from pg_indexes where schemaname = 'public' and indexname = 'lesson_sessions_root_uidx';
  select indexdef into parent_def from pg_indexes where schemaname = 'public' and indexname = 'lesson_sessions_parent_uidx';
  perform pg_temp.rec('schema: parent_session_id is a nullable uuid column of lesson_sessions', col_ok, null);
  perform pg_temp.rec('schema: one root per user is a UNIQUE index on user_id WHERE parent_session_id IS NULL',
    root_def ilike '%unique%' and root_def ilike '%(user_id)%' and root_def ilike '%parent_session_id is null%', root_def);
  perform pg_temp.rec('schema: one child per session is a UNIQUE index on parent_session_id WHERE it IS NOT NULL',
    parent_def ilike '%unique%' and parent_def ilike '%(parent_session_id)%' and parent_def ilike '%parent_session_id is not null%', parent_def);

  -- a line of three for a, a root for b
  insert into public.lesson_sessions (id, user_id, lesson_id, mode, started_at, completed_at, words_total, words_clean, words_failed_twice, parent_session_id)
    values (s1, a, l1, 'first_run', '2026-10-04T10:00:00Z', '2026-10-04T10:05:00Z', 1, 1, 0, null);
  insert into public.lesson_sessions (id, user_id, lesson_id, mode, started_at, completed_at, words_total, words_clean, words_failed_twice, parent_session_id)
    values (s2, a, l1, 'replay', '2026-10-04T11:00:00Z', '2026-10-04T11:05:00Z', 1, 1, 0, s1);
  insert into public.lesson_sessions (id, user_id, lesson_id, mode, started_at, completed_at, words_total, words_clean, words_failed_twice, parent_session_id)
    values (s3, a, l1, 'replay', '2026-10-04T12:00:00Z', '2026-10-04T12:05:00Z', 1, 1, 0, s2);
  insert into public.lesson_sessions (id, user_id, lesson_id, mode, started_at, completed_at, words_total, words_clean, words_failed_twice, parent_session_id)
    values (t1, b, l1, 'first_run', '2026-10-04T10:00:00Z', '2026-10-04T10:05:00Z', 1, 1, 0, null);
  perform pg_temp.rec('chain: three sessions in a line for one user and a root of their own for another are accepted',
    (select count(*) from public.lesson_sessions where user_id in (a, b)) = 4, null);

  -- what the database refuses on its own
  perform pg_temp.must_fail('chain: a second root for the same user',
    format('insert into public.lesson_sessions (id, user_id, lesson_id, mode, started_at, completed_at, words_total, words_clean, words_failed_twice, parent_session_id) values (%L, %L, %L, ''first_run'', now(), now(), 1, 1, 0, null)', x, a, l1), '23505');
  perform pg_temp.must_fail('chain: a fork (a second child of the same session)',
    format('insert into public.lesson_sessions (id, user_id, lesson_id, mode, started_at, completed_at, words_total, words_clean, words_failed_twice, parent_session_id) values (%L, %L, %L, ''replay'', now(), now(), 1, 1, 0, %L)', x, a, l1, s1), '23505');
  perform pg_temp.must_fail('chain: a session that is its own parent',
    format('insert into public.lesson_sessions (id, user_id, lesson_id, mode, started_at, completed_at, words_total, words_clean, words_failed_twice, parent_session_id) values (%L, %L, %L, ''replay'', now(), now(), 1, 1, 0, %L)', x, a, l1, x), '23514');
  perform pg_temp.must_fail('chain: a parent that does not exist',
    format('insert into public.lesson_sessions (id, user_id, lesson_id, mode, started_at, completed_at, words_total, words_clean, words_failed_twice, parent_session_id) values (%L, %L, %L, ''replay'', now(), now(), 1, 1, 0, %L)', x, a, l1, '60000000-0000-4000-8000-0000000000ee'), '23503');
  perform pg_temp.must_fail('chain: deleting a session that has a child',
    format('delete from public.lesson_sessions where id = %L', s1), '23503');
  perform pg_temp.rec('chain: nothing leaked from the refused statements', (select count(*) from public.lesson_sessions where user_id in (a, b)) = 4, null);

  -- the lookup the commit service runs to find the end of the line
  select string_agg(s.id::text, ',') into head_a from public.lesson_sessions s
    where s.user_id = a and not exists (select 1 from public.lesson_sessions c where c.parent_session_id = s.id);
  select string_agg(s.id::text, ',') into head_b from public.lesson_sessions s
    where s.user_id = b and not exists (select 1 from public.lesson_sessions c where c.parent_session_id = s.id);
  perform pg_temp.rec('head lookup: the end of the line for each user, never mixed', head_a = s3::text and head_b = t1::text, coalesce(head_a, 'null') || ',' || coalesce(head_b, 'null'));

  -- the last session of a line can go; the line is then one shorter
  delete from public.lesson_sessions where id = s3;
  get diagnostics rows_deleted = row_count;
  select string_agg(s.id::text, ',') into head_after from public.lesson_sessions s
    where s.user_id = a and not exists (select 1 from public.lesson_sessions c where c.parent_session_id = s.id);
  perform pg_temp.rec('chain: the last session can be deleted and its parent becomes the head', rows_deleted = 1 and head_after = s2::text, coalesce(head_after, 'null'));
  insert into public.lesson_sessions (id, user_id, lesson_id, mode, started_at, completed_at, words_total, words_clean, words_failed_twice, parent_session_id)
    values (s3, a, l1, 'replay', '2026-10-04T12:00:00Z', '2026-10-04T12:05:00Z', 1, 1, 0, s2);

  -- account deletion: the whole line goes in one statement
  insert into public.session_attempts (session_id, n, word_id, origin, step, attempt_no, typed, distance, verdict, used_peek)
    values (s3, 1, w1, 'lesson', 'word', 1, 'zxchain', 0, 'exact', false), (t1, 1, w1, 'lesson', 'word', 1, 'zxchain', 0, 'exact', false);
  delete from auth.users where id = a;
  select count(*) into n1 from public.users where id = a;
  select count(*) into n2 from public.lesson_sessions where user_id = a;
  select count(*) into n3 from public.session_attempts where session_id in (s1, s2, s3);
  select count(*) into n4 from public.lesson_sessions where user_id = b;
  select count(*) into n5 from public.v_account_deletion_gaps;
  perform pg_temp.rec('DELETE ACCOUNT: the profile, the whole session chain and its attempts are gone', n1 = 0 and n2 = 0 and n3 = 0, n1 || ',' || n2 || ',' || n3);
  perform pg_temp.rec('DELETE ACCOUNT: the other user keeps their session and attempt', n4 = 1 and (select count(*) from public.session_attempts where session_id = t1) = 1, n4::text);
  perform pg_temp.rec('DELETE ACCOUNT: v_account_deletion_gaps is still empty', n5 = 0, n5::text);
end $$;

select ok, label, detail from results order by n;
rollback;
