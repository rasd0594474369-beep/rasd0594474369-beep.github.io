// Translates a Supabase (PostgreSQL) migration into SQLite so its tables, constraints and cascades can be
// tested in plain Node. This is a TWIN, not PostgreSQL: it proves columns, constraints and cascade logic,
// never PostgreSQL-only behaviour (RLS, SECURITY DEFINER, triggers, window functions...).
const SKIP =
  /^(create\s+(or\s+replace\s+)?(trigger|view|function|policy|extension)|alter\s+(view|function|default\s+privileges)|alter\s+table\s+[\w.]+\s+(enable|force|disable)\s+row\s+level\s+security|grant|revoke|comment\s+on|drop\s+(trigger|function|view|policy))\b/i;

/** Splits SQL on the ';' that end statements, not on the ones inside a single-quoted string ('' is an escaped quote). */
export function splitStatements(code: string): string[] {
  const out: string[] = [];
  let current = '';
  let inString = false;
  for (let i = 0; i < code.length; i++) {
    const ch = code[i]!;
    if (ch === "'") {
      current += ch;
      if (inString && code[i + 1] === "'") {
        current += "'";
        i++;
      } else {
        inString = !inString;
      }
    } else if (ch === ';' && !inString) {
      out.push(current);
      current = '';
    } else {
      current += ch;
    }
  }
  out.push(current);
  return out;
}

export function translateMigration(sql: string): string {
  const code = sql
    .replace(/--[^\n]*/g, '')
    .replace(/\bcreate\s+(?:or\s+replace\s+)?function\b[\s\S]*?\$\$[\s\S]*?\$\$\s*;/gi, '')
    .replace(/\bdo\s+\$\$[\s\S]*?\$\$\s*;/gi, '');
  return splitStatements(code)
    .map((s) => s.trim())
    .filter((s) => s !== '' && !SKIP.test(s))
    .map((s) =>
      s
        .replace(/\s+references\s+auth\.users\s*\(id\)\s+on\s+delete\s+cascade/gi, '')
        .replace(/\bpublic\./gi, '')
        .replace(/\s+default\s+gen_random_uuid\(\)/gi, '')
        .replace(/\bdefault\s+now\(\)/gi, 'default current_timestamp')
        .replace(/\bbigint\s+generated\s+always\s+as\s+identity\s+primary\s+key/gi, 'integer primary key')
        .replace(/\bbtrim\(/gi, 'trim(')
        .replace(/\bchar_length\(/gi, 'length('),
    )
    .join(';\n');
}

export type Db = {
  exec(sql: string): void;
  prepare(sql: string): {
    all(...p: unknown[]): Record<string, unknown>[];
    run(...p: unknown[]): { changes: number | bigint; lastInsertRowid: number | bigint };
  };
};

export async function openTwin(sql: string): Promise<Db> {
  const mod = 'node:sqlite';
  const { DatabaseSync } = await import(mod);
  const db: Db = new DatabaseSync(':memory:');
  db.exec('PRAGMA foreign_keys = ON');
  db.exec(translateMigration(sql));
  // SQLite twin of the xp_events trigger (the real one is created in the functions migration).
  db.exec('CREATE TRIGGER xp_events_apply AFTER INSERT ON xp_events BEGIN UPDATE users SET total_xp = total_xp + NEW.amount WHERE id = NEW.user_id; END;');
  return db;
}
