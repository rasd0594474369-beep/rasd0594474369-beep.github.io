import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { splitStatements, translateMigration } from './translate.ts';

// The translator is test infrastructure, but every schema test stands on it, so it gets its own tests.
describe('SQLite twin translator', () => {
  it('splits statements at ";" but not inside quoted text', () => {
    assert.deepEqual(splitStatements("select 1; select 'a;b'; select 'it''s; fine'").map((s) => s.trim()), ['select 1', "select 'a;b'", "select 'it''s; fine'"]);
    assert.deepEqual(splitStatements('select 1;').map((s) => s.trim()), ['select 1', '']);
  });

  it('skips a COMMENT ON whose text contains a semicolon, as one statement', () => {
    const sql = "create table public.t (id int);\ncomment on column public.t.id is 'first part; second part';\ncreate index t_idx on public.t (id);";
    assert.equal(translateMigration(sql), 'create table t (id int);\ncreate index t_idx on t (id)');
  });

  it('drops DO blocks, function bodies, SQL comments and the PostgreSQL-only clauses', () => {
    const sql = [
      '-- header; with a semicolon',
      "do $$ begin raise exception 'x'; end $$;",
      'create function public.f() returns int language sql as $$ select 1; $$;',
      'create table public.t (id uuid primary key default gen_random_uuid(), at timestamptz default now(), n bigint generated always as identity primary key);',
      'alter table public.t enable row level security;',
      'grant select on public.t to anon;',
    ].join('\n');
    const out = translateMigration(sql);
    assert.ok(!/do \$\$|function|grant|row level|--/i.test(out), out);
    assert.match(out, /create table t \(id uuid primary key, at timestamptz default current_timestamp, n integer primary key\)/);
  });
});
