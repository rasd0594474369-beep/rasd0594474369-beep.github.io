import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

// config.toml is parsed with regular expressions here (Node has no TOML parser). These tests guard the
// security-relevant lines: no secret in the file, accounts only through Google/Apple, JWT checks on.
const toml = readFileSync(new URL('../../config.toml', import.meta.url), 'utf8');
const code = toml.replace(/^\s*#.*$/gm, '');
const section = (name: string) => new RegExp(`^\\[${name.replace(/\./g, '\\.')}\\]\\s*$([\\s\\S]*?)(?=^\\[|(?![\\s\\S]))`, 'm').exec(code)?.[1] ?? '';

describe('supabase/config.toml', () => {
  it('holds no secret: every secret comes from env()', () => {
    const secrets = [...code.matchAll(/^\s*secret\s*=\s*"([^"]*)"/gm)].map((m) => m[1]!);
    assert.ok(secrets.length >= 2);
    for (const s of secrets) assert.match(s, /^env\([A-Z0-9_]+\)$/);
    assert.ok(!/eyJ[A-Za-z0-9_-]{10,}/.test(code), 'looks like a JWT is committed');
    for (const m of code.matchAll(/^\s*client_id\s*=\s*"([^"]*)"/gm)) assert.match(m[1]!, /^env\([A-Z0-9_]+\)$/);
  });

  it('accounts are created only through Google and Apple', () => {
    assert.match(section('auth'), /enable_anonymous_sign_ins\s*=\s*false/);
    assert.match(section('auth.email'), /enable_signup\s*=\s*false/);
    assert.match(section('auth.sms'), /enable_signup\s*=\s*false/);
    assert.match(section('auth.external.google'), /enabled\s*=\s*true/);
    assert.match(section('auth.external.apple'), /enabled\s*=\s*true/);
    for (const p of ['auth.external.google', 'auth.external.apple']) assert.match(section(p), /skip_nonce_check\s*=\s*false/);
  });

  it('tokens are short-lived and rotate', () => {
    assert.ok(Number(/jwt_expiry\s*=\s*(\d+)/.exec(code)?.[1]) <= 3600);
    assert.match(section('auth'), /enable_refresh_token_rotation\s*=\s*true/);
  });

  it('only the public schema is exposed (no GraphQL) and pages are capped', () => {
    assert.match(section('api'), /schemas\s*=\s*\[\s*"public"\s*\]/);
    assert.ok(Number(/max_rows\s*=\s*(\d+)/.exec(section('api'))?.[1]) <= 1000);
  });

  it('both Edge Functions require a valid user JWT at the gateway', () => {
    for (const f of ['commit-session', 'delete-account']) {
      assert.match(section(`functions.${f}`), /enabled\s*=\s*true/);
      assert.match(section(`functions.${f}`), /verify_jwt\s*=\s*true/);
    }
  });

  it('redirect URLs are exact (no wildcards)', () => {
    const urls = /additional_redirect_urls\s*=\s*\[([\s\S]*?)\]/.exec(code)?.[1] ?? '';
    assert.ok(urls.includes('lingotrace://auth/callback'));
    assert.ok(!urls.includes('*'));
  });
});
