import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync } from 'node:fs';

// Static guards over ALL migrations. They cannot prove that PostgreSQL enforces the policies (that needs a real
// database: supabase/tests/database), but they stop the classic mistakes at review time: a table without RLS,
// a grant that is too wide, a SECURITY DEFINER function without a pinned search_path, a leaking leaderboard.
const dir = new URL('../../migrations/', import.meta.url);
const files = readdirSync(dir).filter((f) => f.endsWith('.sql')).sort();
const raw = files.map((f) => readFileSync(new URL(f, dir), 'utf8'));
const code = raw.map((s) => s.replace(/--[^\n]*/g, '')).join('\n');
const flat = code.replace(/\$\$[\s\S]*?\$\$/g, '$$$$'); // function bodies out of the way, so ';' splits statements
const statements = flat.split(';').map((s) => s.replace(/\s+/g, ' ').trim()).filter(Boolean);

const CONTENT = ['levels', 'lessons', 'vocabulary_bank', 'lesson_words'];
const OWN = ['users', 'user_progress', 'user_word_stats', 'misspelled_words'];
const INTERNAL = ['lesson_sessions', 'session_attempts', 'xp_events'];
const ALL_TABLES = [...CONTENT, ...OWN, ...INTERNAL];
const list = (s: string) => s.split(',').map((x) => x.trim().replace(/^public\./, '')).filter(Boolean).sort();

describe('migrations: hygiene', () => {
  it('are ordered, uniquely timestamped, plain ASCII, with paired dollar quotes and balanced brackets', () => {
    assert.ok(files.length >= 6);
    const stamps = files.map((f) => f.split('_')[0]);
    for (const f of files) assert.match(f, /^\d{14}_[a-z0-9_]+\.sql$/);
    assert.equal(new Set(stamps).size, stamps.length, 'two migrations share a timestamp');
    raw.forEach((s, i) => {
      assert.ok(/^[\x00-\x7F]*$/.test(s), `${files[i]} must be plain ASCII`);
      const c = s.replace(/--[^\n]*/g, '');
      assert.equal((c.match(/\$\$/g) ?? []).length % 2, 0, `${files[i]}: unpaired $$`);
      const bare = c.replace(/'(?:[^']|'')*'/g, "''");
      assert.equal(bare.split('(').length, bare.split(')').length, `${files[i]}: unbalanced parentheses`);
    });
  });
});

describe('migrations: row level security', () => {
  it('is enabled on every table', () => {
    for (const t of ALL_TABLES) assert.match(code, new RegExp(`alter\\s+table\\s+public\\.${t}\\s+enable\\s+row\\s+level\\s+security`, 'i'), `${t} has no RLS`);
  });

  const policies = statements
    .filter((s) => /^create policy /i.test(s))
    .map((s) => {
      const m = /^create policy (\w+) on public\.(\w+)(?: as (permissive|restrictive))? for (\w+) to ([\w, ]+?) (using|with check)/i.exec(s)!;
      assert.ok(m, `cannot parse policy: ${s}`);
      return { name: m[1]!, table: m[2]!, kind: (m[3] ?? 'permissive').toLowerCase(), action: m[4]!.toLowerCase(), roles: list(m[5]!), sql: s };
    });

  it('clients may only SELECT, plus UPDATE of their own profile row', () => {
    assert.ok(policies.length >= 8);
    for (const p of policies.filter((x) => x.kind === 'permissive')) {
      assert.ok(p.action === 'select' || p.action === 'update', `${p.name}: ${p.action} is not allowed for clients`);
      if (p.action === 'update') assert.equal(p.table, 'users', `${p.name}: only users may be updated by clients`);
    }
    const upd = policies.find((p) => p.name === 'users_update_own')!;
    assert.match(upd.sql, /using \(id = \(select auth\.uid\(\)\)\)/i);
    assert.match(upd.sql, /with check \(id = \(select auth\.uid\(\)\)\)/i);
  });

  it('content is readable by anyone, own data only by its owner, internal tables by nobody', () => {
    for (const p of policies.filter((x) => x.kind === 'permissive')) {
      if (CONTENT.includes(p.table)) assert.ok(p.roles.every((r) => r === 'anon' || r === 'authenticated'), `${p.name}: roles`);
      else {
        assert.deepEqual(p.roles, ['authenticated'], `${p.name}: own data is for signed-in users only`);
        assert.match(p.sql, /\(select auth\.uid\(\)\)/i, `${p.name}: must filter on (select auth.uid())`);
      }
    }
    // internal tables: NO permissive policy, and exactly one RESTRICTIVE deny-all that no permissive policy can override
    for (const t of INTERNAL) {
      const own = policies.filter((p) => p.table === t);
      assert.equal(own.filter((p) => p.kind === 'permissive').length, 0, `${t} must have NO permissive policy`);
      assert.equal(own.length, 1, `${t} must have exactly one policy: the restrictive deny`);
      assert.equal(own[0]!.kind, 'restrictive');
      assert.equal(own[0]!.action, 'all');
      assert.deepEqual(own[0]!.roles, ['anon', 'authenticated']);
      assert.match(own[0]!.sql, /using \(false\) with check \(false\)/i);
    }
    for (const t of OWN) assert.ok(policies.some((p) => p.table === t && p.action === 'select'), `${t} needs its select-own policy`);
    assert.match(policies.find((p) => p.name === 'lessons_read_published')!.sql, /using \(is_published\)/i);
  });
});

describe('migrations: grants', () => {
  const grants = statements
    .filter((s) => /^grant /i.test(s))
    .map((s) => {
      const m = /^grant (.+?) on (?:(table|function|sequence) )?(.+) to (.+)$/i.exec(s)!;
      assert.ok(m, `cannot parse grant: ${s}`);
      return { privs: m[1]!.toLowerCase(), kind: (m[2] ?? 'table').toLowerCase(), objects: m[3]!, roles: list(m[4]!) };
    });

  it('never grants write, delete, all, or anything to service_role / public', () => {
    for (const g of grants) {
      assert.ok(!/\b(insert|delete|truncate|references|trigger|all)\b/.test(g.privs), `too wide: grant ${g.privs}`);
      assert.ok(!g.roles.includes('service_role') && !g.roles.includes('public'), `grant to ${g.roles}`);
    }
  });

  it('anon reads published-content tables and nothing else', () => {
    const anon = grants.filter((g) => g.roles.includes('anon'));
    assert.equal(anon.length, 1);
    assert.equal(anon[0]!.privs, 'select');
    assert.deepEqual(list(anon[0]!.objects), [...CONTENT].sort());
  });

  it('signed-in users: select on content and own-data tables, update of exactly four profile columns, two functions', () => {
    const auth = grants.filter((g) => g.roles.includes('authenticated'));
    const selected = auth.filter((g) => g.privs === 'select').flatMap((g) => list(g.objects));
    assert.deepEqual([...new Set(selected)].sort(), [...CONTENT, ...OWN].sort());
    for (const t of INTERNAL) assert.ok(!selected.includes(t), `${t} must not be readable by clients`);

    const update = auth.filter((g) => g.privs.startsWith('update'));
    assert.equal(update.length, 1);
    assert.deepEqual(list(/\(([^)]*)\)/.exec(update[0]!.privs)![1]!), ['display_name', 'show_on_leaderboard', 'time_zone', 'tts_locale']);
    assert.equal(update[0]!.objects.replace('public.', ''), 'users');

    const exec = auth.filter((g) => g.kind === 'function').map((g) => g.objects.replace(/\s+/g, ''));
    assert.deepEqual(exec.sort(), ['public.get_leaderboard(text,int,int)', 'public.get_my_rank(text)']);
  });

  it('starts closed: everything revoked first, for today and for future objects', () => {
    for (const re of [
      /revoke all on all tables in schema public from anon, authenticated, service_role/i,
      /revoke all on all sequences in schema public from anon, authenticated, service_role/i,
      /revoke all on all functions in schema public from public, anon, authenticated, service_role/i,
      /alter default privileges in schema public revoke all on tables from anon, authenticated, service_role/i,
      /alter default privileges in schema public revoke all on functions from public, anon, authenticated, service_role/i,
    ]) assert.match(code.replace(/\s+/g, ' '), re);
    // the grants migration revokes on "all tables / functions in schema public", so it must run after every migration
    // that creates a table, view, function or sequence; later migrations may only add policies and the like
    const grantsFile = files.findIndex((f) => f.endsWith('_grants_lockdown.sql'));
    assert.ok(grantsFile >= 0);
    raw.slice(grantsFile + 1).forEach((s, i) => {
      assert.ok(!/\bcreate\s+(?:or\s+replace\s+)?(?:table|view|function|sequence)\b/i.test(s.replace(/--[^\n]*/g, '')), `${files[grantsFile + 1 + i]} creates objects after the grants migration`);
    });
  });
});

describe('migrations: functions', () => {
  const fns = [...code.matchAll(/create\s+function\s+public\.(\w+)\s*\(([^)]*)\)([\s\S]*?)\$\$([\s\S]*?)\$\$\s*;/gi)].map((m) => ({
    name: m[1]!, args: m[2]!, header: m[3]!.replace(/\s+/g, ' '), body: m[4]!,
  }));

  it('there are exactly the 6 expected functions', () => {
    assert.deepEqual(fns.map((f) => f.name).sort(), ['get_leaderboard', 'get_my_rank', 'handle_new_user', 'set_updated_at', 'trg_xp_events_apply', 'validate_user_time_zone']);
  });

  it('every function pins search_path; only 3 are SECURITY DEFINER', () => {
    for (const f of fns) assert.match(f.header, /set search_path = ''/i, `${f.name} must pin search_path`);
    assert.deepEqual(fns.filter((f) => /security definer/i.test(f.header)).map((f) => f.name).sort(), ['get_leaderboard', 'get_my_rank', 'handle_new_user']);
  });

  it('the leaderboard exposes a display name, a score and ranks, never an id or an e-mail', () => {
    const board = fns.find((f) => f.name === 'get_leaderboard')!;
    const mine = fns.find((f) => f.name === 'get_my_rank')!;
    assert.match(board.header, /returns table \(rank_no bigint, display_name text, score bigint, is_me boolean\)/i);
    assert.match(mine.header, /returns table \(rank_no bigint, score bigint, position_no bigint, players bigint\)/i);
    for (const f of [board, mine]) {
      assert.match(f.body, /show_on_leaderboard/, `${f.name} must honour the opt-out`);
      assert.ok(!/\bemail\b/i.test(f.header + f.body), `${f.name} must not touch e-mail`);
      assert.ok(!/auth\.uid\(\)/.test(f.body.replace(/\(select auth\.uid\(\)\)/g, '')), `${f.name}: use (select auth.uid())`);
    }
    assert.ok(!/returns table \([^)]*user_id/i.test(board.header));
  });

  it('the sign-up trigger never uses the e-mail as a public display name', () => {
    const f = fns.find((x) => x.name === 'handle_new_user')!;
    assert.ok(!/email/i.test(f.body));
    assert.match(f.body, /'Learner'/);
  });

  it('every trigger function is wired to a trigger, and the auth trigger targets auth.users', () => {
    const triggers = statements.filter((s) => /^create trigger /i.test(s));
    assert.equal(triggers.length, 5);
    for (const fn of ['set_updated_at', 'trg_xp_events_apply', 'validate_user_time_zone', 'handle_new_user']) assert.ok(triggers.some((t) => t.includes(`public.${fn}()`)), `${fn} has no trigger`);
    assert.ok(triggers.some((t) => /on auth\.users/i.test(t) && /handle_new_user/.test(t)));
  });
});

describe('migrations: account deletion', () => {
  it('ships the safety-net view, readable by operators only', () => {
    assert.match(code, /create view public\.v_account_deletion_gaps\s+with \(security_invoker = true\)/i);
    assert.ok(!/grant[^;]*v_account_deletion_gaps/i.test(code));
  });
});
