import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync } from 'node:fs';
import { openTwin, type Db } from './translate.ts';

const dir = new URL('../../migrations/', import.meta.url);
const file = readdirSync(dir).find((f) => f.endsWith('_core_schema.sql'));
assert.ok(file, 'core schema migration not found');
const sql = readFileSync(new URL(file, dir), 'utf8');

const TABLES = ['levels', 'lessons', 'vocabulary_bank', 'lesson_words', 'users', 'user_progress', 'user_word_stats', 'misspelled_words', 'lesson_sessions', 'session_attempts', 'xp_events'];
const rejected = /constraint/i; // SQLite: CHECK / UNIQUE / FOREIGN KEY / NOT NULL constraint failed
const count = (db: Db, t: string) => Number(db.prepare(`SELECT count(*) AS n FROM ${t}`).all()[0]!.n);

/** Two users, one lesson of two words, so every table can be given a row. */
function world(db: Db): void {
  db.exec("INSERT INTO users (id, display_name) VALUES ('u1', 'Sara'), ('u2', 'Omar')");
  db.exec("INSERT INTO lessons (id, level_code, lesson_number, global_seq, is_published) VALUES ('l1', 'A1', 1, 1, 1)");
  db.exec("INSERT INTO vocabulary_bank (id, word_text, sentence_context, level_code) VALUES ('w1', 'apple', 'I eat an apple.', 'A1'), ('w2', 'bridge', 'We cross the bridge.', 'A1')");
  db.exec("INSERT INTO lesson_words (lesson_id, position, word_id) VALUES ('l1', 1, 'w1'), ('l1', 2, 'w2')");
}

describe('core schema (SQLite twin)', () => {
  it('creates the 11 tables and seeds the 5 levels', async () => {
    const db = await openTwin(sql);
    const names = db.prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%' ORDER BY name").all().map((r) => String(r.name));
    assert.deepEqual(names, [...TABLES].sort());
    assert.deepEqual(db.prepare('SELECT code FROM levels ORDER BY ordinal').all().map((r) => r.code), ['A1', 'A2', 'B1', 'B2', 'C1']);
  });

  it('vocabulary_bank: bounds on the Arabic texts, case-insensitive uniqueness, sane lengths', async () => {
    const db = await openTwin(sql);
    const ins = (id: string, word: string, extra = '') => db.exec(`INSERT INTO vocabulary_bank (id, word_text, sentence_context${extra ? ', ' + extra.split('=')[0] : ''}) VALUES ('${id}', '${word}', 'a ${word} here'${extra ? ', ' + extra.split('=')[1] : ''})`);
    ins('a', 'apple');
    assert.throws(() => ins('b', 'APPLE'), rejected);                                        // lower(word_text) is unique
    assert.throws(() => ins('c', 'x'.repeat(65)), rejected);                                 // word_text <= 64
    assert.throws(() => ins('d', 'ok', "sentence_ar=''"), rejected);                         // empty translation must be NULL
    assert.throws(() => ins('e', 'ok2', `sentence_ar='${'a'.repeat(301)}'`), rejected);      // <= 300
    ins('f', 'ok3', `sentence_ar='${'a'.repeat(300)}'`);                                     // exactly 300 is fine
    assert.throws(() => ins('g', 'ok4', `meaning_ar='${'a'.repeat(61)}'`), rejected);        // meaning <= 60
    assert.throws(() => db.exec("INSERT INTO vocabulary_bank (id, word_text, sentence_context, level_code) VALUES ('h', 'zz', 'zz zz', 'Z9')"), rejected); // level must exist
  });

  it('lessons and lesson_words: unique order, at most 20 words, a word once per lesson', async () => {
    const db = await openTwin(sql);
    world(db);
    assert.throws(() => db.exec("INSERT INTO lessons (id, level_code, lesson_number, global_seq) VALUES ('l2', 'A1', 2, 1)"), rejected);   // global_seq unique
    assert.throws(() => db.exec("INSERT INTO lessons (id, level_code, lesson_number, global_seq) VALUES ('l3', 'A1', 1, 9)"), rejected);   // (level, number) unique
    assert.throws(() => db.exec("INSERT INTO lesson_words (lesson_id, position, word_id) VALUES ('l1', 21, 'w1')"), rejected);
    assert.throws(() => db.exec("INSERT INTO lesson_words (lesson_id, position, word_id) VALUES ('l1', 3, 'w1')"), rejected);              // same word twice
  });

  it('users: blank names and unknown voices are refused; XP only moves through the ledger twin', async () => {
    const db = await openTwin(sql);
    assert.throws(() => db.exec("INSERT INTO users (id, display_name) VALUES ('x', '   ')"), rejected);
    assert.throws(() => db.exec("INSERT INTO users (id, display_name, tts_locale) VALUES ('x', 'Sara', 'fr-FR')"), rejected);
    assert.throws(() => db.exec("INSERT INTO users (id, display_name, total_xp) VALUES ('x', 'Sara', -1)"), rejected);
    world(db);
    db.exec("INSERT INTO xp_events (user_id, reason, amount) VALUES ('u1', 'lesson_bonus', 50), ('u1', 'words_first_try', 10)");
    assert.equal(Number(db.prepare("SELECT total_xp AS t FROM users WHERE id = 'u1'").all()[0]!.t), 60);
    assert.throws(() => db.exec("INSERT INTO xp_events (user_id, reason, amount) VALUES ('u1', 'adjustment', 0)"), rejected);
    assert.throws(() => db.exec("INSERT INTO xp_events (user_id, reason, amount) VALUES ('u1', 'cheating', 5)"), rejected);
  });

  it('user_word_stats: rotation_state_valid accepts only coherent SRS states', async () => {
    const db = await openTwin(sql);
    world(db);
    const stat = (w: string, weight: number, status: string, due: string) => db.exec(`INSERT INTO user_word_stats (user_id, word_id, error_weight, status, due_seq) VALUES ('u1', '${w}', ${weight}, '${status}', ${due})`);
    assert.throws(() => stat('w1', 0, 'active', '3'), rejected);        // active needs weight >= 1
    assert.throws(() => stat('w1', 1, 'active', 'NULL'), rejected);     // active needs a due_seq
    assert.throws(() => stat('w1', 2, 'mastered', 'NULL'), rejected);   // mastered means weight 0
    assert.throws(() => stat('w1', 0, 'mastered', '3'), rejected);      // mastered has no due_seq
    stat('w1', 2, 'active', '3');
    stat('w2', 0, 'mastered', 'NULL');
  });

  it('misspelled_words: exact typed strings with a frequency; bounded and ordered', async () => {
    const db = await openTwin(sql);
    world(db);
    const miss = (typed: string, occ: number, first = '2026-10-01T00:00:00Z', last = '2026-10-02T00:00:00Z') =>
      db.exec(`INSERT INTO misspelled_words (user_id, word_id, typed, occurrences, first_seen_at, last_seen_at) VALUES ('u1', 'w1', '${typed}', ${occ}, '${first}', '${last}')`);
    miss('apel', 3);
    miss('aple', 1);
    assert.throws(() => miss('apel', 1), rejected);                                           // same user + word + typed is ONE row
    assert.throws(() => miss('x'.repeat(101), 1), rejected);                                  // typed <= 100
    assert.throws(() => miss('', 1), rejected);
    assert.throws(() => miss('zap', 0), rejected);                                            // occurrences >= 1
    assert.throws(() => miss('zop', 1, '2026-10-02T00:00:00Z', '2026-10-01T00:00:00Z'), rejected); // last_seen >= first_seen
    // the user's top mistake first
    assert.deepEqual(db.prepare("SELECT typed FROM misspelled_words WHERE user_id = 'u1' ORDER BY occurrences DESC").all().map((r) => r.typed), ['apel', 'aple']);
  });

  it('sessions: completed_at not before started_at, a closed vocabulary of verdicts', async () => {
    const db = await openTwin(sql);
    world(db);
    const sess = (id: string, start: string, end: string) =>
      db.exec(`INSERT INTO lesson_sessions (id, user_id, lesson_id, mode, started_at, completed_at, words_total, words_clean, words_failed_twice) VALUES ('${id}', 'u1', 'l1', 'first_run', '${start}', '${end}', 2, 1, 0)`);
    sess('s1', '2026-10-11T10:00:00Z', '2026-10-11T10:05:00Z');
    assert.throws(() => sess('s2', '2026-10-11T10:05:00Z', '2026-10-11T10:00:00Z'), rejected);
    const att = (n: number, verdict: string) =>
      db.exec(`INSERT INTO session_attempts (session_id, n, word_id, origin, step, attempt_no, typed, distance, verdict) VALUES ('s1', ${n}, 'w1', 'lesson', 'word', 1, 'apple', 0, '${verdict}')`);
    att(1, 'exact');
    assert.throws(() => att(2, 'maybe'), rejected);
    assert.throws(() => att(1, 'exact'), rejected);                                           // (session, n) is the key
  });

  it('ACCOUNT DELETION: removing a profile wipes every row of that user, and only theirs', async () => {
    const db = await openTwin(sql);
    world(db);
    for (const u of ['u1', 'u2']) {
      db.exec(`INSERT INTO user_progress (user_id, lesson_id, first_completed_at, completions, best_accuracy) VALUES ('${u}', 'l1', '2026-10-11T10:00:00Z', 1, 90)`);
      db.exec(`INSERT INTO user_word_stats (user_id, word_id, error_weight, status, due_seq) VALUES ('${u}', 'w1', 1, 'active', 2)`);
      db.exec(`INSERT INTO misspelled_words (user_id, word_id, typed) VALUES ('${u}', 'w1', 'apel')`);
      db.exec(`INSERT INTO lesson_sessions (id, user_id, lesson_id, mode, started_at, completed_at, words_total, words_clean, words_failed_twice) VALUES ('s-${u}', '${u}', 'l1', 'first_run', '2026-10-11T10:00:00Z', '2026-10-11T10:05:00Z', 2, 1, 0)`);
      db.exec(`INSERT INTO session_attempts (session_id, n, word_id, origin, step, attempt_no, typed, distance, verdict) VALUES ('s-${u}', 1, 'w1', 'lesson', 'word', 1, 'apel', 1, 'minor')`);
      db.exec(`INSERT INTO xp_events (user_id, session_id, reason, amount) VALUES ('${u}', 's-${u}', 'lesson_bonus', 50)`);
    }
    const owned = ['user_progress', 'user_word_stats', 'misspelled_words', 'lesson_sessions', 'session_attempts', 'xp_events'];
    const content = ['levels', 'lessons', 'vocabulary_bank', 'lesson_words'].map((t) => count(db, t));

    db.exec("DELETE FROM users WHERE id = 'u1'"); // in PostgreSQL this is what deleting the auth.users row triggers (FK ON DELETE CASCADE)

    for (const t of owned) {
      assert.equal(Number(db.prepare(`SELECT count(*) AS n FROM ${t} WHERE ${t === 'session_attempts' ? "session_id = 's-u1'" : "user_id = 'u1'"}`).all()[0]!.n), 0, `${t} still holds rows of the deleted user`);
      assert.equal(count(db, t), 1, `${t} lost rows of the OTHER user`);
    }
    assert.deepEqual(['levels', 'lessons', 'vocabulary_bank', 'lesson_words'].map((t) => count(db, t)), content, 'shared content must be untouched');
    assert.equal(Number(db.prepare("SELECT total_xp AS t FROM users WHERE id = 'u2'").all()[0]!.t), 50);
  });
});

describe('core schema (static guards)', () => {
  const blocks = [...sql.matchAll(/create\s+table\s+public\.(\w+)\s*\(([\s\S]*?)\n\);/gi)].map((m) => ({ name: m[1]!, body: m[2]! }));

  it('has exactly the expected tables', () => {
    assert.deepEqual(blocks.map((b) => b.name).sort(), [...TABLES].sort());
  });

  it('every table that belongs to a user cascades from public.users (so account deletion cannot leave rows behind)', () => {
    for (const b of blocks) {
      if (b.name === 'users') assert.match(b.body, /references\s+auth\.users\s*\(id\)\s+on\s+delete\s+cascade/i, 'users must cascade from auth.users');
      else if (/\buser_id\s+uuid/i.test(b.body)) assert.match(b.body, /user_id\s+uuid\s+not\s+null\s+references\s+public\.users\s*\(id\)\s+on\s+delete\s+cascade/i, `${b.name}.user_id must cascade from public.users`);
    }
    const attempts = blocks.find((b) => b.name === 'session_attempts')!;
    assert.match(attempts.body, /session_id\s+uuid\s+not\s+null\s+references\s+public\.lesson_sessions\s*\(id\)\s+on\s+delete\s+cascade/i);
  });

  it('is plain ASCII with balanced brackets and quotes', () => {
    assert.ok(/^[\x00-\x7F]*$/.test(sql));
    const code = sql.replace(/--[^\n]*/g, '');
    assert.equal((code.match(/'/g) ?? []).length % 2, 0, 'unbalanced single quotes');
    const bare = code.replace(/'(?:[^']|'')*'/g, "''");
    assert.equal(bare.split('(').length, bare.split(')').length, 'unbalanced parentheses');
  });
});
