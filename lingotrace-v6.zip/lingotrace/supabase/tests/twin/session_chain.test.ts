import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync } from 'node:fs';
import { openTwin, type Db } from './translate.ts';

// The session chain (migration 20261022000100): what the database itself guarantees, tried on the SQLite twin.
// The twin cannot run the guard against a non-empty table (a PostgreSQL DO block), so that one is checked as text.
const dir = new URL('../../migrations/', import.meta.url);
const read = (suffix: string) => {
  const f = readdirSync(dir).find((n) => n.endsWith(suffix));
  assert.ok(f, `${suffix} not found`);
  return readFileSync(new URL(f, dir), 'utf8');
};
const core = read('_core_schema.sql');
const chain = read('_session_chain.sql');

const rejected = /constraint/i;
const count = (db: Db, sql: string) => Number(db.prepare(`SELECT count(*) AS n FROM ${sql}`).all()[0]!.n);

async function open(): Promise<Db> {
  const db = await openTwin(`${core};\n${chain}`);
  db.exec("INSERT INTO users (id, display_name) VALUES ('u1', 'Sara'), ('u2', 'Omar')");
  db.exec("INSERT INTO lessons (id, level_code, lesson_number, global_seq, is_published) VALUES ('l1', 'A1', 1, 1, 1)");
  db.exec("INSERT INTO vocabulary_bank (id, word_text, sentence_context, level_code) VALUES ('w1', 'apple', 'I eat an apple.', 'A1')");
  return db;
}
/** One committed session; `parent` is a session id or null. */
const session = (db: Db, id: string, user: string, parent: string | null) =>
  db.exec(
    `INSERT INTO lesson_sessions (id, user_id, lesson_id, mode, started_at, completed_at, words_total, words_clean, words_failed_twice, parent_session_id)
     VALUES ('${id}', '${user}', 'l1', 'first_run', '2026-10-04T10:00:00.000Z', '2026-10-04T10:05:00.000Z', 1, 1, 0, ${parent === null ? 'NULL' : `'${parent}'`})`,
  );

describe('session chain (SQLite twin)', () => {
  it('adds one nullable column, and the migration touches nothing else', async () => {
    const db = await open();
    const cols = db.prepare("SELECT name, \"notnull\" AS required FROM pragma_table_info('lesson_sessions') WHERE name = 'parent_session_id'").all();
    assert.deepEqual(cols.map((c) => [c.name, c.required]), [['parent_session_id', 0]]);
    const code = chain.replace(/--[^\n]*/g, '');
    assert.ok(!/\b(grant|revoke|create\s+(table|view|function|trigger|policy))\b/i.test(code), 'the chain migration must not change grants or create objects');
    assert.equal((code.match(/\balter\s+table\b/gi) ?? []).length, 1);
  });

  it('a user gets one root and then a line: each session names the one before it', async () => {
    const db = await open();
    session(db, 's1', 'u1', null);
    session(db, 's2', 'u1', 's1');
    session(db, 's3', 'u1', 's2');
    assert.equal(count(db, 'lesson_sessions'), 3);
    session(db, 't1', 'u2', null); // another user has a root of their own
    assert.equal(count(db, 'lesson_sessions'), 4);
  });

  it('refuses a second root for the same user', async () => {
    const db = await open();
    session(db, 's1', 'u1', null);
    assert.throws(() => session(db, 's2', 'u1', null), rejected);
  });

  it('refuses a fork: two sessions cannot name the same parent', async () => {
    const db = await open();
    session(db, 's1', 'u1', null);
    session(db, 's2', 'u1', 's1');
    assert.throws(() => session(db, 's3', 'u1', 's1'), rejected);
  });

  it('refuses a session that is its own parent, and a parent that does not exist', async () => {
    const db = await open();
    session(db, 's1', 'u1', null);
    assert.throws(() => session(db, 's2', 'u1', 's2'), rejected);
    assert.throws(() => session(db, 's3', 'u1', 'nobody'), rejected);
    assert.equal(count(db, 'lesson_sessions'), 1);
  });

  it('the head is the session nobody names as parent (the lookup the server uses)', async () => {
    const db = await open();
    const head = (u: string) =>
      db.prepare('SELECT s.id FROM lesson_sessions s WHERE s.user_id = ?1 AND NOT EXISTS (SELECT 1 FROM lesson_sessions c WHERE c.parent_session_id = s.id)').all(u).map((r) => r.id);
    assert.deepEqual(head('u1'), []); // no session yet
    session(db, 's1', 'u1', null);
    assert.deepEqual(head('u1'), ['s1']);
    session(db, 's2', 'u1', 's1');
    session(db, 's3', 'u1', 's2');
    session(db, 't1', 'u2', null);
    assert.deepEqual(head('u1'), ['s3']);
    assert.deepEqual(head('u2'), ['t1']); // chains of different users do not mix
  });

  it('a session that has a child cannot be deleted; the head can', async () => {
    const db = await open();
    session(db, 's1', 'u1', null);
    session(db, 's2', 'u1', 's1');
    assert.throws(() => db.exec("DELETE FROM lesson_sessions WHERE id = 's1'"), rejected);
    db.exec("DELETE FROM lesson_sessions WHERE id = 's2'");
    assert.equal(count(db, 'lesson_sessions'), 1);
  });

  it('ACCOUNT DELETION still wipes a whole chain in one go', async () => {
    const db = await open();
    session(db, 's1', 'u1', null);
    session(db, 's2', 'u1', 's1');
    session(db, 's3', 'u1', 's2');
    db.exec("INSERT INTO session_attempts (session_id, n, word_id, origin, step, attempt_no, typed, distance, verdict, used_peek) VALUES ('s3', 1, 'w1', 'lesson', 'word', 1, 'apple', 0, 'exact', 0)");
    session(db, 't1', 'u2', null);
    db.exec("DELETE FROM users WHERE id = 'u1'");
    assert.deepEqual([count(db, "lesson_sessions WHERE user_id = 'u1'"), count(db, 'session_attempts'), count(db, 'lesson_sessions')], [0, 0, 1]); // only u2's session is left
  });

  it('refuses to run on a table that already holds sessions (a DO block the twin cannot execute, so checked as text)', () => {
    const code = chain.replace(/--[^\n]*/g, '');
    assert.match(code, /do\s+\$\$[\s\S]*?if\s+exists\s*\(select\s+1\s+from\s+public\.lesson_sessions\)[\s\S]*?raise\s+exception[\s\S]*?\$\$\s*;/i);
    // and the guard comes before the first schema change
    assert.ok(code.search(/raise\s+exception/i) < code.search(/alter\s+table/i));
  });
});
