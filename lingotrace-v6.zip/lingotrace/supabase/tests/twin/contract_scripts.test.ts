import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync } from 'node:fs';
import { render, runScenario, SCRIPT_PATH } from '../../../scripts/gen-pgrepo-contract.ts';

// The SQL scripts in supabase/tests/database run against the REAL database. Two things must always hold for them:
// they leave no trace (one transaction, always rolled back), and the generated contract script matches the code it tests.
const dir = new URL('../database/', import.meta.url);
const scripts = readdirSync(dir).filter((f) => f.endsWith('.sql')).sort();
const read = (name: string) => readFileSync(new URL(name, dir), 'utf8');
const withoutComments = (sql: string) => sql.replace(/--[^\n]*/g, '');

describe('database test scripts', () => {
  it('are numbered one after another with no gap', () => {
    assert.deepEqual(scripts.map((f) => f.slice(0, 3)), scripts.map((_, i) => String(i + 1).padStart(3, '0')));
    assert.ok(scripts.length >= 6);
  });

  it('each runs in ONE transaction that always ends in ROLLBACK: a stray COMMIT would leave test data in the real database', () => {
    for (const name of scripts) {
      const code = withoutComments(read(name)).trim();
      assert.match(code, /^begin\s*;/i, `${name} must start with begin;`);
      assert.match(code, /rollback\s*;$/i, `${name} must end with rollback;`);
      assert.doesNotMatch(code, /^\s*commit(\s+work|\s+transaction)?\s*;/im, `${name} must never commit`); // (an `end;` is also a COMMIT in SQL, but it closes blocks in PL/pgSQL, so it cannot be told apart by text)
      assert.equal((code.match(/^\s*begin\s*;/gim) ?? []).length, 1, `${name} opens exactly one transaction`);
      assert.doesNotMatch(code, /\b(drop\s+(database|schema|table\s+public)|truncate)\b/i, `${name} must not destroy anything outside the transaction's reach`);
    }
  });

  it('are plain ASCII with balanced dollar quoting, and say in the header what has been verified', () => {
    for (const name of scripts) {
      const text = read(name);
      assert.ok(!/[^\x00-\x7F]/.test(text), `${name} has non-ASCII characters`);
      for (const tag of ['$$', '$a$', '$q$']) assert.equal((text.split(tag).length - 1) % 2, 0, `${name}: unbalanced ${tag}`);
      assert.match(text.split('\n').slice(0, 4).join('\n'), /verified on|Status:/i, `${name}: the header must state its verification status`);
    }
  });

  it('end by listing every check, so a failure cannot hide', () => {
    for (const name of scripts) assert.match(withoutComments(read(name)).trim(), /select ok, label, detail from results order by n;\s*(deallocate[^;]*;\s*)?rollback;$/i, name);
  });
});

describe('005_pgrepo_contract.sql (generated)', () => {
  it('IS CURRENT: it equals what the generator makes from the code today (after changing PgRepo run: node scripts/gen-pgrepo-contract.ts)', async () => {
    const generated = render(await runScenario()).script;
    assert.equal(readFileSync(new URL(`../../../${SCRIPT_PATH}`, import.meta.url), 'utf8') === generated, true, `${SCRIPT_PATH} is out of date: run node scripts/gen-pgrepo-contract.ts`);
  });

  it('exercises every kind of statement the commit service sends, including the paths only a conflict reaches', async () => {
    const { script } = render(await runScenario());
    const fragments = [
      'FOR UPDATE', 'NOT EXISTS (SELECT 1 FROM lesson_sessions c WHERE c.parent_session_id = s.id)', 'ORDER BY lw.position', 'NULLS LAST',
      'INSERT INTO lesson_sessions', 'INSERT INTO session_attempts', 'INSERT INTO user_word_stats', 'ON CONFLICT (user_id, word_id) DO UPDATE',
      'INSERT INTO misspelled_words', 'ON CONFLICT (user_id, word_id, typed) DO UPDATE', 'LEAST(misspelled_words.first_seen_at', 'GREATEST(misspelled_words.last_seen_at',
      'INSERT INTO xp_events', 'INSERT INTO user_progress', 'GREATEST(COALESCE(user_progress.best_accuracy, 0)', 'UPDATE users SET streak_count', 'SELECT total_xp FROM users',
      'CAST(last_active_date AS text)', '$4, $4', 'IN ($2, $3, $4)',
    ];
    for (const f of fragments) assert.ok(script.includes(f), `the scenario no longer reaches: ${f}`);
    // the multi-row INSERT is prepared with more than one row
    assert.match(script, /INSERT INTO session_attempts \([^)]*\) VALUES \(\$1[^)]*\), \(\$11,/);
  });

  it('checks the end state of every table the commit service writes', async () => {
    const { script } = render(await runScenario());
    for (const table of ['lesson_sessions', 'session_attempts', 'user_word_stats', 'misspelled_words', 'xp_events', 'user_progress', 'users']) {
      assert.match(script, new RegExp(`digest_check\\('${table} \\(\\d+ rows\\) holds what the twin holds'`), table);
    }
  });

  it('sends values as text and never inlines them into a statement, so PostgreSQL infers parameter types like it does for the app', async () => {
    const { script } = render(await runScenario());
    const prepares = script.split('\n').filter((l) => l.startsWith('prepare '));
    assert.ok(prepares.length >= 15);
    for (const line of prepares) assert.ok(/\$1\b/.test(line), `statement without parameters: ${line.slice(0, 60)}`);
    assert.ok(!/prepare [a-z0-9_]+\((?!\))/.test(script), 'no parameter types are declared: PostgreSQL has to infer them');
  });
});
