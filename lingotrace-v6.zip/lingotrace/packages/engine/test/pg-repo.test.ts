// PgRepo read paths on the Supabase schema twin (the write path is covered by commit.test.ts).
// Ported from spelling-core/test/repo-words.test.ts (its two schema.sql/migration drift tests are obsolete:
// the Supabase migrations are checked by supabase/tests instead), plus two new contract tests.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { DEFAULT_CONFIG, createRng, pickInjectedMistakes } from '../src/index.ts';
import type { MistakeRecord } from '../src/index.ts';
import { PgRepo } from '../src/server/index.ts';
import { WORDS, openDb, seedWorld, sentenceOf, sqlitePool } from './helpers/db.ts';

async function world() {
  const db = await openDb();
  seedWorld(db);
  db.exec("UPDATE vocabulary_bank SET meaning_ar = 'تفاحة', sentence_ar = 'أرى التفاحة اليوم.' WHERE id = 'id-apple'");
  return { db, repo: new PgRepo(sqlitePool(db)) };
}

describe('Arabic fields reach the app through PgRepo', () => {
  it('loadLessonWords returns meaningAr and sentenceAr (null for a word that has none)', async () => {
    const { repo } = await world();
    const words = await repo.transaction((tx) => tx.loadLessonWords('lesson-1'));
    const get = (t: string) => words.find((w) => w.wordText === t)!;
    assert.deepEqual([get('apple').meaningAr, get('apple').sentenceAr], ['تفاحة', 'أرى التفاحة اليوم.']);
    assert.deepEqual([get('bridge').meaningAr, get('bridge').sentenceAr], [null, null]);
    assert.deepEqual(words.map((w) => w.wordText), WORDS.slice(0, 20)); // in lesson_words.position order
  });

  it('an injected review word (loadDueMistakes) carries both Arabic fields too', async () => {
    const { db, repo } = await world();
    db.exec("INSERT INTO user_word_stats (user_id, word_id, error_weight, status, due_seq, lifetime_failures, last_failed_at) VALUES ('u1', 'id-apple', 1, 'active', 2, 2, '2026-10-01T00:00:00.000Z')");
    const due = await repo.transaction((tx) => tx.loadDueMistakes('u1', 'lesson-2', 5));
    assert.equal(due.length, 1);
    assert.deepEqual([due[0]!.word.wordText, due[0]!.word.meaningAr, due[0]!.word.sentenceAr], ['apple', 'تفاحة', 'أرى التفاحة اليوم.']);
  });
});

describe('PgRepo.lockUser reads the streak date safely', () => {
  it('returns YYYY-MM-DD or null, null for an unknown user, and refuses a non-ISO date (DateStyle)', async () => {
    const { db, repo } = await world();
    db.exec("UPDATE users SET last_active_date = '2026-10-11' WHERE id = 'u1'");
    assert.equal((await repo.transaction((tx) => tx.lockUser('u1')))?.lastActiveDate, '2026-10-11');
    assert.equal((await repo.transaction((tx) => tx.lockUser('u2')))?.lastActiveDate, null);
    assert.equal(await repo.transaction((tx) => tx.lockUser('nobody')), null);
    db.exec("UPDATE users SET last_active_date = '11/10/2026' WHERE id = 'u1'"); // what DateStyle 'SQL, DMY' would return
    await assert.rejects(repo.transaction((tx) => tx.lockUser('u1')), /expected YYYY-MM-DD/);
  });
});

describe('PgRepo contracts with the engine rules', () => {
  // queue-builder.ts sorts the rotation with byPriority(); loadDueMistakes() must return the same order,
  // because the server replays the client's lesson from this list. Checked on random data with many ties and NULLs.
  it('loadDueMistakes: only active, due words outside the lesson, in exactly the engine priority order', async () => {
    for (let seed = 1; seed <= 25; seed++) {
      const rng = createRng(seed);
      const { db, repo } = await world();
      const reserved = ['apple', 'bridge']; // apple → mastered, bridge → not due yet
      const chosen = WORDS.slice(0, 40).filter((t) => !reserved.includes(t) && rng() < 0.5); // rotation words from lessons 1 and 2
      const stamps = [null, '2026-10-01T08:00:00.000Z', '2026-10-01T09:00:00.000Z', '2026-10-02T08:00:00.000Z'];
      const insert = db.prepare("INSERT INTO user_word_stats (user_id, word_id, error_weight, status, due_seq, lifetime_failures, last_failed_at) VALUES ('u1', ?1, ?2, ?3, ?4, 1, ?5)");

      const records: MistakeRecord[] = chosen.map((t) => {
        const errorWeight = 1 + Math.floor(rng() * 3);
        const dueSeq = 1 + Math.floor(rng() * 3);
        const lastFailedAt = stamps[Math.floor(rng() * stamps.length)]!;
        insert.run(`id-${t}`, errorWeight, 'active', dueSeq, lastFailedAt);
        return { word: { wordId: `id-${t}`, wordText: t, sentenceContext: sentenceOf(t), errorWeight }, dueSeq, lastFailedAt };
      });
      insert.run('id-apple', 0, 'mastered', null, null); // finished
      insert.run('id-bridge', 1, 'active', 4, '2026-10-01T00:00:00.000Z'); // due from lesson 4 on
      insert.run('id-shadow', 3, 'active', 1, '2026-10-01T00:00:00.000Z'); // taught by lesson 3 itself
      assert.ok(records.length >= 5, `seed ${seed}: fixture too small to mean anything`);

      const shuffled = records.map((r) => ({ r, k: rng() })).sort((a, b) => a.k - b.k).map((x) => x.r); // the engine must not depend on input order
      const lesson3 = new Set(WORDS.slice(40, 60).map((t) => `id-${t}`));
      const expected = pickInjectedMistakes(shuffled, 3, lesson3, { ...DEFAULT_CONFIG, maxInjectedPerLesson: 1000 }).map((m) => m.word.wordId);
      const actual = (await repo.transaction((tx) => tx.loadDueMistakes('u1', 'lesson-3', 50))).map((m) => m.word.wordId);
      assert.deepEqual(actual, expected, `seed ${seed}`);
    }
  });

  it('isLessonUnlocked / isLessonCompleted: every earlier PUBLISHED lesson must be finished at least once', async () => {
    const { db, repo } = await world();
    const unlocked = (seq: number) => repo.transaction((tx) => tx.isLessonUnlocked('u1', seq));
    const completed = (lesson: string) => repo.transaction((tx) => tx.isLessonCompleted('u1', lesson));
    assert.deepEqual([await unlocked(1), await unlocked(2), await unlocked(3)], [true, false, false]);

    db.exec("INSERT INTO user_progress (user_id, lesson_id, first_completed_at, completions) VALUES ('u1', 'lesson-1', '2026-10-01T00:00:00.000Z', 1)");
    assert.deepEqual([await unlocked(2), await unlocked(3), await completed('lesson-1')], [true, false, true]);

    db.exec("INSERT INTO user_progress (user_id, lesson_id, first_completed_at, completions) VALUES ('u1', 'lesson-2', NULL, 0)"); // started, never finished
    assert.deepEqual([await unlocked(3), await completed('lesson-2')], [false, false]);

    db.exec("UPDATE lessons SET is_published = 0 WHERE id = 'lesson-2'"); // an unpublished lesson never blocks the ones after it
    assert.equal(await unlocked(3), true);
    assert.equal(await repo.transaction((tx) => tx.isLessonUnlocked('u2', 2)), false); // progress is per user
  });
});
