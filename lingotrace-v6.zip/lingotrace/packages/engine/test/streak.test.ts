import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { EMPTY_STREAK, applyLessonCompletion, createRng, effectiveStreak, isValidTimeZone, localDate } from '../src/index.ts';

const at = (iso: string) => new Date(iso);
const RIYADH = 'Asia/Riyadh'; // UTC+3, no DST

describe('streak — calendar day in the user\'s own time zone', () => {
  it('first completed lesson starts a streak of 1 on the local date', () => {
    assert.deepEqual(applyLessonCompletion(EMPTY_STREAK, at('2026-10-04T10:00:00Z'), RIYADH), { streakCount: 1, longestStreak: 1, lastActiveDate: '2026-10-04' });
  });

  it('the day boundary is the USER\'s midnight: 23:30 → 00:30 local is a new day, even only one hour apart', () => {
    let s = applyLessonCompletion(EMPTY_STREAK, at('2026-10-04T20:30:00Z'), RIYADH); // 23:30 on 4 Oct in Riyadh
    s = applyLessonCompletion(s, at('2026-10-04T21:30:00Z'), RIYADH); // 00:30 on 5 Oct in Riyadh
    assert.equal(s.streakCount, 2);
    const utc = applyLessonCompletion(applyLessonCompletion(EMPTY_STREAK, at('2026-10-04T20:30:00Z'), 'UTC'), at('2026-10-04T21:30:00Z'), 'UTC');
    assert.equal(utc.streakCount, 1); // same instants, but one calendar day in UTC
  });

  it('more lessons on the same local day change nothing', () => {
    let s = applyLessonCompletion(EMPTY_STREAK, at('2026-10-04T05:00:00Z'), RIYADH);
    s = applyLessonCompletion(s, at('2026-10-04T08:00:00Z'), RIYADH);
    s = applyLessonCompletion(s, at('2026-10-04T18:00:00Z'), RIYADH);
    assert.equal(s.streakCount, 1);
  });

  it('playing at a LATER clock time each day still counts every day (no rolling-window drift)', () => {
    let s = EMPTY_STREAK;
    for (const iso of ['2026-10-04T20:00:00Z', '2026-10-05T07:00:00Z', '2026-10-06T06:00:00Z']) s = applyLessonCompletion(s, at(iso), 'UTC');
    assert.equal(s.streakCount, 3); // 20:00 → 07:00 next day is only 11h apart, yet a new calendar day
  });

  it('skipping a whole local day resets to 1 and keeps the record', () => {
    let s = applyLessonCompletion(EMPTY_STREAK, at('2026-10-04T10:00:00Z'), 'UTC');
    s = applyLessonCompletion(s, at('2026-10-05T10:00:00Z'), 'UTC');
    s = applyLessonCompletion(s, at('2026-10-07T10:00:00Z'), 'UTC'); // 6th was missed
    assert.deepEqual([s.streakCount, s.longestStreak], [1, 2]);
  });

  it('display: active today or yesterday keeps the streak, two days ago shows 0', () => {
    const s = applyLessonCompletion(applyLessonCompletion(EMPTY_STREAK, at('2026-10-04T10:00:00Z'), 'UTC'), at('2026-10-05T10:00:00Z'), 'UTC');
    assert.equal(effectiveStreak(s, at('2026-10-05T23:59:00Z'), 'UTC'), 2);
    assert.equal(effectiveStreak(s, at('2026-10-06T00:01:00Z'), 'UTC'), 2); // yesterday: still alive, play today to extend
    assert.equal(effectiveStreak(s, at('2026-10-07T00:01:00Z'), 'UTC'), 0);
    assert.equal(effectiveStreak(EMPTY_STREAK, at('2026-10-05T00:00:00Z'), 'UTC'), 0);
  });

  it('daylight saving: consecutive local days count even when the gap is not 24h', () => {
    let s = applyLessonCompletion(EMPTY_STREAK, at('2026-03-08T03:30:00Z'), 'America/New_York'); // 22:30 on 7 Mar (EST)
    s = applyLessonCompletion(s, at('2026-03-09T03:30:00Z'), 'America/New_York'); // 23:30 on 8 Mar (EDT, clocks jumped)
    assert.deepEqual([s.lastActiveDate, s.streakCount], ['2026-03-08', 2]);
  });

  it('a device clock or time zone that moves backwards never changes the streak', () => {
    const s = applyLessonCompletion(EMPTY_STREAK, at('2026-10-05T10:00:00Z'), 'UTC');
    assert.deepEqual(applyLessonCompletion(s, at('2026-10-03T10:00:00Z'), 'UTC'), s);
  });

  it('time zones: local dates and validation', () => {
    assert.equal(localDate(at('2026-10-04T12:00:00Z'), 'Pacific/Kiritimati'), '2026-10-05'); // UTC+14
    assert.equal(localDate(at('2026-10-04T12:00:00Z'), 'Pacific/Pago_Pago'), '2026-10-04'); // UTC-11
    assert.ok(isValidTimeZone('Asia/Riyadh') && isValidTimeZone('UTC'));
    assert.ok(!isValidTimeZone('Mars/Base') && !isValidTimeZone('') && !isValidTimeZone(42));
  });
});

describe('seeded rng', () => {
  it('same seed → same sequence; different seed → different', () => {
    const a = createRng(42), b = createRng(42), c = createRng(43);
    const xs = Array.from({ length: 5 }, () => a());
    assert.deepEqual(xs, Array.from({ length: 5 }, () => b()));
    assert.notDeepEqual(xs, Array.from({ length: 5 }, () => c()));
    assert.ok(xs.every((x) => x >= 0 && x < 1));
  });
});
