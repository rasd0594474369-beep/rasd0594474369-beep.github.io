import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { EMPTY_STREAK, ENGINE_VERSION, beginSession, currentPrompt, newSeed, peek, submit, toSessionCommit } from '../src/index.ts';
import type { AttemptLog, ClaimedAttempt, MistakeRecord, Prompt, SessionCommit, WordItem } from '../src/index.ts';
import { MISSPELLED_MAX_LENGTH, PgRepo, collectMisspellings, commitSession, isUuid, planCommit } from '../src/server/index.ts';
import { READABLE_IDS, UUID_IDS, WORDS, openDb, seedWorld, sentenceOf, sqlitePool, uuidOf } from './helpers/db.ts';
import type { Ids } from './helpers/db.ts';

const commitLoose = (repo: PgRepo, userId: string, c: SessionCommit, now: Date) => commitSession(repo, userId, c, now, { isValidId: () => true }); // fixtures use readable ids
const T0 = Date.parse('2026-10-04T10:00:00.000Z');
const H = 3_600_000;
const garble = (t: string) => 'zz' + t.slice(2);
const wordItem = (ids: Ids, t: string): WordItem => ({ wordId: ids.word(t), wordText: t, sentenceContext: sentenceOf(t), errorWeight: 0 });
const lessonWordsOf = (ids: Ids, n: number) => WORDS.slice((n - 1) * 20, n * 20).map((t) => wordItem(ids, t));

async function world(ids: Ids = READABLE_IDS) {
  const db = await openDb();
  seedWorld(db, ids);
  const repo = new PgRepo(sqlitePool(db));
  const all = (sql: string, ...p: unknown[]) => db.prepare(sql).all(...p).map((r) => ({ ...r })); // node:sqlite rows have a null prototype
  const one = (sql: string, ...p: unknown[]) => all(sql, ...p)[0] as Record<string, unknown>;
  const count = (table: string) => Number(one(`SELECT count(*) AS c FROM ${table}`)?.c);
  return { db, ids, repo, one, all, count };
}
type World = Awaited<ReturnType<typeof world>>;

type PlayOptions = { n: number; sid: string; tz?: string; at?: number; userId?: string; mode?: 'first_run' | 'replay'; parent?: string | null; policy?: (p: Prompt, n: number) => string | { text: string; peek: true } };

/**
 * What an honest client does: sync the rotation, play with the shared engine, build the payload.
 * `parent` is the session played just before; left out, it is the chain head the server knows (an online client).
 */
async function play(w: World, o: PlayOptions): Promise<SessionCommit> {
  const userId = o.userId ?? w.ids.user(1);
  const lessonId = w.ids.lesson(o.n);
  const history: MistakeRecord[] = o.mode === 'replay' ? [] : await w.repo.transaction((tx) => tx.loadDueMistakes(userId, lessonId, 50));
  const parentSessionId = o.parent !== undefined ? o.parent : await w.repo.transaction((tx) => tx.lastSessionId(userId));
  const seed = newSeed();
  const policy = o.policy ?? ((p: Prompt) => p.text);
  let { state, rng } = beginSession({ sessionId: o.sid, lessonSeq: o.n, mode: o.mode ?? 'first_run', seed, lessonWords: lessonWordsOf(w.ids, o.n), history });
  let clock = o.at ?? T0, key = '', k = 0;
  const startedAt = new Date(clock).toISOString();
  while (state.phase !== 'completed') {
    const p = currentPrompt(state)!;
    k = key === `${p.itemId}/${p.step}` ? k + 1 : 1; key = `${p.itemId}/${p.step}`;
    const a = policy(p, k);
    if (typeof a !== 'string') state = peek(state);
    clock += 2000;
    state = submit(state, typeof a === 'string' ? a : a.text, { now: new Date(clock), rng }).state;
  }
  return toSessionCommit(state, { lessonId, parentSessionId, seed, timeZone: o.tz ?? 'UTC', startedAt, completedAt: new Date(clock + 500).toISOString() });
}
const nowOf = (c: SessionCommit) => new Date(Date.parse(c.completedAt) + 1000);
const failTwice = (id: string) => (p: Prompt) => (p.wordId === id ? garble(p.text) : p.text);

/** Play, commit as user u1 with readable ids, and insist that the server accepted it. */
async function playAndCommit(w: World, o: PlayOptions) {
  const c = await play(w, o);
  const r = await commitLoose(w.repo, o.userId ?? 'u1', c, nowOf(c));
  assert.ok(r.ok, `session ${o.sid} should be accepted`);
  return { c, r };
}

describe('commitSession (PgRepo SQL on the Supabase schema twin)', () => {
  it('commits a perfect lesson: session, attempts, XP ledger, progress, streak', async () => {
    const w = await world();
    const c = await play(w, { n: 1, sid: 's1' });
    const r = await commitLoose(w.repo, 'u1', c, nowOf(c));
    assert.ok(r.ok);
    if (r.ok) assert.deepEqual([r.receipt.status, r.receipt.xpEarned, r.receipt.totalXp, r.receipt.streak, r.receipt.newMistakes], ['committed', 250, 250, 1, 0]);
    assert.equal(w.one("SELECT total_xp FROM users WHERE id='u1'")?.total_xp, 250);
    assert.deepEqual(w.one('SELECT words_total, words_clean, xp_earned, mode FROM lesson_sessions'), { words_total: 20, words_clean: 20, xp_earned: 250, mode: 'first_run' });
    assert.equal(w.count('session_attempts'), 40);
    assert.deepEqual(w.all('SELECT reason, amount FROM xp_events ORDER BY id'), [{ reason: 'words_first_try', amount: 200 }, { reason: 'lesson_bonus', amount: 50 }]);
    assert.deepEqual(
      w.one("SELECT completions, first_completed_at IS NOT NULL AS done, best_accuracy, last_accuracy FROM user_progress WHERE lesson_id='lesson-1'"),
      { completions: 1, done: 1, best_accuracy: 100, last_accuracy: 100 },
    );
    assert.equal(w.count('misspelled_words'), 0);
    assert.equal(w.one("SELECT streak_count FROM users WHERE id='u1'")?.streak_count, 1);
  });

  it('is idempotent: committing the same session twice changes nothing', async () => {
    const w = await world();
    const c = await play(w, { n: 1, sid: 's1' });
    await commitLoose(w.repo, 'u1', c, nowOf(c));
    const again = await commitLoose(w.repo, 'u1', c, nowOf(c));
    assert.ok(again.ok && again.receipt.status === 'duplicate' && again.receipt.totalXp === 250);
    assert.deepEqual([w.count('lesson_sessions'), w.count('session_attempts'), w.count('xp_events')], [1, 40, 2]);
  });

  it('writes the whole attempt log in ONE statement: a commit costs a fixed handful of round trips, not one per attempt', async () => {
    const w = await world();
    const statements: string[] = [];
    const counted = new PgRepo(sqlitePool(w.db, { beforeQuery: (text) => statements.push(text.trim()) }));
    const c = await play(w, { n: 1, sid: 's1', policy: failTwice('id-candle') }); // 40 attempts, a rotation row and a misspelling row
    assert.equal(c.attempts.length, 40);
    statements.length = 0; // count the commit only (play() read the rotation and the chain head with a few statements of its own)
    assert.ok((await commitLoose(counted, 'u1', c, nowOf(c))).ok);
    assert.equal(statements.filter((t) => /^INSERT INTO session_attempts/.test(t)).length, 1);
    assert.equal(w.count('session_attempts'), 40);
    // BEGIN + 9 reads + sessions, attempts, stats, misspellings, 2 XP rows, progress, streak, total + COMMIT = 20 today; the budget leaves a little room
    assert.ok(statements.length <= 24, `${statements.length} statements: the budget is 24 (it was 58 when every attempt was its own INSERT)`);
  });

  it('delayed review end to end: failed twice in lesson 1 → injected in lesson 3 → mastered', async () => {
    const w = await world();
    const c1 = await play(w, { n: 1, sid: 's1', policy: failTwice('id-candle') });
    const r1 = await commitLoose(w.repo, 'u1', c1, nowOf(c1));
    assert.ok(r1.ok && r1.receipt.newMistakes === 1 && r1.receipt.xpEarned === 240);
    assert.deepEqual(w.one("SELECT error_weight, status, due_seq, lifetime_failures FROM user_word_stats WHERE word_id='id-candle'"), { error_weight: 1, status: 'active', due_seq: 3, lifetime_failures: 1 });

    const c2 = await play(w, { n: 2, sid: 's2', at: T0 + H });
    assert.deepEqual(c2.injectedWordIds, []); // due in lesson 3, not 2
    assert.ok((await commitLoose(w.repo, 'u1', c2, nowOf(c2))).ok);

    const c3 = await play(w, { n: 3, sid: 's3', at: T0 + 2 * H });
    assert.deepEqual(c3.injectedWordIds, ['id-candle']);
    const r3 = await commitLoose(w.repo, 'u1', c3, nowOf(c3));
    assert.ok(r3.ok && r3.receipt.xpEarned === 255); // 200 + 5 (injected, clean) + 50
    assert.deepEqual(w.one("SELECT error_weight, status, due_seq FROM user_word_stats WHERE word_id='id-candle'"), { error_weight: 0, status: 'mastered', due_seq: null });
    assert.equal(w.one("SELECT total_xp FROM users WHERE id='u1'")?.total_xp, 240 + 250 + 255);
  });

  it('failing an injected word twice raises its weight and reschedules it', async () => {
    const w = await world();
    for (const [n, sid, pol] of [[1, 's1', failTwice('id-candle')], [2, 's2', undefined]] as const) {
      const c = await play(w, { n, sid, at: T0 + n * H, policy: pol });
      assert.ok((await commitLoose(w.repo, 'u1', c, nowOf(c))).ok);
    }
    const c3 = await play(w, { n: 3, sid: 's3', at: T0 + 5 * H, policy: failTwice('id-candle') });
    assert.ok((await commitLoose(w.repo, 'u1', c3, nowOf(c3))).ok);
    assert.deepEqual(w.one("SELECT error_weight, status, due_seq, lifetime_failures FROM user_word_stats WHERE word_id='id-candle'"), { error_weight: 2, status: 'active', due_seq: 5, lifetime_failures: 2 });
  });

  it('the server decides first run vs replay; a replay earns no XP but still counts as activity', async () => {
    const w = await world();
    const c1 = await play(w, { n: 1, sid: 's1' });
    await commitLoose(w.repo, 'u1', c1, nowOf(c1));
    const done = w.one('SELECT first_completed_at AS f FROM user_progress')?.f;

    const bad = await play(w, { n: 1, sid: 's-bad', at: T0 + H });
    const r0 = await commitLoose(w.repo, 'u1', bad, nowOf(bad)); // claims first_run on a completed lesson
    assert.ok(!r0.ok && r0.code === 'mode_mismatch');

    const rp = await play(w, { n: 1, sid: 's-replay', at: T0 + 2 * H, mode: 'replay' });
    const r1 = await commitLoose(w.repo, 'u1', rp, nowOf(rp));
    assert.ok(r1.ok && r1.receipt.xpEarned === 0 && r1.receipt.mode === 'replay' && r1.receipt.totalXp === 250);
    assert.deepEqual(w.one('SELECT completions, first_completed_at AS f FROM user_progress'), { completions: 2, f: done });
    assert.equal(w.count('xp_events'), 2); // no replay XP rows

    const fresh = await play(w, { n: 2, sid: 's-x', at: T0 + 3 * H, mode: 'replay' });
    const r2 = await commitLoose(w.repo, 'u1', fresh, nowOf(fresh)); // claims replay on a lesson never completed
    assert.ok(!r2.ok && r2.code === 'mode_mismatch');
  });

  it('locks lessons: lesson 2 cannot be committed before lesson 1', async () => {
    const w = await world();
    const c = await play(w, { n: 2, sid: 's2' });
    const r = await commitLoose(w.repo, 'u1', c, nowOf(c));
    assert.ok(!r.ok && r.code === 'lesson_locked');
    assert.deepEqual([w.count('lesson_sessions'), w.count('xp_events')], [0, 0]);
  });

  it('rejects tampering: bad injection claims, edited logs, swapped order, truncated logs, unknown lesson', async () => {
    const w = await world();
    const good = await play(w, { n: 1, sid: 's1', policy: failTwice('id-candle') });
    const now = nowOf(good);
    const code = async (c: SessionCommit) => { const r = await commitLoose(w.repo, 'u1', c, now); return r.ok ? 'ok' : r.code; };

    assert.equal(await code({ ...good, injectedWordIds: ['id-umbrella'] }), 'injection_invalid'); // not in the rotation
    assert.equal(await code({ ...good, attempts: good.attempts.map((a) => (a.itemId === 'L:id-candle' ? { ...a, input: 'candle' } : a)) }), 'replay_failed');
    const swapped = good.attempts.map((a, i) => { const j = i === 0 ? 2 : i === 2 ? 0 : i; const b = good.attempts[j]!; return { ...b, at: a.at }; }); // contents swapped, clock still monotonic
    assert.equal(await code({ ...good, attempts: swapped }), 'replay_failed');
    assert.equal(await code({ ...good, attempts: [...good.attempts].reverse() }), 'timing_implausible'); // caught even earlier
    assert.equal(await code({ ...good, attempts: good.attempts.slice(0, -2) }), 'replay_failed');
    assert.equal(await code({ ...good, lessonId: 'nope' }), 'lesson_not_found');
    assert.equal(await code({ ...good, attempts: [] }), 'bad_request');
    assert.equal(w.count('lesson_sessions'), 0);
    assert.equal(w.count('misspelled_words'), 0); // nothing leaks from a rejected session
    assert.equal(await code(good), 'ok'); // the untouched payload is still accepted
  });

  it('rejects implausible timing (bot-fast sessions, future dates, out-of-order timestamps)', async () => {
    const w = await world();
    const good = await play(w, { n: 1, sid: 's1' });
    const now = nowOf(good);
    const code = async (c: SessionCommit) => { const r = await commitLoose(w.repo, 'u1', c, now); return r.ok ? 'ok' : r.code; };
    assert.equal(await code({ ...good, completedAt: new Date(Date.parse(good.startedAt) + 5000).toISOString() }), 'timing_implausible');
    assert.equal(await code({ ...good, completedAt: new Date(now.getTime() + 3_600_000).toISOString() }), 'timing_implausible');
    const shuffled = [...good.attempts]; shuffled[3] = { ...shuffled[3]!, at: good.startedAt };
    assert.equal(await code({ ...good, attempts: shuffled }), 'timing_implausible');
  });

  it('streak across commits: +1 after a day, reset after 48h of silence, record kept', async () => {
    const w = await world();
    const run = async (n: number, sid: string, at: number) => { const c = await play(w, { n, sid, at }); const r = await commitLoose(w.repo, 'u1', c, nowOf(c)); assert.ok(r.ok); return r.ok ? r.receipt : null; };
    assert.equal((await run(1, 's1', T0))?.streak, 1);
    assert.equal((await run(2, 's2', T0 + 30 * H))?.streak, 2);
    const last = await run(3, 's3', T0 + 30 * H + 60 * H);
    assert.deepEqual([last?.streak, last?.longestStreak], [1, 2]);
  });

  it("one user cannot reuse or read another user's session id", async () => {
    const w = await world();
    const c = await play(w, { n: 1, sid: 's1' });
    await commitLoose(w.repo, 'u1', c, nowOf(c));
    const r = await commitLoose(w.repo, 'u2', c, nowOf(c));
    assert.ok(!r.ok && r.code === 'bad_request');
    assert.ok(!(await commitLoose(w.repo, 'ghost', c, nowOf(c))).ok);
  });

  // The failing statement is injected one at a time, so every write of applyPlan is proven to sit inside the transaction:
  // a failure at the LAST write must undo all the earlier ones.
  for (const failing of ['INSERT INTO session_attempts', 'INSERT INTO user_word_stats', 'INSERT INTO misspelled_words', 'INSERT INTO xp_events', 'INSERT INTO user_progress', 'UPDATE users SET streak_count']) {
    it(`is atomic: a failure at "${failing}" rolls back every write of the commit`, async () => {
      const w = await world();
      const boom = new PgRepo(sqlitePool(w.db, { beforeQuery: (t) => { if (t.includes(failing)) throw new Error('disk full'); } }));
      const c = await play(w, { n: 1, sid: 's1', policy: failTwice('id-candle') }); // produces rotation + misspelling rows too
      await assert.rejects(commitLoose(boom, 'u1', c, nowOf(c)), /disk full/);
      assert.deepEqual(['lesson_sessions', 'session_attempts', 'user_word_stats', 'misspelled_words', 'xp_events', 'user_progress'].map(w.count), [0, 0, 0, 0, 0, 0]);
      assert.deepEqual(w.one("SELECT total_xp, streak_count FROM users WHERE id='u1'"), { total_xp: 0, streak_count: 0 });
      assert.ok((await commitLoose(w.repo, 'u1', c, nowOf(c))).ok); // and the retry succeeds
    });
  }

  it('rejects malformed ids before touching the database', async () => {
    const w = await world();
    const c = await play(w, { n: 1, sid: 's1' });
    const r = await commitSession(w.repo, 'u1', c, nowOf(c)); // default id check: 's1' is not a UUID
    assert.ok(!r.ok && r.code === 'bad_request');
    assert.equal(w.count('lesson_sessions'), 0);
  });

  it('accepts real UUIDs end to end with the default id check (the one production uses)', async () => {
    const w = await world(UUID_IDS);
    const c = await play(w, { n: 1, sid: uuidOf('session-1') });
    const r = await commitSession(w.repo, w.ids.user(1), c, nowOf(c)); // no isValidId override
    assert.ok(r.ok && r.receipt.status === 'committed' && r.receipt.xpEarned === 250);
    assert.equal(w.one('SELECT id FROM lesson_sessions')?.id, c.sessionId);
    assert.equal(w.count('session_attempts'), 40);
  });

  it('refuses sessions played with different lesson rules (engine version)', async () => {
    const w = await world();
    const c = await play(w, { n: 1, sid: 's1' });
    const r = await commitLoose(w.repo, 'u1', { ...c, engineVersion: ENGINE_VERSION - 1 }, nowOf(c));
    assert.ok(!r.ok && r.code === 'engine_outdated');
  });

  it('strips NUL characters from typed text (PostgreSQL text columns cannot store them)', async () => {
    const w = await world();
    const c = await play(w, { n: 1, sid: 's1', policy: (p, n) => (p.wordId === 'id-candle' && p.step === 'word' && n === 1 ? 'zz\u0000ndle' : p.text) });
    const ctx = { userId: 'u1', lesson: { id: 'lesson-1', levelCode: 'A1', lessonNumber: 1, globalSeq: 1, isPublished: true }, lessonWords: lessonWordsOf(w.ids, 1), eligibleMistakes: [], previousStats: [], alreadyCompleted: false, unlocked: true, streak: EMPTY_STREAK };
    const plan = planCommit(c, ctx, nowOf(c));
    assert.ok(plan.ok);
    if (plan.ok) {
      assert.ok(plan.plan.attempts.some((a) => a.typed === 'zzndle'));
      assert.ok(plan.plan.attempts.every((a) => !a.typed.includes('\u0000')));
      // typed once in the lesson and once more in its review (the attempt counter restarts for the review item): one merged row
      assert.deepEqual(plan.plan.misspelled.map((m) => [m.typed, m.occurrences]), [['zzndle', 2]]);
    }
  });

  it("streak follows the user's own calendar day (time zone) and rejects invalid zones", async () => {
    const w = await world();
    const run = async (n: number, sid: string, at: number, tz: string) => { const c = await play(w, { n, sid, at, tz }); const r = await commitLoose(w.repo, 'u1', c, nowOf(c)); assert.ok(r.ok); return r.ok ? r.receipt.streak : -1; };
    const t = Date.parse('2026-10-04T20:30:00.000Z'); // 23:30 in Riyadh
    assert.equal(await run(1, 's1', t, 'Asia/Riyadh'), 1);
    assert.equal(await run(2, 's2', t + 3_600_000, 'Asia/Riyadh'), 2); // 00:30 on the next LOCAL day
    assert.deepEqual(w.one("SELECT time_zone AS z, last_active_date AS d FROM users WHERE id='u1'"), { z: 'Asia/Riyadh', d: '2026-10-05' });
    const bad = await play(w, { n: 3, sid: 's3', at: t + 7_200_000 });
    const r = await commitLoose(w.repo, 'u1', { ...bad, timeZone: 'Mars/Base' }, nowOf(bad));
    assert.ok(!r.ok && r.code === 'bad_request');
  });
});

describe('commitSession: lesson accuracy and the misspelling log', () => {
  it('logs each wrong spelling per word, merging case and spacing; exact answers and sentence mistakes are not logged', async () => {
    const w = await world();
    const policy = (p: Prompt, k: number): string => {
      if (p.wordId === 'id-candle' && p.step === 'word') return p.isReview ? 'zzNDLE' : ' ZZNDLE '; // distance 2: fails at once, in the lesson and in the review
      if (p.wordId === 'id-harbor' && p.step === 'word') {
        if (!p.isReview) return 'harbur'; // distance 1: slip → re-type → slip again → fails
        return k === 1 ? 'harbo' : p.text; // review: slip → re-type correctly
      }
      if (p.wordId === 'id-garden' && p.step === 'sentence') return 'nope'; // wrong sentence, right word
      return p.text;
    };
    const { c } = await playAndCommit(w, { n: 1, sid: 's1', policy });

    const rows = w.all('SELECT word_id, typed, occurrences, first_seen_at AS first, last_seen_at AS last FROM misspelled_words ORDER BY word_id, typed');
    assert.deepEqual(rows.map((r) => [r.word_id, r.typed, r.occurrences]), [
      ['id-candle', 'zzndle', 2], // ' ZZNDLE ' and 'zzNDLE' are the same wrong spelling
      ['id-harbor', 'harbo', 1],
      ['id-harbor', 'harbur', 2],
    ]);

    // first/last sighting come from the clock of the attempts the client claimed
    const clock = (pick: (a: ClaimedAttempt) => boolean) => c.attempts.filter(pick).map((a) => a.at);
    const candle = clock((a) => a.step === 'word' && a.itemId.endsWith('id-candle'));
    const harbur = clock((a) => a.step === 'word' && a.itemId === 'L:id-harbor');
    const harbo = clock((a) => a.itemId === 'R:id-harbor' && a.input === 'harbo');
    assert.deepEqual(rows.map((r) => [r.first, r.last]), [
      [candle[0], candle.at(-1)],
      [harbo[0], harbo.at(-1)],
      [harbur[0], harbur.at(-1)],
    ]);
  });

  it('adds counts up across sessions and widens the first/last window, even when an older session arrives later', async () => {
    const w = await world();
    const { c: late } = await playAndCommit(w, { n: 1, sid: 's-late', at: T0 + 2 * H, policy: failTwice('id-candle') }); // played later, reaches the server first
    const { c: early } = await playAndCommit(w, { n: 1, sid: 's-early', at: T0, mode: 'replay', policy: failTwice('id-candle') });

    const sighted = (c: SessionCommit) => c.attempts.filter((a) => a.itemId.endsWith('id-candle')).map((a) => a.at);
    assert.deepEqual(w.one("SELECT occurrences, first_seen_at AS first, last_seen_at AS last FROM misspelled_words WHERE word_id='id-candle' AND typed='zzndle'"), {
      occurrences: 4,
      first: sighted(early)[0], // LEAST: the older session's first attempt
      last: sighted(late).at(-1), // GREATEST: the later session's last attempt
    });
    assert.equal(w.count('misspelled_words'), 1);
  });

  it('sending the same session again changes nothing: no double count in progress, XP, rotation or misspellings', async () => {
    const w = await world();
    const { c } = await playAndCommit(w, { n: 1, sid: 's1', policy: failTwice('id-candle') });
    const tables = ['users', 'lesson_sessions', 'session_attempts', 'user_word_stats', 'misspelled_words', 'xp_events', 'user_progress'];
    const snapshot = () => Object.fromEntries(tables.map((t) => [t, w.all(`SELECT * FROM ${t}`)]));
    const before = snapshot();
    assert.equal(w.one('SELECT occurrences FROM misspelled_words')?.occurrences, 2); // there is something that could be doubled

    const again = await commitLoose(w.repo, 'u1', c, nowOf(c));
    assert.ok(again.ok && again.receipt.status === 'duplicate');
    assert.deepEqual(snapshot(), before);
  });

  it('user_progress keeps the best accuracy and the latest accuracy apart (first run, then replays)', async () => {
    const w = await world();
    const failing = (...ids: string[]) => (p: Prompt) => (ids.includes(p.wordId) ? garble(p.text) : p.text);
    const progress = () => w.one("SELECT completions, best_accuracy AS best, last_accuracy AS last FROM user_progress WHERE lesson_id='lesson-1'");

    await playAndCommit(w, { n: 1, sid: 's1', at: T0, policy: failing('id-candle', 'id-harbor') }); // 18 of 20 words clean
    assert.deepEqual(progress(), { completions: 1, best: 90, last: 90 });
    await playAndCommit(w, { n: 1, sid: 's2', at: T0 + H, mode: 'replay', policy: failing() }); // 20 of 20
    assert.deepEqual(progress(), { completions: 2, best: 100, last: 100 });
    await playAndCommit(w, { n: 1, sid: 's3', at: T0 + 2 * H, mode: 'replay', policy: failing('id-candle', 'id-harbor', 'id-garden') }); // 17 of 20
    assert.deepEqual(progress(), { completions: 3, best: 100, last: 85 });

    // the numbers agree with what each session row recorded
    const sessions = w.all('SELECT words_total, words_clean FROM lesson_sessions ORDER BY completed_at');
    assert.deepEqual(sessions.map((s) => [s.words_total, s.words_clean]), [[20, 18], [20, 20], [20, 17]]);
  });

  it('rounds the accuracy to a whole percent (21 words with an injected review word: 17 clean = 81%)', async () => {
    const w = await world();
    await playAndCommit(w, { n: 1, sid: 's1', at: T0 + H, policy: failTwice('id-candle') }); // candle enters the rotation, due in lesson 3
    await playAndCommit(w, { n: 2, sid: 's2', at: T0 + 2 * H });
    const failing = new Set(['id-shadow', 'id-silver', 'id-spider', 'id-sponge']);
    const c3 = await play(w, { n: 3, sid: 's3', at: T0 + 5 * H, policy: (p) => (failing.has(p.wordId) ? garble(p.text) : p.text) });
    assert.deepEqual(c3.injectedWordIds, ['id-candle']); // precondition: the lesson really has 21 words
    assert.ok((await commitLoose(w.repo, 'u1', c3, nowOf(c3))).ok);
    assert.deepEqual(w.one("SELECT words_total, words_clean FROM lesson_sessions WHERE id='s3'"), { words_total: 21, words_clean: 17 });
    assert.deepEqual(w.one("SELECT best_accuracy, last_accuracy FROM user_progress WHERE lesson_id='lesson-3'"), { best_accuracy: 81, last_accuracy: 81 }); // 80.95 → 81
  });

  it('skips wrong spellings the table cannot hold (blank, over 100 characters), keeps the boundary ones, and still commits', async () => {
    const w = await world();
    const MAX = MISSPELLED_MAX_LENGTH;
    const wrong: Record<string, string> = {
      'id-candle': 'a'.repeat(MAX), // exactly 100: kept
      'id-harbor': 'b'.repeat(MAX + 1), // 101: skipped
      'id-garden': '   ', // blank once normalized: skipped
      'id-dolphin': '😀'.repeat(MAX), // 100 characters but 200 UTF-16 units: kept, because the limit counts characters like char_length
      'id-engine': '😀'.repeat(MAX + 1), // 101 characters: skipped
      'id-forest': 'zz\u0000rest', // the NUL is removed: 'zzrest'
    };
    await playAndCommit(w, { n: 1, sid: 's1', policy: (p) => (p.step === 'word' && !p.isReview ? (wrong[p.wordId] ?? p.text) : p.text) });

    assert.deepEqual(w.all('SELECT word_id, typed FROM misspelled_words ORDER BY word_id').map((r) => [r.word_id, r.typed]), [
      ['id-candle', 'a'.repeat(MAX)],
      ['id-dolphin', '😀'.repeat(MAX)],
      ['id-forest', 'zzrest'],
    ]);
    // the attempt log keeps the long ones in full (its limit is 500)
    assert.equal(Number(w.one('SELECT count(*) AS n FROM session_attempts WHERE length(typed) > 100')?.n), 2);
  });
});

describe('commitSession: the session chain (offline sessions arrive in play order)', () => {
  it('an outbox filled offline is refused out of order, with the head, and accepted in order', async () => {
    const w = await world();
    // played offline one after the other: nothing was committed in between, so each names the previous one
    const a = await play(w, { n: 1, sid: 'sA', at: T0, parent: null });
    const b = await play(w, { n: 2, sid: 'sB', at: T0 + H, parent: 'sA' });
    const c = await play(w, { n: 3, sid: 'sC', at: T0 + 2 * H, parent: 'sB' });
    const send = async (x: SessionCommit) => commitLoose(w.repo, 'u1', x, nowOf(x));

    for (const late of [c, b]) {
      const r = await send(late);
      assert.ok(!r.ok && r.code === 'out_of_order' && r.details?.lastSessionId === null, `${late.sessionId} must wait for the sessions before it`);
    }
    assert.equal(w.count('lesson_sessions'), 0); // refused without a trace

    assert.ok((await send(a)).ok);
    const again = await send(c); // still not its turn
    assert.ok(!again.ok && again.code === 'out_of_order' && again.details?.lastSessionId === 'sA');
    assert.ok((await send(b)).ok);
    assert.ok((await send(c)).ok);

    assert.deepEqual(w.all('SELECT id, parent_session_id AS parent FROM lesson_sessions ORDER BY completed_at').map((r) => [r.id, r.parent]), [['sA', null], ['sB', 'sA'], ['sC', 'sB']]);
    assert.equal(w.one("SELECT total_xp FROM users WHERE id='u1'")?.total_xp, 750); // three perfect lessons
  });

  it('a stale parent is refused and the answer names the real head, so the app can catch up', async () => {
    const w = await world();
    await playAndCommit(w, { n: 1, sid: 's1', at: T0 });
    const stale = await play(w, { n: 2, sid: 's2', at: T0 + H, parent: null }); // the app thinks nothing was committed yet
    const r = await commitLoose(w.repo, 'u1', stale, nowOf(stale));
    assert.ok(!r.ok && r.code === 'out_of_order' && r.details?.lastSessionId === 's1');
    // the same lesson, resent with the head the server just named, is accepted
    const fixed = { ...stale, parentSessionId: 's1' };
    assert.ok((await commitLoose(w.repo, 'u1', fixed, nowOf(fixed))).ok);
  });

  it('a committed session sent again is a duplicate, not out of order, even though the chain has moved on', async () => {
    const w = await world();
    const { c: first } = await playAndCommit(w, { n: 1, sid: 's1', at: T0 });
    await playAndCommit(w, { n: 2, sid: 's2', at: T0 + H });
    const again = await commitLoose(w.repo, 'u1', first, nowOf(first));
    assert.ok(again.ok && again.receipt.status === 'duplicate');
    assert.equal(w.count('lesson_sessions'), 2);
  });

  it('the order check comes before the state checks: a lesson played ahead of its predecessor is out of order, not locked', async () => {
    const w = await world();
    const a = await play(w, { n: 1, sid: 'sA', at: T0, parent: null });
    const b = await play(w, { n: 2, sid: 'sB', at: T0 + H, parent: 'sA' }); // lesson 2 is locked until sA is committed
    const r = await commitLoose(w.repo, 'u1', b, nowOf(b));
    assert.ok(!r.ok && r.code === 'out_of_order', 'a retryable condition must not be reported as a permanent one');
    assert.ok((await commitLoose(w.repo, 'u1', a, nowOf(a))).ok);
    assert.ok((await commitLoose(w.repo, 'u1', b, nowOf(b))).ok);
  });

  it('a rejected session never enters the chain', async () => {
    const w = await world();
    const bad = await play(w, { n: 1, sid: 's-bad', at: T0, policy: failTwice('id-candle') });
    const tampered = { ...bad, attempts: bad.attempts.slice(0, -2) };
    const r = await commitLoose(w.repo, 'u1', tampered, nowOf(bad));
    assert.ok(!r.ok && r.code === 'replay_failed');
    const next = await play(w, { n: 1, sid: 's-next', at: T0 + H }); // an online client still sees an empty chain
    assert.equal(next.parentSessionId, null);
    assert.ok((await commitLoose(w.repo, 'u1', next, nowOf(next))).ok);
    assert.equal(w.count('lesson_sessions'), 1);
  });

  it("each user has a chain of their own: u2's first session needs no parent although u1 has sessions", async () => {
    const w = await world();
    await playAndCommit(w, { n: 1, sid: 's1', at: T0 });
    await playAndCommit(w, { n: 1, sid: 't1', at: T0, userId: 'u2' });
    assert.deepEqual(w.all('SELECT id, user_id, parent_session_id AS parent FROM lesson_sessions ORDER BY id'), [
      { id: 's1', user_id: 'u1', parent: null },
      { id: 't1', user_id: 'u2', parent: null },
    ]);
  });

  it('a session cannot be its own parent, and the parent must be a valid id', async () => {
    const w = await world();
    const c = await play(w, { n: 1, sid: 's1', parent: null });
    const self = await commitLoose(w.repo, 'u1', { ...c, parentSessionId: 's1' }, nowOf(c));
    assert.ok(!self.ok && self.code === 'bad_request');
    const real = await commitSession(w.repo, 'u1', { ...c, sessionId: uuidOf('a'), parentSessionId: 'not-a-uuid' }, nowOf(c)); // default id check
    assert.ok(!real.ok && real.code === 'bad_request');
    assert.equal(w.count('lesson_sessions'), 0);
  });

  it('works end to end with UUIDs and the default id check, parent included', async () => {
    const w = await world(UUID_IDS);
    const first = await play(w, { n: 1, sid: uuidOf('session-1') });
    assert.equal(first.parentSessionId, null);
    assert.ok((await commitSession(w.repo, w.ids.user(1), first, nowOf(first))).ok);
    const second = await play(w, { n: 2, sid: uuidOf('session-2'), at: T0 + H });
    assert.equal(second.parentSessionId, first.sessionId);
    assert.ok((await commitSession(w.repo, w.ids.user(1), second, nowOf(second))).ok);
  });

  it('refuses to commit on top of a corrupt chain (two heads) instead of guessing', async () => {
    const user = { total_xp: 0, streak_count: 0, longest_streak: 0, last_active_date: null, time_zone: 'UTC' };
    const answer = (text: string) => (/FROM users/.test(text) ? [user] : /NOT EXISTS/.test(text) ? [{ id: 'x' }, { id: 'y' }] : []); // an unknown session id, two chain heads
    const pool = { async connect() { return { async query(text: string) { return { rows: answer(text) }; }, release() {} }; } };
    const w = await world();
    const c = await play(w, { n: 1, sid: 's1', parent: null });
    await assert.rejects(commitLoose(new PgRepo(pool), 'u1', c, nowOf(c)), /more than one head/);
  });
});

describe('collectMisspellings (pure)', () => {
  const at = (s: number) => `2026-10-04T10:00:${String(s).padStart(2, '0')}.000Z`;
  const attempt = (n: number, o: Partial<AttemptLog>): AttemptLog => ({
    n, itemId: 'L:w1', wordId: 'w1', origin: 'lesson', step: 'word', attemptNo: 1, input: 'x', distance: 2, verdict: 'major', usedPeek: false, at: at(n), ...o,
  });

  it('counts wrong word-step attempts (slips included) and nothing else', () => {
    const rows = collectMisspellings('u1', [
      attempt(1, { input: 'recieve' }),
      attempt(2, { input: 'receive', verdict: 'exact', distance: 0 }),
      attempt(3, { step: 'sentence', input: 'a wrong sentence' }),
      attempt(4, { input: 'receve', verdict: 'minor', distance: 1 }),
    ]);
    assert.deepEqual(rows.map((r) => [r.typed, r.occurrences]), [['recieve', 1], ['receve', 1]]);
    assert.deepEqual(collectMisspellings('u1', []), []);
    assert.deepEqual(collectMisspellings('u1', [attempt(1, { input: 'receive', verdict: 'exact', distance: 0 })]), []);
  });

  it('merges by word and normalized text, keeps the first and last sighting, never merges across words', () => {
    const rows = collectMisspellings('u1', [
      attempt(1, { input: 'Recieve' }),
      attempt(2, { input: '  recieve  ' }),
      attempt(3, { input: 'recieve', wordId: 'w2', itemId: 'L:w2' }),
      attempt(4, { input: 'RECIEVE' }),
    ]);
    assert.deepEqual(rows, [
      { userId: 'u1', wordId: 'w1', typed: 'recieve', occurrences: 3, firstSeenAt: at(1), lastSeenAt: at(4) },
      { userId: 'u1', wordId: 'w2', typed: 'recieve', occurrences: 1, firstSeenAt: at(3), lastSeenAt: at(3) },
    ]);
  });
});

describe('isUuid', () => {
  it('accepts UUIDs in either case and rejects everything else', () => {
    const u = uuidOf('x');
    assert.ok(isUuid(u) && isUuid(u.toUpperCase()));
    for (const bad of ['', 's1', u.replace(/-/g, ''), `${u}0`, ` ${u}`, '00000000-0000-0000-0000-00000000000g', 42, null, undefined]) {
      assert.equal(isUuid(bad), false, String(bad));
    }
  });
});
