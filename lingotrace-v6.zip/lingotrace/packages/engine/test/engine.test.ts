import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  applySummaryToStats,
  createRng as mulberry32,
  buildLessonQueue,
  currentPrompt,
  evaluateSentence,
  evaluateWord,
  levenshtein,
  normalizeSentence,
  peek,
  pickDispersedSlots,
  pickInjectedMistakes,
  sessionProgress,
  startSession,
  submit,
  summarize,
  toLessonItem,
} from '../src/index.ts';
import type { MistakeRecord, Prompt, Rng, SessionState, SubmitEvent, UserWordStat, WordItem } from '../src/index.ts';

// ─── fixtures & helpers ──────────────────────────────────────────────────────

const NOW = new Date('2026-10-04T10:00:00.000Z');

const LESSON_TEXTS = [
  'apple', 'bridge', 'candle', 'dolphin', 'engine', 'forest', 'garden', 'harbor', 'island', 'jungle',
  'kitchen', 'lantern', 'marble', 'napkin', 'orange', 'pillow', 'quarter', 'rabbit', 'saddle', 'tunnel',
];

const word = (text: string, errorWeight = 0): WordItem => ({
  wordId: `id-${text}`,
  wordText: text,
  sentenceContext: `I can see the ${text} today.`,
  errorWeight,
});
const lessonWords = LESSON_TEXTS.map((t) => word(t));

const mistake = (text: string, errorWeight: number, dueSeq: number, lastFailedAt: string | null = '2026-09-01T00:00:00.000Z'): MistakeRecord => ({
  word: word(text, errorWeight),
  dueSeq,
  lastFailedAt,
});

const stat = (text: string, errorWeight: number, dueSeq: number): UserWordStat => ({
  wordId: `id-${text}`,
  errorWeight,
  status: 'active',
  dueSeq,
  lifetimeFailures: errorWeight,
  lastFailedAt: '2026-09-01T00:00:00.000Z',
  lastReviewedAt: null,
});

const dropLast = (t: string): string => t.slice(0, -1); // exactly 1 edit  → minor
const garble = (t: string): string => 'zz' + t.slice(2); // exactly 2 edits → major

const newSession = (history: MistakeRecord[] = [], lessonSeq = 5, rng: Rng = mulberry32(1)): SessionState =>
  startSession({ sessionId: 's-1', lessonSeq, queue: buildLessonQueue({ lessonWords, history, lessonSeq, rng }) });

type Answer = string | { text: string; peek: true };
type Policy = (p: Prompt, attemptOnStep: number) => Answer;

/** Drives a session to completion with a scripted "user". `rng` decides the 2-or-3 re-queue gap. */
function play(initial: SessionState, policy: Policy, rng: Rng = () => 0, maxSubmits = 2000) {
  let state = initial;
  const events: SubmitEvent[] = [];
  const order: string[] = [];
  let lastKey = '';
  let attempt = 0;
  for (let i = 0; i < maxSubmits; i++) {
    const p = currentPrompt(state);
    if (!p) break;
    if (order[order.length - 1] !== p.itemId) order.push(p.itemId);
    const key = `${p.itemId}/${p.step}`;
    attempt = key === lastKey ? attempt + 1 : 1;
    lastKey = key;
    const answer = policy(p, attempt);
    if (typeof answer !== 'string') state = peek(state);
    const res = submit(state, typeof answer === 'string' ? answer : answer.text, { now: NOW, rng });
    state = res.state;
    events.push(res.event);
  }
  assert.equal(state.phase, 'completed', 'session did not finish within the submit budget');
  return { state, events, order, summary: summarize(state) };
}

const perfect: Policy = (p) => p.text;
const outcomeOf = (s: ReturnType<typeof summarize>, wordId: string) => s.outcomes.find((o) => o.wordId === wordId)?.result;

// ─── 1. spelling evaluation ──────────────────────────────────────────────────

describe('spelling evaluation (Levenshtein)', () => {
  it('computes classic edit distances', () => {
    assert.equal(levenshtein('kitten', 'sitting'), 3);
    assert.equal(levenshtein('', 'abc'), 3);
    assert.equal(levenshtein('abc', 'abc'), 0);
    assert.equal(levenshtein('flaw', 'lawn'), 2);
  });

  it('case differences are a 100% perfect match', () => {
    const e = evaluateWord('beautiful', 'Beautiful');
    assert.equal(e.verdict, 'exact');
    assert.equal(e.distance, 0);
    assert.equal(evaluateWord('  BEAUTIFUL ', 'Beautiful').verdict, 'exact');
  });

  it('one missing / extra / wrong letter is a MINOR slip', () => {
    assert.equal(evaluateWord('beatiful', 'beautiful').verdict, 'minor'); // missing u
    assert.equal(evaluateWord('swimmingg', 'swimming').verdict, 'minor'); // extra g
    assert.equal(evaluateWord('beautifal', 'beautiful').verdict, 'minor'); // wrong letter
  });

  it('brief example check: "beautful" is only ONE edit from "beautiful" → minor by the stated rule', () => {
    assert.equal(levenshtein('beautful', 'beautiful'), 1);
    assert.equal(evaluateWord('beautful', 'beautiful').verdict, 'minor');
  });

  it('two or more edits are MAJOR (swapped letters cost 2 in pure Levenshtein)', () => {
    assert.equal(evaluateWord('butiful', 'beautiful').verdict, 'major');
    assert.equal(evaluateWord('recieve', 'receive').verdict, 'major');
    assert.equal(evaluateWord('', 'cat').verdict, 'major');
    assert.equal(evaluateWord('', 'a').verdict, 'major'); // blank is never a "slip", even for 1-letter words
  });

  it('curly apostrophes from phone keyboards match straight ones', () => {
    assert.equal(evaluateWord('don\u2019t', "don't").verdict, 'exact');
  });
});

describe('sentence validation (forgiving)', () => {
  const target = 'The weather today is beautiful.';

  it('ignores end punctuation and case — omitting the period is NOT a failure', () => {
    assert.equal(evaluateSentence('the weather today is beautiful', target).verdict, 'exact');
    assert.equal(evaluateSentence('The weather today is beautiful!!', target).verdict, 'exact');
    assert.equal(evaluateSentence('THE WEATHER TODAY IS BEAUTIFUL?', target).verdict, 'exact');
  });

  it('ignores commas anywhere', () => {
    assert.equal(evaluateSentence('Yes I do thank you', 'Yes, I do, thank you.').verdict, 'exact');
    assert.equal(evaluateSentence('Yes,I do,thank you', 'Yes, I do, thank you.').verdict, 'exact');
  });

  it('keeps apostrophes and hyphens (they are spelling)', () => {
    assert.equal(normalizeSentence('Don\u2019t stop \u2014 go!'), "don't stop go");
    assert.equal(normalizeSentence('A well-known fact.'), 'a well-known fact');
  });

  it('a real typo still fails', () => {
    assert.notEqual(evaluateSentence('The wether today is beautiful.', target).verdict, 'exact');
  });
});

// ─── 2. lesson queue building (delayed review injection) ─────────────────────

describe('injection selection', () => {
  const history = [
    mistake('umbrella', 2, 4),
    mistake('volcano', 1, 5),
    mistake('window', 3, 9), // not due yet at lesson 6
    mistake('apple', 5, 1), // already taught by this lesson → excluded
    mistake('yogurt', 1, 5, '2026-08-01T00:00:00.000Z'), // same weight+due as volcano, older failure → wins the tie
  ];

  it('only due words, never words of this lesson, max 2, heaviest first, ties by due then age', () => {
    const picked = pickInjectedMistakes(history, 6, new Set(['id-apple']));
    assert.deepEqual(picked.map((m) => m.word.wordText), ['umbrella', 'yogurt']);
  });

  it('nothing due → nothing injected', () => {
    assert.deepEqual(pickInjectedMistakes(history, 0, new Set()), []);
    assert.equal(buildLessonQueue({ lessonWords, history: [], lessonSeq: 3 }).length, 20);
  });

  it('a lesson needs exactly 20 words and no duplicates', () => {
    assert.throws(() => buildLessonQueue({ lessonWords: lessonWords.slice(0, 19), history: [], lessonSeq: 1 }), RangeError);
    const dup = [...lessonWords.slice(0, 19), lessonWords[0] as WordItem];
    assert.throws(() => buildLessonQueue({ lessonWords: dup, history: [], lessonSeq: 1 }), /duplicate/);
  });
});

describe('dispersal', () => {
  it('edge sizes', () => {
    assert.deepEqual(pickDispersedSlots(22, 0, () => 0), []);
    assert.deepEqual(pickDispersedSlots(3, 1, () => 0), [1]);
    assert.deepEqual(pickDispersedSlots(5, 2, () => 0), [1, 3]);
    assert.throws(() => pickDispersedSlots(4, 2, () => 0), RangeError);
  });

  it('2,000 random placements: ≤2 injected, never adjacent, dispersed, standalone-only, base order intact', () => {
    const history = [mistake('umbrella', 2, 4), mistake('volcano', 1, 5), mistake('window', 1, 5)];
    for (let seed = 1; seed <= 2000; seed++) {
      const q = buildLessonQueue({ lessonWords, history, lessonSeq: 8, rng: mulberry32(seed) });
      assert.equal(q.length, 22);
      const at = q.flatMap((it, i) => (it.source === 'injected' ? [i] : []));
      assert.equal(at.length, 2, 'cap of 2 injected words');
      const [a, b] = at as [number, number];
      assert.ok(b - a >= 3, `injected words too close (seed ${seed}: ${a}, ${b})`);
      assert.ok(a >= 1 && b <= 20, 'never first or last');
      assert.deepEqual(
        q.filter((it) => it.source === 'lesson').map((it) => it.word.wordId),
        lessonWords.map((w) => w.wordId),
      );
      for (const it of q) assert.deepEqual(it.steps, it.source === 'lesson' ? ['word', 'sentence'] : ['word']);
    }
  });
});

// ─── 3. session flow ─────────────────────────────────────────────────────────

describe('session: gameplay flow', () => {
  it('perfect run: 20 × 10 XP + 50 bonus, word then sentence for every word, nothing to carry over', () => {
    const { summary, state } = play(newSession(), perfect);
    assert.equal(summary.xp.total, 250);
    assert.deepEqual([summary.xp.firstTry, summary.xp.recovered, summary.xp.lessonBonus], [200, 0, 50]);
    assert.equal(summary.outcomes.length, 20);
    assert.ok(summary.outcomes.every((o) => o.result === 'clean'));
    assert.equal(summary.attempts.length, 40);
    assert.deepEqual(sessionProgress(state), { done: 20, total: 20 });
    assert.deepEqual(applySummaryToStats(summary, [], NOW), []);
  });

  it('minor slip: re-type to pass, sentence still follows, NOT re-queued, NOT carried over, +5 XP', () => {
    const { summary, events } = play(newSession(), (p, n) =>
      p.step === 'word' && p.wordId === 'id-candle' && n === 1 ? dropLast(p.text) : p.text,
    );
    assert.equal(outcomeOf(summary, 'id-candle'), 'minor_recovered');
    assert.ok(events.some((e) => e.kind === 'retype' && e.reason === 'minor_slip'));
    assert.equal(summary.attempts.filter((a) => a.origin === 'immediate_review').length, 0);
    assert.equal(summary.attempts.filter((a) => a.wordId === 'id-candle').length, 3); // word✗ word✓ sentence✓
    assert.deepEqual([summary.xp.firstTry, summary.xp.recovered, summary.xp.total], [190, 5, 245]);
    assert.deepEqual(applySummaryToStats(summary, [], NOW), []);
  });

  it('major mistake: sentence skipped, re-queued standalone after exactly 2 items; passing the review → +5, nothing carried over', () => {
    const { summary, order } = play(newSession(), (p) => (p.itemId === 'L:id-candle' ? garble(p.text) : p.text), () => 0);
    assert.equal(order.indexOf('R:id-candle') - order.indexOf('L:id-candle'), 3); // 2 items in between
    assert.equal(outcomeOf(summary, 'id-candle'), 'review_recovered');
    const candle = summary.attempts.filter((a) => a.wordId === 'id-candle');
    assert.deepEqual(candle.map((a) => [a.origin, a.step, a.verdict]), [
      ['lesson', 'word', 'major'],
      ['immediate_review', 'word', 'exact'],
    ]); // no sentence step at all
    assert.deepEqual([summary.xp.firstTry, summary.xp.recovered, summary.xp.total], [190, 5, 245]);
    assert.deepEqual(applySummaryToStats(summary, [], NOW), []);
  });

  it('the re-queue gap is 2 or 3 depending on the rng', () => {
    const { order } = play(newSession(), (p) => (p.itemId === 'L:id-candle' ? garble(p.text) : p.text), () => 0.99);
    assert.equal(order.indexOf('R:id-candle') - order.indexOf('L:id-candle'), 4); // 3 items in between
  });

  it('failing the review too = "failed twice": error_weight + 1, due 2 lessons later, no third attempt', () => {
    const { summary, events } = play(newSession([], 5), (p) => (p.wordId === 'id-candle' ? garble(p.text) : p.text));
    assert.equal(outcomeOf(summary, 'id-candle'), 'failed_twice');
    assert.equal(summary.attempts.filter((a) => a.wordId === 'id-candle').length, 2);
    const failed = events.filter((e) => e.kind === 'failed');
    assert.deepEqual(failed.map((e) => (e.kind === 'failed' ? e.requeueAfter : -1)), [2, null]);
    assert.equal(summary.xp.total, 190 + 50);
    assert.deepEqual(applySummaryToStats(summary, [], NOW), [
      {
        wordId: 'id-candle',
        errorWeight: 1,
        status: 'active',
        dueSeq: 7, // failed in lesson 5 → mixed into lesson 7
        lifetimeFailures: 1,
        lastFailedAt: NOW.toISOString(),
        lastReviewedAt: NOW.toISOString(),
      },
    ]);
  });

  it('"fails the word multiple times": a second non-exact attempt after a minor slip counts as major', () => {
    for (const second of [dropLast, garble]) {
      const { summary, events } = play(newSession(), (p, n) => {
        if (p.itemId === 'L:id-candle') return n === 1 ? dropLast(p.text) : second(p.text);
        return p.text;
      });
      assert.deepEqual(
        events.filter((e) => e.kind !== 'correct').map((e) => e.kind),
        ['retype', 'failed'],
      );
      assert.equal(outcomeOf(summary, 'id-candle'), 'review_recovered');
    }
  });

  it('failing the very last item appends its review at the end (nothing to put it behind)', () => {
    const queue = lessonWords.slice(0, 3).map(toLessonItem);
    const s0 = startSession({ sessionId: 's-x', lessonSeq: 1, queue });
    const { order, events } = play(s0, (p) => (p.itemId === 'L:id-candle' ? garble(p.text) : p.text));
    assert.deepEqual(order, ['L:id-apple', 'L:id-bridge', 'L:id-candle', 'R:id-candle']);
    const failed = events.find((e) => e.kind === 'failed');
    assert.equal(failed?.kind === 'failed' && failed.requeueAfter, 0);
  });

  it('peeking at the spelling downgrades a first-try success to the +5 tier', () => {
    const { summary } = play(newSession(), (p) => (p.itemId === 'L:id-apple' && p.step === 'word' ? { text: p.text, peek: true } : p.text));
    assert.equal(outcomeOf(summary, 'id-apple'), 'assisted');
    assert.deepEqual([summary.xp.firstTry, summary.xp.recovered], [190, 5]);
  });

  it('a wrong sentence is not repeated: the lesson moves on — no XP, no SRS impact', () => {
    const { summary, events } = play(newSession(), (p) => (p.step === 'sentence' && p.wordId === 'id-bridge' ? p.text + ' extra' : p.text));
    assert.equal(events.filter((e) => e.kind === 'sentence_missed').length, 1);
    assert.equal(summary.attempts.filter((a) => a.wordId === 'id-bridge' && a.step === 'sentence').length, 1);
    assert.equal(outcomeOf(summary, 'id-bridge'), 'clean');
    assert.equal(summary.xp.total, 250);
  });

  it('submitting to a finished session throws', () => {
    const { state } = play(newSession(), perfect);
    assert.throws(() => submit(state, 'x', { now: NOW }), /completed/);
  });

  it('never mutates the state it receives (safe for React / Redux / Zustand)', () => {
    const freeze = <T,>(o: T): T => {
      if (o !== null && typeof o === 'object' && !Object.isFrozen(o)) {
        Object.freeze(o);
        for (const v of Object.values(o as Record<string, unknown>)) freeze(v);
      }
      return o;
    };
    let state = freeze(newSession());
    for (let i = 0; i < 200 && state.phase !== 'completed'; i++) {
      const p = currentPrompt(state) as Prompt;
      const text = p.wordId === 'id-candle' && !p.isReview ? garble(p.text) : p.text;
      state = freeze(submit(freeze(peek(state)), text, { now: NOW, rng: () => 0 }).state);
    }
    assert.equal(state.phase, 'completed');
  });
});

// ─── 4. injected words inside a session + rotation updates ───────────────────

describe('future-lesson injection end-to-end', () => {
  const history = [mistake('umbrella', 2, 4), mistake('volcano', 1, 5), mistake('window', 3, 9), mistake('apple', 5, 1)];
  const previous = [stat('umbrella', 2, 4), stat('volcano', 1, 5)];
  const session = () => newSession(history, 6, mulberry32(7));

  it('2 injected words, standalone only, worth +5 each when clean', () => {
    const q = session().queue;
    assert.deepEqual(q.filter((i) => i.source === 'injected').map((i) => i.itemId), ['I:id-umbrella', 'I:id-volcano']);
    const { summary } = play(session(), perfect);
    assert.equal(summary.attempts.length, 42); // 40 + two word-only attempts
    assert.ok(summary.attempts.filter((a) => a.origin === 'injected').every((a) => a.step === 'word'));
    assert.deepEqual([summary.xp.firstTry, summary.xp.recovered, summary.xp.total], [200, 10, 260]);
  });

  it('clean review lowers error_weight; at 0 the word is mastered and leaves the rotation', () => {
    const { summary } = play(session(), perfect);
    const updates = applySummaryToStats(summary, previous, NOW);
    assert.deepEqual(updates.find((u) => u.wordId === 'id-umbrella'), { ...stat('umbrella', 1, 8), lifetimeFailures: 2, lastReviewedAt: NOW.toISOString() });
    const volcano = updates.find((u) => u.wordId === 'id-volcano');
    assert.equal(volcano?.status, 'mastered');
    assert.equal(volcano?.errorWeight, 0);
    assert.equal(volcano?.dueSeq, null);
  });

  it('failing an injected word twice raises its weight and reschedules it', () => {
    const { summary } = play(session(), (p) => (p.wordId === 'id-umbrella' ? garble(p.text) : p.text));
    const u = applySummaryToStats(summary, previous, NOW).find((x) => x.wordId === 'id-umbrella');
    assert.deepEqual([u?.errorWeight, u?.status, u?.dueSeq, u?.lifetimeFailures], [3, 'active', 8, 3]);
  });

  it('failing first but passing the immediate review keeps the weight and reschedules', () => {
    const { summary } = play(session(), (p) => (p.wordId === 'id-umbrella' && !p.isReview ? garble(p.text) : p.text));
    assert.equal(outcomeOf(summary, 'id-umbrella'), 'review_recovered');
    const u = applySummaryToStats(summary, previous, NOW).find((x) => x.wordId === 'id-umbrella');
    assert.deepEqual([u?.errorWeight, u?.status, u?.dueSeq], [2, 'active', 8]);
  });

  it('replays award no XP and never touch the rotation', () => {
    const s0 = startSession({ sessionId: 's-r', lessonSeq: 5, mode: 'replay', queue: buildLessonQueue({ lessonWords, history: [], lessonSeq: 5 }) });
    const { summary, events } = play(s0, (p) => (p.wordId === 'id-candle' ? garble(p.text) : p.text));
    assert.equal(summary.xp.total, 0);
    assert.ok(events.every((e) => e.kind !== 'correct' || e.xp === 0));
    assert.equal(outcomeOf(summary, 'id-candle'), 'failed_twice');
    assert.deepEqual(applySummaryToStats(summary, [], NOW), []);
  });
});

// ─── 5. fuzz: random users must never break structural rules ─────────────────

describe('fuzz: 400 random sessions', () => {
  it('always terminate; XP matches outcomes; rotation rows satisfy the DB CHECK constraint', () => {
    const rng = mulberry32(20261004);
    const pool = ['umbrella', 'volcano', 'window', 'yogurt', 'zebra', 'anchor'];

    for (let run = 0; run < 400; run++) {
      const lessonSeq = 10;
      const history = pool.filter(() => rng() < 0.6).map((t) => mistake(t, 1 + Math.floor(rng() * 3), 1 + Math.floor(rng() * 12)));
      const previous = history.map((m) => stat(m.word.wordText, m.word.errorWeight, m.dueSeq));
      const queue = buildLessonQueue({ lessonWords, history, lessonSeq, rng });

      const injectedAt = queue.flatMap((it, i) => (it.source === 'injected' ? [i] : []));
      assert.ok(injectedAt.length <= 2);
      assert.ok(injectedAt.every((v, i) => i === 0 || v - (injectedAt[i - 1] as number) >= 2), 'back-to-back injection');

      const { summary, state } = play(
        startSession({ sessionId: `fuzz-${run}`, lessonSeq, queue }),
        (p) => {
          const r = rng();
          if (r < 0.1) return { text: p.text, peek: true };
          if (r < 0.6) return p.text;
          if (p.step === 'sentence') return p.text + ' extra';
          return r < 0.8 ? dropLast(p.text) : garble(p.text);
        },
        rng,
      );

      // structural rules
      assert.ok(summary.attempts.every((a) => a.origin === 'lesson' || a.step === 'word'), 'sentence step only for new words');
      const itemsPerWord = new Map<string, Set<string>>();
      for (const a of summary.attempts) itemsPerWord.set(a.wordId, (itemsPerWord.get(a.wordId) ?? new Set()).add(a.itemId));
      assert.ok([...itemsPerWord.values()].every((s) => s.size <= 2), 'a word is presented at most twice');
      assert.equal(summary.outcomes.length, queue.length);
      assert.ok(state.itemsDone <= 2 * queue.length);

      // XP accounting equals what the outcomes imply
      const expected =
        summary.outcomes.reduce((sum, o) => sum + (o.result === 'failed_twice' ? 0 : o.result === 'clean' && o.source === 'lesson' ? 10 : 5), 0) + 50;
      assert.equal(summary.xp.total, expected);

      // rotation rows obey the schema's CHECK constraint
      const updates = applySummaryToStats(summary, previous, NOW);
      for (const o of summary.outcomes.filter((x) => x.result === 'failed_twice')) {
        assert.ok(updates.some((u) => u.wordId === o.wordId), 'every double failure must be scheduled');
      }
      for (const u of updates) {
        if (u.status === 'active') {
          assert.ok(u.errorWeight >= 1 && u.dueSeq !== null && u.dueSeq > lessonSeq);
        } else {
          assert.ok(u.errorWeight === 0 && u.dueSeq === null);
        }
      }
    }
  });
});
