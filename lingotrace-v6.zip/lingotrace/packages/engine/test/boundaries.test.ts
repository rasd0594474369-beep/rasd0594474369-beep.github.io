// Architecture guard (HANDOFF section 4, decision 1).
// The app bundles `@lingotrace/engine`, so that entry must stay pure: it may not reach ./server/, Node built-ins
// or npm packages. The server entry is dependency-free too (PgRepo talks to a SqlPool interface, not to `pg`).
// These tests walk the real import graph of the source files.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync } from 'node:fs';
import { dirname, join, relative, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

const SRC = fileURLToPath(new URL('../src/', import.meta.url));
const CLIENT_ENTRY = join(SRC, 'index.ts');
const SERVER_ENTRY = join(SRC, 'server', 'index.ts');

const stripComments = (code: string): string => code.replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '');
/** Module specifiers of `import x from 'y'`, `export * from 'y'`, `import 'y'` and `import('y')`. */
const specifiersOf = (file: string): string[] =>
  [...stripComments(readFileSync(file, 'utf8')).matchAll(/(?:\bfrom|\bimport)\s*\(?\s*['"]([^'"]+)['"]/g)].map((m) => m[1]!);

function closure(entry: string): { files: string[]; external: string[] } {
  const seen = new Set<string>();
  const external: string[] = [];
  const todo = [entry];
  for (let file = todo.pop(); file !== undefined; file = todo.pop()) {
    if (seen.has(file)) continue;
    seen.add(file);
    for (const spec of specifiersOf(file)) {
      if (spec.startsWith('.')) todo.push(resolve(dirname(file), spec));
      else external.push(`${relative(SRC, file)} imports "${spec}"`);
    }
  }
  return { files: [...seen].map((f) => relative(SRC, f)).sort(), external };
}

describe('package boundaries', () => {
  it('the client entry reaches no server code, no Node built-in and no npm package', () => {
    const client = closure(CLIENT_ENTRY);
    assert.deepEqual(client.external, []);
    assert.deepEqual(client.files.filter((f) => f.split(sep)[0] === 'server'), []);
    assert.ok(client.files.includes('commit-request.ts'), 'the payload type and helper belong to the client entry');
  });

  it('the server entry has no external dependencies either, and adds the verification code', () => {
    const server = closure(SERVER_ENTRY);
    assert.deepEqual(server.external, []);
    assert.ok(server.files.includes(join('server', 'commit.ts')) && server.files.includes(join('server', 'pg-repo.ts')));
  });

  it('every source file is exported by exactly one entry (nothing forgotten, nothing exported twice)', () => {
    const exportedBy = (entry: string) => specifiersOf(entry).map((s) => relative(SRC, resolve(dirname(entry), s)));
    const modules = readdirSync(SRC, { recursive: true })
      .map(String)
      .filter((f) => f.endsWith('.ts') && f !== 'index.ts' && f !== join('server', 'index.ts'))
      .sort();
    assert.deepEqual([...exportedBy(CLIENT_ENTRY), ...exportedBy(SERVER_ENTRY)].sort(), modules);
  });
});
