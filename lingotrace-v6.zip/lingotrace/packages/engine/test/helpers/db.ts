// Test harness for the commit service.
//
// It runs the REAL Supabase migration (supabase/migrations/*_core_schema.sql), translated to SQLite by the
// schema twin (supabase/tests/twin/translate.ts), and wraps it in a node-postgres-shaped pool so the
// unmodified PgRepo SQL executes against it.
//
// This is a TWIN, not PostgreSQL: it proves wrong columns, constraints, upsert logic and transaction
// behaviour. It cannot prove PostgreSQL-only behaviour (RLS, parameter typing, DateStyle ...);
// that is the job of the real-database contract script (HANDOFF phase 2).
import { createHash } from 'node:crypto';
import { readFileSync, readdirSync } from 'node:fs';
import { openTwin } from '../../../../supabase/tests/twin/translate.ts';
import type { Db } from '../../../../supabase/tests/twin/translate.ts';

export type { Db };

export const WORDS = ('apple bridge candle dolphin engine forest garden harbor island jungle kitchen lantern marble napkin orange pillow quarter rabbit saddle tunnel ' +
  'balance blanket button camera carpet circle cotton desert dinner doctor flower guitar hammer jacket ladder magnet mirror pencil pocket ribbon ' +
  'shadow silver spider sponge summer ticket travel valley velvet violin walnut window winter yellow zipper basket bottle bucket castle cherry').split(' ');
export const sentenceOf = (t: string) => `I can see the ${t} today.`;

/** How the fixture rows are named. Readable ids keep assertions short; UUID ids exercise the production id check. */
export interface Ids {
  user: (n: number) => string;
  lesson: (n: number) => string;
  word: (text: string) => string;
}

export const READABLE_IDS: Ids = { user: (n) => `u${n}`, lesson: (n) => `lesson-${n}`, word: (t) => `id-${t}` };

/** Deterministic RFC-4122 version-5 style UUID derived from a label. */
export function uuidOf(label: string): string {
  const h = createHash('sha1').update(label).digest('hex');
  const variant = ((parseInt(h.charAt(16), 16) & 0x3) | 0x8).toString(16);
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-5${h.slice(13, 16)}-${variant}${h.slice(17, 20)}-${h.slice(20, 32)}`;
}
export const UUID_IDS: Ids = { user: (n) => uuidOf(`user-${n}`), lesson: (n) => uuidOf(`lesson-${n}`), word: (t) => uuidOf(`word-${t}`) };

/** The migrations that define tables, columns and indexes (the others only add functions, policies and grants). */
const SCHEMA_MIGRATIONS = ['_core_schema.sql', '_session_chain.sql'];

export async function openDb(): Promise<Db> {
  const dir = new URL('../../../../supabase/migrations/', import.meta.url);
  const names = readdirSync(dir).sort();
  const sql = SCHEMA_MIGRATIONS.map((suffix) => {
    const file = names.find((f) => f.endsWith(suffix));
    if (!file) throw new Error(`${suffix} not found in supabase/migrations`);
    return readFileSync(new URL(file, dir), 'utf8');
  });
  return openTwin(sql.join(';\n'));
}

/** 2 users, lessons 1..3 of level A1 (20 words each), all published. */
export function seedWorld(db: Db, ids: Ids = READABLE_IDS): void {
  db.exec(`INSERT INTO users (id, display_name) VALUES ('${ids.user(1)}', 'Sara'), ('${ids.user(2)}', 'Omar')`);
  const w = db.prepare('INSERT INTO vocabulary_bank (id, word_text, sentence_context) VALUES (?1, ?2, ?3)');
  for (const t of WORDS) w.run(ids.word(t), t, sentenceOf(t));
  for (let n = 1; n <= 3; n++) {
    db.prepare("INSERT INTO lessons (id, level_code, lesson_number, global_seq, is_published) VALUES (?1, 'A1', ?2, ?2, 1)").run(ids.lesson(n), n);
    WORDS.slice((n - 1) * 20, n * 20).forEach((t, i) =>
      db.prepare('INSERT INTO lesson_words (lesson_id, position, word_id) VALUES (?1, ?2, ?3)').run(ids.lesson(n), i + 1, ids.word(t)),
    );
  }
}

type Row = Record<string, unknown>;
export interface Hooks { beforeQuery?: (text: string) => void }

/**
 * Minimal node-postgres-shaped pool over SQLite:
 * $n → ?n, FOR UPDATE stripped, LEAST/GREATEST → scalar MIN/MAX, booleans → 0/1.
 */
export function sqlitePool(db: Db, hooks: Hooks = {}) {
  const client = {
    async query(text: string, values: unknown[] = []): Promise<{ rows: Row[] }> {
      hooks.beforeQuery?.(text);
      const t = text.trim();
      if (/^(BEGIN|COMMIT|ROLLBACK)\b/i.test(t)) {
        db.exec(t);
        return { rows: [] };
      }
      const sql = t
        .replace(/\$(\d+)/g, '?$1')
        .replace(/\sFOR UPDATE\b/i, '')
        .replace(/\bLEAST\(/g, 'MIN(')
        .replace(/\bGREATEST\(/g, 'MAX(');
      const params = values.map((v) => (typeof v === 'boolean' ? (v ? 1 : 0) : v === undefined ? null : v));
      const stmt = db.prepare(sql);
      if (/^(SELECT|WITH)\b/i.test(sql)) return { rows: stmt.all(...params) };
      stmt.run(...params);
      return { rows: [] };
    },
    release() {},
  };
  return { connect: async () => client };
}
