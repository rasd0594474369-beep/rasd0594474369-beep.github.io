import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { beginSession, currentPrompt, newSeed, peek, replaySession, submit, summarize } from '../src/index.ts';
import type { ClaimedAttempt, MistakeRecord, Prompt, SessionSetup, WordItem } from '../src/index.ts';

const TEXTS = ['apple','bridge','candle','dolphin','engine','forest','garden','harbor','island','jungle','kitchen','lantern','marble','napkin','orange','pillow','quarter','rabbit','saddle','tunnel'];
const word = (t: string, w = 0): WordItem => ({ wordId: `id-${t}`, wordText: t, sentenceContext: `I can see the ${t} today.`, errorWeight: w });
const lessonWords = TEXTS.map((t) => word(t));
const mistake = (t: string, w: number, due: number): MistakeRecord => ({ word: word(t, w), dueSeq: due, lastFailedAt: '2026-09-01T00:00:00.000Z' });
const garble = (t: string) => 'zz' + t.slice(2);

const setup = (over: Partial<SessionSetup> = {}): SessionSetup => ({
  sessionId: 's1', lessonSeq: 6, mode: 'first_run', seed: 12345, lessonWords,
  history: [mistake('umbrella', 2, 4), mistake('volcano', 1, 5)], ...over,
});

/** A client playing honestly with the shared engine; returns what it would send. */
function clientPlay(s: SessionSetup, policy: (p: Prompt, n: number) => string | { text: string; peek: true }) {
  let { state, rng } = beginSession(s);
  const attempts: ClaimedAttempt[] = [];
  let clock = Date.parse('2026-10-04T10:00:00.000Z'), key = '', n = 0;
  while (state.phase !== 'completed') {
    const p = currentPrompt(state)!;
    n = key === `${p.itemId}/${p.step}` ? n + 1 : 1; key = `${p.itemId}/${p.step}`;
    const a = policy(p, n);
    const peeked = typeof a !== 'string';
    if (peeked) state = peek(state);
    clock += 2000;
    const text = typeof a === 'string' ? a : a.text;
    attempts.push({ itemId: p.itemId, step: p.step, input: text, usedPeek: state.peeked, at: new Date(clock).toISOString() });
    state = submit(state, text, { now: new Date(clock), rng }).state;
  }
  return { state, attempts, summary: summarize(state) };
}

describe('deterministic replay', () => {
  it('a server replay reproduces the client session exactly (queue, outcomes, XP, log)', () => {
    const noisy = (p: Prompt, n: number) => (p.wordId === 'id-candle' && !p.isReview ? garble(p.text) : p.wordId === 'id-engine' && p.step === 'word' && n === 1 ? p.text.slice(0, -1) : p.text);
    const c = clientPlay(setup(), noisy);
    const r = replaySession(setup(), c.attempts);
    assert.ok(r.ok);
    if (r.ok) {
      assert.deepEqual(r.summary, c.summary);
      assert.equal(r.summary.xp.total, c.summary.xp.total);
    }
  });

  it('holds for 200 random seeds with failures, peeks and re-queues', () => {
    for (let i = 0; i < 200; i++) {
      const seed = newSeed();
      let k = 0;
      const policy = (p: Prompt) => { k++; return k % 7 === 0 ? garble(p.text) : k % 11 === 0 ? { text: p.text, peek: true as const } : p.text; };
      const c = clientPlay(setup({ seed }), policy);
      const r = replaySession(setup({ seed }), c.attempts);
      assert.ok(r.ok, `seed ${seed}: ${r.ok ? '' : r.reason}`);
      if (r.ok) assert.deepEqual(r.summary, c.summary);
    }
  });

  it('rejects a log that does not follow the queue (swapped items)', () => {
    const c = clientPlay(setup(), (p) => p.text);
    const bad = [...c.attempts];
    [bad[0], bad[2]] = [bad[2]!, bad[0]!];
    const r = replaySession(setup(), bad);
    assert.ok(!r.ok && /expected/.test(r.reason));
  });

  it('rejects a log with an attempt edited to "fix" a failure (the story no longer adds up)', () => {
    const c = clientPlay(setup(), (p) => (p.wordId === 'id-candle' && !p.isReview ? garble(p.text) : p.text));
    const bad = c.attempts.map((a) => (a.itemId === 'L:id-candle' ? { ...a, input: 'candle' } : a));
    const r = replaySession(setup(), bad);
    assert.ok(!r.ok);
  });

  it('rejects unfinished logs and extra attempts after the end', () => {
    const c = clientPlay(setup(), (p) => p.text);
    assert.ok(!replaySession(setup(), c.attempts.slice(0, -1)).ok);
    const extra = [...c.attempts, c.attempts[0]!];
    const r = replaySession(setup(), extra);
    assert.ok(!r.ok && /already finished/.test(r.reason));
  });

  it('a wrong seed can never produce a DIFFERENT accepted outcome (accepted ⇒ identical summary, else rejected)', () => {
    const noisy = (p: Prompt) => (p.wordId === 'id-candle' && !p.isReview ? garble(p.text) : p.text);
    let rejected = 0;
    for (let i = 0; i < 100; i++) {
      const c = clientPlay(setup({ seed: 1000 + i }), noisy);
      const r = replaySession(setup({ seed: 5000 + i }), c.attempts);
      if (r.ok) assert.deepEqual(r.summary, c.summary);
      else rejected++;
    }
    assert.ok(rejected > 0, 'the seed must actually influence the queue');
  });

  it('replay mode never injects, even if a rotation is supplied', () => {
    const { state } = beginSession(setup({ mode: 'replay' }));
    assert.ok(state.queue.every((q) => q.source === 'lesson'));
  });
});
