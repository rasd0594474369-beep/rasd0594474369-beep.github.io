import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { ENGINE_VERSION } from '../src/index.ts';
import type { SessionCommit } from '../src/index.ts';
import { PARSE_LIMITS, parseSessionCommit } from '../src/server/index.ts';

const U = (n: number) => `00000000-0000-4000-8000-${String(n).padStart(12, '0')}`;
const good = (): SessionCommit => ({
  engineVersion: ENGINE_VERSION,
  sessionId: U(1),
  parentSessionId: null,
  lessonId: U(2),
  mode: 'first_run',
  seed: 123456789,
  timeZone: 'Asia/Riyadh',
  startedAt: '2026-10-04T10:00:00.000Z',
  completedAt: '2026-10-04T10:05:00.000Z',
  injectedWordIds: [U(3)],
  attempts: [
    { itemId: `L:${U(4)}`, step: 'word', input: 'candle', usedPeek: false, at: '2026-10-04T10:00:02.000Z' },
    { itemId: `L:${U(4)}`, step: 'sentence', input: '', usedPeek: true, at: '2026-10-04T10:00:04.000Z' }, // a blank answer is allowed: the rules decide
  ],
});
/** The payload as it arrives: serialised and parsed, so it holds exactly what JSON can hold. */
const wire = (o: unknown): unknown => JSON.parse(JSON.stringify(o));
const escapeRegExp = (text: string) => text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); // the standard idiom
const rejects = (body: unknown, field: string) => {
  const r = parseSessionCommit(body);
  assert.ok(!r.ok, `${field}: should be refused`);
  if (!r.ok) assert.match(r.message, new RegExp(escapeRegExp(field)), r.message);
};

describe('parseSessionCommit', () => {
  it('accepts a valid payload unchanged, with or without a parent', () => {
    const r = parseSessionCommit(wire(good()));
    assert.ok(r.ok);
    if (r.ok) assert.deepEqual(r.value, good());
    const child = { ...good(), parentSessionId: U(9) };
    const c = parseSessionCommit(wire(child));
    assert.ok(c.ok && c.value.parentSessionId === U(9));
  });

  it('builds a clean object: unknown fields, verdicts and XP claims go no further', () => {
    const dirty = wire({
      ...good(), xpEarned: 9999, verdict: 'exact', isAdmin: true,
      attempts: good().attempts.map((a) => ({ ...a, verdict: 'exact', distance: 0, xp: 5 })),
    }) as Record<string, unknown>;
    const r = parseSessionCommit(JSON.parse(`${JSON.stringify(dirty).slice(0, -1)},"__proto__":{"polluted":true}}`));
    assert.ok(r.ok);
    if (r.ok) {
      assert.deepEqual(Object.keys(r.value).sort(), Object.keys(good()).sort());
      assert.deepEqual(Object.keys(r.value.attempts[0]!).sort(), ['at', 'input', 'itemId', 'step', 'usedPeek']);
      assert.equal(({} as Record<string, unknown>).polluted, undefined);
    }
  });

  it('refuses what is not an object', () => {
    for (const body of [null, undefined, [], 'text', 42, true]) rejects(body, 'JSON object');
  });

  it('refuses every missing required field, naming it', () => {
    for (const field of Object.keys(good())) {
      const body = wire(good()) as Record<string, unknown>;
      delete body[field];
      rejects(body, field);
    }
  });

  it('refuses wrong types and values, naming the field', () => {
    const cases: Array<[string, (b: Record<string, unknown>) => void]> = [
      ['engineVersion', (b) => (b.engineVersion = 1.5)],
      ['engineVersion', (b) => (b.engineVersion = '1')],
      ['sessionId', (b) => (b.sessionId = '')],
      ['sessionId', (b) => (b.sessionId = 7)],
      ['sessionId', (b) => (b.sessionId = 'x'.repeat(PARSE_LIMITS.idLength + 1))],
      ['parentSessionId', (b) => (b.parentSessionId = 5)],
      ['parentSessionId', (b) => (b.parentSessionId = '')],
      ['lessonId', (b) => (b.lessonId = null)],
      ['mode', (b) => (b.mode = 'practice')],
      ['seed', (b) => (b.seed = -1)],
      ['seed', (b) => (b.seed = 1.5)],
      ['seed', (b) => (b.seed = 4294967296)],
      ['seed', (b) => (b.seed = '5')],
      ['timeZone', (b) => (b.timeZone = '')],
      ['timeZone', (b) => (b.timeZone = 'x'.repeat(PARSE_LIMITS.timeZoneLength + 1))],
      ['startedAt', (b) => (b.startedAt = 123)],
      ['completedAt', (b) => (b.completedAt = 'x'.repeat(PARSE_LIMITS.timestampLength + 1))],
      ['injectedWordIds', (b) => (b.injectedWordIds = 'abc')],
      ['injectedWordIds', (b) => (b.injectedWordIds = Array.from({ length: PARSE_LIMITS.injectedWordIds + 1 }, (_, i) => U(i)))],
      ['injectedWordIds[1]', (b) => (b.injectedWordIds = [U(1), 2])],
      ['attempts', (b) => (b.attempts = {})],
      ['attempts', (b) => (b.attempts = [])],
      ['attempts', (b) => (b.attempts = Array.from({ length: PARSE_LIMITS.attempts + 1 }, () => good().attempts[0]))],
      ['attempts[0]', (b) => (b.attempts = [null])],
      ['attempts[1].step', (b) => ((b.attempts as Array<Record<string, unknown>>)[1]!.step = 'letter')],
      ['attempts[0].input', (b) => ((b.attempts as Array<Record<string, unknown>>)[0]!.input = 5)],
      ['attempts[0].input', (b) => ((b.attempts as Array<Record<string, unknown>>)[0]!.input = 'x'.repeat(PARSE_LIMITS.inputLength + 1))],
      ['attempts[0].usedPeek', (b) => ((b.attempts as Array<Record<string, unknown>>)[0]!.usedPeek = 'yes')],
      ['attempts[0].at', (b) => ((b.attempts as Array<Record<string, unknown>>)[0]!.at = '')],
      ['attempts[0].itemId', (b) => ((b.attempts as Array<Record<string, unknown>>)[0]!.itemId = undefined)],
    ];
    for (const [field, mutate] of cases) {
      const body = wire(good()) as Record<string, unknown>;
      mutate(body);
      rejects(body, field);
    }
  });

  it('accepts the sizes at the limit and refuses one more', () => {
    const at = (n: number) => ({ itemId: `L:${U(n)}`, step: 'word' as const, input: 'a', usedPeek: false, at: '2026-10-04T10:00:02.000Z' });
    const max = { ...good(), attempts: Array.from({ length: PARSE_LIMITS.attempts }, (_, i) => at(i)) };
    assert.ok(parseSessionCommit(wire(max)).ok);
    assert.ok(!parseSessionCommit(wire({ ...max, attempts: [...max.attempts, at(0)] })).ok);
    const longInput = { ...good(), attempts: [{ ...good().attempts[0]!, input: 'x'.repeat(PARSE_LIMITS.inputLength) }] };
    assert.ok(parseSessionCommit(wire(longInput)).ok);
    assert.ok(parseSessionCommit(wire({ ...good(), sessionId: 'x'.repeat(PARSE_LIMITS.idLength) })).ok);
  });

  it('never repeats the value that was sent in its message', () => {
    const body = wire(good()) as Record<string, unknown>;
    body.seed = 'SECRET-VALUE-123';
    const r = parseSessionCommit(body);
    assert.ok(!r.ok);
    if (!r.ok) assert.ok(!r.message.includes('SECRET-VALUE-123'));
  });
});
