/**
 * Spelling evaluation: decides whether an answer is a perfect match, a minor
 * slip (Levenshtein distance exactly 1) or a major mistake (distance > 1).
 *
 * Note: this is PURE Levenshtein, as the brief specifies. Swapped letters
 * ("recieve" vs "receive") cost 2 edits and therefore count as major.
 */

export type Verdict = 'exact' | 'minor' | 'major';

export interface Evaluation {
  verdict: Verdict;
  distance: number;
  normalizedInput: string;
  normalizedTarget: string;
}

// iOS/Android "smart punctuation" types ’ instead of ' — they must compare equal.
const APOSTROPHES = /[\u2018\u2019\u02BC]/g;

// Punctuation ignored by the sentence step. Apostrophes and hyphens stay: they are part of spelling.
const SENTENCE_PUNCTUATION = /[.,?!;:\u2026"\u201C\u201D\u2014\u2013]+/g;

const collapseWhitespace = (s: string): string => s.replace(/\s+/g, ' ').trim();

/** Case-insensitive, trimmed, whitespace-collapsed, apostrophe-normalised. */
export function normalizeWord(raw: string): string {
  return collapseWhitespace(raw.normalize('NFC').replace(APOSTROPHES, "'")).toLowerCase();
}

/** Same as normalizeWord, and additionally ignores . , ? ! ; : quotes and dashes anywhere. */
export function normalizeSentence(raw: string): string {
  return collapseWhitespace(
    raw.normalize('NFC').replace(APOSTROPHES, "'").replace(SENTENCE_PUNCTUATION, ' '),
  ).toLowerCase();
}

/** Classic Levenshtein (insert / delete / substitute), two-row DP, code-point aware. */
export function levenshtein(a: string, b: string): number {
  if (a === b) return 0;
  const A = Array.from(a);
  const B = Array.from(b);
  if (A.length === 0) return B.length;
  if (B.length === 0) return A.length;

  const [short, long] = A.length <= B.length ? [A, B] : [B, A];
  let prev = Array.from({ length: short.length + 1 }, (_, i) => i);
  for (let j = 1; j <= long.length; j++) {
    const curr: number[] = [j];
    for (let i = 1; i <= short.length; i++) {
      const cost = short[i - 1] === long[j - 1] ? 0 : 1;
      curr[i] = Math.min((prev[i] ?? 0) + 1, (curr[i - 1] ?? 0) + 1, (prev[i - 1] ?? 0) + cost);
    }
    prev = curr;
  }
  return prev[short.length] ?? 0;
}

function judge(normalizedInput: string, normalizedTarget: string, maxMinor: number): Evaluation {
  const distance = levenshtein(normalizedInput, normalizedTarget);
  let verdict: Verdict;
  if (distance === 0) verdict = 'exact';
  else if (normalizedInput === '') verdict = 'major'; // a blank submission is never a "slip"
  else verdict = distance <= maxMinor ? 'minor' : 'major';
  return { verdict, distance, normalizedInput, normalizedTarget };
}

/** Step 1 (standalone word). */
export function evaluateWord(input: string, target: string, maxMinorDistance = 1): Evaluation {
  return judge(normalizeWord(input), normalizeWord(target), maxMinorDistance);
}

/** Step 2 (sentence): forgiving — end punctuation and case never cause a failure. */
export function evaluateSentence(input: string, target: string, maxMinorDistance = 1): Evaluation {
  return judge(normalizeSentence(input), normalizeSentence(target), maxMinorDistance);
}
