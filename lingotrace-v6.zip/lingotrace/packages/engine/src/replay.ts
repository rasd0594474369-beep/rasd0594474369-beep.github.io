/**
 * Deterministic sessions: the basis of server-side verification.
 *
 *   CLIENT  beginSession({... seed: newSeed()}) → { state, rng }
 *           then submit(state, text, { now, rng }) with that same rng until completed.
 *   SERVER  replaySession(setup, attempts) re-runs the lesson from the seed and the typed
 *           inputs and derives outcomes + XP itself. The client never sends XP.
 */

import { DEFAULT_CONFIG } from './types.ts';
import type { EngineConfig, MistakeRecord, Rng, StepKind, WordItem } from './types.ts';
import { buildLessonQueue } from './queue-builder.ts';
import { createRng } from './rng.ts';
import { currentPrompt, peek, startSession, submit, summarize } from './session.ts';
import type { SessionMode, SessionState, SessionSummary } from './session.ts';

export interface SessionSetup {
  sessionId: string;
  lessonSeq: number;
  mode: SessionMode;
  seed: number;
  lessonWords: readonly WordItem[];
  /** The user's rotation as of the session start (client: local copy; server: eligible rows). */
  history: readonly MistakeRecord[];
  cfg?: EngineConfig;
}

/** Builds the queue with a seeded RNG. Keep using the returned `rng` for every submit(). */
export function beginSession(setup: SessionSetup): { state: SessionState; rng: Rng } {
  const cfg = setup.cfg ?? DEFAULT_CONFIG;
  const rng = createRng(setup.seed);
  const history = setup.mode === 'replay' ? [] : setup.history; // replays never inject
  const queue = buildLessonQueue({ lessonWords: setup.lessonWords, history, lessonSeq: setup.lessonSeq, cfg, rng });
  return {
    state: startSession({ sessionId: setup.sessionId, lessonSeq: setup.lessonSeq, queue, mode: setup.mode }),
    rng,
  };
}

/** What the client reports for every submission. Verdicts and XP are NOT part of it. */
export interface ClaimedAttempt {
  itemId: string;
  step: StepKind;
  input: string;
  usedPeek: boolean;
  at: string; // ISO-8601
}

export type ReplayResult = { ok: true; state: SessionState; summary: SessionSummary } | { ok: false; reason: string };

const MAX_INPUT_LENGTH = 500;

export function replaySession(setup: SessionSetup, attempts: readonly ClaimedAttempt[]): ReplayResult {
  const cfg = setup.cfg ?? DEFAULT_CONFIG;
  let state: SessionState;
  let rng: Rng;
  try {
    ({ state, rng } = beginSession(setup));
  } catch (e) {
    return { ok: false, reason: `cannot build the lesson queue: ${(e as Error).message}` };
  }

  for (const [i, a] of attempts.entries()) {
    const label = `attempt ${i + 1}`;
    const prompt = currentPrompt(state);
    if (!prompt) return { ok: false, reason: `${label} comes after the lesson was already finished` };
    if (prompt.itemId !== a.itemId || prompt.step !== a.step) {
      return { ok: false, reason: `${label}: expected ${prompt.itemId}/${prompt.step} but got ${String(a.itemId)}/${String(a.step)}` };
    }
    if (typeof a.input !== 'string' || a.input.length > MAX_INPUT_LENGTH) return { ok: false, reason: `${label}: invalid input` };
    const at = new Date(a.at);
    if (Number.isNaN(at.getTime())) return { ok: false, reason: `${label}: invalid timestamp` };

    if (a.usedPeek) state = peek(state);
    state = submit(state, a.input, { now: at, rng, cfg }).state;
  }

  if (state.phase !== 'completed') return { ok: false, reason: 'the attempts do not finish the lesson' };
  return { ok: true, state, summary: summarize(state) };
}
