/**
 * Domain types + configuration for the spelling engine.
 *
 * Everything in src/ is pure (no I/O, no framework imports, no hidden clock or
 * randomness), so the same code runs on-device (React Native) or on the server.
 * Time and randomness are always injected, which keeps every rule unit-testable.
 */

/**
 * Bump whenever a rule that affects replay changes (XP values, gaps, thresholds, queue building).
 * Commits carry it; the server refuses a mismatch instead of silently replaying with different rules.
 */
export const ENGINE_VERSION = 1;

export type LevelCode = 'A1' | 'A2' | 'B1' | 'B2' | 'C1';

/** Random source returning a float in [0, 1). Injected so tests are deterministic. */
export type Rng = () => number;

/**
 * A word as the engine sees it.
 * `errorWeight` is the CURRENT USER's weight for this word (0 if never failed twice).
 * In the database it lives in `user_word_stats`, not on the shared `words` row.
 */
export interface WordItem {
  wordId: string;
  wordText: string;
  sentenceContext: string;
  errorWeight: number;
  /** Arabic meaning shown with the word (optional content). */
  meaningAr?: string | null;
  /** Arabic translation of `sentenceContext` (optional content). */
  sentenceAr?: string | null;
}

export type StepKind = 'word' | 'sentence';

/** Where a queue item came from. An immediate re-queue keeps the source of the word it repeats. */
export type ItemSource = 'lesson' | 'injected';

export interface QueueItem {
  /** Unique inside one session: `L:<wordId>` lesson, `I:<wordId>` injected, `R:<wordId>` immediate review. */
  itemId: string;
  word: WordItem;
  source: ItemSource;
  /** True when this is the same-session re-queue of a word that was just failed. */
  isReview: boolean;
  /** ['word','sentence'] for new lesson words; ['word'] (standalone only) for every review. */
  steps: readonly StepKind[];
}

export type StatStatus = 'active' | 'mastered';

/** Mirrors table `user_word_stats` (one row per user × word = the "error rotation"). */
export interface UserWordStat {
  wordId: string;
  errorWeight: number;
  status: StatStatus;
  /** Global lesson sequence from which the word may be injected; null once mastered. */
  dueSeq: number | null;
  lifetimeFailures: number;
  lastFailedAt: string | null; // ISO-8601 UTC
  lastReviewedAt: string | null; // ISO-8601 UTC
}

/** A word waiting in the user's error rotation (a `user_word_stats` row joined with `words`). */
export interface MistakeRecord {
  word: WordItem;
  dueSeq: number;
  lastFailedAt: string | null; // ISO-8601 UTC
}

export interface EngineConfig {
  /** New words per lesson. The brief fixes this at exactly 20. */
  lessonSize: number;
  /** Max historical mistake words mixed into one future lesson. */
  maxInjectedPerLesson: number;
  /** Same-session re-queue: how many items sit between the failure and its review (inclusive range). */
  immediateReviewGap: { min: number; max: number };
  /** Future injection offset: failed twice in lesson N → eligible from lesson N + this value. */
  reviewGapLessons: number;
  /** Non-exact attempts on one step before it counts as a major mistake ("fails multiple times"). */
  failuresBeforeMajor: number;
  /** Levenshtein distance up to this value is a minor slip. The brief says exactly 1. */
  maxMinorDistance: number;
  xp: { firstTry: number; recovered: number; lessonBonus: number };
  /** Replays never award XP by default (keeps the global leaderboard un-farmable). */
  replayAwardsXp: boolean;
}

export const DEFAULT_CONFIG: EngineConfig = {
  lessonSize: 20,
  maxInjectedPerLesson: 2,
  immediateReviewGap: { min: 2, max: 3 },
  reviewGapLessons: 2,
  failuresBeforeMajor: 2,
  maxMinorDistance: 1,
  xp: { firstTry: 10, recovered: 5, lessonBonus: 50 },
  replayAwardsXp: false,
};
