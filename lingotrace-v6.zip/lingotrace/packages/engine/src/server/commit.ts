/**
 * Committing a finished lesson — the only place where progress, XP, streak, the error rotation and
 * the misspelling log are written. DB-agnostic: planCommit() is pure; commitSession() talks to a CommitRepo.
 *
 * SERVER ONLY. The app imports `@lingotrace/engine`; this module is `@lingotrace/engine/server`.
 *
 * Trust model: the client sends WHAT THE USER TYPED (plus a seed). The server re-runs the lesson
 * (replay.ts) and derives outcomes, XP, rotation updates and the attempt log itself.
 * Not verifiable server-side (and so trusted): that a human typed, and the "peeked" flag.
 */

import { DEFAULT_CONFIG, ENGINE_VERSION } from '../types.ts';
import type { EngineConfig, MistakeRecord, UserWordStat, WordItem } from '../types.ts';
import { normalizeWord } from '../spelling.ts';
import { applySummaryToStats } from '../stats.ts';
import { replaySession } from '../replay.ts';
import type { AttemptLog, SessionMode, SessionSummary } from '../session.ts';
import { applyLessonCompletion, effectiveStreak, isValidTimeZone } from '../streak.ts';
import type { StreakState } from '../streak.ts';
import type { SessionCommit } from '../commit-request.ts';

// ─── the plan (rows to write) ────────────────────────────────────────────────

export interface LessonInfo {
  id: string;
  levelCode: string;
  lessonNumber: number;
  globalSeq: number;
  isPublished: boolean;
}

export type UserRow = StreakState & { totalXp: number; timeZone: string };

export interface CommitContext {
  userId: string;
  lesson: LessonInfo;
  lessonWords: readonly WordItem[];
  /** Everything the rotation would allow for this lesson (use a generous limit, e.g. 50). */
  eligibleMistakes: readonly MistakeRecord[];
  previousStats: readonly UserWordStat[];
  alreadyCompleted: boolean;
  unlocked: boolean;
  streak: StreakState;
}

/** One row of `misspelled_words`: a wrong spelling of one word and how often it was typed in this session. */
export interface MisspellingUpsert {
  userId: string;
  wordId: string;
  /** As the engine normalizes it (trimmed, lower-case, no NUL), 1..MISSPELLED_MAX_LENGTH characters. */
  typed: string;
  occurrences: number;
  firstSeenAt: string; // ISO-8601 UTC
  lastSeenAt: string; // ISO-8601 UTC
}

export interface CommitPlan {
  session: {
    id: string; userId: string; lessonId: string; mode: SessionMode; parentSessionId: string | null;
    startedAt: string; completedAt: string;
    wordsTotal: number; wordsClean: number; wordsFailedTwice: number; xpEarned: number;
  };
  attempts: Array<{
    sessionId: string; n: number; wordId: string; origin: AttemptLog['origin']; step: AttemptLog['step'];
    attemptNo: number; typed: string; distance: number; verdict: AttemptLog['verdict']; usedPeek: boolean;
  }>;
  statUpserts: UserWordStat[];
  /** Wrong spellings from the word step, grouped by (word, typed). Merged into misspelled_words by adding the counts. */
  misspelled: MisspellingUpsert[];
  xpEvents: Array<{ userId: string; sessionId: string; reason: 'words_first_try' | 'words_recovered' | 'lesson_bonus'; amount: number }>;
  lessonProgress: {
    userId: string; lessonId: string; firstCompletedAt: string | null; lastPlayedAt: string;
    /** Share of words answered cleanly in THIS session, 0..100 (user_progress keeps the best and the last). */
    accuracy: number;
  };
  streak: StreakState;
  timeZone: string;
  summary: SessionSummary;
}

export type RejectCode =
  | 'bad_request' | 'lesson_not_found' | 'lesson_unpublished' | 'lesson_locked'
  | 'mode_mismatch' | 'injection_invalid' | 'timing_implausible' | 'replay_failed' | 'engine_outdated'
  | 'out_of_order';

export interface Rejection {
  ok: false;
  code: RejectCode;
  message: string;
  /** Machine-readable extras for the client, e.g. `{ lastSessionId }` with `out_of_order`. */
  details?: { lastSessionId: string | null };
}
const reject = (code: RejectCode, message: string, details?: Rejection['details']): Rejection =>
  details ? { ok: false, code, message, details } : { ok: false, code, message };

export interface CommitOptions {
  cfg?: EngineConfig;
  /** Id format check run before touching the database. Default: UUID (the schema's id type). */
  isValidId?: (id: string) => boolean;
  /** Minimum average time per submission (ms). A cheap bot filter, not proof of a human. */
  minMsPerAttempt?: number;
  maxFutureSkewMs?: number;
  maxAttempts?: number;
}

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
export const isUuid = (s: unknown): s is string => typeof s === 'string' && UUID_RE.test(s);

/** Most attempts one session may report (a perfect 20-word lesson has 40; the rest is room for retries and reviews). */
export const DEFAULT_MAX_ATTEMPTS = 400;

/** PostgreSQL text columns cannot hold NUL. */
const stripNul = (s: string): string => s.replace(/\u0000/g, '');

/** Longest wrong spelling kept in misspelled_words (column check: char_length(typed) between 1 and 100). */
export const MISSPELLED_MAX_LENGTH = 100;

/**
 * Groups the wrong word-step attempts of a session into misspelled_words rows.
 *
 * Counted: every non-exact attempt of the word step (minor slips too; first runs, replays and the
 * immediate review alike). Not counted: sentence-step attempts, and typed text that is empty or longer
 * than MISSPELLED_MAX_LENGTH once normalized (the attempt log still keeps those, up to 500 characters).
 * Length is counted in code points, like PostgreSQL's char_length.
 *
 * `attempts` is in submission order with non-decreasing timestamps (planCommit checks both and
 * replay.ts normalizes `at` to ISO UTC), so the first sighting is the earliest and the last the latest.
 */
export function collectMisspellings(userId: string, attempts: readonly AttemptLog[]): MisspellingUpsert[] {
  const rows = new Map<string, MisspellingUpsert>();
  for (const a of attempts) {
    if (a.step !== 'word' || a.verdict === 'exact') continue;
    const typed = normalizeWord(stripNul(a.input));
    const length = Array.from(typed).length;
    if (length < 1 || length > MISSPELLED_MAX_LENGTH) continue;

    const key = JSON.stringify([a.wordId, typed]);
    const row = rows.get(key);
    if (row) {
      row.occurrences += 1;
      row.lastSeenAt = a.at;
    } else {
      rows.set(key, { userId, wordId: a.wordId, typed, occurrences: 1, firstSeenAt: a.at, lastSeenAt: a.at });
    }
  }
  return [...rows.values()];
}

export function planCommit(
  commit: SessionCommit,
  ctx: CommitContext,
  now: Date,
  opts: CommitOptions = {},
): { ok: true; plan: CommitPlan } | Rejection {
  const cfg = opts.cfg ?? DEFAULT_CONFIG;
  const minMsPerAttempt = opts.minMsPerAttempt ?? 700;
  const skew = opts.maxFutureSkewMs ?? 5 * 60_000;
  const maxAttempts = opts.maxAttempts ?? DEFAULT_MAX_ATTEMPTS;

  if (commit.engineVersion !== ENGINE_VERSION) return reject('engine_outdated', 'update the app: its lesson rules differ from the server');
  if (!ctx.lesson.isPublished) return reject('lesson_unpublished', 'lesson is not published');
  if (!ctx.unlocked) return reject('lesson_locked', 'finish the previous lessons first');

  // The server — not the client — decides whether this is a first run or a replay.
  const mode: SessionMode = ctx.alreadyCompleted ? 'replay' : 'first_run';
  if (commit.mode !== mode) return reject('mode_mismatch', `this lesson must be committed as "${mode}"`);

  if (!Number.isInteger(commit.seed)) return reject('bad_request', 'invalid seed');
  if (!isValidTimeZone(commit.timeZone)) return reject('bad_request', 'invalid time zone');
  if (!Array.isArray(commit.attempts) || commit.attempts.length === 0 || commit.attempts.length > maxAttempts) {
    return reject('bad_request', 'attempts missing or too many');
  }

  // Injected words must be genuinely due rotation words, at most the configured cap.
  if (!Array.isArray(commit.injectedWordIds)) return reject('bad_request', 'injectedWordIds must be a list');
  const claimed = new Set(commit.injectedWordIds);
  if (claimed.size !== commit.injectedWordIds.length) return reject('injection_invalid', 'duplicate injected word');
  if (claimed.size > (mode === 'replay' ? 0 : cfg.maxInjectedPerLesson)) return reject('injection_invalid', 'too many injected words');
  const history = ctx.eligibleMistakes.filter((m) => claimed.has(m.word.wordId));
  if (history.length !== claimed.size) return reject('injection_invalid', 'an injected word is not due for review');

  // Timing plausibility.
  const start = Date.parse(commit.startedAt);
  const end = Date.parse(commit.completedAt);
  if (Number.isNaN(start) || Number.isNaN(end)) return reject('bad_request', 'invalid timestamps');
  if (end < start) return reject('timing_implausible', 'completedAt is before startedAt');
  if (end > now.getTime() + skew) return reject('timing_implausible', 'completedAt is in the future');
  let previous = start;
  for (const a of commit.attempts) {
    const t = Date.parse(a.at);
    if (Number.isNaN(t) || t < previous || t > end + 2000) return reject('timing_implausible', 'attempt timestamps are out of order');
    previous = t;
  }
  if (end - start < commit.attempts.length * minMsPerAttempt) return reject('timing_implausible', 'session was implausibly fast');

  // Re-run the lesson from the seed and the typed inputs.
  const replay = replaySession(
    { sessionId: commit.sessionId, lessonSeq: ctx.lesson.globalSeq, mode, seed: commit.seed, lessonWords: ctx.lessonWords, history, cfg },
    commit.attempts,
  );
  if (!replay.ok) return reject('replay_failed', replay.reason);

  const { summary } = replay;
  const xp = summary.xp;
  const count = (r: string) => summary.outcomes.filter((o) => o.result === r).length;
  const wordsTotal = summary.outcomes.length;
  const wordsClean = count('clean');

  return {
    ok: true,
    plan: {
      session: {
        id: commit.sessionId, userId: ctx.userId, lessonId: ctx.lesson.id, mode, parentSessionId: commit.parentSessionId ?? null,
        startedAt: new Date(start).toISOString(), completedAt: new Date(end).toISOString(),
        wordsTotal, wordsClean, wordsFailedTwice: count('failed_twice'),
        xpEarned: xp.total,
      },
      attempts: summary.attempts.map((a) => ({
        sessionId: commit.sessionId, n: a.n, wordId: a.wordId, origin: a.origin, step: a.step,
        attemptNo: a.attemptNo, typed: stripNul(a.input), distance: a.distance, verdict: a.verdict, usedPeek: a.usedPeek,
      })),
      statUpserts: applySummaryToStats(summary, ctx.previousStats, now, cfg),
      misspelled: collectMisspellings(ctx.userId, summary.attempts),
      xpEvents: (
        [['words_first_try', xp.firstTry], ['words_recovered', xp.recovered], ['lesson_bonus', xp.lessonBonus]] as const
      )
        .filter(([, amount]) => amount > 0)
        .map(([reason, amount]) => ({ userId: ctx.userId, sessionId: commit.sessionId, reason, amount })),
      lessonProgress: {
        userId: ctx.userId, lessonId: ctx.lesson.id,
        firstCompletedAt: ctx.alreadyCompleted ? null : now.toISOString(), lastPlayedAt: now.toISOString(),
        accuracy: wordsTotal === 0 ? 0 : Math.round((100 * wordsClean) / wordsTotal),
      },
      // Any completed lesson (replays included) counts as activity for the streak; only XP is withheld.
      streak: applyLessonCompletion(ctx.streak, now, commit.timeZone),
      timeZone: commit.timeZone,
      summary,
    },
  };
}

// ─── the service ─────────────────────────────────────────────────────────────

export interface CommitTx {
  /** SELECT … FOR UPDATE: serialises concurrent commits of the same user. null = unknown user. */
  lockUser(userId: string): Promise<UserRow | null>;
  findSession(sessionId: string): Promise<{ userId: string; mode: SessionMode; xpEarned: number } | null>;
  /** The head of the user's session chain: the last session committed for them, or null before the first. */
  lastSessionId(userId: string): Promise<string | null>;
  loadLesson(lessonId: string): Promise<LessonInfo | null>;
  loadLessonWords(lessonId: string): Promise<WordItem[]>;
  isLessonCompleted(userId: string, lessonId: string): Promise<boolean>;
  isLessonUnlocked(userId: string, globalSeq: number): Promise<boolean>;
  loadDueMistakes(userId: string, lessonId: string, limit: number): Promise<MistakeRecord[]>;
  loadStats(userId: string, wordIds: readonly string[]): Promise<UserWordStat[]>;
  applyPlan(plan: CommitPlan): Promise<{ totalXp: number }>;
}

export interface CommitRepo {
  transaction<T>(fn: (tx: CommitTx) => Promise<T>): Promise<T>;
}

export interface CommitReceipt {
  status: 'committed' | 'duplicate';
  sessionId: string;
  mode: SessionMode;
  xpEarned: number;
  totalXp: number;
  streak: number;
  longestStreak: number;
  /** Words that just entered (or re-entered) the error rotation. */
  newMistakes: number;
}

export type CommitOutcome = { ok: true; receipt: CommitReceipt } | Rejection;

export async function commitSession(
  repo: CommitRepo,
  userId: string,
  commit: SessionCommit,
  now: Date = new Date(),
  opts: CommitOptions = {},
): Promise<CommitOutcome> {
  // Cheap shape check first: a malformed id would otherwise surface as a database error.
  const validId = opts.isValidId ?? isUuid;
  const parentId = commit.parentSessionId ?? null;
  if (![commit.sessionId, commit.lessonId, ...(parentId === null ? [] : [parentId]), ...(commit.injectedWordIds ?? [])].every(validId)) {
    return reject('bad_request', 'sessionId, parentSessionId, lessonId and injectedWordIds must be valid ids');
  }
  if (parentId === commit.sessionId) return reject('bad_request', 'a session cannot be its own parent');

  return repo.transaction(async (tx): Promise<CommitOutcome> => {
    const user = await tx.lockUser(userId);
    if (!user) return reject('bad_request', 'unknown user');

    const existing = await tx.findSession(commit.sessionId);
    if (existing) {
      if (existing.userId !== userId) return reject('bad_request', 'session id already used');
      return {
        ok: true,
        receipt: {
          status: 'duplicate', sessionId: commit.sessionId, mode: existing.mode, xpEarned: existing.xpEarned,
          totalXp: user.totalXp, streak: effectiveStreak(user, now, user.timeZone), longestStreak: user.longestStreak, newMistakes: 0,
        },
      };
    }

    // Before anything that depends on the user's state: a session that arrives ahead of an earlier one would
    // fail those checks for the wrong reason (locked lesson, different rotation), and that failure looks permanent.
    const head = await tx.lastSessionId(userId);
    if (parentId !== head) return reject('out_of_order', 'send the sessions played before this one first', { lastSessionId: head });

    const lesson = await tx.loadLesson(commit.lessonId);
    if (!lesson) return reject('lesson_not_found', 'unknown lesson');

    const lessonWords = await tx.loadLessonWords(lesson.id);
    const alreadyCompleted = await tx.isLessonCompleted(userId, lesson.id);
    const unlocked = alreadyCompleted || (await tx.isLessonUnlocked(userId, lesson.globalSeq));
    const eligibleMistakes = alreadyCompleted ? [] : await tx.loadDueMistakes(userId, lesson.id, 50);
    const previousStats = await tx.loadStats(userId, [
      ...lessonWords.map((w) => w.wordId),
      ...eligibleMistakes.map((m) => m.word.wordId),
    ]);

    const planned = planCommit(
      commit,
      { userId, lesson, lessonWords, eligibleMistakes, previousStats, alreadyCompleted, unlocked, streak: user },
      now,
      opts,
    );
    if (!planned.ok) return planned;

    const { totalXp } = await tx.applyPlan(planned.plan);
    const { plan } = planned;
    return {
      ok: true,
      receipt: {
        status: 'committed', sessionId: commit.sessionId, mode: plan.session.mode, xpEarned: plan.session.xpEarned,
        totalXp, streak: plan.streak.streakCount, longestStreak: plan.streak.longestStreak,
        newMistakes: plan.summary.outcomes.filter((o) => o.result === 'failed_twice').length,
      },
    };
  });
}
