/**
 * Turns untrusted JSON (the body of a commit request) into a SessionCommit, or says why it cannot.
 *
 * TypeScript types do not exist at run time: without this, `{"attempts":[null]}` would reach the commit service and
 * crash it with a TypeError (checked: "Cannot read properties of null", a 500 and noise in the logs). The parser checks the shape and the sizes, and
 * builds a CLEAN object with only the known fields, so nothing else a client sends travels any further.
 * It does not judge the content (timing, order, rules): planCommit and commitSession do.
 *
 * Error messages name the field and the expectation, never the value that was sent.
 *
 * SERVER ONLY (`@lingotrace/engine/server`).
 */

import type { SessionCommit } from '../commit-request.ts';
import type { ClaimedAttempt } from '../replay.ts';
import type { StepKind } from '../types.ts';
import { DEFAULT_MAX_ATTEMPTS } from './commit.ts';

export type ParseResult = { ok: true; value: SessionCommit } | { ok: false; message: string };

/** Structural bounds, set well above what an honest client sends. The rules (e.g. 500 characters per answer) live in the replay. */
export const PARSE_LIMITS = {
  idLength: 64,
  itemIdLength: 100,
  timeZoneLength: 64,
  timestampLength: 40,
  inputLength: 2000,
  injectedWordIds: 10,
  attempts: DEFAULT_MAX_ATTEMPTS,
} as const;

type Obj = Record<string, unknown>;
const isObject = (v: unknown): v is Obj => typeof v === 'object' && v !== null && !Array.isArray(v);
const isText = (v: unknown, max: number): v is string => typeof v === 'string' && v.length >= 1 && v.length <= max;
const fail = (message: string): ParseResult => ({ ok: false, message });

const MODES = ['first_run', 'replay'] as const;
const STEPS: readonly StepKind[] = ['word', 'sentence'];

function parseAttempt(raw: unknown, at: string): ClaimedAttempt | string {
  if (!isObject(raw)) return `${at} must be an object`;
  const { itemId, step, input, usedPeek, at: time } = raw;
  if (!isText(itemId, PARSE_LIMITS.itemIdLength)) return `${at}.itemId must be a short text`;
  if (typeof step !== 'string' || !(STEPS as readonly string[]).includes(step)) return `${at}.step must be "word" or "sentence"`;
  if (typeof input !== 'string' || input.length > PARSE_LIMITS.inputLength) return `${at}.input must be a text of at most ${PARSE_LIMITS.inputLength} characters`;
  if (typeof usedPeek !== 'boolean') return `${at}.usedPeek must be true or false`;
  if (!isText(time, PARSE_LIMITS.timestampLength)) return `${at}.at must be a timestamp text`;
  return { itemId, step: step as StepKind, input, usedPeek, at: time };
}

export function parseSessionCommit(body: unknown): ParseResult {
  if (!isObject(body)) return fail('the request body must be a JSON object');
  const { engineVersion, sessionId, parentSessionId, lessonId, mode, seed, timeZone, startedAt, completedAt, injectedWordIds, attempts } = body;

  if (typeof engineVersion !== 'number' || !Number.isInteger(engineVersion)) return fail('engineVersion must be an integer');
  if (!isText(sessionId, PARSE_LIMITS.idLength)) return fail('sessionId must be a short text');
  if (parentSessionId !== null && !isText(parentSessionId, PARSE_LIMITS.idLength)) return fail('parentSessionId must be a short text or null');
  if (!isText(lessonId, PARSE_LIMITS.idLength)) return fail('lessonId must be a short text');
  if (typeof mode !== 'string' || !(MODES as readonly string[]).includes(mode)) return fail('mode must be "first_run" or "replay"');
  if (typeof seed !== 'number' || !Number.isInteger(seed) || seed < 0 || seed > 0xffffffff) return fail('seed must be an unsigned 32-bit integer');
  if (!isText(timeZone, PARSE_LIMITS.timeZoneLength)) return fail('timeZone must be a short text');
  if (!isText(startedAt, PARSE_LIMITS.timestampLength)) return fail('startedAt must be a timestamp text');
  if (!isText(completedAt, PARSE_LIMITS.timestampLength)) return fail('completedAt must be a timestamp text');

  if (!Array.isArray(injectedWordIds) || injectedWordIds.length > PARSE_LIMITS.injectedWordIds) return fail(`injectedWordIds must be a list of at most ${PARSE_LIMITS.injectedWordIds} ids`);
  const injected: string[] = [];
  for (const [i, id] of injectedWordIds.entries()) {
    if (!isText(id, PARSE_LIMITS.idLength)) return fail(`injectedWordIds[${i}] must be a short text`);
    injected.push(id);
  }

  if (!Array.isArray(attempts) || attempts.length < 1 || attempts.length > PARSE_LIMITS.attempts) return fail(`attempts must be a list of 1 to ${PARSE_LIMITS.attempts} entries`);
  const claimed: ClaimedAttempt[] = [];
  for (const [i, raw] of attempts.entries()) {
    const parsed = parseAttempt(raw, `attempts[${i}]`);
    if (typeof parsed === 'string') return fail(parsed);
    claimed.push(parsed);
  }

  return {
    ok: true,
    value: {
      engineVersion, sessionId, parentSessionId, lessonId, mode: mode as SessionCommit['mode'], seed, timeZone,
      startedAt, completedAt, injectedWordIds: injected, attempts: claimed,
    },
  };
}
