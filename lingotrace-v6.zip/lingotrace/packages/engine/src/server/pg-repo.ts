/**
 * PostgreSQL adapter for CommitRepo (node-postgres compatible: `pg`, Supabase direct connection).
 * Every statement sticks to portable SQL (numbered $n parameters, ON CONFLICT upserts) and matches the
 * Supabase migrations in supabase/migrations (table names: vocabulary_bank, user_progress, misspelled_words ...).
 *
 * SERVER ONLY (`@lingotrace/engine/server`).
 */

import type { MistakeRecord, UserWordStat, WordItem } from '../types.ts';
import type { CommitPlan, CommitRepo, CommitTx, LessonInfo, UserRow } from './commit.ts';
import type { SessionMode } from '../session.ts';

type Row = Record<string, unknown>;

/** The slice of node-postgres this adapter needs. */
export interface SqlClient {
  query(text: string, values?: unknown[]): Promise<{ rows: Row[] }>;
}
export interface SqlPool {
  connect(): Promise<SqlClient & { release(): void }>;
}

const str = (v: unknown): string => String(v);
const nstr = (v: unknown): string | null => (v === null || v === undefined ? null : str(v));
const num = (v: unknown): number => Number(v); // node-postgres returns bigint as string
const bool = (v: unknown): boolean => v === true || v === 1 || v === 't' || v === 'true';
const iso = (v: unknown): string | null =>
  v === null || v === undefined ? null : v instanceof Date ? v.toISOString() : new Date(String(v)).toISOString();

class PgTx implements CommitTx {
  private readonly c: SqlClient;
  constructor(client: SqlClient) {
    this.c = client;
  }

  async lockUser(userId: string): Promise<UserRow | null> {
    const { rows } = await this.c.query(
      'SELECT total_xp, streak_count, longest_streak, CAST(last_active_date AS text) AS last_active_date, time_zone FROM users WHERE id = $1 FOR UPDATE',
      [userId],
    );
    const r = rows[0];
    if (!r) return null;
    const day = r.last_active_date === null || r.last_active_date === undefined ? null : str(r.last_active_date).slice(0, 10);
    // CAST(date AS text) follows the session DateStyle; anything but ISO would silently corrupt the streak, so refuse it loudly.
    if (day !== null && !/^\d{4}-\d{2}-\d{2}$/.test(day)) {
      throw new Error(`users.last_active_date came back as "${day}", expected YYYY-MM-DD. Set DateStyle to ISO: ALTER ROLE <your role> SET datestyle TO 'ISO, MDY';`);
    }
    return {
      totalXp: num(r.total_xp), streakCount: num(r.streak_count), longestStreak: num(r.longest_streak),
      lastActiveDate: day, timeZone: str(r.time_zone),
    };
  }

  async findSession(sessionId: string): Promise<{ userId: string; mode: SessionMode; xpEarned: number } | null> {
    const { rows } = await this.c.query('SELECT user_id, mode, xp_earned FROM lesson_sessions WHERE id = $1', [sessionId]);
    const r = rows[0];
    return r ? { userId: str(r.user_id), mode: str(r.mode) as SessionMode, xpEarned: num(r.xp_earned) } : null;
  }

  /**
   * The chain head: the user's session that no other session names as its parent. The unique indexes on
   * lesson_sessions (one root per user, one child per session) make that at most one row; two rows would
   * mean the chain is corrupt, and committing on top of a corrupt chain would make it worse, so fail loudly.
   */
  async lastSessionId(userId: string): Promise<string | null> {
    const { rows } = await this.c.query(
      `SELECT s.id FROM lesson_sessions s
       WHERE s.user_id = $1 AND NOT EXISTS (SELECT 1 FROM lesson_sessions c WHERE c.parent_session_id = s.id)
       LIMIT 2`,
      [userId],
    );
    if (rows.length > 1) throw new Error(`the session chain of user ${userId} has more than one head`);
    return rows[0] ? str(rows[0].id) : null;
  }

  async loadLesson(lessonId: string): Promise<LessonInfo | null> {
    const { rows } = await this.c.query(
      'SELECT id, level_code, lesson_number, global_seq, is_published FROM lessons WHERE id = $1',
      [lessonId],
    );
    const r = rows[0];
    return r
      ? { id: str(r.id), levelCode: str(r.level_code), lessonNumber: num(r.lesson_number), globalSeq: num(r.global_seq), isPublished: bool(r.is_published) }
      : null;
  }

  async loadLessonWords(lessonId: string): Promise<WordItem[]> {
    const { rows } = await this.c.query(
      'SELECT w.id, w.word_text, w.sentence_context, w.meaning_ar, w.sentence_ar FROM lesson_words lw JOIN vocabulary_bank w ON w.id = lw.word_id WHERE lw.lesson_id = $1 ORDER BY lw.position',
      [lessonId],
    );
    return rows.map((r) => ({ wordId: str(r.id), wordText: str(r.word_text), sentenceContext: str(r.sentence_context), errorWeight: 0, meaningAr: nstr(r.meaning_ar), sentenceAr: nstr(r.sentence_ar) }));
  }

  async isLessonCompleted(userId: string, lessonId: string): Promise<boolean> {
    const { rows } = await this.c.query(
      'SELECT 1 AS ok FROM user_progress WHERE user_id = $1 AND lesson_id = $2 AND first_completed_at IS NOT NULL',
      [userId, lessonId],
    );
    return rows.length > 0;
  }

  /** Unlocked = every published lesson before this one has been completed at least once. */
  async isLessonUnlocked(userId: string, globalSeq: number): Promise<boolean> {
    const { rows } = await this.c.query(
      `SELECT 1 AS missing FROM lessons l
       LEFT JOIN user_progress lp ON lp.lesson_id = l.id AND lp.user_id = $1
       WHERE l.is_published AND l.global_seq < $2 AND lp.first_completed_at IS NULL
       LIMIT 1`,
      [userId, globalSeq],
    );
    return rows.length === 0;
  }

  /**
   * The rotation words due for injection into this lesson. This statement is the single source of truth
   * for the ORDER BY: it must mirror byPriority() in queue-builder.ts (the client sorts its local copy the same way).
   */
  async loadDueMistakes(userId: string, lessonId: string, limit: number): Promise<MistakeRecord[]> {
    const { rows } = await this.c.query(
      `SELECT w.id, w.word_text, w.sentence_context, w.meaning_ar, w.sentence_ar, s.error_weight, s.due_seq, s.last_failed_at
       FROM user_word_stats s
       JOIN vocabulary_bank w ON w.id = s.word_id
       JOIN lessons l ON l.id = $2
       WHERE s.user_id = $1 AND s.status = 'active' AND s.due_seq <= l.global_seq
         AND NOT EXISTS (SELECT 1 FROM lesson_words lw WHERE lw.lesson_id = $2 AND lw.word_id = s.word_id)
       ORDER BY s.error_weight DESC, s.due_seq ASC, s.last_failed_at ASC NULLS LAST, w.id ASC
       LIMIT $3`,
      [userId, lessonId, limit],
    );
    return rows.map((r) => ({
      word: { wordId: str(r.id), wordText: str(r.word_text), sentenceContext: str(r.sentence_context), errorWeight: num(r.error_weight), meaningAr: nstr(r.meaning_ar), sentenceAr: nstr(r.sentence_ar) },
      dueSeq: num(r.due_seq),
      lastFailedAt: iso(r.last_failed_at),
    }));
  }

  async loadStats(userId: string, wordIds: readonly string[]): Promise<UserWordStat[]> {
    const ids = [...new Set(wordIds)];
    if (ids.length === 0) return [];
    const marks = ids.map((_, i) => `$${i + 2}`).join(', ');
    const { rows } = await this.c.query(
      `SELECT word_id, error_weight, status, due_seq, lifetime_failures, last_failed_at, last_reviewed_at
       FROM user_word_stats WHERE user_id = $1 AND word_id IN (${marks})`,
      [userId, ...ids],
    );
    return rows.map((r) => ({
      wordId: str(r.word_id), errorWeight: num(r.error_weight), status: str(r.status) as UserWordStat['status'],
      dueSeq: r.due_seq === null || r.due_seq === undefined ? null : num(r.due_seq),
      lifetimeFailures: num(r.lifetime_failures), lastFailedAt: iso(r.last_failed_at), lastReviewedAt: iso(r.last_reviewed_at),
    }));
  }

  async applyPlan(p: CommitPlan): Promise<{ totalXp: number }> {
    const s = p.session;
    await this.c.query(
      `INSERT INTO lesson_sessions (id, user_id, lesson_id, mode, parent_session_id, started_at, completed_at, words_total, words_clean, words_failed_twice, xp_earned)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`,
      [s.id, s.userId, s.lessonId, s.mode, s.parentSessionId, s.startedAt, s.completedAt, s.wordsTotal, s.wordsClean, s.wordsFailedTwice, s.xpEarned],
    );
    // One statement for the whole attempt log: a lesson has 40 or more attempts, and every separate statement is a
    // network round trip. 10 values per row; the 400-attempt cap keeps this far below PostgreSQL's 65535-parameter limit.
    if (p.attempts.length > 0) {
      const perRow = 10;
      const rows = p.attempts.map((_, i) => `(${Array.from({ length: perRow }, (_, c) => `$${i * perRow + c + 1}`).join(', ')})`);
      await this.c.query(
        `INSERT INTO session_attempts (session_id, n, word_id, origin, step, attempt_no, typed, distance, verdict, used_peek) VALUES ${rows.join(', ')}`,
        p.attempts.flatMap((a) => [a.sessionId, a.n, a.wordId, a.origin, a.step, a.attemptNo, a.typed, a.distance, a.verdict, a.usedPeek]),
      );
    }
    for (const st of p.statUpserts) {
      await this.c.query(
        `INSERT INTO user_word_stats (user_id, word_id, error_weight, status, due_seq, lifetime_failures, last_failed_at, last_reviewed_at)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
         ON CONFLICT (user_id, word_id) DO UPDATE SET
           error_weight = excluded.error_weight, status = excluded.status, due_seq = excluded.due_seq,
           lifetime_failures = excluded.lifetime_failures, last_failed_at = excluded.last_failed_at,
           last_reviewed_at = excluded.last_reviewed_at`,
        [s.userId, st.wordId, st.errorWeight, st.status, st.dueSeq, st.lifetimeFailures, st.lastFailedAt, st.lastReviewedAt],
      );
    }
    // Exact wrong spellings: add this session's counts to the lasting aggregate, widen the first/last window.
    for (const m of p.misspelled) {
      await this.c.query(
        `INSERT INTO misspelled_words (user_id, word_id, typed, occurrences, first_seen_at, last_seen_at)
         VALUES ($1, $2, $3, $4, $5, $6)
         ON CONFLICT (user_id, word_id, typed) DO UPDATE SET
           occurrences = misspelled_words.occurrences + excluded.occurrences,
           first_seen_at = LEAST(misspelled_words.first_seen_at, excluded.first_seen_at),
           last_seen_at = GREATEST(misspelled_words.last_seen_at, excluded.last_seen_at)`,
        [m.userId, m.wordId, m.typed, m.occurrences, m.firstSeenAt, m.lastSeenAt],
      );
    }
    for (const e of p.xpEvents) {
      await this.c.query('INSERT INTO xp_events (user_id, session_id, reason, amount) VALUES ($1, $2, $3, $4)', [e.userId, e.sessionId, e.reason, e.amount]);
    }
    // best_accuracy only ever goes up; last_accuracy is always the latest session (replays included).
    const lp = p.lessonProgress;
    await this.c.query(
      `INSERT INTO user_progress (user_id, lesson_id, first_completed_at, completions, best_accuracy, last_accuracy, last_played_at)
       VALUES ($1, $2, $3, 1, $4, $4, $5)
       ON CONFLICT (user_id, lesson_id) DO UPDATE SET
         first_completed_at = COALESCE(user_progress.first_completed_at, excluded.first_completed_at),
         completions = user_progress.completions + 1,
         best_accuracy = GREATEST(COALESCE(user_progress.best_accuracy, 0), excluded.best_accuracy),
         last_accuracy = excluded.last_accuracy,
         last_played_at = excluded.last_played_at`,
      [lp.userId, lp.lessonId, lp.firstCompletedAt, lp.accuracy, lp.lastPlayedAt],
    );
    await this.c.query(
      'UPDATE users SET streak_count = $2, longest_streak = $3, last_active_date = $4, time_zone = $5 WHERE id = $1',
      [s.userId, p.streak.streakCount, p.streak.longestStreak, p.streak.lastActiveDate, p.timeZone],
    );
    // users.total_xp is maintained by the trigger on xp_events.
    const { rows } = await this.c.query('SELECT total_xp FROM users WHERE id = $1', [s.userId]);
    return { totalXp: num(rows[0]?.total_xp) };
  }
}

export class PgRepo implements CommitRepo {
  private readonly pool: SqlPool;
  constructor(pool: SqlPool) {
    this.pool = pool;
  }

  async transaction<T>(fn: (tx: CommitTx) => Promise<T>): Promise<T> {
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      const result = await fn(new PgTx(client));
      await client.query('COMMIT');
      return result;
    } catch (e) {
      try {
        await client.query('ROLLBACK');
      } catch {
        /* connection already broken */
      }
      throw e;
    } finally {
      client.release();
    }
  }
}
