/**
 * Daily streak — by CALENDAR DAY in the user's own time zone (IANA name taken from the device,
 * e.g. "Asia/Riyadh"). Dates are 'YYYY-MM-DD' strings and day arithmetic never subtracts 24h,
 * so daylight-saving changes cannot break it.
 *   +1  first lesson completed on a new local day that directly follows the last active day
 *   =   more lessons on the same local day change nothing
 *   1   a missed local day resets it (the lesson just completed starts a new streak)
 * Pass the SERVER's `now`; only the time zone is the user's declaration (worst case a user claims
 * a zone up to 26h away, which shifts "today" by at most one day).
 */

export interface StreakState {
  streakCount: number;
  longestStreak: number;
  /** Last local day with a completed lesson, 'YYYY-MM-DD' in the user's time zone. */
  lastActiveDate: string | null;
}

export const EMPTY_STREAK: StreakState = { streakCount: 0, longestStreak: 0, lastActiveDate: null };

export function isValidTimeZone(tz: unknown): tz is string {
  if (typeof tz !== 'string' || tz.length === 0 || tz.length > 64) return false;
  try {
    new Intl.DateTimeFormat('en-CA', { timeZone: tz });
    return true;
  } catch {
    return false;
  }
}

/** The calendar date at instant `at` in `timeZone`, as 'YYYY-MM-DD'. */
export function localDate(at: Date, timeZone: string): string {
  return new Intl.DateTimeFormat('en-CA', { timeZone, year: 'numeric', month: '2-digit', day: '2-digit' }).format(at);
}

const dayNumber = (d: string): number => Date.UTC(Number(d.slice(0, 4)), Number(d.slice(5, 7)) - 1, Number(d.slice(8, 10))) / 86_400_000;

/** The number to DISPLAY now: active today or yesterday keeps the streak alive; older shows 0. */
export function effectiveStreak(s: StreakState, now: Date, timeZone: string): number {
  if (s.lastActiveDate === null) return 0;
  return dayNumber(localDate(now, timeZone)) - dayNumber(s.lastActiveDate) <= 1 ? s.streakCount : 0;
}

/** State after a lesson is completed at `now`. */
export function applyLessonCompletion(s: StreakState, now: Date, timeZone: string): StreakState {
  const today = localDate(now, timeZone);
  if (s.lastActiveDate === null) return { streakCount: 1, longestStreak: Math.max(s.longestStreak, 1), lastActiveDate: today };
  const gap = dayNumber(today) - dayNumber(s.lastActiveDate);
  if (gap <= 0) return s; // same day, or the clock / time zone moved backwards: nothing changes
  const count = gap === 1 ? s.streakCount + 1 : 1;
  return { streakCount: count, longestStreak: Math.max(s.longestStreak, count), lastActiveDate: today };
}
