/**
 * Builds the queue for ONE lesson, applying the "delayed review" rules:
 *   - at most `maxInjectedPerLesson` (2) historical mistake words are mixed in
 *   - they are dispersed through the lesson and never back-to-back
 *   - they are tested as standalone words only (no sentence step)
 *
 * Injected words are ADDED to the lesson's 20 new words (so a lesson has up to
 * 22 items before any same-session re-queues).
 */

import { DEFAULT_CONFIG } from './types.ts';
import type { EngineConfig, MistakeRecord, QueueItem, Rng, WordItem } from './types.ts';

export const toLessonItem = (word: WordItem): QueueItem => ({
  itemId: `L:${word.wordId}`,
  word,
  source: 'lesson',
  isReview: false,
  steps: ['word', 'sentence'],
});

export const toInjectedItem = (word: WordItem): QueueItem => ({
  itemId: `I:${word.wordId}`,
  word,
  source: 'injected',
  isReview: false,
  steps: ['word'],
});

/** Same-session re-queue of a failed item: always standalone (word step only). */
export const toReviewItem = (item: QueueItem): QueueItem => ({
  itemId: `R:${item.word.wordId}`,
  word: item.word,
  source: item.source,
  isReview: true,
  steps: ['word'],
});

function compareNullsLast(a: string | null, b: string | null): number {
  if (a === b) return 0;
  if (a === null) return 1;
  if (b === null) return -1;
  return a < b ? -1 : 1;
}

/**
 * Priority: heavier error_weight first → longest overdue → oldest failure → id (stable).
 * MUST stay in sync with ORDER BY in SQL function fn_due_mistakes().
 */
function byPriority(a: MistakeRecord, b: MistakeRecord): number {
  return (
    b.word.errorWeight - a.word.errorWeight ||
    a.dueSeq - b.dueSeq ||
    compareNullsLast(a.lastFailedAt, b.lastFailedAt) ||
    (a.word.wordId < b.word.wordId ? -1 : a.word.wordId > b.word.wordId ? 1 : 0)
  );
}

/** Which historical mistakes are injected into the lesson with global sequence `lessonSeq`. */
export function pickInjectedMistakes(
  history: readonly MistakeRecord[],
  lessonSeq: number,
  excludeWordIds: ReadonlySet<string>,
  cfg: EngineConfig = DEFAULT_CONFIG,
): MistakeRecord[] {
  const seen = new Set<string>();
  return history
    .filter((m) => {
      const id = m.word.wordId;
      if (seen.has(id) || excludeWordIds.has(id)) return false; // never twice, never a word the lesson already teaches
      if (m.dueSeq > lessonSeq || m.word.errorWeight <= 0) return false; // not due yet / not in rotation
      seen.add(id);
      return true;
    })
    .sort(byPriority)
    .slice(0, cfg.maxInjectedPerLesson);
}

/**
 * Picks `count` positions (0-based) inside a queue of `total` items:
 * one per equal segment, with jitter, never first/last, never adjacent.
 */
export function pickDispersedSlots(total: number, count: number, rng: Rng): number[] {
  if (count <= 0) return [];
  // Usable positions are 1..total-2 and neighbours need ≥ 1 item between them.
  if (count > Math.floor((total - 1) / 2)) {
    throw new RangeError(`cannot disperse ${count} items inside a queue of ${total}`);
  }

  const segment = total / (count + 1);
  const radius = Math.max(0, Math.floor(segment / 2) - 1);
  const slots: number[] = [];
  let previous = -Infinity;
  for (let j = 1; j <= count; j++) {
    const jitter = radius > 0 ? Math.floor(rng() * (2 * radius + 1)) - radius : 0;
    let slot = Math.min(Math.max(Math.round(j * segment) + jitter, 1), total - 2);
    if (slot < previous + 2) slot = previous + 2;
    slots.push(slot);
    previous = slot;
  }
  // Safety net: if pushing forward overflowed the tail, pull back from the end.
  let ceiling = total - 2;
  for (let i = slots.length - 1; i >= 0; i--) {
    const slot = Math.min(slots[i] ?? ceiling, ceiling);
    slots[i] = slot;
    ceiling = slot - 2;
  }
  return slots;
}

/** Weaves `injected` into `base` at dispersed positions; `base` order is preserved. */
export function mergeInjected<T>(base: readonly T[], injected: readonly T[], rng: Rng): T[] {
  const total = base.length + injected.length;
  const slots = pickDispersedSlots(total, injected.length, rng);
  const out: T[] = [];
  let b = 0;
  let j = 0;
  for (let i = 0; i < total; i++) {
    if (j < slots.length && slots[j] === i) {
      out.push(injected[j++] as T);
    } else {
      out.push(base[b++] as T);
    }
  }
  return out;
}

export interface BuildLessonArgs {
  /** The lesson's new words, in authored order (exactly `cfg.lessonSize`). */
  lessonWords: readonly WordItem[];
  /** The user's error rotation (rows from fn_due_mistakes, or any superset). */
  history: readonly MistakeRecord[];
  /** `lessons.global_seq` of the lesson being opened. */
  lessonSeq: number;
  cfg?: EngineConfig;
  rng?: Rng;
}

export function buildLessonQueue(args: BuildLessonArgs): QueueItem[] {
  const { lessonWords, history, lessonSeq, cfg = DEFAULT_CONFIG, rng = Math.random } = args;

  if (lessonWords.length !== cfg.lessonSize) {
    throw new RangeError(`a lesson must contain exactly ${cfg.lessonSize} words (got ${lessonWords.length})`);
  }
  const lessonIds = new Set(lessonWords.map((w) => w.wordId));
  if (lessonIds.size !== lessonWords.length) throw new Error('duplicate wordId inside a lesson');

  const injected = pickInjectedMistakes(history, lessonSeq, lessonIds, cfg).map((m) => toInjectedItem(m.word));
  return mergeInjected(lessonWords.map(toLessonItem), injected, rng);
}
