/**
 * Lesson session state machine (immutable, reducer-style, JSON-serialisable).
 *
 *   startSession() → [ currentPrompt() → (peek()) → submit() ]* → summarize()
 *
 * Per-word flow
 *   Step 1 (word)      exact                      → pass            (+10 first try / +5 otherwise)
 *                      minor (distance 1)         → re-type to pass (not carried over)
 *                      major (distance > 1)       → FAIL
 *                      2nd non-exact attempt      → FAIL            ("fails multiple times")
 *   Step 2 (sentence)  only for brand-new lesson words, after step 1 passed. Mandatory to attempt,
 *                      forgiving match; a wrong sentence is NOT repeated (the lesson moves on, the UI
 *                      shows the correction). No XP and no SRS consequences either way.
 *   FAIL (first presentation) → word is re-queued, standalone, after the next 2–3 items;
 *                               the sentence step is skipped.
 *   FAIL (inside its immediate review) → "failed twice": stats.ts raises error_weight and
 *                               schedules the word for a FUTURE lesson. No third attempt in-session.
 */

import { DEFAULT_CONFIG } from './types.ts';
import type { EngineConfig, ItemSource, QueueItem, Rng, StepKind } from './types.ts';
import { evaluateSentence, evaluateWord } from './spelling.ts';
import type { Verdict } from './spelling.ts';
import { toReviewItem } from './queue-builder.ts';

export type SessionMode = 'first_run' | 'replay';
export type Phase = 'awaiting_input' | 'awaiting_retype' | 'completed';

type FirstPass = 'clean' | 'assisted' | 'minor_recovered' | 'failed';
type ReviewPass = 'passed' | 'failed';

/** Running record per word (a word is presented at most twice: first time + one immediate review). */
export interface WordRecord {
  wordId: string;
  source: ItemSource;
  first: FirstPass | null;
  review: ReviewPass | null;
}

/** Buckets match the `reason` values of table xp_events. */
export interface XpBreakdown {
  firstTry: number;
  recovered: number;
  lessonBonus: number;
}

/** One row per submission; maps 1:1 to table session_attempts. */
export interface AttemptLog {
  n: number;
  itemId: string;
  wordId: string;
  origin: 'lesson' | 'injected' | 'immediate_review';
  step: StepKind;
  attemptNo: number;
  input: string;
  distance: number;
  verdict: Verdict;
  usedPeek: boolean;
  at: string;
}

export interface SessionState {
  readonly sessionId: string;
  readonly lessonSeq: number;
  readonly mode: SessionMode;
  /** queue[0] is the item on screen. */
  readonly queue: readonly QueueItem[];
  readonly stepIndex: number;
  readonly phase: Phase;
  /** Non-exact attempts on the current step. */
  readonly failedAttempts: number;
  /** The Show/Hide toggle was used on the current step. */
  readonly peeked: boolean;
  readonly itemsDone: number;
  readonly records: Readonly<Record<string, WordRecord>>;
  readonly xp: Readonly<XpBreakdown>;
  readonly log: readonly AttemptLog[];
}

export interface Prompt {
  itemId: string;
  wordId: string;
  step: StepKind;
  /** Spoken by TTS AND the expected answer (the UI uses it for placeholders, peek and the green fill). */
  text: string;
  source: ItemSource;
  isReview: boolean;
  /** True after a minor slip / sentence mismatch: the user must re-type correctly to advance. */
  retype: boolean;
}

export type SubmitEvent =
  | { kind: 'correct'; step: StepKind; xp: number; lessonCompleted: boolean }
  | { kind: 'retype'; reason: 'minor_slip' }
  /** Sentence typed wrongly: not repeated; `reveal` is the correct sentence to show. */
  | { kind: 'sentence_missed'; reveal: string; lessonCompleted: boolean }
  /** `reveal` = correct spelling to show. `requeueAfter` = items before the review (null if this WAS the review). */
  | { kind: 'failed'; reveal: string; requeueAfter: number | null; lessonCompleted: boolean };

export interface SubmitResult {
  state: SessionState;
  event: SubmitEvent;
  verdict: Verdict;
  distance: number;
}

export interface SubmitContext {
  now: Date;
  rng?: Rng;
  cfg?: EngineConfig;
}

export type WordResult = 'clean' | 'assisted' | 'minor_recovered' | 'review_recovered' | 'failed_twice';

export interface WordOutcome {
  wordId: string;
  source: ItemSource;
  result: WordResult;
}

export interface SessionSummary {
  sessionId: string;
  lessonSeq: number;
  mode: SessionMode;
  outcomes: WordOutcome[];
  xp: XpBreakdown & { total: number };
  attempts: AttemptLog[];
}

// ─── public API ──────────────────────────────────────────────────────────────

export function startSession(args: {
  sessionId: string;
  lessonSeq: number;
  queue: readonly QueueItem[];
  mode?: SessionMode;
}): SessionState {
  if (args.queue.length === 0) throw new Error('cannot start a session with an empty queue');
  return {
    sessionId: args.sessionId,
    lessonSeq: args.lessonSeq,
    mode: args.mode ?? 'first_run',
    queue: args.queue,
    stepIndex: 0,
    phase: 'awaiting_input',
    failedAttempts: 0,
    peeked: false,
    itemsDone: 0,
    records: {},
    xp: { firstTry: 0, recovered: 0, lessonBonus: 0 },
    log: [],
  };
}

export function currentPrompt(state: SessionState): Prompt | null {
  if (state.phase === 'completed') return null;
  const { item, step } = currentOf(state);
  return {
    itemId: item.itemId,
    wordId: item.word.wordId,
    step,
    text: step === 'word' ? item.word.wordText : item.word.sentenceContext,
    source: item.source,
    isReview: item.isReview,
    retype: state.phase === 'awaiting_retype',
  };
}

/** Call when the user taps the Show/Hide toggle. A peeked first-try success earns the lower XP tier. */
export function peek(state: SessionState): SessionState {
  return state.phase === 'completed' || state.peeked ? state : { ...state, peeked: true };
}

export function submit(state: SessionState, input: string, ctx: SubmitContext): SubmitResult {
  if (state.phase === 'completed') throw new Error('session is already completed');
  const cfg = ctx.cfg ?? DEFAULT_CONFIG;
  const rng = ctx.rng ?? Math.random;
  const { item, step } = currentOf(state);

  const { verdict, distance } =
    step === 'word'
      ? evaluateWord(input, item.word.wordText, cfg.maxMinorDistance)
      : evaluateSentence(input, item.word.sentenceContext, cfg.maxMinorDistance);

  const logged: SessionState = {
    ...state,
    log: [
      ...state.log,
      {
        n: state.log.length + 1,
        itemId: item.itemId,
        wordId: item.word.wordId,
        origin: item.isReview ? 'immediate_review' : item.source,
        step,
        attemptNo: state.failedAttempts + 1,
        input,
        distance,
        verdict,
        usedPeek: state.peeked,
        at: ctx.now.toISOString(),
      },
    ],
  };

  // Step 2 — sentence: mandatory to attempt, forgiving match, never touches the SRS.
  // A wrong sentence is NOT repeated: the lesson moves on and the UI shows the correction.
  if (step === 'sentence') {
    const next = advance(logged, cfg);
    const lessonCompleted = next.phase === 'completed';
    return verdict === 'exact'
      ? { state: next, verdict, distance, event: { kind: 'correct', step, xp: 0, lessonCompleted } }
      : { state: next, verdict, distance, event: { kind: 'sentence_missed', reveal: item.word.sentenceContext, lessonCompleted } };
  }

  // Step 1 — standalone word.
  if (verdict === 'exact') {
    const tier: PassTier = state.failedAttempts > 0 ? 'recovered' : state.peeked ? 'assisted' : 'first_try';
    const { state: next, xp } = passWord(logged, item, tier, cfg);
    return { state: next, verdict, distance, event: { kind: 'correct', step, xp, lessonCompleted: next.phase === 'completed' } };
  }

  const failures = state.failedAttempts + 1;
  if (verdict === 'minor' && failures < cfg.failuresBeforeMajor) {
    const retype: SessionState = { ...logged, phase: 'awaiting_retype', failedAttempts: failures };
    return { state: retype, verdict, distance, event: { kind: 'retype', reason: 'minor_slip' } };
  }

  const { state: next, requeueAfter } = failWord(logged, item, cfg, rng);
  return {
    state: next,
    verdict,
    distance,
    event: { kind: 'failed', reveal: item.word.wordText, requeueAfter, lessonCompleted: next.phase === 'completed' },
  };
}

/** Only valid once phase === 'completed'. */
export function summarize(state: SessionState): SessionSummary {
  if (state.phase !== 'completed') throw new Error('session is not completed yet');
  return {
    sessionId: state.sessionId,
    lessonSeq: state.lessonSeq,
    mode: state.mode,
    outcomes: Object.values(state.records).map(toOutcome),
    xp: { ...state.xp, total: state.xp.firstTry + state.xp.recovered + state.xp.lessonBonus },
    attempts: [...state.log],
  };
}

/** For the in-lesson progress bar. `total` grows by one whenever a word is re-queued. */
export function sessionProgress(state: SessionState): { done: number; total: number } {
  return { done: state.itemsDone, total: state.itemsDone + state.queue.length };
}

// ─── internals ───────────────────────────────────────────────────────────────

type PassTier = 'first_try' | 'assisted' | 'recovered';

function currentOf(state: SessionState): { item: QueueItem; step: StepKind } {
  const item = state.queue[0];
  const step = item?.steps[state.stepIndex];
  if (!item || !step) throw new Error('session has no current step');
  return { item, step };
}

const freshRecord = (item: QueueItem): WordRecord => ({
  wordId: item.word.wordId,
  source: item.source,
  first: null,
  review: null,
});

const xpDisabled = (s: SessionState, cfg: EngineConfig): boolean => s.mode === 'replay' && !cfg.replayAwardsXp;

function passWord(s: SessionState, item: QueueItem, tier: PassTier, cfg: EngineConfig): { state: SessionState; xp: number } {
  const rec = s.records[item.word.wordId] ?? freshRecord(item);
  const updated: WordRecord = item.isReview
    ? { ...rec, review: 'passed' }
    : { ...rec, first: tier === 'first_try' ? 'clean' : tier === 'assisted' ? 'assisted' : 'minor_recovered' };

  // Full XP only for a brand-new lesson word answered correctly, unaided, on the first attempt.
  const fullTier = !item.isReview && tier === 'first_try' && item.source === 'lesson';
  const xp = xpDisabled(s, cfg) ? 0 : fullTier ? cfg.xp.firstTry : cfg.xp.recovered;

  const withRecord: SessionState = {
    ...s,
    records: { ...s.records, [item.word.wordId]: updated },
    xp: fullTier ? { ...s.xp, firstTry: s.xp.firstTry + xp } : { ...s.xp, recovered: s.xp.recovered + xp },
  };
  return { state: advance(withRecord, cfg), xp };
}

function failWord(s: SessionState, item: QueueItem, cfg: EngineConfig, rng: Rng): { state: SessionState; requeueAfter: number | null } {
  const rec = s.records[item.word.wordId] ?? freshRecord(item);
  const updated: WordRecord = item.isReview ? { ...rec, review: 'failed' } : { ...rec, first: 'failed' };

  let remaining = s.queue.slice(1);
  let requeueAfter: number | null = null;
  if (!item.isReview) {
    // Immediate review: standalone, after the next 2–3 items (or at the very end if fewer remain).
    const { min, max } = cfg.immediateReviewGap;
    requeueAfter = Math.min(min + Math.floor(rng() * (max - min + 1)), remaining.length);
    remaining = [...remaining.slice(0, requeueAfter), toReviewItem(item), ...remaining.slice(requeueAfter)];
  }
  // A review that fails is final for this session: no third attempt (prevents endless loops).
  const state = nextItem({ ...s, records: { ...s.records, [item.word.wordId]: updated } }, remaining, cfg);
  return { state, requeueAfter };
}

/** Finish the current step: go to the next step of the same item, or on to the next item. */
function advance(s: SessionState, cfg: EngineConfig): SessionState {
  const { item } = currentOf(s);
  if (s.stepIndex + 1 < item.steps.length) {
    return { ...s, stepIndex: s.stepIndex + 1, phase: 'awaiting_input', failedAttempts: 0, peeked: false };
  }
  return nextItem(s, s.queue.slice(1), cfg);
}

function nextItem(s: SessionState, queue: readonly QueueItem[], cfg: EngineConfig): SessionState {
  const done = queue.length === 0;
  const bonus = done && !xpDisabled(s, cfg) ? cfg.xp.lessonBonus : 0;
  return {
    ...s,
    queue,
    stepIndex: 0,
    phase: done ? 'completed' : 'awaiting_input',
    failedAttempts: 0,
    peeked: false,
    itemsDone: s.itemsDone + 1,
    xp: bonus > 0 ? { ...s.xp, lessonBonus: s.xp.lessonBonus + bonus } : s.xp,
  };
}

function toOutcome(r: WordRecord): WordOutcome {
  if (r.first === null) throw new Error(`word ${r.wordId} was never answered`);
  if (r.first !== 'failed') return { wordId: r.wordId, source: r.source, result: r.first };
  if (r.review === null) throw new Error(`word ${r.wordId} failed but its review never ran`);
  return { wordId: r.wordId, source: r.source, result: r.review === 'passed' ? 'review_recovered' : 'failed_twice' };
}
