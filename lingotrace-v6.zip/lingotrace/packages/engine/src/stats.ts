/**
 * Delayed review: converts a finished session into updates for the user's
 * error rotation (table `user_word_stats`).
 *
 *   failed twice          → error_weight + 1, active, due again in `reviewGapLessons` lessons
 *   clean, already in rotation → error_weight − 1; at 0 the word is "mastered" and leaves the rotation
 *   any other success, already in rotation → weight unchanged, rescheduled
 *   everything else (incl. minor slips and same-session recoveries) → nothing is carried over
 *
 * Returns ONLY the rows that must be upserted. The result always satisfies the CHECK
 * constraint on user_word_stats:
 *   active   ⇒ error_weight ≥ 1 and due_seq NOT NULL
 *   mastered ⇒ error_weight = 0 and due_seq NULL
 */

import { DEFAULT_CONFIG } from './types.ts';
import type { EngineConfig, UserWordStat } from './types.ts';
import type { SessionSummary } from './session.ts';

export function applySummaryToStats(
  summary: SessionSummary,
  previous: readonly UserWordStat[],
  now: Date,
  cfg: EngineConfig = DEFAULT_CONFIG,
): UserWordStat[] {
  if (summary.mode === 'replay') return []; // replays never touch the rotation

  const prev = new Map(previous.map((s) => [s.wordId, s]));
  const at = now.toISOString();
  const dueSeq = summary.lessonSeq + cfg.reviewGapLessons;
  const updates: UserWordStat[] = [];

  for (const o of summary.outcomes) {
    const p = prev.get(o.wordId);

    if (o.result === 'failed_twice') {
      updates.push({
        wordId: o.wordId,
        errorWeight: (p?.errorWeight ?? 0) + 1,
        status: 'active',
        dueSeq,
        lifetimeFailures: (p?.lifetimeFailures ?? 0) + 1,
        lastFailedAt: at,
        lastReviewedAt: at,
      });
      continue;
    }

    if (p?.status !== 'active') continue; // not in the rotation → nothing to update

    if (o.result === 'clean') {
      const weight = Math.max(0, p.errorWeight - 1);
      updates.push({
        ...p,
        errorWeight: weight,
        status: weight === 0 ? 'mastered' : 'active',
        dueSeq: weight === 0 ? null : dueSeq,
        lastReviewedAt: at,
      });
    } else {
      updates.push({ ...p, dueSeq, lastReviewedAt: at });
    }
  }
  return updates;
}
