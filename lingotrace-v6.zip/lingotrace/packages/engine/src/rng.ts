import type { Rng } from './types.ts';

/**
 * Seedable PRNG (mulberry32).
 * The client plays a session with createRng(seed) and sends the seed with the commit;
 * the server replays the session with the SAME seed, so the random choices
 * (injection positions, 2-or-3 re-queue gap) are reproduced exactly.
 */
export function createRng(seed: number): Rng {
  let a = seed | 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** A fresh unsigned 32-bit seed for a new session (client side). */
export const newSeed = (): number => Math.floor(Math.random() * 4294967296) >>> 0;
