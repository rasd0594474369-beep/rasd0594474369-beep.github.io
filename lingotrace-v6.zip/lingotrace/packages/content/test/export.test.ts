import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync } from 'node:fs';
import { LEVEL_ORDER, parseContent, parseCsv } from '../src/content-import.ts';
import { buildContentJson, buildCsvs, buildLevelSeedSql, csvField } from '../src/export-supabase.ts';
import type { ContentJson } from '../src/export-supabase.ts';
import { lessonId, uuidV5, wordId } from '../src/ids.ts';
import { openTwin, type Db } from '../../../supabase/tests/twin/translate.ts';

const parsed = parseContent(readFileSync(new URL('../data/words.csv', import.meta.url), 'utf8'));
assert.deepEqual(parsed.errors, []);
const content = parsed.content!;
const allWords = content.lessons.flatMap((l) => l.words);
const coreDir = new URL('../../../supabase/migrations/', import.meta.url);
const coreSql = readFileSync(new URL(readdirSync(coreDir).find((f) => f.endsWith('_core_schema.sql'))!, coreDir), 'utf8');
const count = (db: Db, t: string) => Number(db.prepare(`SELECT count(*) AS n FROM ${t}`).all()[0]!.n);

describe('ids', () => {
  it('uuidV5 matches the RFC 4122 test vector, and the ids of existing content never change', () => {
    assert.equal(uuidV5('www.example.com', '6ba7b810-9dad-11d1-80b4-00c04fd430c8'), '2ed6657d-e927-568b-95e1-2665a8aea6a2');
    assert.equal(wordId('bridge'), '9e3b2e84-f287-50c4-a9b0-e2688d32efa6'); // pinned: the same id as in the first seed
    assert.equal(wordId('  Fortunate '), 'e9f5f3bf-aa1f-5a47-81b3-b1fe11d5c0fb');
    assert.equal(lessonId('A1', 1), '32fd4a60-5d2c-56dc-a582-8bf9fc415ad0');
  });
});

describe('the shipped content', () => {
  it('is 2,800 words in 140 lessons of 20 across A1-B2, all with Arabic', () => {
    assert.equal(content.lessons.length, 140);
    assert.equal(allWords.length, 2800);
    assert.ok(content.lessons.every((l) => l.words.length === 20));
    assert.deepEqual(content.levels.filter((l) => l.lessons > 0).map((l) => l.code), ['A1', 'A2', 'B1', 'B2']);
    assert.ok(allWords.every((w) => w.meaning && w.sentenceAr && /[\u0600-\u06FF]/.test(w.meaning + w.sentenceAr)));
    // the importer's informational notes about lesson counts are expected; anything about missing Arabic is not
    assert.deepEqual(parsed.warnings.filter((w) => /translation|meaning|Arabic/i.test(w.message)), []);
  });
});

describe('CSV export (dashboard import)', () => {
  const csv = buildCsvs(content);
  const rows = (s: string) => parseCsv(s).slice(1);

  it('has the right row counts and headers', () => {
    assert.equal(rows(csv.lessons).length, 140);
    assert.equal(rows(csv.vocabularyBank).length, 2800);
    assert.equal(rows(csv.lessonWords).length, 2800);
    assert.deepEqual(parseCsv(csv.lessons)[0], ['id', 'level_code', 'lesson_number', 'global_seq', 'is_published']);
    assert.deepEqual(parseCsv(csv.vocabularyBank)[0], ['id', 'word_text', 'sentence_context', 'meaning_ar', 'sentence_ar', 'level_code', 'freq_rank']);
    assert.deepEqual(parseCsv(csv.lessonWords)[0], ['lesson_id', 'position', 'word_id']);
  });

  it('is consistent: unique ids, dense global_seq, 20 positions per lesson, every link resolves, word level = lesson level', () => {
    const lessons = rows(csv.lessons);
    const words = rows(csv.vocabularyBank);
    const links = rows(csv.lessonWords);
    assert.equal(new Set(lessons.map((r) => r[0])).size, 140);
    assert.equal(new Set(words.map((r) => r[0])).size, 2800);
    assert.deepEqual(lessons.map((r) => Number(r[3])).sort((a, b) => a - b), Array.from({ length: 140 }, (_, i) => i + 1));
    const levelOfLesson = new Map(lessons.map((r) => [r[0]!, r[1]!]));
    const wordsById = new Map(words.map((r) => [r[0]!, r]));
    const perLesson = new Map<string, number[]>();
    for (const [lid, pos, wid] of links) {
      assert.ok(levelOfLesson.has(lid!), `unknown lesson ${lid}`);
      assert.ok(wordsById.has(wid!), `unknown word ${wid}`);
      assert.equal(wordsById.get(wid!)![5], levelOfLesson.get(lid!), 'word level must equal its lesson level');
      perLesson.set(lid!, [...(perLesson.get(lid!) ?? []), Number(pos)]);
    }
    for (const [lid, positions] of perLesson) assert.deepEqual(positions.sort((a, b) => a - b), Array.from({ length: 20 }, (_, i) => i + 1), `lesson ${lid}`);
    assert.equal(new Set(links.map((r) => r[2])).size, 2800, 'every word is in exactly one lesson');
  });

  it('quotes commas, quotes and Arabic correctly (round trip equals the source)', () => {
    assert.equal(csvField('a,b'), '"a,b"');
    assert.equal(csvField('say "hi"'), '"say ""hi"""');
    const back = rows(csv.vocabularyBank);
    const withComma = allWords.find((w) => w.sentence.includes(','))!;
    const r = back.find((x) => x[0] === wordId(withComma.text))!;
    assert.equal(r[2], withComma.sentence);
    assert.equal(r[3], withComma.meaning);
    assert.equal(r[4], withComma.sentenceAr);
  });

  it('has the rank bands for the four levels', () => {
    assert.equal(csv.levelRankBandsSql.split('\n').filter((l) => l.startsWith('update')).length, 4);
    assert.match(csv.levelRankBandsSql, /update public\.levels set rank_from = 1, rank_to = 700 where code = 'A1';/);
  });
});

describe('SQL seed (run on the SQLite twin of the core schema)', () => {
  const files = LEVEL_ORDER.map((l) => buildLevelSeedSql(content, l)).filter((s): s is string => s !== null);
  // strip the schema prefix of the statements only (never inside the data: the sentence of the word 'public' ends with "public."),
  // and do not use translateMigration, which splits on ';' (sentences contain ';')
  const run = (db: Db) => files.forEach((f) => db.exec(f.replace(/\b(insert into|update) public\./g, '$1 ')));

  it('one file per level for A1-B2, none for C1, each in its own transaction', () => {
    assert.equal(files.length, 4);
    assert.equal(buildLevelSeedSql(content, 'C1'), null);
    for (const f of files) assert.match(f, /^-- Generated by[\s\S]*\nbegin;\n[\s\S]*\ncommit;\n$/);
  });

  it('loads cleanly into the real schema constraints, with the right counts, and loading twice changes nothing', async () => {
    const db = await openTwin(coreSql);
    run(db);
    const snapshot = () => ['lessons', 'vocabulary_bank', 'lesson_words'].map((t) => count(db, t));
    assert.deepEqual(snapshot(), [140, 2800, 2800]);
    run(db);
    assert.deepEqual(snapshot(), [140, 2800, 2800]);
    assert.deepEqual(db.prepare("SELECT code, rank_from AS f, rank_to AS t FROM levels WHERE rank_from IS NOT NULL ORDER BY ordinal").all().map((r) => `${r.code}:${r.f}-${r.t}`), ['A1:1-700', 'A2:701-1400', 'B1:1401-2100', 'B2:2101-2800']);
    assert.equal(count(db, "vocabulary_bank WHERE sentence_ar IS NOT NULL AND meaning_ar IS NOT NULL"), 2800);
    assert.equal(count(db, 'lessons WHERE is_published = 1'), 140);
  });

  it('every lesson has 20 words, every sentence contains its word, and Arabic survives', async () => {
    const db = await openTwin(coreSql);
    run(db);
    assert.equal(count(db, '(SELECT lesson_id FROM lesson_words GROUP BY lesson_id HAVING count(*) <> 20)'), 0);
    const bad = db.prepare("SELECT word_text FROM vocabulary_bank WHERE instr(lower(sentence_context), lower(word_text)) = 0").all();
    assert.deepEqual(bad, []);
    const fortunate = db.prepare("SELECT sentence_ar AS s FROM vocabulary_bank WHERE word_text = 'fortunate'").all()[0]!.s;
    assert.equal(fortunate, content.lessons.flatMap((l) => l.words).find((w) => w.text === 'fortunate')!.sentenceAr);
  });
});

describe('content.json and the script that imports it', () => {
  const seedDir = new URL('../../../supabase/seed/', import.meta.url);
  const importSql = readFileSync(new URL('20_import_content_from_storage.sql', seedDir), 'utf8');
  const doc = JSON.parse(buildContentJson(content)) as ContentJson;
  const normalize = (sql: string) => sql.replace(/\s+/g, ' ').trim();
  const csvRows = (name: string) => {
    const [header, ...rows] = parseCsv(readFileSync(new URL(`csv/${name}`, seedDir), 'utf8')).filter((r) => r.length > 1);
    return rows.map((r) => Object.fromEntries(header!.map((h, i) => [h, r[i] ?? ''])));
  };

  it('holds the whole shipped content, with the Arabic intact', () => {
    assert.deepEqual([doc.lessons.length, doc.words.length, doc.lesson_words.length, doc.rank_bands.length], [140, 2800, 2800, 4]);
    assert.equal(doc.version, 1);
    assert.deepEqual(doc.words.map((w) => w.meaning_ar), allWords.map((w) => w.meaning));
    assert.deepEqual(doc.words.map((w) => w.sentence_ar), allWords.map((w) => w.sentenceAr));
    assert.ok(doc.words.every((w) => /[\u0600-\u06FF]/.test(`${w.meaning_ar}${w.sentence_ar}`)));
    assert.ok(doc.lesson_words.every(([lesson, position, word]) => lesson.length === 36 && position >= 1 && position <= 20 && word.length === 36));
  });

  it('has exactly the rows of the CSV files (two independent serialisations of the same content)', () => {
    assert.deepEqual(
      doc.lessons.map((l) => [l.id, l.level_code, String(l.lesson_number), String(l.global_seq), String(l.is_published)]),
      csvRows('01_lessons.csv').map((r) => [r.id, r.level_code, r.lesson_number, r.global_seq, r.is_published]),
    );
    assert.deepEqual(
      doc.words.map((w) => [w.id, w.word_text, w.sentence_context, w.meaning_ar ?? '', w.sentence_ar ?? '', w.level_code, String(w.freq_rank ?? '')]),
      csvRows('02_vocabulary_bank.csv').map((r) => [r.id, r.word_text, r.sentence_context, r.meaning_ar, r.sentence_ar, r.level_code, r.freq_rank]),
    );
    assert.deepEqual(
      doc.lesson_words.map(([lesson, position, word]) => [lesson, String(position), word]),
      csvRows('03_lesson_words.csv').map((r) => [r.lesson_id, r.position, r.word_id]),
    );
  });

  it('is deterministic, and the committed supabase/seed/content.json is the current export (regenerate with: node packages/content/scripts/export-supabase.ts)', () => {
    assert.equal(buildContentJson(content), buildContentJson(content));
    assert.equal(readFileSync(new URL('content.json', seedDir), 'utf8') === buildContentJson(content), true, 'content.json is out of date');
  });

  it('turns an empty Arabic field into null, like the SQL seed does', () => {
    const blank = { ...content, lessons: content.lessons.map((l, i) => (i === 0 ? { ...l, words: l.words.map((w, j) => (j === 0 ? { ...w, meaning: '', sentenceAr: '' } : w)) } : l)) };
    const first = (JSON.parse(buildContentJson(blank as typeof content)) as ContentJson).words[0]!;
    assert.deepEqual([first.meaning_ar, first.sentence_ar], [null, null]);
  });

  it('the import script reads exactly the keys that content.json has, and writes columns that exist in the schema', async () => {
    const reads = [...importSql.matchAll(/jsonb_to_recordset\(doc->'(\w+)'\) as \w+\(([^)]*)\)/g)].map((m) => [m[1]!, m[2]!.split(',').map((c) => c.trim().split(' ')[0]!)] as const);
    assert.deepEqual(reads.map(([key]) => key), ['rank_bands', 'lessons', 'words']);
    for (const [key, columns] of reads) {
      assert.deepEqual(columns, Object.keys((doc as unknown as Record<string, Array<Record<string, unknown>>>)[key]![0]!), `${key}: columns of the script vs keys of the file`);
    }
    assert.match(importSql, /jsonb_array_elements\(doc->'lesson_words'\)/);
    // the insert lists name real columns (the schema is the real core_schema migration on the SQLite twin)
    const db = await openTwin(coreSql);
    const columnsOf = (table: string) => db.prepare(`SELECT name FROM pragma_table_info('${table}')`).all().map((r) => String(r.name));
    for (const m of importSql.matchAll(/insert into public\.(\w+) \(([^)]*)\)/g)) {
      const missing = m[2]!.split(',').map((c) => c.trim()).filter((c) => !columnsOf(m[1]!).includes(c));
      assert.deepEqual(missing, [], `${m[1]}: columns that do not exist`);
    }
    for (const col of ['code', 'rank_from', 'rank_to']) assert.ok(columnsOf('levels').includes(col), `levels.${col}`);
  });

  it('the import script upserts exactly like the SQL seed does', () => {
    const seed = readFileSync(new URL('10_content_A1.sql', seedDir), 'utf8');
    const clauses = (sql: string) => [...normalize(sql).matchAll(/on conflict \([^)]*\) do update set [^;]*?(?= (?:insert|update|select|commit|with|\) ?;)|;|$)/g)].map((m) => m[0]);
    const fromSeed = new Set(clauses(seed).map((c) => c.replace(/;$/, '').trim()));
    for (const clause of clauses(importSql).map((c) => c.replace(/;$/, '').trim())) {
      assert.ok([...fromSeed].some((f) => f.startsWith(clause) || clause.startsWith(f)), `not in the SQL seed: ${clause.slice(0, 90)}`);
    }
  });

  it('is one all-or-nothing transaction that cleans up after itself, in plain ASCII', () => {
    const code = importSql.replace(/--[^\n]*/g, '').trim();
    assert.match(code, /^begin;/);
    assert.match(code, /commit;$/);
    assert.equal((code.match(/\bbegin;/g) ?? []).length, 1);
    assert.doesNotMatch(importSql, /[^\x00-\x7F]/);
    // the extension is created only when absent and dropped only when this script created it
    assert.match(code, /had_http boolean := exists \(select 1 from pg_extension where extname = 'http'\)/);
    assert.match(code, /if not had_http then\s+execute 'create extension http with schema extensions';/);
    assert.match(code, /if not had_http and raw is not null and exists[^;]*then\s+execute 'drop extension http';/);
    // every table write is followed by a check of how many rows it touched
    assert.equal((code.match(/get diagnostics affected = row_count;/g) ?? []).length, 4);
    assert.equal((code.match(/raise exception '(rank bands|lessons|words|lesson_words):/g) ?? []).length, 4);
  });
});
