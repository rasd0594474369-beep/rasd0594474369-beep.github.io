# Attribution

The word list is derived from the **New General Service List (NGSL) v1.2** by Charles Browne, Brent Culligan and
Joseph Phillips, licensed under **CC BY-SA 4.0** (https://creativecommons.org/licenses/by-sa/4.0/).
The app must credit the NGSL (for example in Settings > About), and derivative word lists stay under the same license.
Verify the current license text at https://www.newgeneralservicelist.org before publishing.

The example sentences, the Arabic meanings and the Arabic sentence translations were written for this project and
still need a native-speaker review before release.
