/**
 * Words-file importer (pure: no fs, no Node APIs).
 *
 * CSV columns (header row required, any order, case-insensitive):
 *   level     A1 | A2 | B1 | B2 | C1                              (alias: cefr, المستوى)
 *   word      the target spelling                                  (alias: word_text, الكلمة)
 *   sentence  a sentence using the word                            (alias: sentence_context, example, الجملة)
 *   lesson    optional, 1-based number inside the level            (alias: lesson_number, الدرس)
 *   meaning   optional Arabic meaning shown with the word                  (alias: meaning_ar, المعنى)
 *   sentence_ar  optional Arabic translation of the sentence, shown as «الترجمة»   (alias: sentence_translation, ترجمة_الجملة)
 *   rank      optional global frequency rank (used for "Global Rank 501–1000")   (alias: freq_rank, الترتيب)
 *
 * Without a `lesson` column the rows of each level are cut, in file order, into lessons of 20.
 * Separators , ; or tab are detected; quotes, BOM and CRLF are handled (Excel "CSV UTF-8" works).
 */

import type { LevelCode } from './levels.ts';

export const LEVEL_ORDER: readonly LevelCode[] = ['A1', 'A2', 'B1', 'B2', 'C1'];

export interface ContentWord { text: string; sentence: string; rank: number | null; meaning: string | null; sentenceAr: string | null }
export interface ContentLesson { levelCode: LevelCode; lessonNumber: number; globalSeq: number; words: ContentWord[] }
/**
 * content.json word entry, the format the demo page reads: [text, sentence, meaning, sentenceAr].
 * Trailing fields are dropped when empty; the meaning is '' when only the translation exists.
 */
export function appWordEntry(w: ContentWord): string[] {
  const e = [w.text, w.sentence];
  if (w.meaning || w.sentenceAr) e.push(w.meaning ?? '');
  if (w.sentenceAr) e.push(w.sentenceAr);
  return e;
}
export interface LevelSummary { code: LevelCode; lessons: number; words: number; rankFrom: number | null; rankTo: number | null }
export interface ContentSet { lessons: ContentLesson[]; levels: LevelSummary[] }
/** `row` = spreadsheet row number (the header is row 1; blank lines are ignored). */
export interface Issue { row: number | null; message: string }
export interface ImportResult { content: ContentSet | null; errors: Issue[]; warnings: Issue[] }

// ─── CSV ─────────────────────────────────────────────────────────────────────

function detectDelimiter(text: string): string {
  const first = text.split(/\r?\n/, 1)[0] ?? '';
  let best = ',';
  let bestCount = 0;
  for (const d of [',', ';', '\t']) {
    const n = first.split(d).length - 1;
    if (n > bestCount) { best = d; bestCount = n; }
  }
  return best;
}

export function parseCsv(input: string, delimiter?: string): string[][] {
  const text = input.replace(/^\uFEFF/, '');
  const d = delimiter ?? detectDelimiter(text);
  const rows: string[][] = [];
  let row: string[] = [];
  let field = '';
  let quoted = false;
  for (let i = 0; i < text.length; i++) {
    const c = text.charAt(i);
    if (quoted) {
      if (c === '"') {
        if (text.charAt(i + 1) === '"') { field += '"'; i++; } else quoted = false;
      } else field += c;
    } else if (c === '"' && field === '') quoted = true;
    else if (c === d) { row.push(field); field = ''; }
    else if (c === '\n' || c === '\r') {
      if (c === '\r' && text.charAt(i + 1) === '\n') i++;
      row.push(field); field = ''; rows.push(row); row = [];
    } else field += c;
  }
  if (field !== '' || row.length > 0) { row.push(field); rows.push(row); }
  return rows.filter((r) => r.some((f) => f.trim() !== ''));
}

// ─── parsing + validation ────────────────────────────────────────────────────

const ALIASES = {
  level: ['level', 'cefr', 'المستوى'],
  word: ['word', 'word_text', 'الكلمة'],
  sentence: ['sentence', 'sentence_context', 'example', 'الجملة'],
  meaning: ['meaning', 'meaning_ar', 'المعنى'],
  sentenceAr: ['sentence_ar', 'sentence_translation', 'ترجمة_الجملة'],
  lesson: ['lesson', 'lesson_number', 'الدرس'],
  rank: ['rank', 'freq_rank', 'الترتيب'],
} as const;
type Column = keyof typeof ALIASES;

const clean = (s: string): string => s.normalize('NFC').replace(/\s+/g, ' ').trim();
const key = (s: string): string => clean(s).toLowerCase().replace(/[’‘]/g, "'");
const headerKey = (s: string): string => clean(s).toLowerCase().replace(/[\s-]+/g, '_');

interface RawRow { row: number; level: LevelCode; word: string; sentence: string; lesson: number | null; rank: number | null; meaning: string; sentenceAr: string }

export function parseContent(csv: string, opts: { lessonSize?: number } = {}): ImportResult {
  const size = opts.lessonSize ?? 20;
  const errors: Issue[] = [];
  const warnings: Issue[] = [];
  const fail = (): ImportResult => ({ content: null, errors, warnings });

  const table = parseCsv(csv);
  const header = table[0];
  if (!header) { errors.push({ row: null, message: 'the file is empty' }); return fail(); }

  const index: Partial<Record<Column, number>> = {};
  header.forEach((h, i) => {
    const k = headerKey(h);
    for (const col of Object.keys(ALIASES) as Column[]) if ((ALIASES[col] as readonly string[]).includes(k) && index[col] === undefined) index[col] = i;
  });
  for (const col of ['level', 'word', 'sentence'] as const) {
    if (index[col] === undefined) errors.push({ row: 1, message: `missing column "${col}" (found: ${header.map(clean).join(' | ')})` });
  }
  if (errors.length) return fail();
  const cell = (r: string[], col: Column): string => clean(r[index[col] ?? -1] ?? '');
  const hasLessonCol = index.lesson !== undefined;
  const hasRankCol = index.rank !== undefined;

  const rows: RawRow[] = [];
  const firstSeen = new Map<string, number>();
  let lessonCells = 0;
  table.slice(1).forEach((r, i) => {
    const rowNo = i + 2;
    const levelText = cell(r, 'level').toUpperCase();
    const word = cell(r, 'word');
    const sentence = cell(r, 'sentence');
    const bad = (message: string) => errors.push({ row: rowNo, message });

    const level = (LEVEL_ORDER as readonly string[]).includes(levelText) ? (levelText as LevelCode) : null;
    if (!level) bad(`unknown level "${cell(r, 'level')}" (use A1, A2, B1, B2 or C1)`);
    if (!word) bad('empty word');
    else {
      if (word.length > 40) bad(`word is too long (${word.length} characters)`);
      if (!/\p{L}/u.test(word)) bad(`"${word}" contains no letters`);
      else if (/\d/.test(word)) warnings.push({ row: rowNo, message: `"${word}" contains digits` });
      const seenAt = firstSeen.get(key(word));
      if (seenAt !== undefined) bad(`"${word}" is a duplicate of row ${seenAt}`);
      else firstSeen.set(key(word), rowNo);
    }
    if (!sentence) bad(`empty sentence for "${word}"`);
    else {
      if (sentence.length > 300) bad('sentence is longer than 300 characters');
      else if (sentence.length > 120) warnings.push({ row: rowNo, message: `long sentence (${sentence.length} characters)` });
      if (word && !key(sentence).includes(key(word))) warnings.push({ row: rowNo, message: `sentence does not contain "${word}" (fine for irregular forms)` });
    }

    let lesson: number | null = null;
    if (hasLessonCol && cell(r, 'lesson') !== '') {
      lessonCells++;
      lesson = Number(cell(r, 'lesson'));
      if (!Number.isInteger(lesson) || lesson < 1) { bad(`lesson must be a whole number ≥ 1 (got "${cell(r, 'lesson')}")`); lesson = null; }
    }
    let rank: number | null = null;
    if (hasRankCol && cell(r, 'rank') !== '') {
      rank = Number(cell(r, 'rank'));
      if (!Number.isInteger(rank) || rank < 1) { bad(`rank must be a whole number ≥ 1 (got "${cell(r, 'rank')}")`); rank = null; }
    }
    const meaning = cell(r, 'meaning');
    if (meaning.length > 60) bad(`meaning of "${word}" is longer than 60 characters`);
    const sentenceAr = cell(r, 'sentenceAr');
    if (sentenceAr.length > 300) bad(`Arabic translation of "${word}" is longer than 300 characters`);
    else if (sentenceAr && !/\p{Script=Arabic}/u.test(sentenceAr)) warnings.push({ row: rowNo, message: `Arabic translation of "${word}" has no Arabic letters` });
    if (level && word && sentence) rows.push({ row: rowNo, level, word, sentence, lesson, rank, meaning, sentenceAr });
  });

  if (table.length < 2) errors.push({ row: null, message: 'the file has a header but no words' });
  if (hasLessonCol && lessonCells > 0 && lessonCells !== table.length - 1) {
    errors.push({ row: null, message: 'the lesson column is only partly filled: fill every row or leave the column empty' });
  }
  const translated = rows.filter((r) => r.sentenceAr !== '').length;
  if (translated > 0 && translated < rows.length) {
    warnings.push({ row: null, message: `${rows.length - translated} of ${rows.length} words have no Arabic sentence translation (first: row ${rows.find((r) => r.sentenceAr === '')?.row})` });
  }
  if (errors.length) return fail();

  // ── group into lessons ──
  const useLessonCol = hasLessonCol && lessonCells > 0;
  const lessons: Omit<ContentLesson, 'globalSeq'>[] = [];
  for (const level of LEVEL_ORDER) {
    const inLevel = rows.filter((r) => r.level === level);
    if (inLevel.length === 0) continue;
    const toWord = (r: RawRow): ContentWord => ({ text: r.word, sentence: r.sentence, rank: r.rank, meaning: r.meaning || null, sentenceAr: r.sentenceAr || null });

    if (useLessonCol) {
      const groups = new Map<number, RawRow[]>();
      for (const r of inLevel) groups.set(r.lesson ?? 0, [...(groups.get(r.lesson ?? 0) ?? []), r]);
      const numbers = [...groups.keys()].sort((a, b) => a - b);
      numbers.forEach((n, i) => { if (n !== i + 1) errors.push({ row: null, message: `${level}: lesson numbers must run 1, 2, 3… without gaps (found ${n} where ${i + 1} was expected)` }); });
      for (const n of numbers) {
        const g = groups.get(n) ?? [];
        if (g.length !== size) errors.push({ row: null, message: `${level} lesson ${n} has ${g.length} words (must be exactly ${size})` });
        lessons.push({ levelCode: level, lessonNumber: n, words: g.map(toWord) });
      }
    } else {
      const extra = inLevel.length % size;
      if (extra !== 0) {
        errors.push({ row: null, message: `${level} has ${inLevel.length} words — not a multiple of ${size}. ${extra} word(s) would be left over (last row: ${inLevel[inLevel.length - 1]?.row}). Add ${size - extra} or remove ${extra}.` });
      }
      for (let i = 0; i + size <= inLevel.length; i += size) {
        lessons.push({ levelCode: level, lessonNumber: i / size + 1, words: inLevel.slice(i, i + size).map(toWord) });
      }
    }
  }
  if (errors.length) return fail();

  lessons.sort((a, b) => LEVEL_ORDER.indexOf(a.levelCode) - LEVEL_ORDER.indexOf(b.levelCode) || a.lessonNumber - b.lessonNumber);
  const ordered: ContentLesson[] = lessons.map((l, i) => ({ ...l, globalSeq: i + 1 }));

  const levels: LevelSummary[] = LEVEL_ORDER.flatMap((code) => {
    const ls = ordered.filter((l) => l.levelCode === code);
    if (ls.length === 0) return [];
    const ranks = ls.flatMap((l) => l.words.map((w) => w.rank)).filter((x): x is number => x !== null);
    if (ls.length !== 72) warnings.push({ row: null, message: `${code} has ${ls.length} lessons (the brief's example is 72) — fine if intentional` });
    return [{ code, lessons: ls.length, words: ls.length * size, rankFrom: ranks.length ? Math.min(...ranks) : null, rankTo: ranks.length ? Math.max(...ranks) : null }];
  });

  return { content: { lessons: ordered, levels }, errors, warnings };
}
