/** Deterministic ids: the same input always gives the same id, so re-running a seed updates rows instead of duplicating them. */
import { createHash } from 'node:crypto';

export const APP_NAMESPACE = '3b1f6a52-8c0e-4d7a-9a41-5f2d6c7e8b90';

/** RFC 4122 UUID v5. */
export function uuidV5(name: string, namespace: string = APP_NAMESPACE): string {
  const hash = createHash('sha1').update(Buffer.from(namespace.replace(/-/g, ''), 'hex')).update(name, 'utf8').digest();
  hash.writeUInt8((hash.readUInt8(6) & 0x0f) | 0x50, 6);
  hash.writeUInt8((hash.readUInt8(8) & 0x3f) | 0x80, 8);
  const h = hash.subarray(0, 16).toString('hex');
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
}

export const wordId = (text: string): string => uuidV5(`word:${text.trim().toLowerCase()}`);
export const lessonId = (level: string, lessonNumber: number): string => uuidV5(`lesson:${level}:${lessonNumber}`);
