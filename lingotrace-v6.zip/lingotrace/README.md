# LingoTrace

English spelling (dictation) app: React Native + Expo (iOS, Android, Web/PWA) on Supabase.

**Start with `docs/HANDOFF.md`**: what exists, what is verified, and the ordered list of what remains.

```
supabase/            database (8 migrations applied and verified on a real Supabase), Edge Functions, config, tests, content seed
packages/content/    2,800-word vocabulary (A1-B2) + the export to the Supabase seed
packages/engine/     spelling / SRS / replay engine + the server-side commit service (client and server entries)
prototype/           the frozen visual reference (the HTML prototype)
web/                 the live web app (index.html, auth.js, progress.js, sync.js), the privacy and terms pages (web/legal), unit tests and the browser check (web/e2e)
scripts/             CI entry point (ci.sh), site builder (build-site.mjs), the browser bundle of the engine (bundle-engine.mjs -> engine.js), generators
docs/HANDOFF.md      status + roadmap
```

Run the tests that need no database: `node --test supabase/tests/twin/*.test.ts supabase/tests/functions/*.test.ts packages/content/test/*.test.ts packages/engine/test/*.test.ts web/test/*.test.js` (Node 22.18+).
After changing `packages/engine/src`: `node scripts/sync-engine.ts` (the Edge Functions carry a generated copy). After changing `PgRepo`: `node scripts/gen-pgrepo-contract.ts`. Both have a `--check` mode and a test that fails when they are stale.
