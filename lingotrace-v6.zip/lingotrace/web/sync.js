/* LingoTrace cloud sync (v6). Plain script with no dependencies; the same file runs in the browser (window.LTSync) and in Node tests
   (module.exports.create), so the whole flow is tested against the REAL server code without a browser.

   What it does
   - Every finished lesson is queued in an OUTBOX (localStorage) the moment it finishes, BEFORE it is saved locally, and sent to the
     commit-session Edge Function in play order. The server replays the lesson with the same engine and records it; the device never
     tells the server what it earned, only what was typed.
   - The server is the source of truth: after a rejection, on a new device, and now and then, the account's state is pulled (read-only
     REST calls protected by RLS) and replaces the local state, but never while unsent sessions or a lesson on screen would be overwritten.
   - A device whose local history the account cannot replay (legacy progress from before v6, or another account's progress) is not synced
     until the learner chooses to start the account from zero: the old state is backed up first, nothing is merged or guessed.
   - No secrets: the publishable key is public by design, the user id comes from the sign-in token on the server, and nothing here can
     award points. Retries are idempotent (a session sent twice answers "duplicate"). */
(function (root) {
  'use strict';

  var KEY = 'lingotrace-sync-v1';        // { v:1, baseline:'clean'|'legacy', userId, lastPullAt, lastReceipt:{ totalXp } }
  var OUTBOX_KEY = 'lingotrace-outbox-v1'; // { v:1, items:[{ commit, tries, nextTryAt }], rejected:[{ sessionId, lessonId, code, message, at }] }
  var BACKUP_KEY = 'lingotrace-backup-v1'; // the progress that was on the device before the account started from zero
  var UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  var REGION = 'ap-south-1';             // the database is in Mumbai and a commit makes about 20 round trips
  var MAX_OUTBOX = 200, MAX_REJECTED = 20;
  var BASE_DELAY_MS = 5000, MAX_DELAY_MS = 300000, PULL_EVERY_MS = 600000, MIN_OFFSET_MS = 120000;

  function memoryStorage() { var m = {}; return { getItem: function (k) { return k in m ? m[k] : null; }, setItem: function (k, v) { m[k] = String(v); }, removeItem: function (k) { delete m[k]; } }; }

  function create(env) {
    var LT = env.progress, auth = env.auth, doFetch = env.fetch, url = env.url, key = env.key;
    var storage = env.storage || memoryStorage();
    var nowMs = env.now || function () { return Date.now(); };          // the DEVICE clock (the app's own clock adds the learnt offset on top)
    var random = env.random || Math.random;
    var setT = env.setTimeout || function (f, ms) { return setTimeout(f, ms); };
    var clearT = env.clearTimeout || function (h) { clearTimeout(h); };
    var api = { onStatus: typeof env.onStatus === 'function' ? env.onStatus : null };
    var running = null, timer = null, syncing = false, lastError = null, notice = null, lastSyncAt = null, version = 0;

    function readJson(k) { try { var r = storage.getItem(k); return r == null ? null : JSON.parse(r); } catch (e) { return null; } }
    function writeJson(k, v) { try { storage.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } }

    // ── persistent state ──
    function loadSync() {
      var o = readJson(KEY), s = { v: 1, baseline: null, userId: null, lastPullAt: 0, lastReceipt: null };
      if (o && typeof o === 'object' && o.v === 1) {
        if (o.baseline === 'clean' || o.baseline === 'legacy') s.baseline = o.baseline;
        if (typeof o.userId === 'string' && UUID_RE.test(o.userId)) s.userId = o.userId;
        if (typeof o.lastPullAt === 'number' && isFinite(o.lastPullAt)) s.lastPullAt = o.lastPullAt;
        if (o.lastReceipt && typeof o.lastReceipt.totalXp === 'number' && isFinite(o.lastReceipt.totalXp)) s.lastReceipt = { totalXp: o.lastReceipt.totalXp };
      }
      if (!s.baseline) { s.baseline = LT.isFresh() ? 'clean' : 'legacy'; writeJson(KEY, s); } // decided once, the first time sync runs on this device
      return s;
    }
    function saveSync(s) { writeJson(KEY, s); }
    function loadOutbox() {
      var o = readJson(OUTBOX_KEY), out = { v: 1, items: [], rejected: [] };
      if (!o || o.v !== 1) return out;
      if (Array.isArray(o.items)) o.items.forEach(function (it) {
        if (it && it.commit && typeof it.commit.sessionId === 'string' && UUID_RE.test(it.commit.sessionId)) {
          out.items.push({ commit: it.commit, tries: typeof it.tries === 'number' && isFinite(it.tries) ? it.tries : 0, nextTryAt: typeof it.nextTryAt === 'number' && isFinite(it.nextTryAt) ? it.nextTryAt : 0 });
        }
      });
      if (Array.isArray(o.rejected)) o.rejected.slice(-MAX_REJECTED).forEach(function (r) { if (r && typeof r.sessionId === 'string') out.rejected.push({ sessionId: r.sessionId, lessonId: r.lessonId || null, code: String(r.code || ''), message: String(r.message || ''), at: r.at || 0 }); });
      return out;
    }
    function saveOutbox(o) { writeJson(OUTBOX_KEY, o); }
    function updateItem(sessionId, fn) { var o = loadOutbox(); o.items.forEach(function (it) { if (it.commit.sessionId === sessionId) fn(it); }); saveOutbox(o); }
    function removeItem(sessionId) { var o = loadOutbox(); o.items = o.items.filter(function (it) { return it.commit.sessionId !== sessionId; }); saveOutbox(o); }

    // ── who is this device syncing for? ──
    function user() { var a = auth.state(); return a && a.status === 'in' && a.user && typeof a.user.id === 'string' && UUID_RE.test(a.user.id) ? a.user : null; }
    function needs() { // null | 'baseline' (history the account cannot replay) | 'account' (another account's progress is here)
      var u = user();
      if (!u) return null;
      var s = loadSync();
      if (s.baseline === 'legacy') return 'baseline';
      if (s.userId && s.userId !== u.id) return LT.isFresh() && !loadOutbox().items.length ? null : 'account';
      return null;
    }
    function bind(u) { var s = loadSync(); if (s.userId !== u.id) { s.userId = u.id; s.lastPullAt = 0; s.lastReceipt = null; saveSync(s); } }

    function status() {
      var u = user(), n = needs(), o = loadOutbox();
      return { phase: !u ? 'out' : n ? 'needs' : syncing ? 'syncing' : o.items.length ? 'queued' : 'idle', signedIn: !!u, needs: n, queued: o.items.length, error: lastError, notice: notice, lastSyncAt: lastSyncAt, rejected: o.rejected.length };
    }
    function emit() { if (typeof api.onStatus === 'function') { try { api.onStatus(status()); } catch (e) { /* the UI must never break sync */ } } }

    // ── queueing ──
    function enqueue(commit) { // called by the progress layer for every finished lesson
      version++;
      if (loadSync().baseline !== 'clean') return; // legacy history cannot be replayed by the account: the learner is asked to start from zero first
      var o = loadOutbox();
      if (o.items.some(function (it) { return it.commit.sessionId === commit.sessionId; })) return;
      o.items.push({ commit: commit, tries: 0, nextTryAt: 0 });
      while (o.items.length > MAX_OUTBOX) o.items.shift();
      saveOutbox(o);
      emit();
      kick(0);
    }
    loadSync(); // decide the baseline NOW (fresh device = clean, anything else = legacy), before a lesson can finish and change the answer
    if (typeof LT.onSession === 'function') LT.onSession(enqueue);

    // ── scheduling ──
    function kick(ms) {
      if (timer !== null) { clearT(timer); timer = null; }
      timer = setT(function () { timer = null; flush(); }, Math.max(0, ms || 0));
    }
    function scheduleNext() {
      if (timer !== null) { clearT(timer); timer = null; }
      if (!user() || needs() || (lastError && (lastError.kind === 'auth' || lastError.kind === 'update'))) return; // these need the learner, not a timer
      var it = loadOutbox().items[0];
      if (it) kick(Math.max(1000, it.nextTryAt - nowMs()));
    }
    function backoff(sessionId, tries, retryAfterSec) {
      var wait = Math.min(MAX_DELAY_MS, BASE_DELAY_MS * Math.pow(2, Math.max(0, tries - 1)));
      wait = Math.max(wait * (1 + 0.2 * random()), retryAfterSec > 0 ? retryAfterSec * 1000 : 0);
      updateItem(sessionId, function (it) { it.tries = tries; it.nextTryAt = nowMs() + Math.round(wait); });
    }

    // ── talking to the server ──
    function noteDate(res) { // the server's clock, when the browser lets us read it (CORS exposes few headers): fixes a wrong device clock
      try {
        var d = res.headers && res.headers.get && res.headers.get('date'), ms = d ? Date.parse(d) : NaN;
        if (isFinite(ms) && typeof env.onClockOffset === 'function') { var off = ms - nowMs(); env.onClockOffset(Math.abs(off) >= MIN_OFFSET_MS ? off : 0); }
      } catch (e) { /* ignore */ }
    }
    function retryAfter(res) { var v = res.headers && res.headers.get && res.headers.get('retry-after'), n = v == null ? NaN : Number(v); return isFinite(n) && n > 0 ? n : 0; }
    async function post(commit, token, region) {
      var headers = { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token, apikey: key };
      if (region) headers['x-region'] = REGION;
      var res, body = null;
      try { res = await doFetch(url + '/functions/v1/commit-session', { method: 'POST', headers: headers, body: JSON.stringify(commit) }); } catch (e) { return { kind: 'net' }; }
      noteDate(res);
      try { body = await res.json(); } catch (e) { /* not JSON (a gateway error page) */ }
      if (res.ok && body && body.ok === true && body.receipt) return { kind: 'ok', receipt: body.receipt };
      var err = body && body.error && typeof body.error === 'object' ? body.error : {};
      return { kind: 'http', status: res.status, code: typeof err.code === 'string' ? err.code : 'http_' + res.status, message: typeof err.message === 'string' ? err.message : '', retryable: err.retryable === true, details: err.details && typeof err.details === 'object' ? err.details : null, retryAfter: retryAfter(res) };
    }
    async function send(commit, token) { // with the region hint first; if that route is down, once more without it
      var r = await post(commit, token, true);
      if (r.kind === 'net' || (r.kind === 'http' && (r.status === 502 || r.status === 503 || r.status === 504))) r = await post(commit, token, false);
      return r;
    }
    async function rest(path, token) {
      var res;
      try { res = await doFetch(url + '/rest/v1/' + path, { method: 'GET', headers: { apikey: key, Authorization: 'Bearer ' + token, Accept: 'application/json' } }); } catch (e) { return { ok: false, error: { kind: 'network' } }; }
      noteDate(res);
      if (!res.ok) return { ok: false, error: { kind: 'http', status: res.status, code: 'rest' } };
      try { var rows = await res.json(); return Array.isArray(rows) ? { ok: true, rows: rows } : { ok: false, error: { kind: 'http', status: 0, code: 'rest' } }; } catch (e) { return { ok: false, error: { kind: 'http', status: 0, code: 'rest' } }; }
    }

    // ── sending the outbox in play order ──
    async function drain(token) {
      var out = { sent: 0, rejected: 0, stop: false }, rewrites = 0;
      for (var guard = 0; guard < MAX_OUTBOX + 50; guard++) {
        var it = loadOutbox().items[0];
        if (!it) break;
        if (it.nextTryAt > nowMs()) { out.stop = true; break; } // still waiting out its back-off
        var sid = it.commit.sessionId, r = await send(it.commit, token);
        if (r.kind === 'ok') { // committed or duplicate: both mean the account has it
          removeItem(sid);
          var s = loadSync(); s.lastReceipt = { totalXp: Number(r.receipt.totalXp) }; saveSync(s);
          lastError = null; lastSyncAt = nowMs(); out.sent++; rewrites = 0;
          continue;
        }
        if (r.kind === 'net') { backoff(sid, it.tries + 1, 0); lastError = { kind: 'network' }; out.stop = true; break; }
        if (r.status === 401) { lastError = { kind: 'auth' }; out.stop = true; break; }
        if (r.status === 426 || r.code === 'engine_outdated') { lastError = { kind: 'update' }; out.stop = true; break; }
        if (r.code === 'out_of_order' && r.details && r.details.lastSessionId !== undefined && rewrites < 3) {
          var head = r.details.lastSessionId; // a new device (or a rejected session) learns the chain head here; the parent is not part of what the server replays
          if (it.commit.parentSessionId !== head && (head === null || (typeof head === 'string' && UUID_RE.test(head)))) { rewrites++; updateItem(sid, function (x) { x.commit.parentSessionId = head; }); continue; }
        }
        if (r.retryable || r.status === 429 || r.status >= 500 || r.code === 'out_of_order') {
          backoff(sid, it.tries + 1, r.retryAfter); lastError = { kind: 'http', status: r.status, code: r.code }; out.stop = true; break;
        }
        // this session can never be recorded (the account disagrees with it): keep a note, move on
        removeItem(sid);
        var o = loadOutbox();
        o.rejected.push({ sessionId: sid, lessonId: it.commit.lessonId || null, code: r.code, message: r.message, at: nowMs() });
        o.rejected = o.rejected.slice(-MAX_REJECTED);
        saveOutbox(o);
        notice = { kind: 'rejected', count: (notice && notice.count || 0) + 1, code: r.code };
        out.rejected++;
      }
      return out;
    }

    // ── pulling the account's state ──
    async function fetchCloud(token) {
      var a = await rest('users?select=total_xp,streak_count,longest_streak,last_active_date', token);
      if (!a.ok) return a;
      if (!a.rows.length) return { ok: false, error: { kind: 'profile' } }; // the profile row is created at sign-up
      var b = await rest('user_progress?select=lesson_id,first_completed_at&first_completed_at=not.is.null', token);
      if (!b.ok) return b;
      var stats = [], off = 0;
      for (var guard = 0; guard < 20; guard++) {
        var c = await rest('user_word_stats?select=word_id,error_weight,status,due_seq,lifetime_failures,last_failed_at,last_reviewed_at&order=word_id&limit=1000&offset=' + off, token);
        if (!c.ok) return c;
        stats = stats.concat(c.rows);
        if (c.rows.length < 1000) break;
        off += 1000;
      }
      var u = a.rows[0];
      return { ok: true, cloud: {
        totalXp: Number(u.total_xp), streakCount: u.streak_count, longestStreak: u.longest_streak, lastActiveDate: u.last_active_date,
        completedLessonIds: b.rows.map(function (r) { return r.lesson_id; }),
        rotation: stats.map(function (r) { return { wordId: r.word_id, errorWeight: r.error_weight, status: r.status, dueSeq: r.due_seq, lifetimeFailures: r.lifetime_failures, lastFailedAt: r.last_failed_at, lastReviewedAt: r.last_reviewed_at }; }),
      } };
    }
    async function pull(token) {
      var v = version, c = await fetchCloud(token);
      if (!c.ok) { lastError = c.error; return false; }
      // never overwrite newer local progress: a lesson finished (or the outbox filled) while we were reading
      if (v !== version || loadOutbox().items.length || (typeof env.canPull === 'function' && !env.canPull())) return false;
      LT.replaceFromCloud(c.cloud);
      var s = loadSync(); s.lastPullAt = nowMs(); saveSync(s);
      lastError = null; lastSyncAt = nowMs();
      if (typeof env.onPulled === 'function') { try { env.onPulled(); } catch (e) { /* ignore */ } }
      return true;
    }
    async function maybePull(token, drained) {
      var s = loadSync();
      var mismatch = drained.sent > 0 && s.lastReceipt && s.lastReceipt.totalXp !== LT.state.xp; // the account's total disagrees with ours: it wins
      var due = !s.lastPullAt || nowMs() - s.lastPullAt >= PULL_EVERY_MS;
      if (!(drained.rejected || mismatch || due)) return;
      if (typeof env.canPull === 'function' && !env.canPull()) return; // not while a lesson is on screen
      await pull(token);
    }

    async function cycle() {
      var u = user();
      if (!u || needs()) return;
      bind(u);
      var token = await auth.getAccessToken();
      if (!token) { lastError = { kind: 'auth' }; return; }
      syncing = true; emit();
      try {
        var drained = await drain(token);
        if (!drained.stop && !loadOutbox().items.length) await maybePull(token, drained);
      } finally { syncing = false; }
    }
    function flush() { // one cycle at a time (and one tab at a time where the browser has Web Locks)
      if (running) return running;
      var work = env.locks ? env.locks.request('lingotrace-sync', { ifAvailable: true }, function (lock) { return lock ? cycle() : null; }) : cycle();
      running = Promise.resolve(work).catch(function (e) { lastError = { kind: 'internal', message: String(e && e.message || e) }; }).then(function () { running = null; emit(); scheduleNext(); });
      return running;
    }

    // ── decisions the learner makes ──
    async function adopt() { // start THIS account from the account's own history: back up what is here, begin fresh, take the cloud state
      var u = user();
      if (!u) throw new Error('sign in first');
      var s = loadSync(), o = loadOutbox();
      writeJson(BACKUP_KEY, { at: new Date(nowMs()).toISOString(), forUser: s.userId, unsent: o.items.length, state: LT.snapshot() });
      LT.startOver();
      saveOutbox({ v: 1, items: [], rejected: [] });
      s = loadSync(); s.baseline = 'clean'; s.userId = u.id; s.lastPullAt = 0; s.lastReceipt = null; saveSync(s);
      version++; notice = null; lastError = null; emit();
      await flush();
    }
    function localReset() { // the learner wiped this device: unsent sessions are gone with it, the account's progress comes back at the next pull
      saveOutbox({ v: 1, items: [], rejected: [] });
      var s = loadSync(); s.baseline = 'clean'; s.lastPullAt = 0; s.lastReceipt = null; saveSync(s);
      version++; notice = null; lastError = null; emit(); kick(0);
    }

    api.flush = flush;
    api.kick = kick;
    api.status = status;
    api.adopt = adopt;
    api.localReset = localReset;
    api.ackNotice = function () { notice = null; };
    api.onAuthChange = function (e) { if (e && (e.type === 'signin' || e.type === 'update')) { if (lastError && lastError.kind === 'auth') lastError = null; kick(0); } emit(); };
    api.pending = function () { return loadOutbox().items.length; };
    api.rejected = function () { return loadOutbox().rejected; };
    api.baseline = function () { return loadSync().baseline; };
    api.keys = { sync: KEY, outbox: OUTBOX_KEY, backup: BACKUP_KEY };
    return api;
  }

  var api = { create: create, KEY: KEY, OUTBOX_KEY: OUTBOX_KEY, BACKUP_KEY: BACKUP_KEY };
  if (typeof window !== 'undefined' && window.document) root.LTSync = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : this);
