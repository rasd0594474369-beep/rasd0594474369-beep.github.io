// Node tests for web/auth.js: the whole sign-in flow with a fake Supabase, no browser needed.
const test = require('node:test');
const assert = require('node:assert/strict');
const { createAuth, CONFIG, STORE_KEY } = require('../auth.js');

const NOW = 1_800_000_000;
const URLBASE = CONFIG.url;

function setup({ hash = '', stored = null, routes = {} } = {}) {
  const store = new Map();
  if (stored) store.set(STORE_KEY, JSON.stringify(stored));
  const calls = [];
  const events = [];
  const loc = { hash, pathname: '/', search: '', origin: 'https://me.github.io', href: '' };
  const hist = { replaced: [], replaceState(_s, _t, u) { this.replaced.push(u); loc.hash = ''; } };
  const fetchFn = async (u, opts = {}) => {
    calls.push({ url: u.replace(URLBASE, ''), method: opts.method || 'GET', headers: opts.headers, body: opts.body });
    const key = Object.keys(routes).find((k) => u.startsWith(URLBASE + k));
    if (!key) throw new Error('no route for ' + u);
    const r = routes[key];
    const out = typeof r === 'function' ? r(opts) : r;
    if (out instanceof Error) throw out;
    return { ok: out.status >= 200 && out.status < 300, status: out.status, json: async () => out.body };
  };
  let now = NOW;
  const auth = createAuth({
    url: URLBASE, key: CONFIG.key, fetch: fetchFn, location: loc, history: hist, now: () => now,
    storage: { getItem: (k) => (store.has(k) ? store.get(k) : null), setItem: (k, v) => store.set(k, v), removeItem: (k) => store.delete(k) },
  });
  auth.onChange = (e) => events.push(e.type);
  return { auth, store, calls, events, loc, hist, setNow: (n) => { now = n; } };
}

const GOOGLE_USER = { id: 'u1', email: 'sara@example.com', user_metadata: { full_name: 'Sara A', avatar_url: 'https://x/y.png' } };
const okUser = { status: 200, body: GOOGLE_USER };

test('return from Google: stores the session, cleans the URL, loads the user, emits signin', async () => {
  const t = setup({ hash: '#access_token=AT&refresh_token=RT&expires_in=3600&token_type=bearer', routes: { '/auth/v1/user': okUser } });
  assert.equal(t.auth.state().status, 'out');
  await t.auth.init();
  const s = t.auth.state();
  assert.equal(s.status, 'in');
  assert.deepEqual(s.user, { id: 'u1', email: 'sara@example.com', name: 'Sara A', avatar: 'https://x/y.png' });
  assert.deepEqual(t.hist.replaced, ['/']);
  assert.deepEqual(t.events, ['signin']);
  const saved = JSON.parse(t.store.get(STORE_KEY));
  assert.equal(saved.access_token, 'AT'); assert.equal(saved.refresh_token, 'RT'); assert.equal(saved.expires_at, NOW + 3600);
  const userCall = t.calls.find((c) => c.url === '/auth/v1/user');
  assert.equal(userCall.headers.Authorization, 'Bearer AT'); assert.equal(userCall.headers.apikey, CONFIG.key);
});

test('a stored valid session shows at once and is verified once, with no refresh', async () => {
  const t = setup({ stored: { access_token: 'AT', refresh_token: 'RT', expires_at: NOW + 1000, user: { id: 'u1', email: 'a@b.c', name: 'Cached', avatar: null } }, routes: { '/auth/v1/user': okUser } });
  assert.equal(t.auth.state().status, 'in');
  assert.equal(t.auth.state().user.name, 'Cached');
  await t.auth.init();
  assert.equal(t.auth.state().user.name, 'Sara A');
  assert.deepEqual(t.calls.map((c) => c.url), ['/auth/v1/user']);
  assert.deepEqual(t.events, ['update']);
});

test('an expired session is refreshed first, then the new token is used', async () => {
  const t = setup({
    stored: { access_token: 'OLD', refresh_token: 'RT1', expires_at: NOW - 5, user: null },
    routes: { '/auth/v1/token': { status: 200, body: { access_token: 'NEW', refresh_token: 'RT2', expires_in: 3600 } }, '/auth/v1/user': okUser },
  });
  await t.auth.init();
  assert.equal(t.calls[0].url, '/auth/v1/token?grant_type=refresh_token');
  assert.equal(JSON.parse(t.calls[0].body).refresh_token, 'RT1');
  assert.equal(t.calls[1].headers.Authorization, 'Bearer NEW');
  const saved = JSON.parse(t.store.get(STORE_KEY));
  assert.equal(saved.access_token, 'NEW'); assert.equal(saved.refresh_token, 'RT2'); assert.equal(saved.expires_at, NOW + 3600);
  assert.equal(t.auth.state().status, 'in');
});

test('a refresh token the server rejects signs the user out with a clear message', async () => {
  const t = setup({ stored: { access_token: 'OLD', refresh_token: 'BAD', expires_at: NOW - 5, user: null }, routes: { '/auth/v1/token': { status: 400, body: { error: 'invalid_grant' } } } });
  await t.auth.init();
  const s = t.auth.state();
  assert.equal(s.status, 'out'); assert.match(s.error, /سجّل الدخول من جديد/);
  assert.equal(t.store.has(STORE_KEY), false);
  assert.ok(t.events.includes('signout'));
});

test('offline (network error) keeps the session and the cached user', async () => {
  const t = setup({
    stored: { access_token: 'OLD', refresh_token: 'RT', expires_at: NOW - 5, user: { id: 'u1', email: 'a@b.c', name: 'Cached', avatar: null } },
    routes: { '/auth/v1/token': new Error('offline'), '/auth/v1/user': new Error('offline') },
  });
  await t.auth.init();
  assert.equal(t.auth.state().status, 'in'); assert.equal(t.auth.state().user.name, 'Cached');
  assert.equal(JSON.parse(t.store.get(STORE_KEY)).refresh_token, 'RT');
});

test('server errors (429/5xx) on refresh do not sign the user out', async () => {
  const t = setup({ stored: { access_token: 'OLD', refresh_token: 'RT', expires_at: NOW - 5, user: null }, routes: { '/auth/v1/token': { status: 429, body: {} }, '/auth/v1/user': { status: 503, body: {} } } });
  await t.auth.init();
  assert.equal(t.auth.state().status, 'in');
  assert.equal(t.store.has(STORE_KEY), true);
});

test('a 401 on the user call refreshes once and retries; a second 401 signs out', async () => {
  let userCalls = 0;
  const t = setup({
    stored: { access_token: 'AT', refresh_token: 'RT', expires_at: NOW + 1000, user: null },
    routes: { '/auth/v1/token': { status: 200, body: { access_token: 'AT2', refresh_token: 'RT2', expires_in: 3600 } }, '/auth/v1/user': () => (++userCalls === 1 ? { status: 401, body: {} } : okUser) },
  });
  await t.auth.init();
  assert.equal(userCalls, 2); assert.equal(t.auth.state().user.name, 'Sara A');

  const t2 = setup({
    stored: { access_token: 'AT', refresh_token: 'RT', expires_at: NOW + 1000, user: null },
    routes: { '/auth/v1/token': { status: 200, body: { access_token: 'AT2', expires_in: 3600 } }, '/auth/v1/user': { status: 401, body: {} } },
  });
  await t2.auth.init();
  assert.equal(t2.auth.state().status, 'out');
});

test('an error in the URL is shown, the URL is cleaned and an existing session is kept', async () => {
  const t = setup({ hash: '#error=access_denied&error_code=x&error_description=User+cancelled', stored: { access_token: 'AT', refresh_token: 'RT', expires_at: NOW + 1000, user: null }, routes: { '/auth/v1/user': okUser } });
  await t.auth.init();
  assert.equal(t.auth.state().error, 'User cancelled');
  assert.deepEqual(t.hist.replaced, ['/']);
  assert.equal(t.auth.state().status, 'in');
  assert.ok(t.events.includes('error'));

  const t2 = setup({ hash: '#error=access_denied' });
  await t2.auth.init();
  assert.equal(t2.auth.state().status, 'out'); assert.equal(t2.auth.state().error, 'access_denied');
});

test('logout signs out locally at once and calls the server with scope=local; offline is fine', async () => {
  const t = setup({ stored: { access_token: 'AT', refresh_token: 'RT', expires_at: NOW + 1000, user: null }, routes: { '/auth/v1/logout': { status: 204, body: null } } });
  const p = t.auth.logout();
  assert.equal(t.auth.state().status, 'out'); assert.equal(t.store.has(STORE_KEY), false);
  await p;
  assert.equal(t.calls[0].url, '/auth/v1/logout?scope=local'); assert.equal(t.calls[0].method, 'POST'); assert.equal(t.calls[0].headers.Authorization, 'Bearer AT');

  const t2 = setup({ stored: { access_token: 'AT', refresh_token: 'RT', expires_at: NOW + 1000, user: null }, routes: { '/auth/v1/logout': new Error('offline') } });
  await t2.auth.logout();
  assert.equal(t2.auth.state().status, 'out');
});

test('getAccessToken: null when signed out, cached when fresh, one refresh for parallel callers', async () => {
  const out = setup();
  assert.equal(await out.auth.getAccessToken(), null);

  const fresh = setup({ stored: { access_token: 'AT', refresh_token: 'RT', expires_at: NOW + 1000, user: null } });
  assert.equal(await fresh.auth.getAccessToken(), 'AT'); assert.equal(fresh.calls.length, 0);

  const old = setup({ stored: { access_token: 'OLD', refresh_token: 'RT', expires_at: NOW + 10, user: null }, routes: { '/auth/v1/token': { status: 200, body: { access_token: 'NEW', refresh_token: 'RT2', expires_in: 3600 } } } });
  const [a, b, c] = await Promise.all([old.auth.getAccessToken(), old.auth.getAccessToken(), old.auth.getAccessToken()]);
  assert.deepEqual([a, b, c], ['NEW', 'NEW', 'NEW']);
  assert.equal(old.calls.filter((x) => x.url.startsWith('/auth/v1/token')).length, 1);
});

test('login goes to Supabase with Google and an encoded redirect back to this page', () => {
  const t = setup();
  t.auth.login();
  assert.equal(t.loc.href, URLBASE + '/auth/v1/authorize?provider=google&redirect_to=' + encodeURIComponent('https://me.github.io/'));
});

test('damaged or foreign storage content counts as signed out', () => {
  const t = setup();
  t.store.set(STORE_KEY, '{not json');
  const again = createAuth({ url: URLBASE, key: CONFIG.key, fetch: async () => { throw new Error('x'); }, location: t.loc, history: t.hist, storage: { getItem: (k) => t.store.get(k) ?? null, setItem() {}, removeItem() {} } });
  assert.equal(again.state().status, 'out');
  t.store.set(STORE_KEY, JSON.stringify({ access_token: 5 }));
  assert.equal(createAuth({ url: URLBASE, key: CONFIG.key, fetch: async () => {}, location: t.loc, history: t.hist, storage: { getItem: (k) => t.store.get(k) ?? null, setItem() {}, removeItem() {} } }).state().status, 'out');
});
