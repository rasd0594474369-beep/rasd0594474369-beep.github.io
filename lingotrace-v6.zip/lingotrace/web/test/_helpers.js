// Shared by the web unit tests (not a test itself: the CI only runs web/test/*.test.js).
const fs = require('node:fs');
const path = require('node:path');
const { pathToFileURL } = require('node:url');

const ROOT = path.resolve(__dirname, '..', '..');

/** The lesson content embedded in web/index.html: { D, HOMO, lessons: [{ level, number, words: [[text, sentence, meaningAr, sentenceAr]] }] }. */
function loadCatalog() {
  const line = fs.readFileSync(path.join(ROOT, 'web', 'index.html'), 'utf8').split('\n').find((l) => l.startsWith('const D='));
  if (!line) throw new Error('web/index.html no longer has the content line (const D=...)');
  const { D, HOMO } = new Function(line + '; return { D, HOMO }')();
  const lessons = D.levels.flatMap((l) => l.lessons.map((x) => ({ level: l.code, number: x.n, words: x.words })));
  return { D, HOMO, lessons };
}

/** The browser bundle of the engine, evaluated in THIS realm (so deepEqual works) without touching globalThis. */
async function loadEngineBundle() {
  const { bundleEngine } = await import(pathToFileURL(path.join(ROOT, 'scripts', 'bundle-engine.mjs')).href);
  const { code } = bundleEngine(path.join(ROOT, 'packages', 'engine', 'src'));
  return new Function('window', code + '\nreturn window.LTEngine;')({});
}

/** The TypeScript engine exactly as the server runs it. */
async function loadEngineTs() {
  return import(pathToFileURL(path.join(ROOT, 'packages', 'engine', 'src', 'index.ts')).href);
}

function makeStorage(initial = {}) {
  const m = new Map(Object.entries(initial));
  return {
    getItem: (k) => (m.has(k) ? m.get(k) : null),
    setItem: (k, v) => { m.set(k, String(v)); },
    removeItem: (k) => { m.delete(k); },
    dump: () => Object.fromEntries(m),
  };
}

// ── scripted "user": what a person might type, deterministic for a given rand() ──
function typo(target, rand) { // one-character slip: delete, insert or substitute
  const chars = [...target];
  if (!chars.length) return 'x';
  const i = Math.floor(rand() * chars.length), op = Math.floor(rand() * 3);
  if (op === 0) chars.splice(i, 1); else if (op === 1) chars.splice(i, 0, 'q'); else chars[i] = chars[i] === 'z' ? 'y' : 'z';
  return chars.join('');
}
function behave(rand, target, step) {
  const r = rand();
  if (r < 0.58) return target;
  if (r < 0.72) return typo(target, rand);
  if (r < 0.80) return target.toUpperCase();
  if (r < 0.86) return `  ${target}  `;
  if (r < 0.90) return target.replace(/[.,?!]/g, '');
  if (r < 0.97) return typo(typo(target, rand), rand);
  return step === 'word' ? 'xx' : 'a b c';
}

module.exports = { ROOT, loadCatalog, loadEngineBundle, loadEngineTs, makeStorage, typo, behave };
