// progress.js: ids, migration of the v3/v4 state, the lesson flow on the engine, and proof that what the client plays is what the server replays.
const test = require('node:test');
const assert = require('node:assert/strict');
const { pathToFileURL } = require('node:url');
const path = require('node:path');
const H = require('./_helpers.js');
const Progress = require('../progress.js');

let engine, ts, ids, catalog;
test.before(async () => {
  engine = await H.loadEngineBundle();
  ts = await H.loadEngineTs();
  ids = await import(pathToFileURL(path.join(H.ROOT, 'packages', 'content', 'src', 'ids.ts')).href);
  catalog = H.loadCatalog();
});

const DAY = 86400e3;
function mk(opts = {}) {
  const storage = opts.storage || H.makeStorage();
  const clock = { ms: opts.start ?? Date.UTC(2026, 10, 17, 10, 0, 0) };
  let n = 0;
  const LT = Progress.create({
    engine, lessons: catalog.lessons, storage, now: () => new Date(clock.ms), timeZone: opts.timeZone || 'UTC',
    newId: () => `00000000-0000-4000-8000-${String(++n).padStart(12, '0')}`,
  });
  return { LT, storage, clock };
}
// plays a session to the end; policy(cur, sess) returns the text to type (default: always right)
function play(LT, sess, policy) {
  for (let guard = 0; !LT.finished(sess); guard++) {
    assert.ok(guard < 500, 'the session must finish');
    const c = LT.cur(sess);
    LT.submit(sess, policy ? policy(c, sess) : c.text);
  }
  return LT.finish(sess);
}
const WRONG = 'zzzzzz';
const legacyState = (over = {}) => JSON.stringify({
  xp: 130, streak: 3, best: 5, day: '2026-11-17', c: { 1: 1, 2: 1 },
  rot: {
    the: { weight: 2, status: 'active', due: 3, last: '2026-11-10T08:00:00.000Z' },
    be: { weight: 0, status: 'mastered', due: null, last: '2026-11-09T08:00:00.000Z' },
    notaword: { weight: 1, status: 'active', due: 2, last: '2026-11-08T08:00:00.000Z' },
  },
  loc: 'en-GB', unlock: false, tr: false, ...over,
});

test('word and lesson ids are the database ids: all 2,800 words and 140 lessons match packages/content ids', () => {
  let words = 0;
  for (const l of catalog.lessons) {
    assert.equal(Progress.uuidV5(`lesson:${l.level}:${l.number}`), ids.lessonId(l.level, l.number));
    for (const w of l.words) { words++; assert.equal(Progress.uuidV5(`word:${w[0].trim().toLowerCase()}`), ids.wordId(w[0])); }
  }
  assert.equal(words, 2800);
  const { LT } = mk();
  assert.equal(LT.wordId('The '), ids.wordId('the'), 'ids ignore case and surrounding spaces, like the server');
  assert.equal(LT.lessonId(1), ids.lessonId('A1', 1));
  assert.equal(LT.lessonId(140), ids.lessonId('B2', 35));
});

test('migration: v3/v4 progress becomes the new format without losing anything, and the old key is left alone', () => {
  const storage = H.makeStorage({ 'spelling-v2': legacyState() });
  const { LT } = mk({ storage });
  assert.equal(LT.migrated, true);
  assert.equal(LT.state.xp, 130);
  assert.deepEqual(Object.keys(LT.state.completed).sort(), ['1', '2']);
  assert.deepEqual(LT.state.streak, { streakCount: 3, longestStreak: 5, lastActiveDate: '2026-11-17' });
  assert.deepEqual(LT.state.prefs, { loc: 'en-GB', unlock: false, tr: false });
  const the = LT.state.rotation[LT.wordId('the')], be = LT.state.rotation[LT.wordId('be')];
  assert.deepEqual(the, { wordId: LT.wordId('the'), errorWeight: 2, status: 'active', dueSeq: 3, lifetimeFailures: 2, lastFailedAt: '2026-11-10T08:00:00.000Z', lastReviewedAt: '2026-11-10T08:00:00.000Z' });
  assert.deepEqual([be.errorWeight, be.status, be.dueSeq, be.lifetimeFailures], [0, 'mastered', null, 1]);
  assert.equal(Object.keys(LT.state.rotation).length, 2, 'a word that is not in the catalog is dropped');
  assert.deepEqual(LT.rotation().map((r) => [r.text, r.weight, r.due]), [['the', 2, 3]]);
  assert.equal(LT.streak(), 3);
  // written once, under the new key; the old key is byte-for-byte what it was
  const dump = storage.dump();
  assert.equal(dump['spelling-v2'], legacyState());
  assert.equal(JSON.parse(dump['lingotrace-progress-v1']).xp, 130);
});

test('migration runs once: with the new key present the old state is ignored, even if the old key changes', () => {
  const storage = H.makeStorage({ 'spelling-v2': legacyState() });
  mk({ storage }).LT.state.xp += 0;
  storage.setItem('spelling-v2', legacyState({ xp: 99999 }));
  const again = mk({ storage });
  assert.equal(again.LT.migrated, false);
  assert.equal(again.LT.state.xp, 130);
});

test('migration: damaged or foreign storage is handled without crashing and without losing the old data', () => {
  for (const bad of ['{not json', 'null', '[]', '"x"', '42']) {
    const storage = H.makeStorage({ 'spelling-v2': bad });
    const { LT } = mk({ storage });
    assert.equal(LT.migrated, false);
    assert.equal(LT.state.xp, 0);
    assert.equal(storage.dump()['spelling-v2'], bad, 'the old value is not touched');
    assert.equal(storage.dump()['lingotrace-progress-v1'], undefined, 'nothing is written until there is something to save');
  }
  // a damaged NEW key falls back to the old progress instead of wiping it
  const storage = H.makeStorage({ 'lingotrace-progress-v1': '{"v":1,"xp":"lots"', 'spelling-v2': legacyState() });
  assert.equal(mk({ storage }).LT.state.xp, 130);
});

test('migration: invalid values are cleaned one by one (same strictness as the old loader)', () => {
  const messy = legacyState({
    xp: -5, streak: 'x', best: 7, day: '2026-13-45', c: { 0: 1, 1: 1, 141: 1, 999: 1, abc: 1, 3: 0, 4: 1 },
    rot: {
      The: { weight: 1, status: 'active', due: 2, last: '2026-11-01T00:00:00.000Z' },
      the: { weight: 3, status: 'active', due: 4, last: '2026-11-02T00:00:00.000Z' }, // same word, other spelling: the heavier one wins
      and: { weight: 'x', status: 'active', due: 1, last: 'x' },
      of: { weight: 1, status: 'weird', due: 1, last: 'x' },
      to: { weight: 1, status: 'active', due: -1, last: 'x' },
      'bad key!': { weight: 1, status: 'active', due: 1, last: 'x' },
    },
    loc: 'fr-FR', unlock: 'yes', tr: 0,
  });
  const { LT } = mk({ storage: H.makeStorage({ 'spelling-v2': messy }) });
  assert.equal(LT.state.xp, 0);
  assert.deepEqual(LT.state.streak, { streakCount: 0, longestStreak: 7, lastActiveDate: null });
  assert.deepEqual(Object.keys(LT.state.completed).sort(), ['1', '4']);
  assert.deepEqual(LT.state.prefs, { loc: 'en-US', unlock: false, tr: true });
  assert.deepEqual(Object.keys(LT.state.rotation), [LT.wordId('the')]);
  assert.equal(LT.state.rotation[LT.wordId('the')].errorWeight, 3);
});

test('a hand-edited new state is normalized: an active word always has weight and a due lesson, a mastered one never does', () => {
  const id = (t) => Progress.uuidV5('word:' + t);
  const raw = JSON.stringify({ v: 1, xp: 5, streak: { streakCount: 9, longestStreak: 1, lastActiveDate: '2026-11-17' }, completed: { 1: true }, lastSessionId: 'nope',
    rotation: {
      [id('the')]: { wordId: id('the'), errorWeight: 0, status: 'active', dueSeq: null },
      [id('be')]: { wordId: id('be'), errorWeight: 4, status: 'mastered', dueSeq: 9 },
      'not-a-uuid': { errorWeight: 1, status: 'active', dueSeq: 1 },
    } });
  const { LT } = mk({ storage: H.makeStorage({ 'lingotrace-progress-v1': raw }) });
  const the = LT.state.rotation[id('the')], be = LT.state.rotation[id('be')];
  assert.deepEqual([the.errorWeight, the.status, the.dueSeq], [1, 'active', 0]);
  assert.deepEqual([be.errorWeight, be.status, be.dueSeq], [0, 'mastered', null]);
  assert.equal(Object.keys(LT.state.rotation).length, 2);
  assert.equal(LT.state.streak.longestStreak, 9, 'the best streak is never below the current one');
  assert.equal(LT.state.lastSessionId, null);
});

test('reset wipes the new state and the old key, so nothing comes back by migration', () => {
  const storage = H.makeStorage({ 'spelling-v2': legacyState() });
  const { LT } = mk({ storage });
  assert.equal(LT.state.xp, 130);
  LT.reset();
  assert.equal(LT.state.xp, 0);
  assert.equal(storage.dump()['spelling-v2'], undefined);
  const again = mk({ storage });
  assert.equal(again.LT.migrated, false);
  assert.equal(again.LT.state.xp, 0);
  assert.deepEqual(again.LT.state.completed, {});
});

test('a perfect first run earns 250 XP, completes the lesson, starts the streak and survives a reload', () => {
  const { LT, storage, clock } = mk();
  const sess = LT.start(1);
  assert.equal(sess.mode, 'first_run');
  assert.deepEqual(LT.progress(sess), { done: 0, total: 20 });
  const summary = play(LT, sess);
  assert.equal(summary.xp.total, 250);
  assert.deepEqual(sess.es.xp, { firstTry: 200, recovered: 0, lessonBonus: 50 });
  assert.equal(LT.state.xp, 250);
  assert.ok(LT.isDone(1) && !LT.isDone(2));
  assert.equal(LT.nextLesson(), 2);
  assert.equal(LT.streak(), 1);
  assert.deepEqual(LT.rotation(), []);
  const reloaded = mk({ storage, start: clock.ms }).LT;
  assert.deepEqual(reloaded.state, LT.state);
  assert.equal(reloaded.migrated, false);
});

test('finishing twice does not pay twice', () => {
  const { LT } = mk();
  const sess = LT.start(1);
  play(LT, sess);
  LT.finish(sess);
  assert.equal(LT.state.xp, 250);
});

test('a replay awards no XP, never touches the rotation and does not inject; it still counts as activity for the streak', () => {
  const { LT, clock } = mk();
  play(LT, LT.start(1));
  clock.ms += DAY;
  const replay = LT.start(1);
  assert.equal(replay.mode, 'replay');
  assert.ok(replay.es.queue.every((q) => q.source === 'lesson'));
  play(LT, replay, (c) => (c.step === 'word' ? WRONG : c.text));
  assert.equal(LT.state.xp, 250);
  assert.deepEqual(LT.rotation(), []);
  assert.equal(LT.state.streak.streakCount, 2);
  assert.equal(LT.state.lastSessionId, replay.sessionId);
});

test('failing a word twice puts it in the rotation (due two lessons later); injections are at most 2, dispersed, and a clean pass retires the word', () => {
  const { LT } = mk();
  const failed = [];
  play(LT, LT.start(2), (c) => {
    if (c.step === 'word' && !c.rev && failed.length < 2 && !failed.includes(c.word.wordId)) { failed.push(c.word.wordId); return WRONG; }
    if (c.rev && failed.includes(c.word.wordId)) return WRONG;
    return c.text;
  });
  assert.equal(LT.rotation().length, 2);
  for (const r of LT.rotation()) assert.deepEqual([r.weight, r.due], [1, 4]);
  assert.equal(LT.state.xp, 250 - 2 * 10 + 0, 'two failed words lose their first-try XP, the bonus stays');
  assert.equal(LT.start(3).es.queue.length, 20, 'not due yet: nothing injected');
  const s4 = LT.start(4);
  const inj = s4.es.queue.map((q, i) => [q, i]).filter(([q]) => q.source === 'injected');
  assert.equal(s4.es.queue.length, 22);
  assert.equal(inj.length, 2);
  assert.deepEqual(inj.map(([q]) => q.itemId).sort(), failed.map((id) => `I:${id}`).sort());
  assert.ok(inj.every(([q]) => q.isReview === false && q.steps.length === 1 && q.steps[0] === 'word'), 'standalone: a word step only');
  const [p1, p2] = inj.map(([, i]) => i);
  assert.ok(p1 >= 1 && p2 <= 22 - 2 && p2 - p1 >= 2, `dispersed: ${p1}, ${p2}`);
  play(LT, s4); // everything right, injected words included
  assert.deepEqual(LT.rotation(), []);
  assert.deepEqual(failed.map((id) => LT.state.rotation[id].status), ['mastered', 'mastered']);
  assert.ok(failed.every((id) => LT.state.rotation[id].dueSeq === null && LT.state.rotation[id].errorWeight === 0));
});

test('the tiers: peeked 5 XP, minor slip then right 5 XP, a missed sentence costs nothing and is not requeued, right at once 10 XP', () => {
  const { LT } = mk();
  const sess = LT.start(1);
  const first = LT.cur(sess);
  LT.peek(sess);
  assert.deepEqual(LT.submit(sess, first.text), { k: 'ok', xp: 5 }, 'answer shown first: lower tier');
  assert.deepEqual(LT.submit(sess, LT.cur(sess).text), { k: 'ok', xp: 0 }, 'the sentence step pays nothing of its own');
  const second = LT.cur(sess);
  assert.equal(LT.submit(sess, second.text.slice(1)).k, 'retype', 'one letter missing: try again');
  assert.deepEqual(LT.submit(sess, second.text), { k: 'ok', xp: 5 });
  const sentence = LT.cur(sess);
  assert.equal(sentence.step, 'sentence');
  const total = LT.progress(sess).total;
  assert.deepEqual(LT.submit(sess, 'nope'), { k: 'miss', reveal: sentence.text });
  assert.equal(LT.progress(sess).total, total, 'a missed sentence is not requeued');
  assert.deepEqual(LT.submit(sess, LT.cur(sess).text), { k: 'ok', xp: 10 });
});

test('the streak counts consecutive days in the user time zone and restarts after a missed day', () => {
  const { LT, clock } = mk({ timeZone: 'Asia/Riyadh', start: Date.UTC(2026, 10, 17, 20, 30) }); // 23:30 in Riyadh
  play(LT, LT.start(1));
  assert.equal(LT.streak(), 1);
  clock.ms += 2 * 3600e3; // 01:30 the next local day, only two hours later
  play(LT, LT.start(2));
  assert.equal(LT.state.streak.streakCount, 2);
  clock.ms += 3 * DAY;
  assert.equal(LT.streak(), 0, 'three idle days: the streak shows as lost');
  play(LT, LT.start(3));
  assert.deepEqual(LT.state.streak, { streakCount: 1, longestStreak: 2, lastActiveDate: '2026-11-21' });
});

test('start validates the lesson number; preferences accept only known values; locked lessons follow the progress', () => {
  const { LT } = mk();
  for (const bad of [0, 141, 1.5, -1, '1']) assert.throws(() => LT.start(bad), RangeError);
  assert.equal(LT.setPref('loc', 'fr-FR'), false);
  assert.equal(LT.setPref('loc', 'en-GB'), true);
  assert.equal(LT.state.prefs.loc, 'en-GB');
  assert.equal(LT.setPref('tr', 'no'), false);
  assert.ok(LT.canOpen(1) && !LT.canOpen(2));
  LT.setPref('unlock', true);
  assert.ok(LT.canOpen(50));
});

test('what the client plays is what the server replays: 24 random sessions in a row (injections, replays, peeks, slips)', () => {
  const { LT, clock } = mk();
  const rand = ts.createRng(2026);
  const byLower = new Map(catalog.lessons.flatMap((l) => l.words).map((w) => [w[0].toLowerCase(), w]));
  const item = (w, weight) => ({ wordId: LT.wordId(w[0]), wordText: w[0], sentenceContext: w[1], errorWeight: weight, meaningAr: w[2] || null, sentenceAr: w[3] || null });
  const plan = [1, 2, 3, 4, 5, 6, 1, 7, 8, 9, 10, 2, 11, 12, 13, 14, 3, 15, 16, 17, 18, 19, 20, 21];
  let parent = null, injected = 0, replays = 0;
  for (const g of plan) {
    clock.ms += Math.floor(rand() * 2 * DAY);
    const history = Object.values(LT.state.rotation).filter((r) => r.status === 'active')
      .map((r) => ({ word: item(byLower.get(LT.textOf(r.wordId).toLowerCase()), r.errorWeight), dueSeq: r.dueSeq, lastFailedAt: r.lastFailedAt }));
    const sess = LT.start(g, { seed: Math.floor(rand() * 4294967296) >>> 0 });
    assert.equal(sess.parentSessionId, parent, 'sessions form a chain');
    play(LT, sess, (c, s) => { if (rand() < 0.08) LT.peek(s); return H.behave(rand, c.text, c.step); });
    const commit = LT.commitOf(sess);
    const l = catalog.lessons[g - 1];
    assert.equal(commit.lessonId, ids.lessonId(l.level, l.number));
    assert.equal(commit.mode, sess.mode);
    const replay = ts.replaySession({ sessionId: sess.sessionId, lessonSeq: g, mode: commit.mode, seed: commit.seed, lessonWords: l.words.map((w) => item(w, 0)), history }, commit.attempts);
    assert.ok(replay.ok, replay.reason);
    assert.deepEqual(replay.summary, LT.summary(sess), 'the server derives the same outcomes and XP');
    assert.deepEqual([...commit.injectedWordIds].sort(), Object.values(sess.es.records).filter((r) => r.source === 'injected').map((r) => r.wordId).sort());
    injected += commit.injectedWordIds.length;
    if (sess.mode === 'replay') replays++;
    parent = sess.sessionId;
  }
  assert.ok(injected >= 2 && replays >= 3, `the plan must exercise injections (${injected}) and replays (${replays})`);
});
