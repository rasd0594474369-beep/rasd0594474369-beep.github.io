// Cloud sync (v6), tested against the REAL commit-session handler, the real commit service and the real lesson catalog (on the schema twin):
// the client queues, sends, backs off, learns the chain head, takes the account's state back, and the account always ends up equal to the device.
const test = require('node:test');
const assert = require('node:assert/strict');
const { randomUUID } = require('node:crypto');
const H = require('./_helpers.js');
const Progress = require('../progress.js');
const Sync = require('../sync.js');
const { createBackend } = require('./_backend.js');

let engine, ts, catalog, backend, clock, ids;
const URL_ = 'https://project.supabase.co', KEY_ = 'sb_publishable_test';
const newUser = (name) => backend.addUser(randomUUID(), name);

test.before(async () => {
  engine = await H.loadEngineBundle();
  ts = await H.loadEngineTs();
  catalog = H.loadCatalog();
  clock = { ms: Date.UTC(2026, 10, 21, 9, 0, 0) };
  const probe = Progress.create({ engine, lessons: catalog.lessons });
  ids = { lessonId: probe.lessonId, wordId: probe.wordId };
  backend = await createBackend({ catalog, ids, clock });
});
test.beforeEach(() => { backend.hooks.before = null; backend.calls.length = 0; clock.ms += 60 * 60 * 1000; }); // every test starts an hour later, with a clean call log

/** One phone: its own storage, progress layer, sync module, a fake sign-in and fake timers. */
function device(o = {}) {
  const storage = o.storage || H.makeStorage();
  const skew = o.skew || 0;
  const LT = Progress.create({ engine, lessons: catalog.lessons, storage, now: () => new Date(clock.ms + skew), timeZone: 'UTC', newId: randomUUID });
  const who = { user: o.userId ? { id: o.userId } : null };
  const auth = {
    state: () => (who.user ? { status: 'in', user: who.user, error: null } : { status: 'out', user: null, error: null }),
    getAccessToken: async () => (who.user ? backend.token(who.user.id) : null),
  };
  const timers = [], offsets = [];
  let canPull = true;
  const sync = Sync.create({
    progress: LT, auth, fetch: (u, i) => backend.fetch(u, i), storage, url: URL_, key: KEY_, now: () => clock.ms, random: () => 0,
    setTimeout: (f, ms) => { timers.push({ f, ms, live: true }); return timers.length; }, // ids start at 1 like a browser's
    clearTimeout: (h) => { if (timers[h - 1]) timers[h - 1].live = false; },
    onClockOffset: (ms) => offsets.push(ms), canPull: () => canPull,
  });
  return { storage, LT, sync, who, timers, offsets, signIn: (id) => { who.user = { id }; }, signOut: () => { who.user = null; }, setCanPull: (v) => { canPull = v; }, live: () => timers.filter((t) => t.live) };
}
/** A finished lesson typed the way a person would (perfect = always right). */
function play(LT, o = {}) {
  const rand = o.rand, g = o.seq || LT.nextLesson(), failed = new Set();
  const s = LT.start(g);
  while (!LT.finished(s)) {
    const c = LT.cur(s);
    let typed = o.perfect || !rand ? c.text : H.behave(rand, c.text, c.step);
    if (o.fail && c.step === 'word' && ((!c.rev && failed.size < o.fail && !failed.has(c.word.wordId)) || (c.rev && failed.has(c.word.wordId)))) { failed.add(c.word.wordId); typed = 'zzzzzz'; } // fail these words twice: they join the review list
    clock.ms += 2000;
    LT.submit(s, typed);
  }
  clock.ms += 500;
  return { s, summary: LT.finish(s) };
}
const view = (LT) => ({
  xp: LT.state.xp,
  completed: Object.keys(LT.state.completed).sort((a, b) => a - b),
  streak: [LT.state.streak.streakCount, LT.state.streak.longestStreak, LT.state.streak.lastActiveDate],
  rotation: Object.values(LT.state.rotation).map((r) => [r.wordId, r.errorWeight, r.status, r.dueSeq, r.lifetimeFailures]).sort(),
});
const accountXp = (u) => Number(backend.db.prepare('SELECT total_xp AS x FROM users WHERE id = ?1').all(u)[0].x);
const sessionsOf = (u) => backend.count(`lesson_sessions WHERE user_id = '${u}'`);

test('a finished lesson is queued first, sent in the background, and the account then matches the device', async () => {
  const u = newUser(), A = device({ userId: u });
  assert.equal(A.sync.status().phase, 'idle');
  const { summary } = play(A.LT, { perfect: true });
  assert.equal(summary.xp.total, 250);
  assert.deepEqual([A.sync.status().queued, A.sync.status().phase], [1, 'queued'], 'queued the moment it finished');
  assert.equal(A.live().length, 1, 'a send is scheduled');
  await A.sync.flush();
  assert.deepEqual([A.sync.status().queued, A.sync.status().phase, A.sync.status().error], [0, 'idle', null]);
  assert.equal(sessionsOf(u), 1);
  assert.equal(accountXp(u), 250);
  assert.equal(A.LT.state.xp, 250);

  const B = device({ userId: u }); // a second phone on the same account
  await B.sync.flush();
  assert.deepEqual(view(B.LT), view(A.LT), 'a new device takes the account state');
  assert.equal(B.LT.nextLesson(), 2);
});

test('property: after random lessons (mistakes, rotation words, replays) the account equals the device, and a second device equals both', async () => {
  let rotationSeen = 0, injectedSeen = 0, replays = 0;
  for (const seed of [11, 12, 13]) {
    const rand = ts.createRng(seed), u = newUser(), A = device({ userId: u });
    let played = 0;
    for (let i = 0; i < 6; i++) {
      const r = play(A.LT, { rand, fail: i === 0 ? 3 : 0 }); played++; // lesson 1 leaves three review words, due again from lesson 3
      injectedSeen += A.LT.commitOf(r.s).injectedWordIds.length;
      if (i === 3) { const rp = play(A.LT, { rand, seq: 2 }); played++; replays += rp.summary.mode === 'replay' ? 1 : 0; } // a replay in the middle
      if (rand() < 0.5) await A.sync.flush(); // sometimes sent as we go, sometimes batched
    }
    await A.sync.flush();
    assert.equal(A.sync.status().queued, 0);
    assert.equal(sessionsOf(u), played, `seed ${seed}: every session was recorded`);
    assert.equal(accountXp(u), A.LT.state.xp, `seed ${seed}: the account's XP equals the device's`);
    const B = device({ userId: u });
    await B.sync.flush();
    assert.deepEqual(view(B.LT), view(A.LT), `seed ${seed}: the account's whole state (XP, lessons, streak, review words) equals the device's`);
    rotationSeen += Object.keys(B.LT.state.rotation).length;
  }
  assert.ok(rotationSeen > 0 && injectedSeen > 0 && replays === 3, `coverage: review words ${rotationSeen}, injected ${injectedSeen}, replays ${replays}`);
});

test('a lost answer: the lesson is recorded once, the retry is answered "duplicate" and nothing is counted twice', async () => {
  const u = newUser(), A = device({ userId: u });
  play(A.LT, { perfect: true });
  let lost = false;
  backend.hooks.before = async (url, init) => {
    if (url.pathname.endsWith('commit-session') && !lost) { lost = true; await backend.raw(url.href, init); throw new TypeError('connection lost after the server answered'); }
    return null;
  };
  await A.sync.flush();
  assert.equal(A.sync.status().queued, 0);
  assert.equal(sessionsOf(u), 1);
  assert.equal(accountXp(u), 250, 'not 500');
  assert.equal(backend.calls.filter((c) => c.path.endsWith('commit-session')).length, 2, 'sent, lost, sent again (without the region hint)');
});

test('offline: sessions wait in play order with a growing back-off, and all arrive when the connection is back', async () => {
  const u = newUser(), A = device({ userId: u });
  backend.hooks.before = async () => { throw new TypeError('offline'); };
  for (let i = 0; i < 3; i++) play(A.LT, { perfect: true });
  assert.equal(A.sync.status().queued, 3);
  await A.sync.flush();
  let st = A.sync.status();
  assert.deepEqual([st.queued, st.phase, st.error.kind], [3, 'queued', 'network']);
  const calls = backend.calls.length;
  await A.sync.flush(); // nothing is sent while the back-off runs
  assert.equal(backend.calls.length, calls);
  assert.ok(A.live().at(-1).ms >= 5000, 'the next attempt is scheduled later');
  backend.hooks.before = null;
  clock.ms += 6000;
  await A.sync.flush();
  assert.deepEqual([A.sync.status().queued, A.sync.status().phase], [0, 'idle']);
  assert.equal(sessionsOf(u), 3);
  const rows = backend.db.prepare('SELECT parent_session_id AS p, id FROM lesson_sessions WHERE user_id = ?1 ORDER BY completed_at').all(u);
  assert.equal(rows[0].p, null);
  assert.deepEqual([rows[1].p, rows[2].p], [rows[0].id, rows[1].id], 'the chain follows the play order');
  assert.equal(accountXp(u), 750);
});

test('429 honours Retry-After, 500 backs off, 426 stops for good until the app is updated; nothing is ever dropped', async () => {
  const u = newUser(), A = device({ userId: u });
  play(A.LT, { perfect: true });
  const fail = (status, code, headers = {}) => async (url) => (url.pathname.endsWith('commit-session') ? new Response(JSON.stringify({ ok: false, error: { code, message: code, retryable: status !== 426 } }), { status, headers: { 'content-type': 'application/json', ...headers } }) : null);
  backend.hooks.before = fail(429, 'rate_limited', { 'retry-after': '30' });
  await A.sync.flush();
  let item = JSON.parse(A.storage.getItem(Sync.OUTBOX_KEY)).items[0];
  assert.ok(item.nextTryAt - clock.ms >= 30000, 'Retry-After is respected');
  assert.deepEqual([A.sync.status().error.status, A.sync.status().queued], [429, 1]);
  clock.ms += 31000;
  backend.hooks.before = fail(500, 'internal');
  await A.sync.flush();
  item = JSON.parse(A.storage.getItem(Sync.OUTBOX_KEY)).items[0];
  assert.equal(item.tries, 2);
  clock.ms += 60000;
  backend.hooks.before = fail(426, 'engine_outdated');
  await A.sync.flush();
  assert.equal(A.sync.status().error.kind, 'update');
  assert.equal(A.live().length, 0, 'no timer: only an update helps');
  assert.equal(A.sync.status().queued, 1);
  backend.hooks.before = null;
  await A.sync.flush();
  assert.equal(A.sync.status().queued, 0);
  assert.equal(accountXp(u), 250);
});

test('401: the outbox is kept, no timer spins, and signing in again continues where it stopped', async () => {
  const u = newUser(), A = device({ userId: u });
  play(A.LT, { perfect: true });
  backend.hooks.before = async (url) => (url.pathname.endsWith('commit-session') ? new Response('{"code":401,"message":"Invalid JWT"}', { status: 401 }) : null);
  await A.sync.flush();
  assert.deepEqual([A.sync.status().error.kind, A.sync.status().queued, A.live().length], ['auth', 1, 0]);
  backend.hooks.before = null;
  A.sync.onAuthChange({ type: 'update' });
  assert.equal(A.sync.status().error, null);
  await A.sync.flush();
  assert.equal(A.sync.status().queued, 0);
  assert.equal(sessionsOf(u), 1);
});

test('the region hint is sent, and when that route is down the same request goes once more without it', async () => {
  const u = newUser(), A = device({ userId: u });
  play(A.LT, { perfect: true });
  backend.hooks.before = async (url, init) => (url.pathname.endsWith('commit-session') && init.headers['x-region'] ? new Response('<html>bad gateway</html>', { status: 502 }) : null);
  await A.sync.flush();
  const posts = backend.calls.filter((c) => c.path.endsWith('commit-session'));
  assert.deepEqual(posts.map((c) => c.headers['x-region'] || null), ['ap-south-1', null]);
  assert.equal(A.sync.status().queued, 0);
  assert.equal(sessionsOf(u), 1);
  const h = posts[0].headers;
  assert.deepEqual([h.apikey, /^Bearer .+\..+\./.test(h.Authorization), h['Content-Type']], [KEY_, true, 'application/json']);
});

test('a new phone learns the chain head from the server (out_of_order), its session is accepted, and the first phone catches up', async () => {
  const u = newUser(), A = device({ userId: u });
  play(A.LT, { perfect: true }); play(A.LT, { perfect: true });
  await A.sync.flush();
  const B = device({ userId: u });
  await B.sync.flush();
  assert.equal(B.LT.state.lastSessionId, null, 'a pulled state does not know the chain head');
  const { s } = play(B.LT, { perfect: true }); // lesson 3
  assert.equal(B.LT.commitOf(s).parentSessionId, null);
  const before = backend.commitCalls();
  await B.sync.flush();
  assert.equal(B.sync.status().queued, 0);
  assert.ok(backend.commitCalls() - before >= 2, 'rejected once with the head, then accepted');
  const third = backend.db.prepare('SELECT parent_session_id AS p FROM lesson_sessions WHERE id = ?1').all(s.sessionId)[0];
  const second = backend.db.prepare('SELECT id FROM lesson_sessions WHERE user_id = ?1 AND parent_session_id IS NOT NULL ORDER BY completed_at LIMIT 1').all(u)[0];
  assert.equal(third.p, second.id);
  assert.equal(sessionsOf(u), 3);

  clock.ms += 11 * 60 * 1000; // ten minutes later the first phone looks again
  await A.sync.flush();
  assert.deepEqual(view(A.LT), view(B.LT), 'the first phone sees the lesson played on the second');
  assert.equal(A.LT.nextLesson(), 4);
});

test('a session the account cannot accept is set aside with its reason, and the device takes the account state (the server wins)', async () => {
  const u = newUser(), A = device({ userId: u });
  A.LT.setPref('unlock', true);
  play(A.LT, { perfect: true, seq: 3 }); // lessons 1 and 2 are not finished: locked for the account
  assert.equal(A.LT.state.xp, 250);
  await A.sync.flush();
  assert.equal(sessionsOf(u), 0);
  assert.deepEqual(A.sync.rejected().map((r) => r.code), ['lesson_locked']);
  const st = A.sync.status();
  assert.deepEqual([st.queued, st.notice.kind, st.notice.code], [0, 'rejected', 'lesson_locked']);
  assert.deepEqual(view(A.LT).completed, [], 'the local jump ahead is gone');
  assert.equal(A.LT.state.xp, 0);
  A.sync.ackNotice();
  assert.equal(A.sync.status().notice, null);
  play(A.LT, { perfect: true }); // the normal way works
  await A.sync.flush();
  assert.equal(accountXp(u), 250);
});

test('progress from before the account existed is never synced silently: the learner decides, a backup is kept, then the account starts from zero', async () => {
  const u = newUser(), storage = H.makeStorage();
  play(Progress.create({ engine, lessons: catalog.lessons, storage, now: () => new Date(clock.ms), timeZone: 'UTC', newId: randomUUID }), { perfect: true }); // v5.1 days: no sync yet
  const A = device({ storage, userId: u });
  assert.equal(A.sync.baseline(), 'legacy');
  assert.deepEqual([A.sync.status().phase, A.sync.status().needs], ['needs', 'baseline']);
  await A.sync.flush();
  assert.equal(backend.calls.length, 0, 'nothing is sent, nothing is read');
  play(A.LT, { perfect: true }); // still playable; just not queued
  assert.equal(A.sync.status().queued, 0);

  await A.sync.adopt();
  const backup = JSON.parse(storage.getItem(Sync.BACKUP_KEY));
  assert.deepEqual([backup.state.xp, Object.keys(backup.state.completed)], [500, ['1', '2']], 'the old progress is kept on the device');
  assert.equal(A.LT.isFresh(), true);
  assert.deepEqual([A.sync.status().needs, A.sync.baseline()], [null, 'clean']);
  assert.equal(JSON.parse(storage.getItem(Progress.KEY)).prefs.loc, 'en-US', 'preferences survive');

  const { summary } = play(A.LT, { perfect: true }); // lesson 1 again, now a real first run
  assert.equal(summary.mode, 'first_run');
  await A.sync.flush();
  assert.equal(accountXp(u), 250);
  assert.equal(sessionsOf(u), 1);
});

test('another account on this phone: its progress is not mixed in; switching backs up and takes the new account state', async () => {
  const u1 = newUser(), u2 = newUser(), A = device({ userId: u1 });
  play(A.LT, { perfect: true });
  await A.sync.flush();
  const gone = view(A.LT);
  A.signOut();
  assert.equal(A.sync.status().phase, 'out');
  A.signIn(u2);
  assert.deepEqual([A.sync.status().phase, A.sync.status().needs], ['needs', 'account']);
  const calls = backend.calls.length;
  await A.sync.flush();
  assert.equal(backend.calls.length, calls);
  await A.sync.adopt();
  assert.deepEqual(JSON.parse(A.storage.getItem(Sync.BACKUP_KEY)).state.xp, 250);
  assert.deepEqual(view(A.LT).completed, [], 'the second account starts from its own (empty) state');
  assert.equal(accountXp(u1), 250, 'the first account is untouched');
  // and back again: the first account's progress comes from the cloud, nothing local is needed
  A.signOut(); A.signIn(u1);
  assert.equal(A.sync.status().needs, null, 'a fresh device state can take over without asking');
  await A.sync.flush();
  assert.deepEqual(view(A.LT), gone);
});

test('lessons played while signed out wait on the device, and are sent in order after signing in', async () => {
  const u = newUser(), A = device();
  play(A.LT, { perfect: true }); play(A.LT, { perfect: true });
  assert.deepEqual([A.sync.status().phase, A.sync.status().queued], ['out', 2]);
  await A.sync.flush();
  assert.equal(backend.calls.length, 0);
  A.signIn(u);
  A.sync.onAuthChange({ type: 'signin' });
  await A.sync.flush();
  assert.deepEqual([A.sync.status().queued, sessionsOf(u), accountXp(u)], [0, 2, 500]);
});

test('the lesson is queued BEFORE it is saved locally, so a crash in between can never lose it for the account', () => {
  const log = [], base = H.makeStorage();
  const storage = { getItem: (k) => base.getItem(k), removeItem: (k) => base.removeItem(k), dump: base.dump, setItem: (k, v) => { log.push(k); base.setItem(k, v); } };
  const u = newUser(), A = device({ storage, userId: u });
  const s = A.LT.start(1);
  while (!A.LT.finished(s)) { clock.ms += 2000; A.LT.submit(s, A.LT.cur(s).text); }
  log.length = 0;
  A.LT.finish(s);
  assert.ok(log.indexOf(Sync.OUTBOX_KEY) !== -1 && log.indexOf(Progress.KEY) !== -1);
  assert.ok(log.indexOf(Sync.OUTBOX_KEY) < log.indexOf(Progress.KEY), `order of writes: ${log.join(' → ')}`);
});

test('a pull never overwrites newer local progress: a lesson finished while the account was being read stays and is sent', async () => {
  const u = newUser(), A = device({ userId: u });
  let injected = false;
  backend.hooks.before = async (url) => { if (url.pathname.endsWith('user_word_stats') && !injected) { injected = true; play(A.LT, { perfect: true }); } return null; };
  await A.sync.flush(); // the device is reading the (empty) account when its learner finishes lesson 1
  assert.ok(A.LT.state.completed[1], 'the lesson finished meanwhile is still there');
  assert.equal(A.LT.state.xp, 250);
  assert.equal(A.sync.status().queued, 1, 'and it is waiting to be sent');
  backend.hooks.before = null;
  await A.sync.flush();
  assert.deepEqual([A.sync.status().queued, sessionsOf(u), accountXp(u), A.LT.state.xp], [0, 1, 250, 250]);
});

test('no pull while a lesson is on screen', async () => {
  const u = newUser(), A = device({ userId: u });
  A.setCanPull(false);
  await A.sync.flush();
  assert.equal(backend.calls.filter((c) => c.path.startsWith('/rest/')).length, 0);
  A.setCanPull(true);
  await A.sync.flush();
  assert.ok(backend.calls.filter((c) => c.path.startsWith('/rest/')).length >= 3);
});

test('a device clock that is far off is corrected from the server clock; a small difference is ignored', async () => {
  const u = newUser(), A = device({ userId: u, skew: 10 * 60 * 1000 }); // the device clock is 10 minutes fast
  await A.sync.flush(); // a read is enough to learn the server time
  assert.ok(A.offsets.length > 0);
  assert.ok(Math.abs(A.offsets.at(-1) - 0) >= 0, 'reported');
  // the sync module measures against the device clock it is given (not the corrected one)
  const B = device({ userId: u });
  await B.sync.flush();
  assert.ok(B.offsets.every((o) => o === 0), 'within two minutes: no correction');
  const C = Sync.create({ progress: B.LT, auth: { state: () => ({ status: 'in', user: { id: u } }), getAccessToken: async () => backend.token(u) }, fetch: (a, b) => backend.fetch(a, b), storage: H.makeStorage(), url: URL_, key: KEY_, now: () => clock.ms + 10 * 60 * 1000, onClockOffset: (o) => B.offsets.push(o), setTimeout: () => 0, clearTimeout: () => {} });
  await C.flush();
  assert.ok(Math.abs(B.offsets.at(-1) + 10 * 60 * 1000) <= 1000, `offset ${B.offsets.at(-1)}`);
});

test('wiping the device: unsent sessions go with it, and the account progress comes back from the cloud', async () => {
  const u = newUser(), A = device({ userId: u });
  play(A.LT, { perfect: true });
  await A.sync.flush();
  const kept = view(A.LT);
  backend.hooks.before = async () => { throw new TypeError('offline'); };
  play(A.LT, { perfect: true }); // never sent
  assert.equal(A.sync.status().queued, 1);
  A.sync.localReset();
  A.LT.reset();
  backend.hooks.before = null;
  assert.equal(A.sync.status().queued, 0);
  await A.sync.flush();
  assert.deepEqual(view(A.LT), kept);
  assert.equal(sessionsOf(u), 1);
});

test('damaged sync storage never breaks the app, and a damaged outbox item is set aside by the server, not retried forever', async () => {
  const u = newUser(), storage = H.makeStorage({ [Sync.KEY]: '{oops', [Sync.OUTBOX_KEY]: JSON.stringify({ v: 1, items: [{ commit: { sessionId: randomUUID(), junk: true }, tries: 'x', nextTryAt: 'y' }, 7, null] }) });
  const A = device({ storage, userId: u });
  assert.equal(A.sync.status().queued, 1, 'the one readable item is kept');
  await A.sync.flush();
  assert.equal(A.sync.status().queued, 0);
  assert.equal(A.sync.rejected().length, 1);
  assert.equal(A.sync.rejected()[0].code, 'bad_request');
  assert.doesNotThrow(() => play(A.LT, { perfect: true }));
});

test('taking the account state is defensive: garbage rows are ignored, valid ones kept, and preferences and the chain head stay', () => {
  const A = device();
  A.LT.setPref('loc', 'en-GB');
  const s = A.LT.start(1);
  while (!A.LT.finished(s)) { clock.ms += 2000; A.LT.submit(s, A.LT.cur(s).text); }
  A.LT.finish(s);
  const head = A.LT.state.lastSessionId;
  const w = catalog.lessons[0].words[0][0], wid = ids.wordId(w);
  A.LT.replaceFromCloud({
    totalXp: 40.5, streakCount: 'x', longestStreak: -2, lastActiveDate: 'yesterday',
    completedLessonIds: [ids.lessonId(2), 'nope', 7, null, randomUUID()],
    rotation: [
      { wordId: wid, errorWeight: 2, status: 'active', dueSeq: 4, lifetimeFailures: 3, lastFailedAt: null, lastReviewedAt: null },
      { wordId: 'not-a-word', errorWeight: 1, status: 'active', dueSeq: 1, lifetimeFailures: 1 },
      { wordId: ids.wordId(catalog.lessons[1].words[0][0]), errorWeight: 'many', status: 'active', dueSeq: 1, lifetimeFailures: 1 },
      null, 5,
    ],
  });
  assert.deepEqual([A.LT.state.xp, Object.keys(A.LT.state.completed), Object.keys(A.LT.state.rotation)], [0, ['2'], [wid]], 'bad numbers become zero, unknown lessons and words are dropped');
  assert.deepEqual(A.LT.state.streak, { streakCount: 0, longestStreak: 0, lastActiveDate: null });
  assert.equal(A.LT.state.prefs.loc, 'en-GB');
  assert.equal(A.LT.state.lastSessionId, head);
  assert.equal(JSON.parse(A.storage.getItem(Progress.KEY)).completed[2], true, 'and it is saved');
});
