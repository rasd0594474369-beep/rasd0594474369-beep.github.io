// Node tests for the privacy and terms pages: they are built into the site, link to each other and to the app,
// load nothing external, and what the privacy page says about third parties matches what the app really loads.
const test = require('node:test');
const assert = require('node:assert/strict');
const { execFileSync } = require('node:child_process');
const { mkdtempSync, readFileSync, existsSync, readdirSync } = require('node:fs');
const { tmpdir } = require('node:os');
const { join, resolve } = require('node:path');

const ROOT = resolve(__dirname, '..', '..');
const EMAIL = 'rasd0594474369@gmail.com';
const read = (p) => readFileSync(join(ROOT, p), 'utf8');

const out = mkdtempSync(join(tmpdir(), 'lingotrace-site-'));
execFileSync(process.execPath, [join(ROOT, 'scripts', 'build-site.mjs'), out], { cwd: ROOT, stdio: 'pipe' });
const pages = {
  privacy: readFileSync(join(out, 'privacy', 'index.html'), 'utf8'),
  terms: readFileSync(join(out, 'terms', 'index.html'), 'utf8'),
};
const hrefs = (html) => [...html.matchAll(/href="([^"]*)"/g)].map((m) => m[1]);
const updated = (html) => (html.match(/آخر تحديث: ([^<]+)</) || [])[1];

test('the site build publishes /privacy/ and /terms/ and keeps sources and tests out', () => {
  assert.ok(existsSync(join(out, 'privacy', 'index.html')));
  assert.ok(existsSync(join(out, 'terms', 'index.html')));
  assert.ok(existsSync(join(out, 'index.html')));
  const names = readdirSync(out);
  for (const bad of ['legal', 'test', 'e2e']) assert.ok(!names.includes(bad), `${bad}/ must not be published`);
});

for (const name of ['privacy', 'terms']) {
  test(`${name}: Arabic RTL page with title, last-updated date and the contact email`, () => {
    const html = pages[name];
    assert.match(html, /<html lang="ar" dir="rtl">/);
    assert.match(html, /<title>[^<]+\| LingoTrace<\/title>/);
    assert.ok(updated(html), 'has a last-updated line');
    assert.ok(html.includes(`mailto:${EMAIL}`), 'has the contact email');
  });

  test(`${name}: loads nothing external (no scripts, frames, images, stylesheets or fonts)`, () => {
    const html = pages[name];
    assert.doesNotMatch(html, /<script/i);
    assert.doesNotMatch(html, /<iframe/i);
    assert.doesNotMatch(html, /<img/i);
    assert.doesNotMatch(html, /<link[^>]+rel="stylesheet"/i);
    assert.doesNotMatch(html, /@import|url\(\s*['"]?https?:/i);
    assert.doesNotMatch(html, /\ssrc=/i);
  });

  test(`${name}: every outside link opens safely and the page links back to the app`, () => {
    const html = pages[name];
    for (const m of html.matchAll(/<a [^>]*href="(https?:[^"]+)"[^>]*>/g)) assert.match(m[0], /rel="noopener"/, `external link needs rel=noopener: ${m[1]}`);
    assert.ok(hrefs(html).includes('../'), 'has a link back to the app');
  });
}

test('the two pages link to each other and carry the same last-updated date', () => {
  assert.ok(hrefs(pages.privacy).includes('../terms/'));
  assert.ok(hrefs(pages.terms).includes('../privacy/'));
  assert.equal(updated(pages.privacy), updated(pages.terms));
});

test('the app links to both pages from the signed-in and the signed-out account card', () => {
  const app = read('web/index.html');
  assert.equal(app.split("lk('terms/'").length - 1, 2);
  assert.equal(app.split("lk('privacy/'").length - 1, 2);
});

test('privacy page names the providers the app really uses', () => {
  const html = pages.privacy;
  for (const word of ['Google', 'Supabase', 'GitHub Pages']) assert.ok(html.includes(word), `mentions ${word}`);
  assert.ok(html.includes('Google Fonts'), 'mentions Google Fonts');
  assert.ok(html.includes('30 يومًا'), 'states the deletion time');
});

test('what the app loads from outside is exactly what the privacy page discloses', () => {
  const hostsOf = (src) => new Set([...src.matchAll(/https?:\/\/([^\s"'<>)\\\/:]+)/g)].map((m) => m[1]));
  const appHosts = hostsOf(read('web/index.html'));
  const authHosts = hostsOf(read('web/auth.js'));
  assert.deepEqual([...appHosts].sort(), ['fonts.googleapis.com'], 'index.html may only reference Google Fonts; add any new host to the privacy page first');
  assert.deepEqual([...authHosts].sort(), ['yvszergcvjnzpogubqex.supabase.co'], 'auth.js may only talk to the Supabase project');
});
