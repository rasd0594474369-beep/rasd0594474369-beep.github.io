// v5 must behave like v3 for the same inputs. The ORIGINAL v3/v4.1 logic (fixtures/legacy-v3-logic.txt, a verbatim copy) runs unmodified next to the
// engine-based v5 flow; both get the same random stream, the same typed text and the same peeks, and every answer and every final state is compared.
// The ONLY intended difference: ids. v3 used the word text as its id, v5 uses the database UUID, so the legacy code gets the UUIDs too
// (they decide tie-breaks when the rotation is sorted). Everything else must match.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const H = require('./_helpers.js');
const Progress = require('../progress.js');

const LEGACY_CODE = fs.readFileSync(path.join(__dirname, 'fixtures', 'legacy-v3-logic.txt'), 'utf8');
const TZ = Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
const HOUR = 3600e3, DAY = 24 * HOUR;

let engine, catalog;
test.before(async () => { engine = await H.loadEngineBundle(); catalog = H.loadCatalog(); });

function makeLegacy({ D, random, now, idOf }) {
  const code = LEGACY_CODE.replace("const mkw=t=>({id:t,text:t,", "const mkw=t=>({id:IDOF(t),text:t,");
  assert.ok(code.includes('IDOF(t)'), 'the id swap must apply');
  const store = {};
  const FakeMath = Object.create(Math);
  FakeMath.random = random;
  const FakeDate = class extends Date { constructor(...a) { if (a.length) super(...a); else super(now.ms); } static now() { return now.ms; } };
  const factory = new Function('D', 'localStorage', 'Math', 'Date', 'IDOF',
    code + '\nreturn { L, build, mkw, submit, finish, streak, evalW, evalS, get S() { return S; }, set S(v) { S = v; }, get P() { return P; } };');
  return factory(D, { getItem: (k) => store[k] ?? null, setItem: (k, v) => { store[k] = String(v); } }, FakeMath, FakeDate, idOf);
}
function legacyStart(lg, g, textOf) { // the one function of v3 that lived in the UI part of the file
  const mode = lg.P.c[g] ? 'replay' : 'first_run';
  const hist = mode === 'replay' ? [] : Object.entries(lg.P.rot).filter(([, r]) => r.status === 'active').map(([id, r]) => ({ w: lg.mkw(textOf(id)), weight: r.weight, due: r.due, last: r.last }));
  lg.S = { q: lg.build(lg.L[g - 1].words.map(([t]) => lg.mkw(t)), hist, g), lesson: g, mode, step: 0, fails: 0, peek: false, done: 0, rec: {}, xp: { first: 0, rec: 0, bonus: 0 }, finished: false };
}

test('spelling verdicts: v3 and the engine agree on 6,000 typed answers (words and sentences)', () => {
  const noop = () => 0;
  const idOf = (t) => t;
  const lg = makeLegacy({ D: catalog.D, random: noop, now: { ms: Date.UTC(2026, 10, 1) }, idOf });
  const rand = engine.createRng(31);
  let different = 0;
  for (let i = 0; i < 3000; i++) {
    const w = catalog.lessons[i % catalog.lessons.length].words[(i * 7) % 20];
    const word = H.behave(rand, w[0], 'word'), sentence = H.behave(rand, w[1], 'sentence');
    assert.equal(engine.evaluateWord(word, w[0], 1).verdict, lg.evalW(word, w[0]), `word ${JSON.stringify([word, w[0]])}`);
    assert.equal(engine.evaluateSentence(sentence, w[1], 1).verdict, lg.evalS(sentence, w[1]), `sentence ${JSON.stringify([sentence, w[1]])}`);
    if (word !== w[0]) different++;
  }
  assert.ok(different > 500, 'the inputs must include many wrong ones');
});

test('lessons: 60 users x 14 lessons (first runs, replays, slips, peeks, failures, injections, idle days): every answer and every state match v3', () => {
  const stats = { injected: 0, failedTwice: 0, retypes: 0, replays: 0, misses: 0, steps: 0 };
  for (let user = 0; user < 60; user++) {
    const rand = engine.createRng(777 + user);
    const now = { ms: Date.UTC(2026, 10, 1, 9, 0, 0) };
    let stream = engine.createRng(1);
    const LT = Progress.create({
      engine, lessons: catalog.lessons, storage: H.makeStorage(), now: () => new Date(now.ms), timeZone: TZ,
      newId: (() => { let n = 0; return () => `00000000-0000-4000-8000-${String(++n).padStart(12, '0')}`; })(),
    });
    const lg = makeLegacy({ D: catalog.D, random: () => stream(), now, idOf: LT.wordId });
    const plan = [1, 2, 3, 4, 1, 5, 6, 7, 2, 8, 9, 10, 11, 12];
    for (const g of plan) {
      now.ms += [0, 5 * HOUR, DAY, 1.5 * DAY, 3 * DAY][Math.floor(rand() * 5)];
      const seed = Math.floor(rand() * 4294967296) >>> 0;
      stream = engine.createRng(seed); // v3 draws from Math.random: give it the very stream the engine session will use
      legacyStart(lg, g, LT.textOf);
      const sess = LT.start(g, { seed });
      assert.deepEqual(sess.es.queue.map((q) => `${q.itemId}|${q.steps}`), lg.S.q.map((q) => `${q.id}|${q.steps}`), `queue of lesson ${g}, user ${user}`);
      stats.injected += sess.es.queue.filter((q) => q.source === 'injected').length;
      if (sess.mode === 'replay') stats.replays++;
      for (let guard = 0; !lg.S.finished; guard++) {
        assert.ok(guard < 500 && !LT.finished(sess), 'both sessions end together');
        const q = lg.S.q[0], step = q.steps[lg.S.step], target = step === 'word' ? q.w.text : q.w.sentence;
        const c = LT.cur(sess);
        assert.deepEqual([c.step, c.text, c.rev, c.src], [step, target, q.rev, q.src]);
        if (rand() < 0.1) { lg.S.peek = true; LT.peek(sess); }
        const input = H.behave(rand, target, step);
        const a = lg.submit(input), b = LT.submit(sess, input);
        assert.deepEqual(b, a, `answer to ${JSON.stringify(input)} for ${JSON.stringify(target)}`);
        stats.steps++;
        if (a.k === 'retype') stats.retypes++;
        if (a.k === 'miss') stats.misses++;
      }
      assert.ok(LT.finished(sess));
      assert.deepEqual(sess.es.xp, { firstTry: lg.S.xp.first, recovered: lg.S.xp.rec, lessonBonus: lg.S.xp.bonus });
      lg.finish();
      LT.finish(sess);
      // state: XP, completed lessons, rotation, streak
      assert.equal(LT.state.xp, lg.P.xp);
      assert.deepEqual(Object.keys(LT.state.completed).sort(), Object.keys(lg.P.c).sort());
      const rotation = Object.fromEntries(Object.values(LT.state.rotation).map((r) => [r.wordId, { weight: r.errorWeight, status: r.status, due: r.dueSeq, last: r.lastFailedAt }]));
      assert.deepEqual(rotation, lg.P.rot);
      assert.deepEqual([LT.state.streak.streakCount, LT.state.streak.longestStreak, LT.state.streak.lastActiveDate], [lg.P.streak, lg.P.best, lg.P.day]);
      assert.equal(LT.streak(), lg.streak());
      stats.failedTwice += Object.values(rotation).filter((r) => r.status === 'active').length;
    }
  }
  assert.ok(stats.injected > 80 && stats.retypes > 100 && stats.misses > 100 && stats.replays >= 60 && stats.failedTwice > 100,
    `the run must exercise every path: ${JSON.stringify(stats)}`);
});
