// Lessons in progress (v5.1): the app saves a lesson after every accepted action, so closing it mid-lesson and reopening it resumes at the same
// word with the same points. The main proof is a property test: kill the app at EVERY step of random lessons, reopen, finish, and require the
// outcome to be byte-for-byte what an uninterrupted lesson produces (state, XP, review words, random choices, the commit the server replays).
const test = require('node:test');
const assert = require('node:assert/strict');
const H = require('./_helpers.js');
const Progress = require('../progress.js');

let engine, ts, catalog;
test.before(async () => {
  engine = await H.loadEngineBundle();
  ts = await H.loadEngineTs();
  catalog = H.loadCatalog();
});

const KEY = Progress.KEY, DRAFT = Progress.DRAFT_KEY;
const WRONG = 'zzzzzz';
const plain = (x) => JSON.parse(JSON.stringify(x));

// An "app" whose memory can be thrown away: world.open() builds a brand-new progress layer on the SAME storage (= closing and reopening the app).
function world(storage) {
  const st = storage || H.makeStorage();
  const clock = { ms: Date.UTC(2026, 10, 21, 8, 0, 0) };
  let n = 0;
  const open = (s = st) => Progress.create({
    engine, lessons: catalog.lessons, storage: s, now: () => new Date(clock.ms), timeZone: 'UTC',
    newId: () => `00000000-0000-4000-8000-${String(++n).padStart(12, '0')}`,
  });
  return { storage: st, clock, open };
}
const answerRight = (LT, s, times) => { for (let i = 0; i < times; i++) LT.submit(s, LT.cur(s).text); };
const finishRight = (LT, s) => { while (!LT.finished(s)) LT.submit(s, LT.cur(s).text); return LT.finish(s); };
const draftsOf = (storage) => { const raw = storage.getItem(DRAFT); return raw == null ? null : JSON.parse(raw).drafts; };

test('a lesson is saved after every accepted action, and only what the learner did is stored', () => {
  const w = world(), LT = w.open();
  assert.equal(w.storage.getItem(DRAFT), null, 'nothing is saved before a lesson starts');
  const s = LT.start(1, { seed: 5 });
  let d = draftsOf(w.storage)['1'];
  assert.deepEqual([d.attempts.length, d.peeked, d.open, d.mode, d.seed, d.lesson, d.sessionId], [0, false, true, 'first_run', 5, 1, s.sessionId]);
  LT.peek(s);
  assert.equal(draftsOf(w.storage)['1'].peeked, true, 'the peek is saved the moment it happens');
  const word = LT.cur(s).text;
  LT.submit(s, word);
  d = draftsOf(w.storage)['1'];
  assert.equal(d.attempts.length, 1);
  assert.deepEqual(Object.keys(d.attempts[0]).sort(), ['at', 'input', 'itemId', 'step', 'usedPeek']);
  assert.deepEqual([d.attempts[0].input, d.attempts[0].usedPeek, d.attempts[0].step], [word, true, 'word']);
  assert.equal(d.peeked, false, 'the next step starts un-peeked');
  for (const k of ['xp', 'queue', 'records', 'log']) assert.ok(!(k in d), `no derived data is stored (${k}): the state is rebuilt from what was typed`);
  assert.ok(JSON.stringify(d).length < 2000, 'tiny');
  assert.equal(w.open().state.xp, 0, 'points inside a lesson count toward the total only when the lesson is finished');
});

test('closing the app on word 4 and reopening: the same word, the same points, the same place in the lesson', () => {
  const w = world(), LT = w.open();
  const s = LT.start(1, { seed: 7 });
  answerRight(LT, s, 6); // words 1-3, each is the word and its sentence
  const before = { cur: plain(LT.cur(s)), xp: plain(s.es.xp), progress: plain(LT.progress(s)) };
  assert.deepEqual([before.progress.done, before.xp.firstTry, LT.cur(s).step], [3, 30, 'word']);

  const LT2 = w.open(); // everything in memory is gone: only the storage is left
  assert.equal(LT2.state.xp, 0);
  const r = LT2.resumeOpen();
  assert.ok(r && r.resumed === true && r.open === true);
  assert.deepEqual(plain(LT2.cur(r)), before.cur, 'the same word is on screen');
  assert.deepEqual(plain(r.es.xp), before.xp, 'the same points inside the lesson');
  assert.deepEqual(plain(LT2.progress(r)), before.progress, 'the same progress bar');
  assert.deepEqual(plain(r.es), plain(s.es), 'the whole engine state is identical');
  assert.equal(LT2.state.xp, 0, 'still not counted toward the total');

  const summary = finishRight(LT2, r);
  assert.equal(summary.xp.total, 250, 'a clean lesson is still 250 XP, even after a restart in the middle');
  assert.equal(LT2.state.xp, 250);
  assert.equal(draftsOf(w.storage), null, 'finished: nothing is left to resume');
  assert.equal(w.open().resumeOpen(), null);
  assert.equal(w.open().state.xp, 250, 'and the finished lesson is saved normally');
});

test('every step, every kind of lesson: killing the app anywhere and reopening gives exactly the uninterrupted outcome', (t) => {
  const byLower = new Map(catalog.lessons.flatMap((l) => l.words).map((x) => [x[0].toLowerCase(), x]));
  const item = (LT, x, weight) => ({ wordId: LT.wordId(x[0]), wordText: x[0], sentenceContext: x[1], errorWeight: weight, meaningAr: x[2] || null, sentenceAr: x[3] || null });

  function baseDump(kind) {
    const w = world(), LT = w.open();
    if (kind === 'injected') { // lesson 1 with three words failed twice (due from lesson 3), then lesson 2 clean
      const s = LT.start(1, { seed: 11 }), failed = new Set();
      while (!LT.finished(s)) {
        const c = LT.cur(s);
        const bad = c.step === 'word' && ((!c.rev && failed.size < 3 && !failed.has(c.word.wordId)) || (c.rev && failed.has(c.word.wordId)));
        if (bad) failed.add(c.word.wordId);
        LT.submit(s, bad ? WRONG : c.text);
      }
      LT.finish(s);
      finishRight(LT, LT.start(2, { seed: 12 }));
      assert.equal(LT.rotation().length, 3);
    } else if (kind === 'replay') finishRight(LT, LT.start(1, { seed: 13 }));
    return w.storage.dump();
  }

  let trials = 0, resumedPoints = 0, injectedSeen = 0, withPeekPoint = 0, withRetypePoint = 0;
  const plan = [
    ...[101, 102, 103, 104, 105, 106, 107, 108].map((seed) => ({ kind: 'injected', seq: 3, seed })),
    ...[201, 202, 203].map((seed) => ({ kind: 'replay', seq: 1, seed })),
    ...[301, 302, 303].map((seed) => ({ kind: 'plain', seq: 1, seed })),
  ];
  for (const t of plan) {
    const rand = ts.createRng(t.seed), base = baseDump(t.kind), sessionId = `11111111-2222-4333-8444-${String(t.seed).padStart(12, '0')}`;
    const seed = Math.floor(rand() * 4294967296) >>> 0;

    // 1) the uninterrupted lesson, recording every action (a peek or a typed answer) and the state after each one
    const st = H.makeStorage(base), w = world(st), LT = w.open();
    const t0 = w.clock.ms;
    const sess = LT.start(t.seq, { seed, sessionId });
    const actions = [], snaps = [st.dump()], esAt = [plain(sess.es)];
    const act = (a) => { actions.push(a); w.clock.ms = t0 + 1000 * actions.length; if (a.op === 'peek') LT.peek(sess); else LT.submit(sess, a.input); snaps.push(st.dump()); esAt.push(plain(sess.es)); };
    while (!LT.finished(sess)) {
      const c = LT.cur(sess);
      if (rand() < 0.1 && !sess.es.peeked) act({ op: 'peek' });
      act({ op: 'submit', input: H.behave(rand, c.text, c.step) });
      assert.ok(actions.length < 600, 'the lesson must end');
    }
    const tEnd = t0 + 1000 * (actions.length + 1);
    w.clock.ms = tEnd;
    const refSummary = LT.finish(sess), refCommit = LT.commitOf(sess), refState = plain(LT.state);

    // the server accepts it and derives the same outcome
    const l = catalog.lessons[t.seq - 1];
    const baseLT = world(H.makeStorage(base)).open();
    const history = Object.values(baseLT.state.rotation).filter((r) => r.status === 'active')
      .map((r) => ({ word: item(baseLT, byLower.get(baseLT.textOf(r.wordId).toLowerCase()), r.errorWeight), dueSeq: r.dueSeq, lastFailedAt: r.lastFailedAt }));
    const replay = ts.replaySession({ sessionId, lessonSeq: t.seq, mode: refCommit.mode, seed, lessonWords: l.words.map((x) => item(baseLT, x, 0)), history }, refCommit.attempts);
    assert.ok(replay.ok, replay.reason);
    assert.deepEqual(replay.summary, refSummary);
    injectedSeen += refCommit.injectedWordIds.length;
    if (t.kind === 'injected') assert.ok(refCommit.injectedWordIds.length > 0, 'the injected trials really contain rotation words');

    // 2) kill the app after EVERY action (and right at the start), reopen from what was saved, play the rest, compare with the reference
    for (let k = 0; k <= actions.length; k++) {
      const st2 = H.makeStorage(snaps[k]), w2 = world(st2);
      w2.clock.ms = t0 + 1000 * k;
      const LT2 = w2.open(), r = LT2.resumeOpen();
      assert.ok(r, `trial ${t.seed}: nothing to resume after ${k} actions`);
      assert.deepEqual(plain(r.es), esAt[k], `trial ${t.seed}: the rebuilt state after ${k} actions differs`);
      if (r.es.peeked) withPeekPoint++;
      if (r.es.phase === 'awaiting_retype') withRetypePoint++;
      for (let j = k; j < actions.length; j++) {
        w2.clock.ms = t0 + 1000 * (j + 1);
        if (actions[j].op === 'peek') LT2.peek(r); else LT2.submit(r, actions[j].input);
      }
      w2.clock.ms = tEnd;
      assert.deepEqual(LT2.finish(r), refSummary, `trial ${t.seed}: outcome differs after a restart at action ${k}`);
      assert.deepEqual(LT2.commitOf(r), refCommit, `trial ${t.seed}: the commit differs after a restart at action ${k}`);
      assert.deepEqual(plain(LT2.state), refState, `trial ${t.seed}: the saved progress differs after a restart at action ${k}`);
      assert.equal(st2.getItem(DRAFT), null, 'nothing left behind');
      resumedPoints++;
    }
    trials++;
  }
  t.diagnostic(`resume coverage: ${trials} lessons, ${resumedPoints} interruption points, ${injectedSeen} injected words, ${withPeekPoint} peek points, ${withRetypePoint} retype points`);
  assert.equal(trials, 14);
  assert.ok(resumedPoints > 600, `many interruption points were exercised (${resumedPoints})`);
  assert.ok(injectedSeen > 0 && withPeekPoint > 5 && withRetypePoint > 5, `coverage: injected ${injectedSeen}, peek points ${withPeekPoint}, retype points ${withRetypePoint}`);
});

test('the eye button cannot be undone by closing the app: a peek stays a peek', () => {
  const w = world(), LT = w.open(), s = LT.start(1, { seed: 9 });
  LT.peek(s);
  const r = w.open().resumeOpen();
  assert.equal(r.es.peeked, true);
  const out = w.open().resumeOpen();
  assert.deepEqual(plain(out.es), plain(r.es));
  const LT2 = w.open(), r2 = LT2.resumeOpen();
  assert.deepEqual(LT2.submit(r2, LT2.cur(r2).text), { k: 'ok', xp: 5 }, 'the lower tier applies, exactly as without a restart');
});

test('a wrong attempt is not forgotten: after a near-miss, a restart still needs the retype, and a second slip fails the word', () => {
  const w = world(), LT = w.open(), s = LT.start(1, { seed: 21 });
  while (!(LT.cur(s).step === 'word' && LT.cur(s).text.length >= 4)) LT.submit(s, LT.cur(s).text);
  const word = LT.cur(s).text, slip = word.slice(1);
  assert.equal(LT.submit(s, slip).k, 'retype');

  const LT2 = w.open(), r = LT2.resumeOpen();
  assert.deepEqual([r.es.phase, r.es.failedAttempts, LT2.cur(r).text], ['awaiting_retype', 1, word]);
  assert.equal(LT2.submit(r, slip).k, 'fail', 'closing the app did not reset the attempt counter');
  assert.equal(LT2.cur(r).text !== word || LT2.cur(r).rev === false, true);

  const w3 = world(), A = w3.open(), s3 = A.start(1, { seed: 21 });
  while (!(A.cur(s3).step === 'word' && A.cur(s3).text.length >= 4)) A.submit(s3, A.cur(s3).text);
  A.submit(s3, A.cur(s3).text.slice(1));
  const B = w3.open(), r3 = B.resumeOpen();
  assert.deepEqual(B.submit(r3, B.cur(r3).text), { k: 'ok', xp: 5 }, 'a correct retype after the restart pays the recovered tier');
});

test('the back arrow still works after a restart: the answers already given are rebuilt (near-misses are not part of it)', () => {
  const w = world(), LT = w.open(), s = LT.start(1, { seed: 31 });
  const w1 = LT.cur(s).text; LT.submit(s, w1);
  const s1 = LT.cur(s).text; LT.submit(s, s1);
  while (!(LT.cur(s).step === 'word' && LT.cur(s).text.length >= 4)) LT.submit(s, LT.cur(s).text);
  const trailLength = LT.progress(s).done * 2;
  const w2 = LT.cur(s).text;
  LT.submit(s, w2.slice(1)); // near-miss: not reviewable
  LT.submit(s, w2);
  const r = w.open().resumeOpen();
  assert.equal(r.trail.length, trailLength + 1, 'the near-miss is not in the trail, the corrected answer is');
  assert.deepEqual(r.trail.slice(0, 2).map((t) => [t.step, t.text]), [['word', w1], ['sentence', s1]]);
  assert.deepEqual([r.trail.at(-1).step, r.trail.at(-1).text, r.trail.at(-1).wordText], ['word', w2, w2]);
});

test('closed right after the last answer: reopening finishes the lesson exactly once and nothing is lost', () => {
  const w = world(), LT = w.open(), s = LT.start(1, { seed: 3 });
  while (!LT.finished(s)) LT.submit(s, LT.cur(s).text); // the last answer is accepted, the app dies before finish()
  assert.equal(w.open().state.xp, 0, 'not credited yet: the app died before finish()');
  const LT2 = w.open(), r = LT2.resumeOpen();
  assert.ok(r && LT2.finished(r), 'a completed session comes back as completed');
  const summary = LT2.finish(r);
  assert.equal(summary.xp.total, 250);
  assert.equal(LT2.finish(r) === summary, false);
  assert.equal(LT2.state.xp, 250, 'a second finish() adds nothing');
  assert.deepEqual(Object.keys(LT2.state.completed), ['1']);
  assert.equal(LT2.state.lastSessionId, r.sessionId);
  assert.equal(w.open().resumeOpen(), null);
  assert.equal(w.open().state.xp, 250);
});

test('leaving a lesson on purpose: a first run waits (nothing lost), a practice run and an untouched lesson are not kept', () => {
  // first run with progress: kept, not reopened by itself, resumable from the map
  let w = world(), LT = w.open(), s = LT.start(1, { seed: 41 });
  answerRight(LT, s, 5);
  LT.leave(s);
  let d = draftsOf(w.storage)['1'];
  assert.deepEqual([d.open, d.attempts.length], [false, 5]);
  let LT2 = w.open();
  assert.equal(LT2.resumeOpen(), null, 'the app does not jump back into a lesson the learner left');
  assert.equal(LT2.hasDraft(1), true, 'the map can offer «تابع»');
  assert.equal(LT2.hasDraft(2), false);
  const r = LT2.resume(1);
  assert.deepEqual(plain(r.es), plain(s.es));
  assert.equal(draftsOf(w.storage)['1'].open, true, 'resuming makes it the open lesson again');

  // untouched: nothing to resume
  w = world(); LT = w.open(); s = LT.start(1, { seed: 42 }); LT.leave(s);
  assert.equal(w.storage.getItem(DRAFT), null);
  assert.equal(w.open().hasDraft(1), false);

  // practice (replay): not kept after leaving on purpose, but kept while the app is merely closed
  w = world(); LT = w.open(); finishRight(LT, LT.start(1, { seed: 43 }));
  s = LT.start(1, { seed: 44 }); assert.equal(s.mode, 'replay'); answerRight(LT, s, 4);
  assert.equal(w.open().resumeOpen().mode, 'replay', 'a replay survives the app being closed');
  LT.leave(s);
  assert.equal(w.storage.getItem(DRAFT), null, 'but leaving a replay on purpose drops it: practice never traps the learner');

  // leaving after the last answer finishes the lesson instead of losing it
  w = world(); LT = w.open(); s = LT.start(1, { seed: 45 });
  while (!LT.finished(s)) LT.submit(s, LT.cur(s).text);
  LT.leave(s);
  assert.equal(LT.state.xp, 250);
  assert.equal(w.storage.getItem(DRAFT), null);
});

test('several lessons can wait (unlock-all practice mode): starting one never destroys another, one is open, and the cap keeps the newest', () => {
  const w = world(), LT = w.open();
  LT.setPref('unlock', true);
  const order = [5, 9, 12, 20, 30];
  for (const g of order) {
    w.clock.ms += 1000;
    const s = LT.start(g, { seed: g });
    answerRight(LT, s, 2);
    w.clock.ms += 1000;
    LT.leave(s);
  }
  const d = draftsOf(w.storage);
  assert.deepEqual(Object.keys(d).map(Number).sort((a, b) => a - b), [9, 12, 20, 30], 'at most 4 wait; the oldest (lesson 5) went');
  assert.ok(Object.values(d).every((x) => x.open === false));
  const s = LT.start(9, { seed: 99 }); // starting fresh replaces only lesson 9's own draft
  assert.equal(draftsOf(w.storage)['9'].sessionId, s.sessionId);
  assert.deepEqual(Object.keys(draftsOf(w.storage)).map(Number).sort((a, b) => a - b), [9, 12, 20, 30]);
  const r12 = w.open().resume(12);
  assert.equal(r12.es.log.length, 2);
  const open = Object.entries(draftsOf(w.storage)).filter(([, x]) => x.open).map(([k]) => k);
  assert.deepEqual(open, ['12'], 'exactly one lesson is open at a time');
});

test('stale drafts are dropped, never resumed: finished elsewhere, already recorded, reset, or a replay of a lesson that is not complete', () => {
  const base = world(), LT = base.open(), s = LT.start(1, { seed: 51 });
  answerRight(LT, s, 4);
  const draftRaw = base.storage.getItem(DRAFT), parsed = JSON.parse(draftRaw);

  // the same lesson was finished on another device / tab: its draft must not come back
  let st = H.makeStorage({ [DRAFT]: draftRaw, [KEY]: JSON.stringify({ v: 1, xp: 250, streak: { streakCount: 1, longestStreak: 1, lastActiveDate: '2026-11-21' }, completed: { 1: true }, rotation: {}, prefs: { loc: 'en-US', unlock: false, tr: true }, lastSessionId: null }) });
  let LT2 = world(st).open();
  assert.equal(LT2.resumeOpen(), null);
  assert.equal(st.getItem(DRAFT), null, 'and the stale draft is removed');

  // that very session was already recorded
  st = H.makeStorage({ [DRAFT]: draftRaw, [KEY]: JSON.stringify({ v: 1, xp: 0, streak: { streakCount: 0, longestStreak: 0, lastActiveDate: null }, completed: {}, rotation: {}, prefs: { loc: 'en-US', unlock: false, tr: true }, lastSessionId: parsed.drafts['1'].sessionId }) });
  assert.equal(world(st).open().resumeOpen(), null);

  // a replay draft needs a completed lesson (after «إعادة ضبط التجربة» there is none)
  const replayDraft = JSON.stringify({ v: 1, drafts: { 1: { ...parsed.drafts['1'], mode: 'replay' } } });
  assert.equal(world(H.makeStorage({ [DRAFT]: replayDraft })).open().resumeOpen(), null);

  // a locked lesson (unlock-all switched off again) is not resumable
  const locked = JSON.stringify({ v: 1, drafts: { 7: { ...parsed.drafts['1'], lesson: 7 } } });
  assert.equal(world(H.makeStorage({ [DRAFT]: locked })).open().resumeOpen(), null);

  // reset wipes drafts too
  LT.reset();
  assert.equal(base.storage.getItem(DRAFT), null);
  assert.equal(base.open().resumeOpen(), null);
});

test('damaged or foreign storage never breaks the app: no draft, no exception, and a lesson can still be played', () => {
  const real = world(), A = real.open(), s = A.start(1, { seed: 61 });
  answerRight(A, s, 3);
  const good = JSON.parse(real.storage.getItem(DRAFT)), g = good.drafts['1'];
  const wrap = (d, k = '1') => JSON.stringify({ v: 1, drafts: { [k]: d } });
  const bad = [
    'not json', '{', 'null', '[]', '"x"', '{"v":2,"drafts":{}}', '{"v":1}', '{"v":1,"drafts":[]}',
    wrap({ ...g, ev: 999 }), wrap({ ...g, sessionId: 'nope' }), wrap({ ...g, mode: 'other' }), wrap({ ...g, seed: -1 }), wrap({ ...g, seed: 2 ** 32 }),
    wrap({ ...g, seed: 1.5 }), wrap({ ...g, startedAt: 'yesterday' }), wrap({ ...g, peeked: 'yes' }), wrap({ ...g, open: 1 }), wrap({ ...g, lesson: 2 }),
    wrap(g, '0'), wrap(g, '141'), wrap(g, 'abc'),
    wrap({ ...g, history: [{ wordId: 'not-a-uuid', errorWeight: 1, dueSeq: 1, lastFailedAt: null }] }),
    wrap({ ...g, history: [{ wordId: '00000000-0000-4000-8000-000000000000', errorWeight: 1, dueSeq: 1, lastFailedAt: null }] }),
    wrap({ ...g, history: [1, 2, 3] }),
    wrap({ ...g, attempts: Array.from({ length: 401 }, () => g.attempts[0]) }),
    wrap({ ...g, attempts: [{ ...g.attempts[0], step: 'other' }] }),
    wrap({ ...g, attempts: [{ ...g.attempts[0], input: 5 }] }),
    wrap({ ...g, attempts: [{ ...g.attempts[0], input: 'x'.repeat(501) }] }),
    wrap({ ...g, attempts: [{ ...g.attempts[0], usedPeek: 'no' }] }),
    wrap({ ...g, attempts: [{ ...g.attempts[0], at: 'never' }] }),
    wrap({ ...g, attempts: [{ ...g.attempts[0], itemId: 'L:00000000-0000-4000-8000-000000000000' }] }), // a log that does not fit the lesson
    wrap({ ...g, attempts: [g.attempts[0], g.attempts[0]] }), // the second attempt repeats the first item's step
  ];
  for (const raw of bad) {
    const st = H.makeStorage({ [DRAFT]: raw }), LT = world(st).open();
    assert.doesNotThrow(() => LT.resumeOpen(), raw.slice(0, 80));
    assert.equal(LT.resumeOpen(), null, raw.slice(0, 80));
    assert.equal(LT.hasDraft(1), false);
    assert.doesNotThrow(() => finishRight(LT, LT.start(1, { seed: 1 })), 'the lesson can still be played');
  }

  // storage that refuses writes (private mode, quota): the lesson still works in memory
  const broken = { getItem: () => null, setItem: () => { throw new Error('QuotaExceededError'); }, removeItem: () => { throw new Error('nope'); } };
  const LT = Progress.create({ engine, lessons: catalog.lessons, storage: broken, now: () => new Date(0) });
  const sess = LT.start(1, { seed: 2 });
  assert.doesNotThrow(() => { LT.peek(sess); finishRight(LT, sess); LT.leave(LT.start(2)); LT.reset(); });
});

test('the chain of sessions follows the order lessons FINISH, so a lesson resumed later still has the right parent for the server', () => {
  const w = world(), LT = w.open();
  LT.setPref('unlock', true);
  const first = LT.start(1, { seed: 71 });
  answerRight(LT, first, 4);
  LT.leave(first); // waits on the map
  const other = LT.start(2, { seed: 72 });
  finishRight(LT, other); // lesson 2 finishes while lesson 1 waits
  const r = w.open().resume(1);
  assert.equal(r.parentSessionId, other.sessionId, 'the parent is whatever finished last');
  const LT2 = w.open(), r2 = LT2.resume(1);
  finishRight(LT2, r2);
  assert.equal(LT2.commitOf(r2).parentSessionId, other.sessionId);
  assert.equal(LT2.state.lastSessionId, r2.sessionId);
  // and the server replays it
  const l = catalog.lessons[0], byLower = new Map(l.words.map((x) => [x[0].toLowerCase(), x]));
  const item = (x) => ({ wordId: LT2.wordId(x[0]), wordText: x[0], sentenceContext: x[1], errorWeight: 0, meaningAr: x[2] || null, sentenceAr: x[3] || null });
  const commit = LT2.commitOf(r2);
  const replay = ts.replaySession({ sessionId: r2.sessionId, lessonSeq: 1, mode: commit.mode, seed: commit.seed, lessonWords: l.words.map(item), history: [] }, commit.attempts);
  assert.ok(replay.ok && byLower.size === 20, replay.reason);
  assert.deepEqual(replay.summary, LT2.summary(r2));
});

test('resume() answers null for anything that is not a saved lesson', () => {
  const w = world(), LT = w.open();
  for (const bad of [0, 141, -1, 1.5, '1', null, undefined, NaN]) assert.equal(LT.resume(bad), null);
  assert.equal(LT.resume(1), null);
  assert.equal(LT.resumeOpen(), null);
  assert.equal(LT.hasDraft(1), false);
  assert.doesNotThrow(() => { LT.discard(1); LT.leave(null); LT.leave(undefined); });
});
