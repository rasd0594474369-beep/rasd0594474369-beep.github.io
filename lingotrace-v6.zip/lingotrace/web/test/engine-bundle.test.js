// The browser bundle (engine.js) must be the same engine the server runs: same exports, same behavior, and the build must refuse to drift.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const { execFileSync } = require('node:child_process');
const H = require('./_helpers.js');

const SRC = path.join(H.ROOT, 'packages', 'engine', 'src');
const bundler = () => import(pathToFileURL(path.join(H.ROOT, 'scripts', 'bundle-engine.mjs')).href);

test('the bundle is one classic script with no import/export left and exports exactly what the TypeScript index exports', async () => {
  const { bundleEngine } = await bundler();
  const { code, exports } = bundleEngine(SRC);
  assert.doesNotMatch(code, /^\s*(import|export)\b/m);
  assert.match(code, /^\/\* LingoTrace lesson engine for the browser\. GENERATED/);
  const ts = await H.loadEngineTs();
  const bundle = await H.loadEngineBundle();
  assert.deepEqual(Object.keys(bundle).sort(), Object.keys(ts).sort());
  assert.equal(new Set(exports).size, exports.length, 'no name is exported twice');
});

test('the build refuses a module that is not in the bundle order and two modules declaring one name', async () => {
  const { bundleEngine } = await bundler();
  const copy = (mutate) => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'lt-engine-'));
    for (const f of fs.readdirSync(SRC)) if (f.endsWith('.ts')) fs.copyFileSync(path.join(SRC, f), path.join(dir, f));
    mutate(dir);
    return dir;
  };
  const extra = copy((d) => {
    fs.writeFileSync(path.join(d, 'extra.ts'), 'export const EXTRA = 1;\n');
    fs.appendFileSync(path.join(d, 'index.ts'), "export * from './extra.ts';\n");
  });
  assert.throws(() => bundleEngine(extra), /re-exports/);
  const dup = copy((d) => fs.appendFileSync(path.join(d, 'rng.ts'), '\nexport const ENGINE_VERSION = 2;\n'));
  assert.throws(() => bundleEngine(dup), /declared in both/);
});

test('site build writes engine.js identical to the bundler output', async () => {
  const { bundleEngine } = await bundler();
  const out = fs.mkdtempSync(path.join(os.tmpdir(), 'lt-site-'));
  execFileSync(process.execPath, [path.join(H.ROOT, 'scripts', 'build-site.mjs'), out], { cwd: H.ROOT, stdio: 'pipe' });
  assert.equal(fs.readFileSync(path.join(out, 'engine.js'), 'utf8'), bundleEngine(SRC).code);
  for (const f of ['index.html', 'auth.js', 'progress.js', 'engine.js']) assert.ok(fs.existsSync(path.join(out, f)), `${f} is published`);
  assert.match(fs.readFileSync(path.join(out, 'sw.js'), 'utf8'), /engine\.js.*progress\.js/s, 'the service worker pre-caches both scripts');
});

test('bundle and TypeScript engine behave identically on 300 random sessions (every state, summary, commit and rotation update)', async () => {
  const ts = await H.loadEngineTs();
  const bundle = await H.loadEngineBundle();
  const { lessons } = H.loadCatalog();
  const item = (e, weight) => ({ wordId: `id-${e[0]}`, wordText: e[0], sentenceContext: e[1], errorWeight: weight, meaningAr: e[2] || null, sentenceAr: e[3] || null });
  let injected = 0, failed = 0;
  for (let n = 0; n < 300; n++) {
    const rand = ts.createRng(5000 + n);
    const lesson = lessons[n % lessons.length];
    const others = lessons[(n + 7) % lessons.length].words;
    const history = Array.from({ length: Math.floor(rand() * 4) }, (_, i) => ({ word: item(others[i], 1 + Math.floor(rand() * 3)), dueSeq: 1 + Math.floor(rand() * 5), lastFailedAt: rand() < 0.2 ? null : `2026-11-0${1 + i}T08:00:00.000Z` }));
    const setup = { sessionId: `s-${n}`, lessonSeq: 1 + (n % 140), mode: n % 9 === 0 ? 'replay' : 'first_run', seed: Math.floor(rand() * 4294967296) >>> 0, lessonWords: lesson.words.map((w) => item(w, 0)), history };
    let a = ts.beginSession(setup), b = bundle.beginSession(setup);
    assert.equal(JSON.stringify(a.state.queue), JSON.stringify(b.state.queue));
    injected += a.state.queue.filter((q) => q.source === 'injected').length;
    const at = new Date('2026-11-17T10:00:00Z');
    for (let guard = 0; a.state.phase !== 'completed'; guard++) {
      assert.ok(guard < 500, 'session must finish');
      const pa = ts.currentPrompt(a.state), pb = bundle.currentPrompt(b.state);
      assert.equal(JSON.stringify(pa), JSON.stringify(pb));
      if (rand() < 0.1) { a = { ...a, state: ts.peek(a.state) }; b = { ...b, state: bundle.peek(b.state) }; }
      const input = H.behave(rand, pa.text, pa.step);
      const ra = ts.submit(a.state, input, { now: at, rng: a.rng }), rb = bundle.submit(b.state, input, { now: at, rng: b.rng });
      assert.equal(JSON.stringify(ra), JSON.stringify(rb));
      if (ra.event.kind === 'failed') failed++;
      a = { ...a, state: ra.state }; b = { ...b, state: rb.state };
    }
    const sa = ts.summarize(a.state), sb = bundle.summarize(b.state);
    assert.equal(JSON.stringify(sa), JSON.stringify(sb));
    assert.equal(JSON.stringify(ts.applySummaryToStats(sa, [], at)), JSON.stringify(bundle.applySummaryToStats(sb, [], at)));
    const meta = { lessonId: 'l', parentSessionId: null, seed: setup.seed, timeZone: 'UTC', startedAt: at.toISOString(), completedAt: at.toISOString() };
    assert.equal(JSON.stringify(ts.toSessionCommit(a.state, meta)), JSON.stringify(bundle.toSessionCommit(b.state, meta)));
  }
  assert.ok(injected > 100 && failed > 100, `the sessions must exercise injections (${injected}) and failures (${failed})`);
});

test('spelling evaluation is identical in the bundle and in TypeScript (words and sentences)', async () => {
  const ts = await H.loadEngineTs();
  const bundle = await H.loadEngineBundle();
  const { lessons } = H.loadCatalog();
  const rand = ts.createRng(99);
  for (let i = 0; i < 4000; i++) {
    const w = lessons[i % lessons.length].words[i % 20];
    for (const [target, fn] of [[w[0], 'evaluateWord'], [w[1], 'evaluateSentence']]) {
      const input = H.behave(rand, target, fn === 'evaluateWord' ? 'word' : 'sentence');
      assert.deepEqual(bundle[fn](input, target, 1), ts[fn](input, target, 1));
    }
  }
});
