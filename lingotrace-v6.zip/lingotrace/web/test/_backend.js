// A stand-in for the Supabase project, for the sync tests and the browser check (not a test itself: the CI only runs web/test/*.test.js).
// The part that matters is REAL: the unmodified commit-session HTTP handler, the real commit service and PgRepo, running on the schema twin
// (the real migrations translated to SQLite) with the REAL lesson catalog of the app. Around it a small fake of the REST reads the app uses
// (users, user_progress, user_word_stats, answered from the same tables) and a hook to inject network failures and gateway answers.
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const H = require('./_helpers.js');

const imp = (rel) => import(pathToFileURL(path.join(H.ROOT, rel)).href);
const b64url = (v) => Buffer.from(JSON.stringify(v)).toString('base64url');

/** A token shaped like Supabase's user tokens (the platform checks signatures, the function reads the claims). */
function tokenFor(userId, expSeconds) {
  const claims = { sub: userId, role: 'authenticated', aud: 'authenticated', exp: expSeconds, app_metadata: { provider: 'google', providers: ['google'] } };
  return `${b64url({ alg: 'ES256', typ: 'JWT', kid: 'test' })}.${b64url(claims)}.c2lnbmF0dXJl`;
}

/**
 * @param {{ catalog: {lessons: Array<{level:string, number:number, words:Array<any>}>}, ids: {lessonId:(seq:number)=>string, wordId:(text:string)=>string},
 *           clock: {ms:number}, origin?: string, rateLimit?: number }} o
 */
async function createBackend(o) {
  const dbmod = await imp('packages/engine/test/helpers/db.ts');
  const srv = await imp('packages/engine/src/server/index.ts');
  const handlerMod = await imp('supabase/functions/commit-session/handler.ts');
  const authMod = await imp('supabase/functions/_shared/auth.ts');
  const corsMod = await imp('supabase/functions/_shared/cors.ts');
  const rlMod = await imp('supabase/functions/_shared/rate-limit.ts');
  const clock = o.clock, origin = o.origin || 'https://app.example';

  const db = await dbmod.openDb();
  const seenWords = new Set();
  o.catalog.lessons.forEach((l, i) => {
    const seq = i + 1;
    db.prepare("INSERT INTO lessons (id, level_code, lesson_number, global_seq, is_published) VALUES (?1, ?2, ?3, ?4, 1)").run(o.ids.lessonId(seq), l.level, l.number, seq);
    l.words.forEach((w, pos) => {
      const id = o.ids.wordId(w[0]);
      if (!seenWords.has(id)) { seenWords.add(id); db.prepare('INSERT INTO vocabulary_bank (id, word_text, sentence_context) VALUES (?1, ?2, ?3)').run(id, w[0], w[1]); }
      db.prepare('INSERT INTO lesson_words (lesson_id, position, word_id) VALUES (?1, ?2, ?3)').run(o.ids.lessonId(seq), pos + 1, id);
    });
  });
  const repo = new srv.PgRepo(dbmod.sqlitePool(db));
  const events = [];
  const handler = handlerMod.createCommitHandler({
    authenticate: authMod.createAuthenticator({ now: () => clock.ms }),
    repo,
    limiter: rlMod.createRateLimiter({ limit: o.rateLimit || 100000, windowMs: 60000, now: () => clock.ms }),
    cors: corsMod.corsPolicyFromEnv(origin),
    now: () => new Date(clock.ms),
    log: (level, event, data = {}) => events.push({ level, event, data }),
  });

  const backend = { db, events, calls: [], hooks: { before: null }, origin };
  backend.addUser = (id, name = 'Learner') => { db.prepare('INSERT INTO users (id, display_name) VALUES (?1, ?2)').run(id, name); return id; };
  backend.count = (sql) => Number(db.prepare(`SELECT count(*) AS n FROM ${sql}`).all()[0].n);
  backend.token = (userId, ttlSeconds = 3600) => tokenFor(userId, Math.floor(clock.ms / 1000) + ttlSeconds);

  const json = (status, body, headers = {}) => new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json', ...headers } });
  function subOf(init) {
    const h = init.headers || {}, a = h.Authorization || h.authorization || '';
    try { return JSON.parse(Buffer.from(a.replace(/^Bearer /, '').split('.')[1], 'base64url').toString()).sub; } catch (e) { return null; }
  }
  function rest(u, init) {
    const sub = subOf(init);
    if (!sub) return json(401, { message: 'JWT expected' });
    const table = u.pathname.replace('/rest/v1/', ''), q = u.searchParams;
    let rows;
    if (table === 'users') rows = db.prepare('SELECT total_xp, streak_count, longest_streak, last_active_date FROM users WHERE id = ?1').all(sub);
    else if (table === 'user_progress') rows = db.prepare('SELECT lesson_id, first_completed_at FROM user_progress WHERE user_id = ?1 AND first_completed_at IS NOT NULL').all(sub);
    else if (table === 'user_word_stats') {
      rows = db.prepare('SELECT word_id, error_weight, status, due_seq, lifetime_failures, last_failed_at, last_reviewed_at FROM user_word_stats WHERE user_id = ?1 ORDER BY word_id LIMIT ?2 OFFSET ?3')
        .all(sub, Number(q.get('limit') || 1000), Number(q.get('offset') || 0));
    } else return json(404, { message: 'no such table' });
    return json(200, rows.map((r) => ({ ...r })));
  }

  /** What `fetch` does for the app: the same URLs the real project answers. */
  backend.raw = (url, init = {}) => handler(new Request(url, init)); // the real handler, skipping the hooks (to model an answer that gets lost)
  backend.fetch = async (url, init = {}) => {
    const u = new URL(url);
    backend.calls.push({ method: init.method || 'GET', path: u.pathname, headers: init.headers || {} });
    if (backend.hooks.before) { const r = await backend.hooks.before(u, init); if (r) return r; } // may throw (= a network error) or answer instead
    let res;
    if (u.pathname === '/functions/v1/commit-session') res = await handler(new Request(url, init));
    else if (u.pathname.startsWith('/rest/v1/')) res = rest(u, init);
    else res = new Response('not found', { status: 404 });
    res.headers.set('date', new Date(clock.ms).toUTCString()); // the gateway stamps its own clock on every answer
    return res;
  };
  backend.commitCalls = () => backend.calls.filter((c) => c.path === '/functions/v1/commit-session').length;
  return backend;
}

module.exports = { createBackend, tokenFor };
