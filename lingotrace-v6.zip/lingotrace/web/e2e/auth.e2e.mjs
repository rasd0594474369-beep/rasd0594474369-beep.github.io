// End-to-end check of the web app in real Chromium with a fake Supabase: Google sign-in, the legal pages, and (v5) the lesson engine, the
// migration of v3/v4 progress and the offline shell (run it in Claude's sandbox: Playwright is global there).
// Usage: node web/e2e/auth.e2e.mjs <dist-dir> [port]
import { createRequire } from 'node:module';
import { createServer } from 'node:http';
import { readFileSync, existsSync } from 'node:fs';
import { extname, join } from 'node:path';
import { randomUUID } from 'node:crypto';
const require = createRequire('/home/claude/.npm-global/lib/node_modules/');
const localRequire = createRequire(import.meta.url);
const { chromium } = require('playwright');

const dir = process.argv[2] ?? 'dist-site';
const port = Number(process.argv[3] ?? 8771);
const SB = 'https://yvszergcvjnzpogubqex.supabase.co';
const types = { '.html': 'text/html', '.js': 'text/javascript', '.png': 'image/png', '.webmanifest': 'application/manifest+json' };
const server = createServer((req, res) => {
  const path = decodeURIComponent(new URL(req.url, 'http://x').pathname);
  // like GitHub Pages: /privacy answers 301 -> /privacy/ when privacy/index.html exists
  if (path !== '/' && !path.endsWith('/') && !extname(path) && existsSync(join(dir, path, 'index.html'))) { res.writeHead(301, { location: path + '/' }); return res.end(); }
  const p = join(dir, path.replace(/\/$/, '/index.html'));
  if (!existsSync(p)) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { 'content-type': types[extname(p)] ?? 'application/octet-stream' }); res.end(readFileSync(p));
}).listen(port);
const ORIGIN = `http://localhost:${port}`;

// v6: the cloud. The REAL commit-session handler + commit service run in this process on the schema twin with the real lesson catalog;
// the browser reaches them through Playwright routes (CORS preflight included), so what is tested is what Supabase will run.
const H = localRequire('../test/_helpers.js');
const ProgressNode = localRequire('../progress.js');
const { createBackend } = localRequire('../test/_backend.js');
const catalogNode = H.loadCatalog();
const probe = ProgressNode.create({ engine: await H.loadEngineBundle(), lessons: catalogNode.lessons });
const backend = await createBackend({ catalog: catalogNode, ids: { lessonId: probe.lessonId, wordId: probe.wordId }, clock: { get ms() { return Date.now(); } }, origin: ORIGIN });

let fails = 0;
const check = (name, ok, extra = '') => { console.log(ok ? 'PASS' : 'FAIL', name, extra); if (!ok) fails++; };
const cors = { 'access-control-allow-origin': '*', 'access-control-allow-headers': '*', 'access-control-allow-methods': '*' };
const calls = [];
const restCors = { 'access-control-allow-origin': '*', 'access-control-allow-headers': 'authorization, apikey, content-type, x-client-info, accept', 'access-control-allow-methods': 'GET, POST, OPTIONS' };
async function realRoute(route, r, u, user) { // the Edge Function and the REST reads, answered by the real code
  const drop = new Set(['host', 'content-length', 'connection', 'accept-encoding']);
  const headers = Object.fromEntries(Object.entries(r.headers()).filter(([k]) => !drop.has(k)));
  const isFn = u.pathname.startsWith('/functions/v1/');
  try {
    let res;
    if (r.method() === 'OPTIONS') { if (!isFn) return route.fulfill({ status: 204, headers: restCors }); res = await backend.raw(r.url(), { method: 'OPTIONS', headers }); }
    else { headers.authorization = 'Bearer ' + backend.token(user.id); res = await backend.fetch(r.url(), { method: r.method(), headers, body: r.method() === 'POST' ? r.postData() : undefined }); }
    const h = Object.fromEntries(res.headers); if (!isFn) h['access-control-allow-origin'] = '*';
    return route.fulfill({ status: res.status, headers: h, body: await res.text() });
  } catch (e) { return route.abort('failed'); } // a hook that throws = the network is down
}
async function fakeSupabase(ctx, { user = { id: 'u1', email: 'sara@example.com', user_metadata: { full_name: 'Sara A' } }, authorizeTo = null, refreshStatus = 200, real = false } = {}) {
  await ctx.route(SB + '/**', async (route) => {
    const r = route.request(), u = new URL(r.url());
    calls.push(r.method() + ' ' + u.pathname + u.search);
    if (real && (u.pathname.startsWith('/functions/v1/') || u.pathname.startsWith('/rest/v1/'))) return realRoute(route, r, u, user);
    if (r.method() === 'OPTIONS') return route.fulfill({ status: 204, headers: cors });
    if (u.pathname === '/auth/v1/authorize') {
      const back = u.searchParams.get('redirect_to');
      return route.fulfill({ status: 302, headers: { location: authorizeTo ?? back + '#access_token=AT1&refresh_token=RT1&expires_in=3600&token_type=bearer' } });
    }
    if (u.pathname === '/auth/v1/user') return route.fulfill({ status: 200, headers: { ...cors, 'content-type': 'application/json' }, body: JSON.stringify(user) });
    if (u.pathname === '/auth/v1/token') return route.fulfill({ status: refreshStatus, headers: { ...cors, 'content-type': 'application/json' }, body: JSON.stringify(refreshStatus === 200 ? { access_token: 'AT2', refresh_token: 'RT2', expires_in: 3600 } : { error: 'invalid_grant' }) });
    if (u.pathname === '/auth/v1/logout') return route.fulfill({ status: 204, headers: cors });
    return route.fulfill({ status: 200, headers: { ...cors, 'content-range': '0-0/1' }, body: '[]' });
  });
}
const browser = await chromium.launch();
const newCtx = () => browser.newContext({ viewport: { width: 390, height: 844 }, locale: 'ar', deviceScaleFactor: 2, isMobile: true, hasTouch: true });
const watch = (page) => { const errs = []; page.on('pageerror', (e) => errs.push('pageerror: ' + e.message)); page.on('console', (m) => { if (m.type() === 'error' && !/fonts\.(googleapis|gstatic)|ERR_|Failed to load resource/.test(m.text())) errs.push('console: ' + m.text()); }); return errs; };
const openProfile = async (page) => { await page.click('nav button[data-t=me]'); await page.waitForTimeout(150); };

// 1) signed out: the profile tab offers Google sign-in
{
  const ctx = await newCtx(); await fakeSupabase(ctx); const page = await ctx.newPage(); const errs = watch(page);
  await page.goto(ORIGIN + '/'); await page.waitForSelector('#app *');
  await openProfile(page);
  check('signed out: login button shown', (await page.locator('button.open', { hasText: 'Google' }).count()) === 1);
  await page.screenshot({ path: '/tmp/e2e-signedout.png' });

  // 2) press login -> fake Google/Supabase -> back with tokens in the hash -> profile tab shows the account
  await page.click('button.open >> text=Google');
  await page.waitForFunction(() => document.body.innerText.includes('Sara A'), null, { timeout: 8000 });
  check('after the redirect: name and email shown', (await page.innerText('#app')).includes('sara@example.com'));
  check('after sign-in the profile tab is open', (await page.locator('nav button.on').getAttribute('data-t')) === 'me');
  check('tokens removed from the URL', !(await page.evaluate(() => location.hash)) && !page.url().includes('access_token'));
  const stored = await page.evaluate(() => JSON.parse(localStorage.getItem('lingotrace-auth-v1')));
  check('session stored (access + refresh)', stored.access_token === 'AT1' && stored.refresh_token === 'RT1');
  await page.screenshot({ path: '/tmp/e2e-signedin.png' });

  // 3) reload: still signed in, no login button
  await page.reload(); await page.waitForSelector('#app *'); await openProfile(page);
  check('reload keeps the session', (await page.innerText('#app')).includes('Sara A'));

  // 4) sign out
  await page.click('button >> text=تسجيل الخروج');
  await page.waitForFunction(() => !!document.querySelector('button.open'));
  check('sign out: back to the login button + storage cleared', (await page.evaluate(() => localStorage.getItem('lingotrace-auth-v1'))) === null);
  check('logout hit the server with scope=local', calls.some((c) => c.startsWith('POST /auth/v1/logout?scope=local')));
  check('no JS errors (flow 1-4)', errs.length === 0, errs.join(' | '));
  await ctx.close();
}
// 5) an expired stored session is refreshed on start
{
  const ctx = await newCtx(); await fakeSupabase(ctx); const page = await ctx.newPage(); const errs = watch(page);
  await page.addInitScript(() => { if (!localStorage.getItem('lingotrace-auth-v1')) localStorage.setItem('lingotrace-auth-v1', JSON.stringify({ access_token: 'OLD', refresh_token: 'RT0', expires_at: 1, user: { id: 'u1', email: 'cached@example.com', name: 'Cached', avatar: null } })); });
  calls.length = 0;
  await page.goto(ORIGIN + '/'); await page.waitForSelector('#app *'); await page.waitForTimeout(500); await openProfile(page);
  check('expired session: refresh then user reload', calls.some((c) => c.includes('/auth/v1/token?grant_type=refresh_token')) && (await page.innerText('#app')).includes('Sara A'));
  check('new tokens saved', (await page.evaluate(() => JSON.parse(localStorage.getItem('lingotrace-auth-v1')).access_token)) === 'AT2');
  check('no JS errors (refresh)', errs.length === 0, errs.join(' | '));
  await ctx.close();
}
// 6) refresh rejected -> signed out with a message
{
  const ctx = await newCtx(); await fakeSupabase(ctx, { refreshStatus: 400 }); const page = await ctx.newPage();
  await page.addInitScript(() => { localStorage.setItem('lingotrace-auth-v1', JSON.stringify({ access_token: 'OLD', refresh_token: 'BAD', expires_at: 1, user: null })); });
  await page.goto(ORIGIN + '/'); await page.waitForSelector('#app *'); await page.waitForTimeout(500); await openProfile(page);
  const txt = await page.innerText('#app');
  check('rejected refresh: login button + message', txt.includes('سجّل الدخول من جديد') && (await page.locator('button.open').count()) === 1);
  await ctx.close();
}
// 7) cancelled Google sign-in: error shown, app fine
{
  const ctx = await newCtx(); await fakeSupabase(ctx, { authorizeTo: ORIGIN + '/#error=access_denied&error_description=Access+denied' }); const page = await ctx.newPage(); const errs = watch(page);
  await page.goto(ORIGIN + '/'); await page.waitForSelector('#app *'); await openProfile(page);
  await page.click('button.open >> text=Google');
  await page.waitForFunction(() => document.body.innerText.includes('Access denied'), null, { timeout: 8000 });
  check('cancelled login: message shown on the profile tab', (await page.locator('nav button.on').getAttribute('data-t')) === 'me');
  check('no JS errors (cancel)', errs.length === 0, errs.join(' | '));
  await ctx.close();
}
// 8) offline with a stored session: profile still shows the cached account, lessons still open
{
  const ctx = await newCtx(); await fakeSupabase(ctx); const page = await ctx.newPage(); const errs = watch(page);
  await page.addInitScript(() => { if (!localStorage.getItem('lingotrace-auth-v1')) localStorage.setItem('lingotrace-auth-v1', JSON.stringify({ access_token: 'AT', refresh_token: 'RT', expires_at: 9999999999, user: { id: 'u1', email: 'cached@example.com', name: 'Cached', avatar: null } })); });
  await page.goto(ORIGIN + '/'); await page.waitForSelector('#app *'); await page.evaluate(() => navigator.serviceWorker.ready); await page.reload(); await page.waitForTimeout(400);
  await ctx.setOffline(true);
  await page.reload({ waitUntil: 'domcontentloaded' }); await page.waitForSelector('#app *'); await page.waitForTimeout(400); await openProfile(page);
  // the account was refreshed from the (fake) server on the earlier online load, so offline shows that last known name
  check('offline: last known account shown, no login button', (await page.innerText('#app')).includes('Sara A') && (await page.locator('button.open').count()) === 0);
  await page.click('nav button[data-t=home]'); await page.click('.open'); await page.waitForTimeout(300);
  check('offline: lesson map opens', (await page.innerText('#app')).includes('ابدأ'));
  check('offline: a lesson starts from the cached engine', await page.evaluate(() => { try { return LT.start(1).es.queue.length === 20; } catch (e) { return false; } }));
  check('no JS errors (offline)', errs.length === 0, errs.join(' | '));
  await ctx.close();
}
// 9) regression: the lesson itself still works (type the first word right, see progress move)
{
  const ctx = await newCtx(); await fakeSupabase(ctx); const page = await ctx.newPage(); const errs = watch(page);
  await page.goto(ORIGIN + '/'); await page.waitForSelector('#app *');
  await page.click('.open'); await page.waitForSelector('.nd.cu'); await page.click('.nd.cu'); await page.waitForSelector('#in');
  const w1 = await page.evaluate(() => LT.cur(S).word.wordText);
  await page.fill('#in', w1); await page.press('#in', 'Enter');
  await page.waitForFunction(() => LT.cur(S).step === 'sentence' || LT.progress(S).done >= 1, null, { timeout: 8000 });
  check('lesson: correct word accepted and the item advances', await page.evaluate(() => LT.cur(S).step === 'sentence' || LT.progress(S).done >= 1));
  check('no JS errors (lesson)', errs.length === 0, errs.join(' | '));
  await ctx.close();
}
// 10) legal pages: linked from the profile tab, reachable at the exact URLs registered in Google Cloud, load nothing external, link back
{
  const ctx = await newCtx(); await fakeSupabase(ctx); const page = await ctx.newPage(); const errs = watch(page);
  const external = [];
  page.on('request', (r) => { if (/^\/(privacy|terms)\//.test(new URL(page.url()).pathname) && !r.url().startsWith(ORIGIN)) external.push(r.url()); });
  await page.goto(ORIGIN + '/'); await page.waitForSelector('#app *'); await openProfile(page);
  check('signed out: terms and privacy links shown', (await page.locator('#app a[href="terms/"]').count()) === 1 && (await page.locator('#app a[href="privacy/"]').count()) === 1);
  await page.goto(ORIGIN + '/privacy'); // exactly what was typed in Google Cloud
  check('/privacy redirects to /privacy/ and shows the policy', new URL(page.url()).pathname === '/privacy/' && (await page.locator('h1').innerText()) === 'سياسة الخصوصية');
  check('privacy page shows the contact email', (await page.innerText('main')).includes('rasd0594474369@gmail.com'));
  await page.screenshot({ path: '/tmp/e2e-privacy.png' });
  await page.click('header a:has-text("العودة إلى التطبيق")'); await page.waitForSelector('#app *');
  check('back link returns to the app', new URL(page.url()).pathname === '/');
  await openProfile(page); await page.click('#app a[href="terms/"]'); await page.waitForSelector('h1');
  check('terms link opens /terms/', new URL(page.url()).pathname === '/terms/' && (await page.locator('h1').innerText()) === 'شروط الاستخدام');
  await page.screenshot({ path: '/tmp/e2e-terms.png' });
  await page.click('footer a:has-text("سياسة الخصوصية")'); await page.waitForSelector('h1');
  check('terms footer links to the privacy page', new URL(page.url()).pathname === '/privacy/');
  await page.goto(ORIGIN + '/terms'); check('/terms redirects to /terms/', new URL(page.url()).pathname === '/terms/');
  check('legal pages requested nothing from other origins', external.length === 0, external.join(' '));
  check('no JS errors (legal)', errs.length === 0, errs.join(' | '));
  await ctx.close();
}
// 11) v5 migration in the real browser: v3/v4 progress ('spelling-v2') shows up unchanged, is copied to the new key once, and a reset cannot bring it back
{
  const tz = 'Asia/Riyadh';
  const today = new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date());
  const LEGACY = { xp: 130, streak: 3, best: 5, day: today, c: { 1: 1, 2: 1 }, rot: { the: { weight: 2, status: 'active', due: 3, last: '2026-11-10T08:00:00.000Z' }, be: { weight: 0, status: 'mastered', due: null, last: '2026-11-09T08:00:00.000Z' }, notaword: { weight: 1, status: 'active', due: 2, last: '2026-11-08T08:00:00.000Z' } }, loc: 'en-GB', unlock: false, tr: false };
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, locale: 'ar', timezoneId: tz, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
  await fakeSupabase(ctx);
  await ctx.addInitScript((legacy) => { try { if (!localStorage.getItem('__seeded')) { localStorage.setItem('spelling-v2', JSON.stringify(legacy)); localStorage.setItem('__seeded', '1'); } } catch (e) { /* ignore */ } }, LEGACY);
  const page = await ctx.newPage(); const errs = watch(page);
  await page.goto(ORIGIN + '/'); await page.waitForSelector('#app *'); await openProfile(page);
  const text = await page.innerText('#app');
  check('migration: XP, completed lessons and the mistake list are carried over', text.includes('130') && text.includes('2 / 140') && text.includes('the · وزن 2 · درس 3') && !text.includes('notaword'), text.replace(/\s+/g, ' ').slice(0, 160));
  const saved = await page.evaluate(() => ({ now: JSON.parse(localStorage.getItem('lingotrace-progress-v1')), old: localStorage.getItem('spelling-v2'), notr: document.body.classList.contains('notr'), streak: LT.streak() }));
  check('migration: new key written, old key untouched, preferences and streak kept', saved.now.v === 1 && saved.now.xp === 130 && Object.keys(saved.now.completed).join() === '1,2' && saved.now.prefs.loc === 'en-GB' && saved.old === JSON.stringify(LEGACY) && saved.notr && saved.streak === 3);
  await page.screenshot({ path: '/tmp/e2e-migrated.png' });
  await page.reload(); await page.waitForSelector('#app *'); await openProfile(page);
  check('migration runs once: after a reload the state is the same', (await page.evaluate(() => P.xp)) === 130 && (await page.evaluate(() => LT.migrated)) === false);
  await page.selectOption('select', 'en-US'); await page.check('input[type=checkbox]');
  const prefs = await page.evaluate(() => ({ p: P.prefs, saved: JSON.parse(localStorage.getItem('lingotrace-progress-v1')).prefs }));
  check('the voice select and the unlock switch update and save the preferences', prefs.p.loc === 'en-US' && prefs.p.unlock === true && prefs.saved.loc === 'en-US' && prefs.saved.unlock === true, JSON.stringify(prefs));
  page.once('dialog', (d) => d.accept()); await page.click('button:has-text("إعادة ضبط التجربة")'); await page.waitForTimeout(150);
  check('reset: XP back to 0 and the old key removed', (await page.evaluate(() => P.xp)) === 0 && (await page.evaluate(() => localStorage.getItem('spelling-v2'))) === null);
  await page.reload(); await page.waitForSelector('#app *');
  check('after a reset and a reload the old progress does not come back', (await page.evaluate(() => P.xp)) === 0 && (await page.evaluate(() => Object.keys(P.completed).length)) === 0);
  check('no JS errors (migration)', errs.length === 0, errs.join(' | '));
  await ctx.close();
}
// 12) a whole lesson on the bundled engine in Chromium: 250 XP, saved, survives a reload, replay pays nothing, a double failure enters the mistake list and is injected later
{
  const ctx = await newCtx(); await fakeSupabase(ctx); const page = await ctx.newPage(); const errs = watch(page);
  await page.goto(ORIGIN + '/'); await page.waitForSelector('#app *');
  const first = await page.evaluate(() => {
    S = LT.start(1); const mode = S.mode, items = S.es.queue.length;
    for (let g = 0; !LT.finished(S) && g < 500; g++) LT.submit(S, LT.cur(S).text);
    LT.finish(S); S = null;
    return { mode, items, xp: P.xp, completed: Object.keys(P.completed), streak: LT.streak(), next: LT.nextLesson() };
  });
  check('lesson 1 on the engine: 20 words, 250 XP, completed, streak 1, next is lesson 2', first.mode === 'first_run' && first.items === 20 && first.xp === 250 && first.completed.join() === '1' && first.streak === 1 && first.next === 2, JSON.stringify(first));
  const saved = await page.evaluate(() => JSON.parse(localStorage.getItem('lingotrace-progress-v1')));
  check('progress is saved under the new key with a session chain id', saved.v === 1 && saved.xp === 250 && saved.completed['1'] === true && saved.streak.streakCount === 1 && /^[0-9a-f-]{36}$/.test(saved.lastSessionId));
  await page.reload(); await page.waitForSelector('#app *'); await openProfile(page);
  check('after a reload the XP and the lesson are still there', (await page.innerText('#app')).includes('1 / 140') && (await page.evaluate(() => P.xp)) === 250);
  const replay = await page.evaluate(() => { S = LT.start(1); const mode = S.mode; while (!LT.finished(S)) LT.submit(S, LT.cur(S).text); LT.finish(S); S = null; return { mode, xp: P.xp }; });
  check('replay: no extra XP', replay.mode === 'replay' && replay.xp === 250);
  const fail = await page.evaluate(() => {
    const failed = []; S = LT.start(2);
    while (!LT.finished(S)) {
      const c = LT.cur(S); let t = c.text;
      if (c.step === 'word' && !c.rev && !failed.length) { failed.push(c.word.wordId); t = 'zzzzzz'; } else if (c.rev && failed.includes(c.word.wordId)) t = 'zzzzzz';
      LT.submit(S, t);
    }
    LT.finish(S); S = null;
    return { rotation: LT.rotation().map((r) => [r.text, r.weight, r.due]) };
  });
  check('a word failed twice enters the mistake list (weight 1, due lesson 4)', fail.rotation.length === 1 && fail.rotation[0][1] === 1 && fail.rotation[0][2] === 4, JSON.stringify(fail));
  await page.evaluate(() => go('home')); await openProfile(page);
  check('the profile lists it', (await page.innerText('#app')).includes(fail.rotation[0][0] + ' · وزن 1 · درس 4'));
  const at4 = await page.evaluate(() => { S = LT.start(4); const pos = S.es.queue.findIndex((q) => q.source === 'injected'); while (LT.cur(S).src !== 'injected') LT.submit(S, LT.cur(S).text); V = 'lesson'; show = false; render(); return { pos, len: S.es.queue.length }; });
  check('lesson 4 injects the word, labels it on screen, and it is neither first nor last', at4.pos >= 1 && (await page.locator('.sm2', { hasText: 'من أخطائك السابقة' }).count()) === 1, JSON.stringify(at4));
  await page.screenshot({ path: '/tmp/e2e-injected.png' });
  check('no JS errors (engine lesson)', errs.length === 0, errs.join(' | '));
  await ctx.close();
}
// 13) answer shown = peek: the lower XP tier, and the answer that stays visible on the next step still counts as a peek
{
  const ctx = await newCtx(); await fakeSupabase(ctx); const page = await ctx.newPage(); const errs = watch(page);
  await page.goto(ORIGIN + '/'); await page.waitForSelector('#app *');
  await page.click('.open'); await page.waitForSelector('.nd.cu'); await page.click('.nd.cu'); await page.waitForSelector('#in');
  const w1 = await page.evaluate(() => LT.cur(S).word.wordText);
  await page.click('button[onclick="toggle()"]');
  check('the eye button shows the answer and records the peek', (await page.locator('.ans').count()) === 1 && (await page.evaluate(() => S.es.peeked)) === true);
  await page.fill('#in', w1); await page.press('#in', 'Enter');
  await page.waitForFunction(() => !busy && LT.cur(S).step === 'sentence', null, { timeout: 8000 });
  check('the answer is still shown on the sentence step, and counts as a peek there too', (await page.locator('.ans').count()) === 1 && (await page.evaluate(() => S.es.peeked)) === true);
  const s1 = await page.evaluate(() => LT.cur(S).text);
  await page.fill('#in', s1); await page.press('#in', 'Enter');
  await page.waitForFunction(() => !busy && LT.progress(S).done >= 1, null, { timeout: 20000 });
  check('a peeked first try pays the lower tier (5 XP, not 10)', await page.evaluate(() => S.es.xp.recovered === 5 && S.es.xp.firstTry === 0));
  check('no JS errors (peek)', errs.length === 0, errs.join(' | '));
  await ctx.close();
}
// 14) v5.1: closing the app in the middle of a lesson loses nothing: reopening continues at the same word with the same points
{
  const ctx = await newCtx(); await fakeSupabase(ctx); let page = await ctx.newPage(); let errs = watch(page);
  await page.goto(ORIGIN + '/'); await page.waitForSelector('#app *');
  await page.click('.open'); await page.waitForSelector('.nd.cu');
  check('the current lesson on the map says «ابدأ» before anything was played', (await page.innerText('.nd.cu .go')).trim() === 'ابدأ');
  await page.click('.nd.cu'); await page.waitForSelector('#in');
  // word 1 typed for real through the UI (animations included), then words 2 and 3 quickly through the same engine calls
  const w1 = await page.evaluate(() => LT.cur(S).text);
  await page.fill('#in', w1); await page.press('#in', 'Enter');
  await page.waitForFunction(() => !busy && LT.cur(S).step === 'sentence', null, { timeout: 8000 });
  const s1 = await page.evaluate(() => LT.cur(S).text);
  await page.fill('#in', s1); await page.press('#in', 'Enter');
  await page.waitForFunction(() => !busy && LT.progress(S).done >= 1, null, { timeout: 20000 });
  await page.evaluate(() => { for (let i = 0; i < 4; i++) LT.submit(S, LT.cur(S).text); });
  const before = await page.evaluate(() => ({ text: LT.cur(S).text, step: LT.cur(S).step, done: LT.progress(S).done, total: LT.progress(S).total, xp: { ...S.es.xp } }));
  check('three words done, now on word 4 (a word step), 30 points inside the lesson', before.done === 3 && before.step === 'word' && before.xp.firstTry === 30, JSON.stringify(before));
  const saved = await page.evaluate(() => JSON.parse(localStorage.getItem('lingotrace-active-v1')));
  check('the lesson is saved after every answer under its own key (6 answers so far)', saved.v === 1 && saved.drafts['1'].attempts.length === 6 && saved.drafts['1'].open === true);
  check('nothing is counted toward the total yet', (await page.evaluate(() => JSON.parse(localStorage.getItem('lingotrace-progress-v1') || '{"xp":0}').xp)) === 0);

  // "close the app" two ways: a reload, and closing the page then opening a new one on the same storage
  for (const how of ['reload', 'new page']) {
    if (how === 'reload') await page.reload(); else { await page.close(); page = await ctx.newPage(); errs = watch(page); await page.goto(ORIGIN + '/'); }
    await page.waitForSelector('#in', { state: 'attached' }); await page.waitForSelector('.lbar');
    const after = await page.evaluate(() => ({ view: V, resumed: S && S.resumed, text: LT.cur(S).text, step: LT.cur(S).step, done: LT.progress(S).done, total: LT.progress(S).total, xp: { ...S.es.xp }, bar: document.querySelector('.lbar i').style.width, total_xp: P.xp }));
    check(`${how}: reopened straight inside the lesson on the same word with the same points`, after.view === 'lesson' && after.resumed === true && after.text === before.text && after.step === before.step && after.done === before.done && after.total === before.total && after.xp.firstTry === 30 && after.total_xp === 0, JSON.stringify(after));
    check(`${how}: the progress bar is where it was`, after.bar === `${before.done / before.total * 100}%`, after.bar);
    check(`${how}: a short note says the lesson was resumed`, (await page.innerText('.msg')).includes('تابعنا الدرس من حيث توقفت'));
    check(`${how}: the bottom navigation is hidden like in any lesson`, (await page.evaluate(() => getComputedStyle(document.querySelector('nav')).display)) === 'none');
  }
  // the back arrow works on what was answered before the restart
  check('the back arrow is enabled after a restart (the earlier answers are rebuilt)', (await page.evaluate(() => H.length)) === 3 * 2 && (await page.locator('#bk[disabled]').count()) === 0);
  // finish the lesson: typing the next word for real, then the rest: still 250 XP in total
  const w4 = await page.evaluate(() => LT.cur(S).text);
  await page.fill('#in', w4); await page.press('#in', 'Enter');
  await page.waitForFunction(() => !busy && LT.cur(S).step === 'sentence', null, { timeout: 8000 });
  await page.evaluate(() => { while (!LT.finished(S)) LT.submit(S, LT.cur(S).text); LT.finish(S); render(); });
  check('finishing a resumed lesson pays the normal 250 XP and the result screen shows it', (await page.evaluate(() => P.xp)) === 250 && (await page.innerText('#app')).includes('+250 XP') && (await page.innerText('#app')).includes('اكتمل الدرس 1'));
  check('and nothing is left to resume', (await page.evaluate(() => localStorage.getItem('lingotrace-active-v1'))) === null);
  check('no JS errors (resume)', errs.length === 0, errs.join(' | '));
  await ctx.close();
}
// 14b) leaving on purpose keeps a first run («تابع» on the map), a reload then stays on the home screen, the restart button starts over
{
  const ctx = await newCtx(); await fakeSupabase(ctx); const page = await ctx.newPage(); const errs = watch(page);
  await page.goto(ORIGIN + '/'); await page.waitForSelector('#app *');
  await page.click('.open'); await page.waitForSelector('.nd.cu'); await page.click('.nd.cu'); await page.waitForSelector('#in');
  check('no restart button before anything is answered', (await page.locator('button[onclick="restart()"]').count()) === 0);
  await page.evaluate(() => { for (let i = 0; i < 4; i++) LT.submit(S, LT.cur(S).text); render(); });
  check('a restart button appears next to the close button once something was answered', (await page.locator('button[onclick="restart()"]').count()) === 1);
  const mid = await page.evaluate(() => ({ done: LT.progress(S).done, text: LT.cur(S).text }));
  await page.click('button[onclick="go(\'path\')"]'); await page.waitForSelector('.nd.cu');
  check('leaving with the close button returns to the map and the lesson says «تابع»', (await page.evaluate(() => V)) === 'path' && (await page.innerText('.nd.cu .go')).trim() === 'تابع');
  await page.reload(); await page.waitForSelector('#app *');
  check('after a reload the app opens on the home screen (the learner left the lesson on purpose)', (await page.evaluate(() => V)) === 'home' && (await page.evaluate(() => S)) === null);
  await page.click('.open'); await page.waitForSelector('.nd.cu');
  check('the map still offers «تابع»', (await page.innerText('.nd.cu .go')).trim() === 'تابع');
  await page.click('.nd.cu'); await page.waitForSelector('#in');
  const back = await page.evaluate(() => ({ done: LT.progress(S).done, text: LT.cur(S).text, resumed: S.resumed }));
  check('tapping it resumes at the same word', back.done === mid.done && back.text === mid.text && back.resumed === true, JSON.stringify([mid, back]));
  // a declined confirmation changes nothing; an accepted one starts the lesson again from the first word
  page.once('dialog', (d) => d.dismiss()); await page.click('button[onclick="restart()"]'); await page.waitForTimeout(150);
  check('cancelling the restart question keeps the lesson as it is', (await page.evaluate(() => LT.progress(S).done)) === mid.done);
  page.once('dialog', (d) => d.accept()); await page.click('button[onclick="restart()"]');
  await page.waitForFunction(() => S && S.resumed === false && LT.progress(S).done === 0);
  check('confirming starts the lesson over: first word, no points, no restart button yet', (await page.evaluate(() => S.es.xp.firstTry)) === 0 && (await page.locator('button[onclick="restart()"]').count()) === 0);
  await page.click('button[onclick="go(\'path\')"]'); await page.waitForSelector('.nd.cu');
  check('an untouched lesson says «ابدأ» again', (await page.innerText('.nd.cu .go')).trim() === 'ابدأ' && (await page.evaluate(() => localStorage.getItem('lingotrace-active-v1'))) === null);
  check('no JS errors (leave and restart)', errs.length === 0, errs.join(' | '));
  await ctx.close();
}
// 14c) the app dies right after the last answer (before the result screen): reopening shows the result, credited once
{
  const ctx = await newCtx(); await fakeSupabase(ctx); const page = await ctx.newPage(); const errs = watch(page);
  await page.goto(ORIGIN + '/'); await page.waitForSelector('#app *');
  await page.evaluate(() => { S = LT.start(1); while (!LT.finished(S)) LT.submit(S, LT.cur(S).text); }); // accepted, but finish() never ran
  check('before the restart nothing is counted', (await page.evaluate(() => JSON.parse(localStorage.getItem('lingotrace-progress-v1') || '{"xp":0}').xp)) === 0);
  await page.reload(); await page.waitForSelector('#app *');
  const r = await page.evaluate(() => ({ xp: P.xp, done: Object.keys(P.completed).join(), view: V }));
  check('reopening shows the finished lesson and credits its 250 XP once', r.xp === 250 && r.done === '1' && r.view === 'lesson' && (await page.innerText('#app')).includes('+250 XP'), JSON.stringify(r));
  await page.reload(); await page.waitForSelector('#app *');
  check('another reload does not credit it again and opens on the home screen', (await page.evaluate(() => P.xp)) === 250 && (await page.evaluate(() => V)) === 'home');
  check('no JS errors (finished while closed)', errs.length === 0, errs.join(' | '));
  await ctx.close();
}
// 14d) a practice run (replay) survives the app being closed but is not kept when the learner leaves it; «إعادة ضبط التجربة» clears any saved lesson
{
  const ctx = await newCtx(); await fakeSupabase(ctx); const page = await ctx.newPage(); const errs = watch(page);
  await page.goto(ORIGIN + '/'); await page.waitForSelector('#app *');
  await page.evaluate(() => { S = LT.start(1); while (!LT.finished(S)) LT.submit(S, LT.cur(S).text); LT.finish(S); S = LT.start(1); for (let i = 0; i < 4; i++) LT.submit(S, LT.cur(S).text); });
  await page.reload(); await page.waitForSelector('#app *');
  check('a replay in progress is reopened after the app was closed (still 0 XP for it)', (await page.evaluate(() => V === 'lesson' && S.mode === 'replay' && S.resumed && LT.progress(S).done === 2 && P.xp === 250)));
  await page.click('button[onclick="go(\'path\')"]'); await page.waitForSelector('.nd.dn');
  check('leaving the replay on purpose drops it', (await page.evaluate(() => localStorage.getItem('lingotrace-active-v1'))) === null);
  await page.evaluate(() => { S = LT.start(2); for (let i = 0; i < 4; i++) LT.submit(S, LT.cur(S).text); });
  await page.click('nav button[data-t=me]').catch(() => {});
  await page.evaluate(() => { go('me'); });
  page.once('dialog', (d) => d.accept()); await page.click('text=إعادة ضبط التجربة'); await page.waitForTimeout(150);
  check('«إعادة ضبط التجربة» removes the saved lesson too', (await page.evaluate(() => localStorage.getItem('lingotrace-active-v1'))) === null && (await page.evaluate(() => P.xp)) === 0);
  await page.reload(); await page.waitForSelector('#app *');
  check('after the reset the app opens on the home screen with nothing to resume', (await page.evaluate(() => V)) === 'home');
  check('no JS errors (replay and reset)', errs.length === 0, errs.join(' | '));
  await ctx.close();
}
// 15) the result screen after a lesson (what a user sees when a lesson ends), a replay's result, and the leaderboard tab still renders
{
  const ctx = await newCtx(); await fakeSupabase(ctx); const page = await ctx.newPage(); const errs = watch(page);
  await page.goto(ORIGIN + '/'); await page.waitForSelector('#app *');
  const info = await page.evaluate(() => {
    S = LT.start(1); let failedWord = null;
    while (!LT.finished(S)) { const c = LT.cur(S); let t = c.text; if (c.step === 'word' && !c.rev && !failedWord) { failedWord = c.word.wordText; t = 'zzzzzz'; } LT.submit(S, t); }
    LT.finish(S); V = 'lesson'; show = false; render();
    const x = S.es.xp; return { failedWord, total: x.firstTry + x.recovered + x.lessonBonus, x };
  });
  const text = await page.innerText('#app');
  check('result screen: lesson title, XP total and breakdown', text.includes('اكتمل الدرس 1') && text.includes(String(info.total)) && text.includes(`من أول محاولة ${info.x.firstTry}`) && text.includes(`مراجعات ${info.x.recovered}`) && text.includes(`مكافأة ${info.x.lessonBonus}`), text.replace(/\s+/g, ' ').slice(0, 220));
  check('result screen lists the word that needed a review', text.includes(info.failedWord), info.failedWord);
  await page.screenshot({ path: '/tmp/e2e-result.png' });
  const rp = await page.evaluate(() => { S = LT.start(1); while (!LT.finished(S)) LT.submit(S, LT.cur(S).text); LT.finish(S); V = 'lesson'; render(); return P.xp; });
  check('replay result says no points and XP is unchanged', (await page.innerText('#app')).includes('إعادة — بلا نقاط') && rp === info.total);
  await page.evaluate(() => go('home')); await page.click('nav button[data-t=board]'); await page.waitForTimeout(150);
  check('leaderboard tab renders and shows the user row', (await page.innerText('#app')).includes('أنت'));
  check('no JS errors (result screens)', errs.length === 0, errs.join(' | '));
  await ctx.close();
}

// ───────────── v6: cloud sync against the real commit-session code ─────────────
const learn = (page) => page.evaluate(() => { for (;;) { if (LT.finished(S)) break; skew += 2000; LT.submit(S, LT.cur(S).text); } skew += 500; return LT.finish(S).xp.total; }); // a lesson typed right, with realistic timing (the server checks it)
const startLesson = (page, g) => page.evaluate((n) => { S = LT.start(n); }, g);
const signInUi = async (page, name = 'Sara A') => { await page.goto(ORIGIN + '/'); await page.waitForSelector('#app *'); await openProfile(page); await page.click('button.open >> text=Google'); await page.waitForFunction((n) => document.body.innerText.includes(n), name, { timeout: 8000 }); };
const waitText = (page, t, ms = 15000) => page.waitForFunction((x) => document.body.innerText.includes(x), t, { timeout: ms });
const waitFor = async (fn, ms = 15000) => { const t0 = Date.now(); while (Date.now() - t0 < ms) { if (await fn()) return true; await new Promise((r) => setTimeout(r, 100)); } return false; };
const SAVED = 'تقدمك محفوظ في حسابك ✓';
const U1 = backend.addUser(randomUUID(), 'Sara');
const userOf = (id, n = 'Sara A') => ({ id, email: 'sara@example.com', user_metadata: { full_name: n } });
let phone1;

// 16) a lesson finished while signed in reaches the account through the browser (CORS preflight, the Edge Function, the real replay)
{
  const ctx = await newCtx(); await fakeSupabase(ctx, { user: userOf(U1), real: true }); const page = await ctx.newPage(); const errs = watch(page);
  await signInUi(page); await waitText(page, SAVED);
  check('signed in on a fresh phone: the account card says the progress is saved', true);
  await startLesson(page, 1);
  const xp = await learn(page);
  check('the lesson is finished locally (250 XP) and queued', xp === 250 && (await page.evaluate(() => P.xp)) === 250);
  check('the account recorded the lesson (the server replayed it itself)', await waitFor(() => backend.count(`lesson_sessions WHERE user_id = '${U1}'`) === 1));
  check('and credited the same 250 XP', Number(backend.db.prepare('SELECT total_xp AS x FROM users WHERE id = ?1').all(U1)[0].x) === 250);
  await page.evaluate(() => go('me')); await waitText(page, SAVED);
  check('the profile says «تقدمك محفوظ في حسابك ✓» again', (await page.innerText('#app')).includes(SAVED));
  check('the browser called the Edge Function with POST and read its answer', calls.some((c) => c.startsWith('POST /functions/v1/commit-session')));
  await page.screenshot({ path: '/tmp/e2e-synced.png' });
  check('no JS errors (sync)', errs.length === 0, errs.join(' | '));
  phone1 = ctx; // kept open for the reset check below
}
// 17) a second phone on the same account takes its progress and continues the chain
{
  const ctx = await newCtx(); await fakeSupabase(ctx, { user: userOf(U1), real: true }); const page = await ctx.newPage(); const errs = watch(page);
  await signInUi(page);
  check('a second phone pulls the account: 250 XP and lesson 1 done', await waitFor(async () => (await page.evaluate(() => P.xp === 250 && !!P.completed[1] && LT.nextLesson() === 2))));
  await startLesson(page, 2); await learn(page);
  check('its lesson 2 is accepted (the chain head was learnt from the server)', await waitFor(() => backend.count(`lesson_sessions WHERE user_id = '${U1}'`) === 2));
  const rows = backend.db.prepare('SELECT id, parent_session_id AS p FROM lesson_sessions WHERE user_id = ?1 ORDER BY completed_at').all(U1);
  check('and it is chained after lesson 1', rows[1].p === rows[0].id);
  check('no JS errors (second phone)', errs.length === 0, errs.join(' | '));
  await ctx.close();
}
// 18) progress from before sync is not mixed in silently: the learner is asked, a backup is kept, then the account starts from zero
{
  const U3 = backend.addUser(randomUUID(), 'Omar');
  const ctx = await newCtx(); await fakeSupabase(ctx, { user: userOf(U3, 'Omar B'), real: true });
  await ctx.addInitScript(() => { if (!localStorage.getItem('lingotrace-progress-v1')) localStorage.setItem('lingotrace-progress-v1', JSON.stringify({ v: 1, xp: 155, streak: { streakCount: 1, longestStreak: 1, lastActiveDate: '2026-11-21' }, completed: { 1: true }, rotation: {}, prefs: { loc: 'en-US', unlock: false, tr: true }, lastSessionId: null })); });
  const page = await ctx.newPage(); const errs = watch(page);
  const before = calls.length;
  await signInUi(page, 'Omar B');
  await waitText(page, 'ابدأ حسابي من الصفر');
  check('legacy progress: the card explains and offers «ابدأ حسابي من الصفر»', (await page.innerText('#app')).includes('لا يمكن التحقق منه'));
  await page.screenshot({ path: '/tmp/e2e-decision.png' });
  await page.waitForTimeout(600);
  check('nothing was sent or read for this account meanwhile', !calls.slice(before).some((c) => /\/functions\/v1\/|\/rest\/v1\//.test(c)));
  check('and the local progress is untouched', (await page.evaluate(() => P.xp)) === 155);
  page.once('dialog', (d) => d.accept()); await page.click('button:has-text("ابدأ حسابي من الصفر")');
  await waitText(page, SAVED);
  const st = await page.evaluate(() => ({ xp: P.xp, done: Object.keys(P.completed).length, backup: JSON.parse(localStorage.getItem('lingotrace-backup-v1') || 'null') }));
  check('the account starts from zero and the old progress is backed up on the phone', st.xp === 0 && st.done === 0 && st.backup && st.backup.state.xp === 155 && !!st.backup.state.completed[1], JSON.stringify(st));
  await page.screenshot({ path: '/tmp/e2e-adopted.png' });
  await startLesson(page, 1); await learn(page);
  check('lesson 1 is now a real first run, recorded by the account with 250 XP', await waitFor(() => backend.count(`lesson_sessions WHERE user_id = '${U3}'`) === 1) && Number(backend.db.prepare('SELECT total_xp AS x FROM users WHERE id = ?1').all(U3)[0].x) === 250);
  check('no JS errors (legacy decision)', errs.length === 0, errs.join(' | '));
  await ctx.close();
}
// 19) offline: the lesson waits («بانتظار الاتصال») and is sent by itself when the connection is back
{
  const U4 = backend.addUser(randomUUID(), 'Lina');
  const ctx = await newCtx(); await fakeSupabase(ctx, { user: userOf(U4, 'Lina C'), real: true }); const page = await ctx.newPage(); const errs = watch(page);
  await signInUi(page, 'Lina C'); await waitText(page, SAVED);
  backend.hooks.before = async (u) => { if (u.pathname.includes('commit-session')) throw new TypeError('offline'); return null; };
  await startLesson(page, 1); await learn(page);
  await page.evaluate(() => go('me'));
  await waitText(page, 'بانتظار الاتصال');
  check('offline: the profile says a session is waiting', (await page.innerText('#app')).includes('بانتظار الاتصال: جلسة'));
  check('and nothing reached the account', backend.count(`lesson_sessions WHERE user_id = '${U4}'`) === 0);
  await page.screenshot({ path: '/tmp/e2e-offline.png' });
  backend.hooks.before = null;
  await page.evaluate(() => dispatchEvent(new Event('online')));
  await waitText(page, SAVED, 20000);
  check('back online: the lesson arrives by itself and the account has the XP', backend.count(`lesson_sessions WHERE user_id = '${U4}'`) === 1 && Number(backend.db.prepare('SELECT total_xp AS x FROM users WHERE id = ?1').all(U4)[0].x) === 250);
  check('no JS errors (offline)', errs.length === 0, errs.join(' | '));
  await ctx.close();
}
// 20) «إعادة ضبط التجربة» wipes only this phone: the account progress comes straight back
{
  const page = (await phone1.pages())[0];
  await page.evaluate(() => go('me'));
  page.once('dialog', async (d) => { check('the reset asks first and says the account keeps the progress', d.message().includes('يبقى ويرجع')); await d.accept(); });
  await page.click('button:has-text("إعادة ضبط التجربة")');
  check('the progress comes back from the account after a reset (500 XP: lesson 2 was played on the other phone)', await waitFor(() => page.evaluate(() => P.xp === 500 && !!P.completed[1] && !!P.completed[2])));
  await phone1.close();
}
await browser.close(); server.close();
console.log(fails === 0 ? 'ALL PASS' : fails + ' FAILED');
process.exit(fails ? 1 : 0);
