/**
 * Writes supabase/tests/database/005_pgrepo_contract.sql from the statements PgRepo REALLY sends.
 *
 *   node scripts/gen-pgrepo-contract.ts            write the script
 *   node scripts/gen-pgrepo-contract.ts --check    change nothing; exit 1 when the script is out of date
 *   node scripts/gen-pgrepo-contract.ts --explain  also print what the SQLite twin ended up with (to compare after a failed check)
 *
 * Why generated: the unit tests run PgRepo's SQL on a SQLite twin. SQLite is not PostgreSQL, so some things can only
 * be proven on the real database: parameter typing (`$4` used twice), `GREATEST/LEAST` on timestamps, upsert targets
 * matching real indexes, the multi-row INSERT, the session-chain indexes. This script replays a fixed scenario through the
 * real commit service on the twin, records every statement with its values, and writes them out as PREPARE / EXECUTE
 * (the way a driver sends them: parameters of unspecified type, values as text). Run on PostgreSQL inside a transaction
 * that is rolled back, every statement must execute, the chain-head and rotation lookups must return what the twin
 * returned, and in the end every table must hold exactly what the twin holds (compared as md5 digests).
 *
 * Because the file is generated from the code, it cannot drift from it; a test fails when PgRepo changes and this file was not regenerated.
 */

import { createHash } from 'node:crypto';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { DEFAULT_CONFIG, beginSession, currentPrompt, submit, toSessionCommit } from '../packages/engine/src/index.ts';
import type { EngineConfig, Prompt, SessionCommit } from '../packages/engine/src/index.ts';
import { PgRepo, commitSession } from '../packages/engine/src/server/index.ts';
import type { MistakeRecord } from '../packages/engine/src/index.ts';
import { openDb, sqlitePool, uuidOf } from '../packages/engine/test/helpers/db.ts';
import type { Db } from '../packages/engine/test/helpers/db.ts';

/** Edited by hand after the script has been run on the real database (then regenerate). */
export const STATUS_LINE = '-- Status: verified on the real database (Supabase project lingotrace, PostgreSQL 17.11) on 2026-10-25: 79 of 79 checks ok.';
export const SCRIPT_PATH = 'supabase/tests/database/005_pgrepo_contract.sql';

// ─── the scenario ────────────────────────────────────────────────────────────

/** 3 words per lesson and a review gap of one lesson keep the script small and put the injection in the second lesson. */
const CFG: EngineConfig = { ...DEFAULT_CONFIG, lessonSize: 3, reviewGapLessons: 1 };
const id = (kind: string, key: string | number) => uuidOf(`contract:${kind}:${key}`);
const U1 = id('user', 1);
const U2 = id('user', 2);
/** Words and numbers chosen so that they cannot collide with the real content that is seeded later. */
const WORDS = ['apple', 'bridge', 'candle', 'dolphin', 'engine', 'forest', 'garden', 'harbor', 'island'].map((w) => `zx${w}`);
const wordId = (text: string) => id('word', text);
const lessonId = (n: number) => id('lesson', n);
const lessonNumber = (n: number) => 30000 + n;
const globalSeq = (n: number) => 900000 + n;
const sentenceOf = (text: string) => `I can see the ${text} today.`;
const lessonTexts = (n: number) => WORDS.slice((n - 1) * 3, n * 3);
const T0 = Date.parse('2026-10-04T10:00:00.000Z');
const HOUR = 3_600_000;

/** Two substitutions: a major mistake (a minor slip is a single edit). */
const wrongly = (text: string) => `qq${text.slice(2)}`;
/** One letter missing: a minor slip. */
const slip = (text: string) => text.slice(0, -1);

function seedTwin(db: Db): void {
  db.exec(`INSERT INTO users (id, display_name) VALUES ('${U1}', 'Contract One'), ('${U2}', 'Contract Two')`);
  for (const t of WORDS) db.prepare('INSERT INTO vocabulary_bank (id, word_text, sentence_context) VALUES (?1, ?2, ?3)').run(wordId(t), t, sentenceOf(t));
  for (const n of [1, 2, 3]) {
    db.prepare("INSERT INTO lessons (id, level_code, lesson_number, global_seq, is_published) VALUES (?1, 'A1', ?2, ?3, 1)").run(lessonId(n), lessonNumber(n), globalSeq(n));
    lessonTexts(n).forEach((t, i) => db.prepare('INSERT INTO lesson_words (lesson_id, position, word_id) VALUES (?1, ?2, ?3)').run(lessonId(n), i + 1, wordId(t)));
  }
}

interface Recorded { phase: string; text: string; values: unknown[]; rows: Array<Record<string, unknown>> }

interface PlayArgs {
  n: number; sessionId: string; userId: string; parent: string | null; seed: number; at: number;
  mode?: 'first_run' | 'replay'; answer?: (prompt: Prompt, attempt: number) => string;
}

async function play(clientRepo: PgRepo, a: PlayArgs): Promise<SessionCommit> {
  const words = lessonTexts(a.n).map((t) => ({ wordId: wordId(t), wordText: t, sentenceContext: sentenceOf(t), errorWeight: 0 }));
  const history: MistakeRecord[] = a.mode === 'replay' ? [] : await clientRepo.transaction((tx) => tx.loadDueMistakes(a.userId, lessonId(a.n), 50));
  const setup = { sessionId: a.sessionId, lessonSeq: globalSeq(a.n), mode: a.mode ?? 'first_run', seed: a.seed, lessonWords: words, history, cfg: CFG };
  let { state, rng } = beginSession(setup);
  let clock = a.at;
  const startedAt = new Date(clock).toISOString();
  let key = '';
  let k = 0;
  while (state.phase !== 'completed') {
    const p = currentPrompt(state)!;
    k = key === `${p.itemId}/${p.step}` ? k + 1 : 1;
    key = `${p.itemId}/${p.step}`;
    clock += 2000;
    state = submit(state, a.answer ? a.answer(p, k) : p.text, { now: new Date(clock), rng, cfg: CFG }).state;
  }
  return toSessionCommit(state, { lessonId: lessonId(a.n), parentSessionId: a.parent, seed: a.seed, timeZone: 'Asia/Riyadh', startedAt, completedAt: new Date(clock + 500).toISOString() });
}

export interface Scenario {
  recorded: Recorded[];
  outcomes: Record<string, string>;
  db: Db;
}

export async function runScenario(): Promise<Scenario> {
  const db = await openDb();
  seedTwin(db);
  const recorded: Recorded[] = [];
  let phase = '';
  let recording = false;
  const pool = sqlitePool(db);
  const recordingPool = {
    async connect() {
      const client = await pool.connect();
      return {
        async query(text: string, values: unknown[] = []) {
          const result = await client.query(text, values);
          if (recording) recorded.push({ phase, text, values, rows: result.rows });
          return result;
        },
        release: () => client.release(),
      };
    },
  };
  const server = new PgRepo(recordingPool);
  const clientRepo = new PgRepo(pool); // what the app reads for itself: not part of the contract
  const outcomes: Record<string, string> = {};
  const commit = async (name: string, userId: string, c: SessionCommit) => {
    phase = name;
    recording = true;
    const r = await commitSession(server, userId, c, new Date(Date.parse(c.completedAt) + 1000), { cfg: CFG });
    recording = false;
    outcomes[name] = r.ok ? r.receipt.status : r.code;
  };

  const [s1, s2, s3, s4, s5] = [id('session', 1), id('session', 2), id('session', 3), id('session', 4), id('session', 5)] as const;

  // S1: lesson 1, first run. The first word fails twice (major mistake in the lesson and again in the review).
  const c1 = await play(clientRepo, { n: 1, sessionId: s1, userId: U1, parent: null, seed: 1111, at: T0, answer: (p) => (p.wordId === wordId(WORDS[0]!) ? wrongly(p.text) : p.text) });
  await commit('S1 first run', U1, c1);
  // S2: lesson 2, first run. The failed word is due and gets injected; it fails twice again.
  const c2 = await play(clientRepo, { n: 2, sessionId: s2, userId: U1, parent: s1, seed: 2222, at: T0 + HOUR, answer: (p) => (p.wordId === wordId(WORDS[0]!) ? wrongly(p.text) : p.text) });
  await commit('S2 first run with an injected word', U1, c2);
  // S3: lesson 1 again as a replay, and a worse one: the first word has a slip, a major mistake, then the right spelling in
  // the review; the second word fails twice. Accuracy falls from 67 to 33, so best_accuracy must keep 67 while last_accuracy follows.
  const c3 = await play(clientRepo, {
    n: 1, sessionId: s3, userId: U1, parent: s2, seed: 3333, at: T0 + 2 * HOUR, mode: 'replay',
    answer: (p, attempt) => {
      if (p.wordId === wordId(WORDS[1]!)) return wrongly(p.text);
      if (p.wordId !== wordId(WORDS[0]!) || p.step !== 'word') return p.text;
      if (!p.isReview) return attempt === 1 ? slip(p.text) : wrongly(p.text);
      return attempt === 1 ? slip(p.text) : p.text;
    },
  });
  await commit('S3 replay', U1, c3);
  // S4: another user starts a chain of their own.
  const c4 = await play(clientRepo, { n: 1, sessionId: s4, userId: U2, parent: null, seed: 4444, at: T0 + 3 * HOUR });
  await commit('S4 other user', U2, c4);
  // The first session sent again: answered from the record, nothing written.
  await commit('S1 sent again', U1, c1);
  // A session that names a stale parent: refused before anything is written.
  const c5 = await play(clientRepo, { n: 3, sessionId: s5, userId: U1, parent: s1, seed: 5555, at: T0 + 4 * HOUR });
  await commit('S5 stale parent', U1, c5);

  // The scenario must keep covering what it was written to cover; if the engine changes and it drifts, fail here.
  const expectOutcomes: Record<string, string> = {
    'S1 first run': 'committed', 'S2 first run with an injected word': 'committed', 'S3 replay': 'committed',
    'S4 other user': 'committed', 'S1 sent again': 'duplicate', 'S5 stale parent': 'out_of_order',
  };
  for (const [name, want] of Object.entries(expectOutcomes)) {
    if (outcomes[name] !== want) throw new Error(`scenario drifted: "${name}" ended as ${outcomes[name]}, expected ${want}`);
  }
  if (c2.injectedWordIds.length !== 1) throw new Error('scenario drifted: lesson 2 should inject exactly the failed word');
  const one = (sql: string) => Object.values(db.prepare(sql).all()[0] ?? {})[0];
  const checks: Array<[string, unknown, unknown]> = [
    ['the repeated misspelling reached the upsert conflict path (occurrences of the major mistake)', one(`SELECT occurrences FROM misspelled_words WHERE typed = '${wrongly(WORDS[0]!)}'`), 5],
    ['the replay reached the user_progress conflict path (completions)', one(`SELECT completions FROM user_progress WHERE user_id = '${U1}' AND lesson_id = '${lessonId(1)}'`), 2],
    ['the rotation row was updated in place by the injected failure (error_weight)', one(`SELECT error_weight FROM user_word_stats WHERE user_id = '${U1}' AND word_id = '${wordId(WORDS[0]!)}'`), 2],
    ['the chain of the first user has three sessions', one(`SELECT count(*) FROM lesson_sessions WHERE user_id = '${U1}'`), 3],
    ['best_accuracy kept the better first run after a worse replay', one(`SELECT best_accuracy FROM user_progress WHERE user_id = '${U1}' AND lesson_id = '${lessonId(1)}'`), 67],
    ['last_accuracy followed the worse replay', one(`SELECT last_accuracy FROM user_progress WHERE user_id = '${U1}' AND lesson_id = '${lessonId(1)}'`), 33],
  ];
  for (const [what, got, want] of checks) if (Number(got) !== want) throw new Error(`scenario drifted: ${what} is ${String(got)}, expected ${want}`);
  return { recorded, outcomes, db };
}

// ─── rendering ───────────────────────────────────────────────────────────────

const squash = (text: string) => text.replace(/\s+/g, ' ').trim();
/** Values go in as text, like a driver's parameters: PostgreSQL then infers each type from the statement, exactly as it does for the app. */
const quote = (v: unknown): string => (v === null || v === undefined ? 'NULL' : `'${String(typeof v === 'boolean' ? (v ? 'true' : 'false') : v).replace(/'/g, "''")}'`);
const md5 = (text: string) => createHash('md5').update(text).digest('hex');

/**
 * Every id of the scenario appears in the script hundreds of times, and a UUID is 36 characters. The script therefore writes
 * them as short tokens (`@u1@`, `@w3@`) and replaces the tokens inside the database (pg_temp.sub) from a small table, which makes
 * the file about 60% smaller and far easier to paste or read.
 */
const SESSION_IDS = [1, 2, 3, 4, 5].map((n) => id('session', n));
const TOKENS: Array<[string, string]> = [
  [U1, 'u1'], [U2, 'u2'],
  ...[1, 2, 3].map((n): [string, string] => [lessonId(n), `l${n}`]),
  ...WORDS.map((t, i): [string, string] => [wordId(t), `w${i + 1}`]),
  ...SESSION_IDS.map((sid, i): [string, string] => [sid, `s${i + 1}`]),
];
const tokenize = (text: string): string => TOKENS.reduce((acc, [uuid, key]) => acc.split(uuid).join(`@${key}@`), text);

function describeStatement(text: string): string {
  const t = squash(text);
  const insert = /^INSERT INTO (\w+)/.exec(t);
  if (insert) return `INSERT ${insert[1]}${/ON CONFLICT/.test(t) ? ' (upsert)' : ''}`;
  const update = /^UPDATE (\w+)/.exec(t);
  if (update) return `UPDATE ${update[1]}`;
  if (/NOT EXISTS \(SELECT 1 FROM lesson_sessions c/.test(t)) return 'SELECT chain head';
  if (/FROM user_word_stats s JOIN vocabulary_bank/.test(t)) return 'SELECT due mistakes';
  const from = /FROM (\w+)/.exec(t);
  return `SELECT ${from ? from[1] : '?'}`;
}

interface Column { name: string; kind: 'text' | 'epoch' | 'bool' }
interface TableDigest { label: string; table: string; where: string; columns: Column[]; order: string[] }

const USERS_IN = `('${U1}', '${U2}')`;
const SESSIONS_OF_USERS = `session_id IN (SELECT id FROM lesson_sessions WHERE user_id IN ${USERS_IN})`;
const text = (name: string): Column => ({ name, kind: 'text' });
const epoch = (name: string): Column => ({ name, kind: 'epoch' });
const bool = (name: string): Column => ({ name, kind: 'bool' });

// Known limit: the order columns are sorted as text (collate "C"), so a numeric key such as `n` sorts like a number only while it
// stays below 10 (the scenario's largest is 8). Do not grow the scenario past that without changing the ORDER BY.
const DIGESTS: TableDigest[] = [
  { label: 'lesson_sessions', table: 'lesson_sessions', where: `user_id IN ${USERS_IN}`, order: ['id'],
    columns: ['id', 'user_id', 'lesson_id', 'mode', 'parent_session_id', 'words_total', 'words_clean', 'words_failed_twice', 'xp_earned'].map(text) },
  { label: 'session_attempts', table: 'session_attempts', where: SESSIONS_OF_USERS, order: ['session_id', 'n'],
    columns: [...['session_id', 'n', 'word_id', 'origin', 'step', 'attempt_no', 'typed', 'distance', 'verdict'].map(text), bool('used_peek')] },
  { label: 'user_word_stats', table: 'user_word_stats', where: `user_id IN ${USERS_IN}`, order: ['user_id', 'word_id'],
    columns: [...['user_id', 'word_id', 'error_weight', 'status', 'due_seq', 'lifetime_failures'].map(text), epoch('last_failed_at'), epoch('last_reviewed_at')] },
  { label: 'misspelled_words', table: 'misspelled_words', where: `user_id IN ${USERS_IN}`, order: ['user_id', 'word_id', 'typed'],
    columns: [...['user_id', 'word_id', 'typed', 'occurrences'].map(text), epoch('first_seen_at'), epoch('last_seen_at')] },
  { label: 'xp_events', table: 'xp_events', where: `user_id IN ${USERS_IN}`, order: ['session_id', 'reason'],
    columns: ['user_id', 'session_id', 'reason', 'amount'].map(text) },
  { label: 'user_progress', table: 'user_progress', where: `user_id IN ${USERS_IN}`, order: ['user_id', 'lesson_id'],
    columns: [...['user_id', 'lesson_id', 'completions', 'best_accuracy', 'last_accuracy'].map(text), epoch('first_completed_at'), epoch('last_played_at')] },
  { label: 'users', table: 'users', where: `id IN ${USERS_IN}`, order: ['id'],
    columns: ['id', 'total_xp', 'streak_count', 'longest_streak', 'last_active_date', 'time_zone'].map(text) },
];

const pgCell = (c: Column) =>
  c.kind === 'epoch' ? `coalesce(floor(extract(epoch from ${c.name}))::bigint::text, 'null')`
    : c.kind === 'bool' ? `coalesce(${c.name}::int::text, 'null')`
      : `coalesce(${c.name}::text, 'null')`;
const sqliteCell = (c: Column) =>
  c.kind === 'epoch' ? `coalesce(cast(strftime('%s', ${c.name}) as text), 'null')` : `coalesce(cast(${c.name} as text), 'null')`;

const pgDigestQuery = (d: TableDigest) =>
  `select coalesce(string_agg(concat_ws('~', ${d.columns.map(pgCell).join(', ')}), '|' order by ${d.order.map((o) => `${o}::text collate "C"`).join(', ')}), '') from public.${d.table} where ${d.where}`;
const sqliteDigestQuery = (d: TableDigest) =>
  `select coalesce(group_concat(row_text, '|'), '') from (select ${d.columns.map(sqliteCell).join(" || '~' || ")} as row_text from ${d.table} where ${d.where} order by ${d.order.join(', ')})`;

const HELPERS = `create temp table results (n serial primary key, ok boolean not null, label text not null, detail text);

create function pg_temp.rec(p_label text, p_ok boolean, p_detail text default null) returns void language plpgsql as $$
begin
  insert into results (ok, label, detail) values (coalesce(p_ok, false), p_label, p_detail);
end $$;

-- The ids of the scenario have short names in this file (@u1@ is the first user, @w3@ the third word ...).
create temp table ids (k text primary key, val text not null);

create function pg_temp.sub(p_text text) returns text language plpgsql as $$
declare r record; v text := p_text;
begin
  for r in select k, val from ids loop
    v := replace(v, '@' || r.k || '@', r.val);
  end loop;
  return v;
end $$;

-- Runs one prepared statement with text arguments, as a driver would, and records whether it worked.
create function pg_temp.exec(p_label text, p_name text, p_args text default null) returns void language plpgsql as $$
begin
  execute 'execute ' || p_name || coalesce('(' || pg_temp.sub(p_args) || ')', '');
  perform pg_temp.rec(p_label, true);
exception when others then
  perform pg_temp.rec(p_label, false, sqlstate || ': ' || sqlerrm);
end $$;

-- Runs a prepared SELECT and compares the ids it returns, in order, with what the twin returned.
create function pg_temp.exec_ids(p_label text, p_name text, p_args text, p_expected text) returns void language plpgsql as $$
declare v text;
begin
  execute 'create temp table contract_r as execute ' || p_name || '(' || pg_temp.sub(p_args) || ')';
  select coalesce(string_agg(id::text, ','), '') into v from contract_r;
  drop table contract_r;
  perform pg_temp.rec(p_label, v = pg_temp.sub(p_expected), case when v = pg_temp.sub(p_expected) then null else 'got [' || v || '], expected [' || pg_temp.sub(p_expected) || ']' end);
exception when others then
  perform pg_temp.rec(p_label, false, sqlstate || ': ' || sqlerrm);
end $$;

-- Compares the md5 of a table digest with the one the SQLite twin produced.
create function pg_temp.digest_check(p_label text, p_query text, p_md5 text) returns void language plpgsql as $$
declare v text;
begin
  execute pg_temp.sub(p_query) into v;
  perform pg_temp.rec(p_label, md5(coalesce(v, '')) = p_md5, case when md5(coalesce(v, '')) = p_md5 then null else left(coalesce(v, '(null)'), 700) end);
exception when others then
  perform pg_temp.rec(p_label, false, sqlstate || ': ' || sqlerrm);
end $$;`;

export interface Generated { script: string; explain: string }

export function render(s: Scenario): Generated {
  const names = new Map<string, string>();
  const bodies: string[] = [];
  const nameOf = (raw: string): string => {
    const key = squash(raw);
    let name = names.get(key);
    if (name === undefined) {
      name = `contract_q${String(names.size + 1).padStart(2, '0')}`;
      names.set(key, name);
      bodies.push(`prepare ${name} as ${key};`);
    }
    return name;
  };

  const flow: string[] = [];
  let phase = '';
  let seq = 0;
  for (const r of s.recorded) {
    if (/^(BEGIN|COMMIT|ROLLBACK)\b/i.test(r.text.trim())) continue; // the script is one transaction of its own
    if (r.phase !== phase) {
      phase = r.phase;
      seq = 0;
      flow.push(`\n-- ${phase}`);
    }
    seq += 1;
    const name = nameOf(r.text);
    const label = `${phase} #${String(seq).padStart(2, '0')} ${describeStatement(r.text)}`.replace(/'/g, "''");
    const args = r.values.length === 0 ? null : tokenize(r.values.map(quote).join(', '));
    const kind = describeStatement(r.text);
    if (kind === 'SELECT chain head' || kind === 'SELECT due mistakes') {
      const expected = tokenize(r.rows.map((row) => String(row.id)).join(','));
      flow.push(`select pg_temp.exec_ids('${label} returns the twin''s ids', '${name}', $a$${args ?? ''}$a$, '${expected}');`);
    } else {
      flow.push(`select pg_temp.exec('${label}', '${name}'${args === null ? '' : `, $a$${args}$a$`});`);
    }
  }

  const explainLines: string[] = [];
  const digests = DIGESTS.map((d) => {
    const row = s.db.prepare(sqliteDigestQuery(d)).all()[0] as Record<string, unknown>;
    const digest = String(Object.values(row)[0] ?? '');
    const rows = digest === '' ? 0 : digest.split('|').length;
    explainLines.push(`${d.label} (${rows} rows) md5 ${md5(digest)}\n${digest.split('|').map((x) => `    ${x}`).join('\n')}`);
    return `select pg_temp.digest_check('${d.label} (${rows} rows) holds what the twin holds', $q$${tokenize(pgDigestQuery(d))}$q$, '${md5(digest)}');`;
  });

  const insertList = (rows: string[]) => rows.map((r) => `  ${r}`).join(',\n');
  const world = [
    `insert into auth.users (id, aud, role, email, raw_user_meta_data) values\n${insertList([U1, U2].map((u, i) => `('${u}', 'authenticated', 'authenticated', 'contract${i + 1}@example.com', '{}')`))};`,
    `insert into public.vocabulary_bank (id, word_text, sentence_context) values\n${insertList(WORDS.map((t) => `('${wordId(t)}', '${t}', '${sentenceOf(t)}')`))};`,
    `insert into public.lessons (id, level_code, lesson_number, global_seq, is_published) values\n${insertList([1, 2, 3].map((n) => `('${lessonId(n)}', 'A1', ${lessonNumber(n)}, ${globalSeq(n)}, true)`))};`,
    `insert into public.lesson_words (lesson_id, position, word_id) values\n${insertList([1, 2, 3].flatMap((n) => lessonTexts(n).map((t, i) => `('${lessonId(n)}', ${i + 1}, '${wordId(t)}')`)))};`,
  ].join('\n');

  const script = [
    `-- =============================================================================
-- 005_pgrepo_contract.sql   GENERATED by scripts/gen-pgrepo-contract.ts: do not edit, regenerate.
${STATUS_LINE}
-- Runs inside ONE transaction that always ends with ROLLBACK, so it leaves no trace.
--   psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f supabase/tests/database/005_pgrepo_contract.sql
-- or paste it into the Supabase SQL editor. The last SELECT lists every check: ok = true must hold for all.
--
-- What it proves on a REAL PostgreSQL (the unit tests only had a SQLite twin): every statement of the commit service
-- (src/server/pg-repo.ts) is accepted with parameters of unspecified type, exactly as a driver sends them; the chain-head
-- and due-mistakes lookups return what the twin returned; and after a fixed scenario (a first run, an injected review, a
-- replay, a second user, a repeated and a stale session) every table holds exactly what the twin holds.
-- Ids are written as tokens (@u1@, @w3@ ...) that the script replaces from its own table (pg_temp.sub). Needs the owner role (postgres) and the migrations up to 20261022000100_session_chain.sql. It uses lesson numbers
-- 30001..30003 and words starting with "zx", which cannot clash with the seeded content. Keep this file plain ASCII.
-- =============================================================================
begin;
deallocate all;
`,
    HELPERS,
    `\n-- world: two users (the sign-up trigger creates their profiles), nine words, three lessons`,
    `insert into ids (k, val) values\n${insertList(TOKENS.map(([uuid, key]) => `('${key}', '${uuid}')`))};`,
    world,
    `\n-- the statements, prepared once each`,
    bodies.join('\n'),
    `\n-- the scenario, statement by statement, in the order the commit service sent them`,
    flow.join('\n'),
    `\n-- end state against the twin`,
    digests.join('\n'),
    `\ndeallocate all;
select ok, label, detail from results order by n;
rollback;
`,
  ].join('\n');
  return { script, explain: explainLines.join('\n\n') };
}

async function main(): Promise<void> {
  const root = fileURLToPath(new URL('../', import.meta.url));
  const path = `${root}${SCRIPT_PATH}`;
  const { script, explain } = render(await runScenario());
  if (process.argv.includes('--explain')) console.log(explain);
  if (process.argv.includes('--check')) {
    if (!existsSync(path) || readFileSync(path, 'utf8') !== script) {
      console.error(`${SCRIPT_PATH} is OUT OF DATE: run node scripts/gen-pgrepo-contract.ts`);
      process.exitCode = 1;
    } else {
      console.log(`${SCRIPT_PATH} is up to date`);
    }
    return;
  }
  writeFileSync(path, script);
  console.log(`wrote ${SCRIPT_PATH} (${script.length} bytes, ${script.split('\n').length} lines)`);
}

if (process.argv[1] !== undefined && import.meta.url === pathToFileURL(process.argv[1]).href) await main();
