// Draws the LingoTrace icons (an "L" and a typing cursor). Needs `sharp`, which exists in Claude's sandbox.
// Usage: node scripts/make-icons.mjs <output-dir>
import { createRequire } from 'node:module';
import { mkdirSync } from 'node:fs';
const require = createRequire('/home/claude/.npm-global/lib/node_modules/');
const sharp = require('sharp');
const out = process.argv[2] ?? 'site-placeholder';
mkdirSync(out, { recursive: true });

const glyph = `
  <rect x="150" y="128" width="52" height="256" rx="14" fill="#ff5a78"/>
  <rect x="150" y="332" width="170" height="52" rx="14" fill="#ff5a78"/>
  <rect x="352" y="214" width="26" height="170" rx="10" fill="#34d399"/>`;
const svg = (bg) => `<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 512 512">${bg}${glyph}</svg>`;
const rounded = svg('<rect width="512" height="512" rx="112" fill="#0d1220"/>');
const full = svg('<rect width="512" height="512" fill="#0d1220"/>');

const jobs = [
  [rounded, 192, 'icon-192.png'],
  [rounded, 512, 'icon-512.png'],
  [full, 512, 'icon-maskable-512.png'],
  [full, 180, 'apple-touch-icon.png'],
];
for (const [s, size, name] of jobs) {
  await sharp(Buffer.from(s)).resize(size, size).png().toFile(`${out}/${name}`);
  console.log('wrote', `${out}/${name}`);
}
