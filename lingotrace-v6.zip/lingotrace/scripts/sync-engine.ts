/**
 * Copies the engine into the Edge Functions: packages/engine/src  ->  supabase/functions/_shared/engine
 *
 * Why a copy: a deployed Edge Function can only use files inside supabase/functions, and the engine must stay a
 * single source of truth (the app and the server have to run the very same rules, or the server's replay would
 * disagree with what the app played). So the engine lives in packages/engine and this script mirrors it, byte for
 * byte, into a folder nobody edits by hand.
 *
 *   node scripts/sync-engine.ts           write the copy (run it after every change to packages/engine/src)
 *   node scripts/sync-engine.ts --check   change nothing; exit 1 when the copy is out of date (for CI and tests)
 *
 * No dependencies. Node 22.18+ runs this TypeScript file directly.
 */

import { existsSync, mkdirSync, readFileSync, readdirSync, rmSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

export const MARKER_FILE = 'GENERATED.md';
export const MARKER_TEXT = `# GENERATED, do not edit

This folder is a byte-for-byte copy of \`packages/engine/src\`, made by \`scripts/sync-engine.ts\`.
Change the engine there, then run \`node scripts/sync-engine.ts\`. \`--check\` fails when this copy is out of date.
`;

export interface SyncReport {
  /** Present in both, different content. */
  changed: string[];
  /** In the engine, absent from the copy. */
  missing: string[];
  /** In the copy, not part of the engine (a stale file or something added by hand). */
  extra: string[];
}

/** Every file under `dir`, as sorted paths relative to it with "/" separators. */
function listFiles(dir: string, prefix = ''): string[] {
  if (!existsSync(dir)) return [];
  const out: string[] = [];
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const rel = prefix === '' ? entry.name : `${prefix}/${entry.name}`;
    if (entry.isDirectory()) out.push(...listFiles(join(dir, entry.name), rel));
    else out.push(rel);
  }
  return out.sort();
}

export function syncEngine(options: { source: string; target: string; write: boolean }): SyncReport {
  const { source, target, write } = options;
  const wanted = new Map<string, string>();
  for (const rel of listFiles(source)) {
    if (rel.endsWith('.ts')) wanted.set(rel, readFileSync(join(source, rel), 'utf8'));
  }
  if (wanted.size === 0) throw new Error(`no .ts files found in ${source}`);
  wanted.set(MARKER_FILE, MARKER_TEXT);

  const present = new Set(listFiles(target));
  const report: SyncReport = { changed: [], missing: [], extra: [...present].filter((f) => !wanted.has(f)) };
  for (const [rel, text] of wanted) {
    if (!present.has(rel)) report.missing.push(rel);
    else if (readFileSync(join(target, rel), 'utf8') !== text) report.changed.push(rel);
  }

  if (write) {
    for (const rel of report.extra) rmSync(join(target, rel));
    for (const rel of [...report.missing, ...report.changed]) {
      mkdirSync(dirname(join(target, rel)), { recursive: true });
      writeFileSync(join(target, rel), wanted.get(rel)!);
    }
  }
  return report;
}

export const inSync = (r: SyncReport): boolean => r.changed.length + r.missing.length + r.extra.length === 0;

function main(): void {
  const root = fileURLToPath(new URL('../', import.meta.url));
  const check = process.argv.includes('--check');
  const report = syncEngine({
    source: join(root, 'packages/engine/src'),
    target: join(root, 'supabase/functions/_shared/engine'),
    write: !check,
  });
  const lines = [
    ...report.missing.map((f) => `  missing  ${f}`),
    ...report.changed.map((f) => `  changed  ${f}`),
    ...report.extra.map((f) => `  extra    ${f}`),
  ];
  if (inSync(report)) {
    console.log('engine copy is up to date');
  } else if (check) {
    console.error(`engine copy is OUT OF DATE:\n${lines.join('\n')}\nrun: node scripts/sync-engine.ts`);
    process.exitCode = 1;
  } else {
    console.log(`engine copy updated:\n${lines.join('\n')}`);
  }
}

if (process.argv[1] !== undefined && import.meta.url === pathToFileURL(process.argv[1]).href) main();
