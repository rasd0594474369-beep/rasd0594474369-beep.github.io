/* LingoTrace progress layer: the local state (XP, streak, completed lessons, error rotation, preferences) and the lesson flow,
   built on the tested lesson engine (engine.js, generated from packages/engine). No DOM in here. The same file runs in the
   browser (window.LTProgress) and in Node tests (module.exports), so migration and lesson flow are tested without a browser.

   Lessons in progress (v5.1) live under 'lingotrace-active-v1': after EVERY accepted action (start, each typed answer, each peek) the
   seed and everything typed so far is saved, so closing the app mid-lesson and reopening it resumes at the very same word with the
   very same points (the engine is deterministic: replaying the saved log rebuilds the exact state).

   State lives in localStorage under 'lingotrace-progress-v1'. Progress written by v3/v4 ('spelling-v2') is migrated ONCE, the
   first time the new key is missing, and the old key is left untouched until the user resets (a rollback loses nothing).
   Word and lesson ids are the SAME deterministic UUIDs the database uses (packages/content/src/ids.ts), so what runs here is
   what the server will replay. */
(function (root) {
  'use strict';

  var KEY = 'lingotrace-progress-v1';
  var LEGACY_KEY = 'spelling-v2';
  var DRAFT_KEY = 'lingotrace-active-v1'; // lessons in progress: { v:1, drafts: { "<lesson number>": draft } } (format in the README of this file's header)
  var MAX_ATTEMPTS = 400;                 // the server's cap per commit (DEFAULT_MAX_ATTEMPTS in packages/engine/src/server/commit.ts)
  var MAX_DRAFTS = 4;                     // lessons that can wait at the same time (normally one; more only in the unlock-all practice mode)
  var APP_NAMESPACE = '3b1f6a52-8c0e-4d7a-9a41-5f2d6c7e8b90'; // same constant as packages/content/src/ids.ts
  var UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
  var DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

  // ───────── ids: RFC 4122 UUID v5 (SHA-1), synchronous, identical to the server's ─────────
  function sha1(bytes) {
    var h0 = 0x67452301, h1 = 0xefcdab89, h2 = 0x98badcfe, h3 = 0x10325476, h4 = 0xc3d2e1f0;
    var len = bytes.length, total = ((len + 9 + 63) >> 6) << 6;
    var buf = new Uint8Array(total);
    buf.set(bytes); buf[len] = 0x80;
    var view = new DataView(buf.buffer);
    view.setUint32(total - 8, Math.floor(len / 0x20000000));
    view.setUint32(total - 4, (len << 3) >>> 0);
    var w = new Array(80), i;
    for (var off = 0; off < total; off += 64) {
      for (i = 0; i < 16; i++) w[i] = view.getUint32(off + i * 4);
      for (i = 16; i < 80; i++) { var x = w[i - 3] ^ w[i - 8] ^ w[i - 14] ^ w[i - 16]; w[i] = ((x << 1) | (x >>> 31)) >>> 0; }
      var a = h0, b = h1, c = h2, d = h3, e = h4;
      for (i = 0; i < 80; i++) {
        var f, k;
        if (i < 20) { f = (b & c) | (~b & d); k = 0x5a827999; }
        else if (i < 40) { f = b ^ c ^ d; k = 0x6ed9eba1; }
        else if (i < 60) { f = (b & c) | (b & d) | (c & d); k = 0x8f1bbcdc; }
        else { f = b ^ c ^ d; k = 0xca62c1d6; }
        var t = ((((a << 5) | (a >>> 27)) + f + e + k + w[i]) | 0);
        e = d; d = c; c = (b << 30) | (b >>> 2); b = a; a = t;
      }
      h0 = (h0 + a) | 0; h1 = (h1 + b) | 0; h2 = (h2 + c) | 0; h3 = (h3 + d) | 0; h4 = (h4 + e) | 0;
    }
    var out = new Uint8Array(20), ov = new DataView(out.buffer);
    [h0, h1, h2, h3, h4].forEach(function (v, n) { ov.setUint32(n * 4, v >>> 0); });
    return out;
  }
  function hex(bytes) { return Array.prototype.map.call(bytes, function (b) { return (b < 16 ? '0' : '') + b.toString(16); }).join(''); }
  function uuidFromBytes(h) { var s = hex(h); return s.slice(0, 8) + '-' + s.slice(8, 12) + '-' + s.slice(12, 16) + '-' + s.slice(16, 20) + '-' + s.slice(20, 32); }
  function uuidV5(name, ns) {
    var nsHex = (ns || APP_NAMESPACE).replace(/-/g, ''), nsBytes = new Uint8Array(16);
    for (var i = 0; i < 16; i++) nsBytes[i] = parseInt(nsHex.substr(i * 2, 2), 16);
    var nameBytes = new TextEncoder().encode(name), all = new Uint8Array(16 + nameBytes.length);
    all.set(nsBytes); all.set(nameBytes, 16);
    var h = sha1(all).subarray(0, 16);
    h[6] = (h[6] & 0x0f) | 0x50; h[8] = (h[8] & 0x3f) | 0x80;
    return uuidFromBytes(h);
  }
  function randomUuid() {
    var c = root.crypto;
    if (c && typeof c.randomUUID === 'function') return c.randomUUID();
    var b = new Uint8Array(16);
    if (c && c.getRandomValues) c.getRandomValues(b); else for (var i = 0; i < 16; i++) b[i] = Math.floor(Math.random() * 256);
    b[6] = (b[6] & 0x0f) | 0x40; b[8] = (b[8] & 0x3f) | 0x80;
    return uuidFromBytes(b);
  }

  // ───────── small validators (same strictness as the v3 loader) ─────────
  function isInt(v) { return typeof v === 'number' && isFinite(v) && Math.floor(v) === v && v >= 0 && v < 1e9; }
  function isUint32(v) { return typeof v === 'number' && isFinite(v) && Math.floor(v) === v && v >= 0 && v <= 4294967295; }
  function isDate(s) {
    if (typeof s !== 'string' || !DATE_RE.test(s)) return false;
    var d = new Date(Date.UTC(+s.slice(0, 4), +s.slice(5, 7) - 1, +s.slice(8, 10)));
    return d.toISOString().slice(0, 10) === s;
  }
  function isStamp(s) { return typeof s === 'string' && s.length <= 30 && !isNaN(Date.parse(s)); }
  function memoryStorage() { var m = {}; return { getItem: function (k) { return k in m ? m[k] : null; }, setItem: function (k, v) { m[k] = String(v); }, removeItem: function (k) { delete m[k]; } }; }

  function defaults() {
    return {
      v: 1, xp: 0,
      streak: { streakCount: 0, longestStreak: 0, lastActiveDate: null },
      completed: {}, rotation: {},
      prefs: { loc: 'en-US', unlock: false, tr: true },
      lastSessionId: null,
    };
  }

  /* env: { engine (window.LTEngine), lessons: [{ level, number, words: [[text, sentence, meaningAr, sentenceAr], …] }] in lesson order
            (index + 1 is the global lesson number), storage?, now?, timeZone?, newId?, random? } */
  function create(env) {
    var engine = env.engine, lessons = env.lessons, TOTAL = lessons.length;
    var storage = env.storage || memoryStorage();
    var clock = env.now || function () { return new Date(); };
    var timeZone = env.timeZone && engine.isValidTimeZone(env.timeZone) ? env.timeZone : 'UTC';
    var newId = env.newId || randomUuid;
    var random = env.random || Math.random;

    // ── catalog ──
    var byText = new Map(), ids = new Map(), byId = null;
    lessons.forEach(function (l) { l.words.forEach(function (w) { byText.set(w[0].toLowerCase(), { text: w[0], sentence: w[1], meaning: w[2] || null, sentenceAr: w[3] || null }); }); });
    function idOf(text) {
      var k = String(text).trim().toLowerCase(), id = ids.get(k);
      if (!id) { id = uuidV5('word:' + k); ids.set(k, id); }
      return id;
    }
    function entryById(id) {
      if (!byId) { byId = new Map(); byText.forEach(function (e) { byId.set(idOf(e.text), e); }); }
      return byId.get(id) || null;
    }
    function wordItem(entry, weight) {
      return { wordId: idOf(entry.text), wordText: entry.text, sentenceContext: entry.sentence, errorWeight: weight || 0, meaningAr: entry.meaning, sentenceAr: entry.sentenceAr };
    }
    function lessonIdOf(seq) { var l = lessons[seq - 1]; return uuidV5('lesson:' + l.level + ':' + l.number); }

    // ── loading, validation and migration ──
    function cleanStat(wordId, r) {
      if (!UUID_RE.test(wordId) || !r || typeof r !== 'object' || !entryById(wordId)) return null; // unknown word: nothing to build a lesson item from
      if (!isInt(r.errorWeight) || (r.status !== 'active' && r.status !== 'mastered')) return null;
      var active = r.status === 'active', weight = active ? Math.max(1, r.errorWeight) : 0;
      var due = active ? (isInt(r.dueSeq) ? r.dueSeq : 0) : null; // an active word without a due lesson is due now
      return {
        wordId: wordId, errorWeight: weight, status: r.status, dueSeq: due,
        lifetimeFailures: isInt(r.lifetimeFailures) ? r.lifetimeFailures : Math.max(1, weight),
        lastFailedAt: isStamp(r.lastFailedAt) ? r.lastFailedAt : null,
        lastReviewedAt: isStamp(r.lastReviewedAt) ? r.lastReviewedAt : null,
      };
    }
    function cleanCommon(o, s) { // completed lessons + preferences: identical rules for the new and the legacy shape
      if (o.prefs && typeof o.prefs === 'object') { if (o.prefs.loc === 'en-US' || o.prefs.loc === 'en-GB') s.prefs.loc = o.prefs.loc; if (typeof o.prefs.unlock === 'boolean') s.prefs.unlock = o.prefs.unlock; if (typeof o.prefs.tr === 'boolean') s.prefs.tr = o.prefs.tr; }
    }
    function cleanStreak(count, longest, day) {
      var d = isDate(day) ? day : null, c = d && isInt(count) ? count : 0, l = isInt(longest) ? longest : 0;
      return { streakCount: c, longestStreak: Math.max(l, c), lastActiveDate: d };
    }
    function parseCurrent(raw) {
      var o;
      try { o = JSON.parse(raw); } catch (e) { return null; }
      if (!o || typeof o !== 'object' || Array.isArray(o) || o.v !== 1) return null;
      var s = defaults();
      if (isInt(o.xp)) s.xp = o.xp;
      var st = o.streak && typeof o.streak === 'object' ? o.streak : {};
      s.streak = cleanStreak(st.streakCount, st.longestStreak, st.lastActiveDate);
      cleanCommon(o, s);
      if (o.completed && typeof o.completed === 'object') Object.keys(o.completed).forEach(function (k) { if (/^\d{1,3}$/.test(k) && +k >= 1 && +k <= TOTAL && o.completed[k]) s.completed[k] = true; });
      if (o.rotation && typeof o.rotation === 'object') Object.keys(o.rotation).forEach(function (id) { var c = cleanStat(id, o.rotation[id]); if (c) s.rotation[id] = c; });
      if (typeof o.lastSessionId === 'string' && UUID_RE.test(o.lastSessionId)) s.lastSessionId = o.lastSessionId;
      return s;
    }
    function migrateLegacy(raw) { // v3/v4 shape: { xp, streak, best, day, c: {n: 1}, rot: {text: {weight, status, due, last}}, loc, unlock, tr }
      var o;
      try { o = JSON.parse(raw); } catch (e) { return null; }
      if (!o || typeof o !== 'object' || Array.isArray(o)) return null;
      var s = defaults();
      if (isInt(o.xp)) s.xp = o.xp;
      s.streak = cleanStreak(o.streak, o.best, o.day);
      cleanCommon({ prefs: { loc: o.loc, unlock: o.unlock, tr: o.tr } }, s);
      if (o.c && typeof o.c === 'object') Object.keys(o.c).forEach(function (k) { if (/^\d{1,3}$/.test(k) && +k >= 1 && +k <= TOTAL && o.c[k]) s.completed[k] = true; });
      if (o.rot && typeof o.rot === 'object') Object.keys(o.rot).forEach(function (text) {
        var r = o.rot[text];
        if (!/^[A-Za-z' -]{1,40}$/.test(text) || !r || !isInt(r.weight) || (r.status !== 'active' && r.status !== 'mastered') || !(r.due === null || isInt(r.due)) || typeof r.last !== 'string') return;
        var e = byText.get(text.toLowerCase());
        if (!e) return; // a word that is not in the catalog cannot be taught again: drop it
        var last = isStamp(r.last) ? r.last.slice(0, 30) : null;
        var c = cleanStat(idOf(e.text), { errorWeight: r.weight, status: r.status, dueSeq: r.due, lifetimeFailures: Math.max(1, r.weight), lastFailedAt: last, lastReviewedAt: last });
        var prev = s.rotation[c && c.wordId];
        if (c && (!prev || prev.errorWeight < c.errorWeight)) s.rotation[c.wordId] = c; // two spellings of one word: keep the heavier one
      });
      return s;
    }
    var migrated = false;
    function read(k) { try { return storage.getItem(k); } catch (e) { return null; } }
    function save() { try { storage.setItem(KEY, JSON.stringify(state)); return true; } catch (e) { return false; } }
    var state = (function load() {
      var raw = read(KEY), s = raw != null ? parseCurrent(raw) : null;
      if (!s) { var old = read(LEGACY_KEY); if (old != null) { s = migrateLegacy(old); migrated = !!s; } }
      return s || defaults();
    })();
    if (migrated) save(); // write the new key now, so the migration runs exactly once

    // ── lessons ──
    function nextLesson() { for (var g = 1; g <= TOTAL; g++) if (!state.completed[g]) return g; return 0; }
    function canOpen(g) { var n = nextLesson(); return state.prefs.unlock || n === 0 || g <= n; }
    function activeHistory() {
      return Object.keys(state.rotation).map(function (id) { return state.rotation[id]; })
        .filter(function (r) { return r.status === 'active'; })
        .map(function (r) { return { word: wordItem(entryById(r.wordId), r.errorWeight), dueSeq: r.dueSeq, lastFailedAt: r.lastFailedAt }; });
    }
    function lessonWordItems(seq) { return lessons[seq - 1].words.map(function (w) { return wordItem(byText.get(w[0].toLowerCase()), 0); }); }

    // ── lessons in progress (drafts) ──
    // A draft is the session's seed, the rotation words that were mixed in, and every attempt typed so far (the same attempts the server
    // replays at commit time). Nothing derived is stored: the state is rebuilt by replaying them, so it can never disagree with the engine.
    function cleanDraft(k, o) { // strict, like the progress loader: anything unexpected means "no draft", never an exception
      if (!/^\d{1,3}$/.test(k) || !o || typeof o !== 'object') return null;
      var seq = +k, i;
      if (seq < 1 || seq > TOTAL || o.lesson !== seq || o.ev !== engine.ENGINE_VERSION) return null; // a rule change (new engine version) retires old drafts
      if (typeof o.sessionId !== 'string' || !UUID_RE.test(o.sessionId) || (o.mode !== 'first_run' && o.mode !== 'replay')) return null;
      if (!isUint32(o.seed) || !isStamp(o.startedAt) || !isStamp(o.savedAt) || typeof o.peeked !== 'boolean' || typeof o.open !== 'boolean') return null;
      if (!Array.isArray(o.history) || o.history.length > 2 || !Array.isArray(o.attempts) || o.attempts.length > MAX_ATTEMPTS) return null;
      var history = [], attempts = [];
      for (i = 0; i < o.history.length; i++) {
        var h = o.history[i];
        if (!h || typeof h.wordId !== 'string' || !UUID_RE.test(h.wordId) || !entryById(h.wordId) || !isInt(h.errorWeight) || h.errorWeight < 1 || !isInt(h.dueSeq) || !(h.lastFailedAt === null || isStamp(h.lastFailedAt))) return null;
        history.push({ wordId: h.wordId, errorWeight: h.errorWeight, dueSeq: h.dueSeq, lastFailedAt: h.lastFailedAt });
      }
      for (i = 0; i < o.attempts.length; i++) {
        var a = o.attempts[i];
        if (!a || typeof a.itemId !== 'string' || a.itemId.length > 80 || (a.step !== 'word' && a.step !== 'sentence') || typeof a.input !== 'string' || a.input.length > 500 || typeof a.usedPeek !== 'boolean' || !isStamp(a.at)) return null;
        attempts.push({ itemId: a.itemId, step: a.step, input: a.input, usedPeek: a.usedPeek, at: a.at });
      }
      return { ev: o.ev, sessionId: o.sessionId, lesson: seq, mode: o.mode, seed: o.seed, startedAt: o.startedAt, history: history, attempts: attempts, peeked: o.peeked, open: o.open, savedAt: o.savedAt };
    }
    function readDrafts() {
      var raw = read(DRAFT_KEY), o, out = {};
      if (raw == null) return out;
      try { o = JSON.parse(raw); } catch (e) { return out; }
      if (!o || typeof o !== 'object' || o.v !== 1 || !o.drafts || typeof o.drafts !== 'object') return out;
      Object.keys(o.drafts).forEach(function (k) { var d = cleanDraft(k, o.drafts[k]); if (d) out[k] = d; }); // damaged entries are dropped on the next write
      return out;
    }
    function writeDrafts(all) {
      var keys = Object.keys(all);
      while (keys.length > MAX_DRAFTS) { // keep the open lesson and the most recently saved ones
        var victim = keys.filter(function (k) { return !all[k].open; }).sort(function (a, b) { return all[a].savedAt < all[b].savedAt ? -1 : 1; })[0];
        if (!victim) break;
        delete all[victim]; keys = Object.keys(all);
      }
      try { if (keys.length) storage.setItem(DRAFT_KEY, JSON.stringify({ v: 1, drafts: all })); else storage.removeItem(DRAFT_KEY); return true; } catch (e) { return false; /* the app keeps working in memory */ }
    }
    function persist(sess, open) { // read-modify-write, so another tab's draft for another lesson is never clobbered
      if (sess.committed) return;
      var all = readDrafts(), want = open !== undefined ? open : sess.open !== false;
      if (want) Object.keys(all).forEach(function (k) { all[k].open = false; }); // exactly one lesson is "open" (the one on screen)
      all[sess.lesson] = {
        ev: engine.ENGINE_VERSION, sessionId: sess.sessionId, lesson: sess.lesson, mode: sess.mode, seed: sess.seed, startedAt: sess.startedAt,
        history: sess.injected || [],
        attempts: sess.es.log.map(function (a) { return { itemId: a.itemId, step: a.step, input: a.input, usedPeek: a.usedPeek, at: a.at }; }),
        peeked: !!sess.es.peeked, open: want, savedAt: clock().toISOString(),
      };
      sess.open = want;
      writeDrafts(all);
    }
    function dropDraft(seq, sessionId) {
      var all = readDrafts();
      if (!all[seq] || (sessionId && all[seq].sessionId !== sessionId)) return;
      delete all[seq]; writeDrafts(all);
    }
    function usable(d) { // is a saved lesson still consistent with the local state?
      if (d.sessionId === state.lastSessionId) return false; // that session already finished and was recorded
      if (d.mode === 'first_run') return !state.completed[d.lesson] && canOpen(d.lesson);
      return !!state.completed[d.lesson]; // a replay only exists for a completed lesson
    }
    function rebuild(d) { // replay the saved attempts through the engine exactly like the server's replaySession, but stop where the learner stopped
      try {
        var hist = d.history.map(function (h) { return { word: wordItem(entryById(h.wordId), h.errorWeight), dueSeq: h.dueSeq, lastFailedAt: h.lastFailedAt }; });
        var begun = engine.beginSession({ sessionId: d.sessionId, lessonSeq: d.lesson, mode: d.mode, seed: d.seed, lessonWords: lessonWordItems(d.lesson), history: hist });
        var es = begun.state, rng = begun.rng, trail = [];
        for (var i = 0; i < d.attempts.length; i++) {
          var a = d.attempts[i], p = engine.currentPrompt(es);
          if (!p || p.itemId !== a.itemId || p.step !== a.step) return null; // the saved log does not fit the lesson any more
          var wordText = es.queue[0].word.wordText;
          if (a.usedPeek) es = engine.peek(es);
          var r = engine.submit(es, a.input, { now: new Date(a.at), rng: rng });
          es = r.state;
          if (r.event.kind !== 'retype') trail.push({ text: p.text, step: p.step, wordText: wordText }); // what the back arrow can review
        }
        if (d.peeked) es = engine.peek(es); // the answer was on screen when the app closed: it still counts as a peek
        return { es: es, rng: rng, seed: d.seed, lesson: d.lesson, mode: d.mode, sessionId: d.sessionId, parentSessionId: state.lastSessionId, startedAt: d.startedAt, completedAt: null, committed: false, injected: d.history, trail: trail, open: true, resumed: true };
      } catch (e) { return null; }
    }
    function resume(seq) { // the saved session of a lesson, rebuilt, or null (and the stale draft is removed: never stuck)
      if (!isInt(seq) || seq < 1 || seq > TOTAL) return null;
      var d = readDrafts()[seq];
      if (!d) return null;
      var sess = usable(d) ? rebuild(d) : null;
      if (!sess) { dropDraft(seq); return null; }
      persist(sess, true);
      return sess;
    }
    function resumeOpen() { // the app was closed while a lesson was on screen: reopen exactly there
      var all = readDrafts(), ks = Object.keys(all).filter(function (k) { return all[k].open; }).sort(function (a, b) { return all[a].savedAt < all[b].savedAt ? 1 : -1; });
      for (var i = 0; i < ks.length; i++) { var s = resume(+ks[i]); if (s) return s; }
      return null;
    }
    function hasDraft(seq) { var d = readDrafts()[seq]; return !!d && usable(d) && (d.attempts.length > 0 || d.peeked); } // something worth resuming
    function leave(sess) { // the learner left the lesson screen on purpose
      if (!sess || sess.committed) return;
      if (finished(sess)) { finish(sess); return; } // the last answer was already accepted: do not lose the lesson
      if (sess.mode === 'replay' || (!sess.es.log.length && !sess.es.peeked)) { sess.open = false; dropDraft(sess.lesson, sess.sessionId); } // practice runs and untouched lessons are not kept
      else persist(sess, false); // a first run keeps its points: it waits on the map («تابع») until it is finished or restarted
    }
    function discard(seq) { dropDraft(seq); }

    function start(seq, opts) {
      if (!isInt(seq) || seq < 1 || seq > TOTAL) throw new RangeError('no such lesson: ' + seq);
      opts = opts || {};
      var mode = state.completed[seq] ? 'replay' : 'first_run';
      var seed = opts.seed != null ? opts.seed : Math.floor(random() * 4294967296) >>> 0, sessionId = opts.sessionId || newId();
      var hist = mode === 'replay' ? [] : activeHistory(); // replays never inject (the engine enforces it too)
      var begun = engine.beginSession({ sessionId: sessionId, lessonSeq: seq, mode: mode, seed: seed, lessonWords: lessonWordItems(seq), history: hist });
      var used = begun.state.queue.filter(function (q) { return q.source === 'injected'; }).map(function (q) { return q.word.wordId; });
      var injected = hist.filter(function (h) { return used.indexOf(h.word.wordId) >= 0; }).map(function (h) { return { wordId: h.word.wordId, errorWeight: h.word.errorWeight, dueSeq: h.dueSeq, lastFailedAt: h.lastFailedAt }; });
      var sess = { es: begun.state, rng: begun.rng, seed: seed, lesson: seq, mode: mode, sessionId: sessionId, parentSessionId: state.lastSessionId, startedAt: clock().toISOString(), completedAt: null, committed: false, injected: injected, trail: [], open: true, resumed: false };
      persist(sess, true);
      return sess;
    }
    function cur(sess) {
      var item = sess.es.queue[0], step = item.steps[sess.es.stepIndex];
      return { item: item, word: item.word, step: step, text: step === 'word' ? item.word.wordText : item.word.sentenceContext, rev: item.isReview, src: item.source };
    }
    function submit(sess, input) { // result shape of the v3 prototype, so the screens did not have to change
      var r = engine.submit(sess.es, input, { now: clock(), rng: sess.rng }), e = r.event;
      sess.es = r.state;
      persist(sess); // saved the moment the answer is accepted, before any animation: closing the app now loses nothing
      if (e.kind === 'correct') return { k: 'ok', xp: e.xp };
      if (e.kind === 'retype') return { k: 'retype', why: 'minor' };
      if (e.kind === 'sentence_missed') return { k: 'miss', reveal: e.reveal };
      return { k: 'fail', reveal: e.reveal, after: e.requeueAfter };
    }
    function peek(sess) { var was = sess.es.peeked; sess.es = engine.peek(sess.es); if (!was && sess.es.peeked) persist(sess); } // the peek is saved too: closing and reopening must not undo it
    function finished(sess) { return sess.es.phase === 'completed'; }
    function finish(sess) { // applies a completed session to the local state exactly once
      if (sess.committed) return sess.committed;
      var summary = engine.summarize(sess.es), now = clock();
      sess.parentSessionId = state.lastSessionId; // the chain follows the order lessons FINISH (a resumed lesson may have started long before)
      if (summary.mode === 'first_run') {
        state.xp += summary.xp.total;
        engine.applySummaryToStats(summary, Object.keys(state.rotation).map(function (id) { return state.rotation[id]; }), now).forEach(function (u) { state.rotation[u.wordId] = u; });
        state.completed[sess.lesson] = true;
      }
      state.streak = engine.applyLessonCompletion(state.streak, now, timeZone); // replays count as activity; only XP is withheld
      state.lastSessionId = sess.sessionId;
      sess.completedAt = now.toISOString();
      save();
      sess.committed = true;
      dropDraft(sess.lesson, sess.sessionId); // nothing left to resume
      return summary;
    }
    function commitOf(sess) { // the request the server will replay (v6 sends it; tests replay it against the server engine)
      return engine.toSessionCommit(sess.es, { lessonId: lessonIdOf(sess.lesson), parentSessionId: sess.parentSessionId, seed: sess.seed, timeZone: timeZone, startedAt: sess.startedAt, completedAt: sess.completedAt || clock().toISOString() });
    }
    function rotation() {
      return Object.keys(state.rotation).map(function (id) { return state.rotation[id]; }).filter(function (r) { return r.status === 'active'; })
        .map(function (r) { var e = entryById(r.wordId); return { wordId: r.wordId, text: e ? e.text : r.wordId, weight: r.errorWeight, due: r.dueSeq }; })
        .sort(function (a, b) { return b.weight - a.weight || a.due - b.due || (a.text < b.text ? -1 : 1); });
    }
    function setPref(name, value) {
      if ((name === 'loc' && (value === 'en-US' || value === 'en-GB')) || ((name === 'unlock' || name === 'tr') && typeof value === 'boolean')) { state.prefs[name] = value; save(); return true; }
      return false;
    }
    function reset() { // wipes everything, the old v3 key included, so nothing can come back by migration
      Object.keys(state).forEach(function (k) { delete state[k]; });
      Object.assign(state, defaults());
      try { storage.removeItem(LEGACY_KEY); storage.removeItem(DRAFT_KEY); } catch (e) { /* ignore */ }
      save();
    }

    return {
      state: state, total: TOTAL, migrated: migrated,
      nextLesson: nextLesson, canOpen: canOpen, isDone: function (g) { return !!state.completed[g]; },
      start: start, cur: cur, submit: submit, peek: peek, finished: finished, finish: finish, commitOf: commitOf,
      resume: resume, resumeOpen: resumeOpen, hasDraft: hasDraft, leave: leave, discard: discard,
      progress: function (sess) { return engine.sessionProgress(sess.es); },
      summary: function (sess) { return engine.summarize(sess.es); },
      streak: function () { return engine.effectiveStreak(state.streak, clock(), timeZone); },
      rotation: rotation, textOf: function (id) { var e = entryById(id); return e ? e.text : id; },
      wordId: idOf, lessonId: lessonIdOf, save: save, setPref: setPref, reset: reset,
    };
  }

  var api = { create: create, uuidV5: uuidV5, KEY: KEY, LEGACY_KEY: LEGACY_KEY, DRAFT_KEY: DRAFT_KEY, APP_NAMESPACE: APP_NAMESPACE };
  if (typeof window !== 'undefined' && window.document) root.LTProgress = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
