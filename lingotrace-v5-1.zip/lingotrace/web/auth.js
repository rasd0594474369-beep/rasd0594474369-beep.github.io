/* LingoTrace sign-in with Google through Supabase Auth (implicit flow: the tokens come back in the URL fragment).
   Plain script with no dependencies. The same file runs in the browser (window.Auth) and in Node tests
   (module.exports.createAuth), so the whole flow is tested without a browser. The key below is the PUBLIC
   publishable key: it is meant to ship inside the app, the database rules (RLS) protect the data. */
(function (root) {
  'use strict';
  var CONFIG = { url: 'https://yvszergcvjnzpogubqex.supabase.co', key: 'sb_publishable_c44u4I6YkwEFiGmM2xBRPQ_FPOYdjPq' };
  var STORE_KEY = 'lingotrace-auth-v1';
  var REFRESH_MARGIN = 60; // refresh the access token when fewer than 60 seconds are left

  function createAuth(env) {
    var url = env.url, key = env.key, doFetch = env.fetch, storage = env.storage, loc = env.location, hist = env.history;
    var nowSec = env.now || function () { return Math.floor(Date.now() / 1000); };
    var api = { onChange: null };
    var error = null, refreshing = null;

    function load() {
      try {
        var o = JSON.parse(storage.getItem(STORE_KEY) || 'null');
        if (o && typeof o.access_token === 'string' && typeof o.refresh_token === 'string' && isFinite(o.expires_at)) return o;
      } catch (e) { /* damaged storage: treat as signed out */ }
      return null;
    }
    var session = load();
    var status = session ? 'in' : 'out'; // a stored session is shown at once (cached user) and verified in the background

    function save() {
      try { if (session) storage.setItem(STORE_KEY, JSON.stringify(session)); else storage.removeItem(STORE_KEY); } catch (e) { /* storage full or blocked */ }
    }
    function emit(type) { try { if (typeof api.onChange === 'function') api.onChange({ type: type }); } catch (e) { /* the UI must never break auth */ } }
    function cleanUrl() { try { hist.replaceState(null, '', loc.pathname + loc.search); } catch (e) { /* ignore */ } }
    function headers(token) { return { apikey: key, Authorization: 'Bearer ' + token }; }
    function mapUser(u) {
      var m = (u && u.user_metadata) || {}, email = (u && u.email) || '';
      return { id: u && u.id, email: email, name: m.full_name || m.name || email.split('@')[0] || '', avatar: m.avatar_url || m.picture || null };
    }
    function dropSession(message) { session = null; status = 'out'; error = message || null; save(); emit('signout'); }

    // One refresh at a time: refresh tokens rotate, so two parallel refreshes would invalidate each other.
    function refresh() {
      if (refreshing) return refreshing;
      if (!session) return Promise.resolve(false);
      var rt = session.refresh_token;
      refreshing = doFetch(url + '/auth/v1/token?grant_type=refresh_token', {
        method: 'POST', headers: { apikey: key, 'Content-Type': 'application/json' }, body: JSON.stringify({ refresh_token: rt })
      }).then(function (r) {
        if (r.status === 400 || r.status === 401 || r.status === 403) { dropSession('انتهت جلسة الدخول، سجّل الدخول من جديد.'); return false; }
        if (!r.ok) return false; // 429 / 5xx: keep the session and try again later
        return r.json().then(function (j) {
          if (!j || !j.access_token) return false;
          session = { access_token: j.access_token, refresh_token: j.refresh_token || rt, expires_at: isFinite(j.expires_at) ? j.expires_at : nowSec() + (Number(j.expires_in) || 3600), user: session && session.user || null };
          save();
          return true;
        });
      }).catch(function () { return false; /* offline: keep the session */ }).then(function (ok) { refreshing = null; return ok; });
      return refreshing;
    }

    function loadUser(retried) {
      return doFetch(url + '/auth/v1/user', { headers: headers(session.access_token) }).then(function (r) {
        if (r.status === 401 || r.status === 403) {
          if (retried) { dropSession('تعذّر التحقق من الحساب، سجّل الدخول من جديد.'); return false; }
          return refresh().then(function (ok) { return ok && session ? loadUser(true) : false; });
        }
        if (!r.ok) return false;
        return r.json().then(function (u) { session.user = mapUser(u); save(); return true; });
      }).catch(function () { return false; /* offline: the cached user stays */ });
    }

    // Call once at startup: handles the return from Google, restores a stored session, refreshes it when it is old.
    function init() {
      var h = new URLSearchParams(String(loc.hash || '').replace(/^#/, ''));
      var fresh = false;
      if (h.get('error') || h.get('error_description')) {
        error = h.get('error_description') || h.get('error');
        cleanUrl();
        emit('error');
      } else if (h.get('access_token') && h.get('refresh_token')) {
        session = { access_token: h.get('access_token'), refresh_token: h.get('refresh_token'), expires_at: Number(h.get('expires_at')) || nowSec() + (Number(h.get('expires_in')) || 3600), user: null };
        error = null; fresh = true; status = 'loading';
        save(); cleanUrl();
      }
      if (!session) { status = 'out'; return Promise.resolve(); }
      var first = session.expires_at - nowSec() < REFRESH_MARGIN ? refresh() : Promise.resolve(true);
      return first.then(function () {
        if (!session) return null;
        return loadUser(false);
      }).then(function () {
        if (!session) return;
        status = 'in';
        emit(fresh ? 'signin' : 'update');
      });
    }

    function login() {
      loc.href = url + '/auth/v1/authorize?provider=google&redirect_to=' + encodeURIComponent(loc.origin + loc.pathname);
    }

    function logout() {
      var token = session && session.access_token;
      session = null; error = null; status = 'out'; save(); emit('signout');
      if (!token) return Promise.resolve();
      // scope=local signs out this device only, not the user's other devices
      return doFetch(url + '/auth/v1/logout?scope=local', { method: 'POST', headers: headers(token) }).catch(function () { /* offline: already signed out here */ }).then(function () {});
    }

    // For API calls: a token that is valid for at least a minute (refreshes when needed), or null when signed out.
    function getAccessToken() {
      if (!session) return Promise.resolve(null);
      if (session.expires_at - nowSec() >= REFRESH_MARGIN) return Promise.resolve(session.access_token);
      return refresh().then(function () { return session ? session.access_token : null; });
    }

    api.init = init; api.login = login; api.logout = logout; api.getAccessToken = getAccessToken;
    api.state = function () { return { status: status, user: (session && session.user) || null, error: error }; };
    api.clearError = function () { error = null; };
    return api;
  }

  if (typeof window !== 'undefined' && window.document) {
    var storage;
    try { storage = window.localStorage; storage.getItem(STORE_KEY); } catch (e) { storage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }
    root.Auth = createAuth({ url: CONFIG.url, key: CONFIG.key, fetch: window.fetch.bind(window), storage: storage, location: window.location, history: window.history });
  }
  if (typeof module !== 'undefined' && module.exports) module.exports = { createAuth: createAuth, CONFIG: CONFIG, STORE_KEY: STORE_KEY };
})(typeof window !== 'undefined' ? window : globalThis);
